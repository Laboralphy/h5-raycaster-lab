/** Classe de déplacement automatisé et stupidité artificielle des mobiles
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet 
 * Classe de base pouvant être étendue
 */
O2.createClass('O876_Raycaster.Thinker', {
	oMobile: null,
	oGame: null,
	think: function() {}
});

