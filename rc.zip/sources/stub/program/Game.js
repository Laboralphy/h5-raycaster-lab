O2.extendClass('STUB.Game', O876_Raycaster.GameAbstract, {
});
