<?php
define('PROJECT_PATH', dirname(__FILE__));
require_once PROJECT_PATH . '/../../dynamics/packer/cjs.inc.php';
cjs();
