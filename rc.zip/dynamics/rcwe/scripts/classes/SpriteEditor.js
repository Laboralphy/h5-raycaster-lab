O2.extendClass('RCWE.SpriteEditor', RCWE.Window, {

	build: function() {
		__inherited('Sprite editor');
		
	}
});
