<?php
print json_encode($this->list);
