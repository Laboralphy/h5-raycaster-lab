<?php
print 1;
