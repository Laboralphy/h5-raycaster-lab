<?php namespace O876\Symbol\Plugin;

use O876\Symbol\Symbol as Symbol;

interface Intf {
	public function run(Symbol $oSymbol, array $aArguments);
}
