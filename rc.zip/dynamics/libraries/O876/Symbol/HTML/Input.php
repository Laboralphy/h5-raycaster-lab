<?php


namespace O876\Symbol\HTML;

/**
 * @brief Input
 * 
 * @author Ralphy
 * @version 100
 *          @date 2010-09-23
 */
use O876\Symbol\symbol as Symbol;

class Input extends Symbol {
	public function __construct() {
		parent::__construct ( 'input' );
	}
}