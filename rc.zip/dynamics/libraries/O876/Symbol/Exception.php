<?php namespace O876\Symbol;
class Exception extends \Exception {
	
}
