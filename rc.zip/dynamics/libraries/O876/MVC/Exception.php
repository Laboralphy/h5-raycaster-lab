<?php namespace O876\MVC;

/**
 * Juste une exception perso MVC
 * @author raphael.marandet
 *
 */
class Exception extends \Exception {
  
}