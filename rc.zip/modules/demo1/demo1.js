/** O2: Fonctionalités Orientées Objets pour Javascript
 * 2010 Raphaël Marandet
 * ver 1.0 10.10.2010
 * ver 1.1 28.04.2013 : ajout d'un support namespace  
 */

var O2 = {};

/** Remplace dans une chaine "inherited(" par "inherited(this"
 * @param s Chaine à remplacer
 * @return nouvelle chaine remplacée
 */
function __inheritedThisMacroString(s) {
	return s.toString().replace(/__inherited\s*\(/mg,
			'__inheritedCaller(this, ').replace(
			/__inheritedCaller\s*\(\s*this,\s*\)/mg, '__inheritedCaller(this)');
}

/** Invoque la methode parente
 * @param This appelant, + Paramètres normaux de la methode parente.
 * @return Retour normal de la methode parente.
 */
function __inheritedCaller() {
	var fCaller = __inheritedCaller.caller;
	var oThis = arguments[0];
	var aParams;
	if ('__inherited' in fCaller) {
		aParams = Array.prototype.slice.call(arguments, 1);
		//for (iParam = 1; iParam < arguments.length; iParam++) {
		//	aParams.push(arguments[iParam]);
		//}
		return fCaller.__inherited.apply(oThis, aParams);
	} else {
		throw new Error('o2: no __inherited');
	}
}

/** Creation d'une nouvelle classe
 * @example NouvelleClasse = Function.createClass(function(param1) { this.data = param1; });
 * @param fConstructor prototype du constructeur
 * @return Function
 */
Function.prototype.createClass = function(pPrototype) {
	var f;
	f = function() {
		if ('__construct' in this) {
			this.__construct.apply(this, arguments);
		}
	};
	if (pPrototype === undefined) {
		return f;
	} else if (typeof pPrototype === 'object') {
		return f.extendPrototype(pPrototype);
	} else {
		return null;
	}
};

/** Mécanisme d'extention de classe.
 * Cette fonction accepte un ou deux paramètres
 * Appel avec 1 paramètre :
 * @param Définition de prototype à ajouter à la classe.
 * Appel avec 2 paramètres :
 * @param Classe parente
 * @param Définition de prototype à ajouter à la classe.
 * @return Instance de lui-même.
 */
Function.prototype.extendPrototype = function(aDefinition) {
	var iProp = '', f, fInherited;
	if (aDefinition instanceof Function) {
		aDefinition = aDefinition.prototype;
	}
	for (iProp in aDefinition) {
		f = aDefinition[iProp];
		if (iProp in this.prototype	&& (this.prototype[iProp] instanceof Function)) {
			// Sauvegarde de la méthode en cours : elle pourrait être héritée
			fInherited = this.prototype[iProp];
			// La méthode en cour est déja présente dans la super classe
			if (f instanceof Function) {
				// completion des __inherited
				eval('f = ' + __inheritedThisMacroString(f.toString()));
				this.prototype[iProp] = f;
				this.prototype[iProp].__inherited = fInherited;
			} else {
				// On écrase probablement une methode par une propriété : Erreur
				throw new Error(
						'o2: method ' + iProp + ' overridden by property.');
			}
		} else {
			// Ecrasement de la propriété
			this.prototype[iProp] = aDefinition[iProp];
		}
	}
	return this;
};

/** Mécanisme d'extension de classe
 * @param Parent Nom de la classe Parente
 * @param X prototype du constructeur (optionnel)
 * @param Y prototype de la classe étendue
 */
Function.prototype.extendClass = function(Parent, X) {
	var f = this.createClass().extendPrototype(Parent).extendPrototype(X);
	return f;
};

/**
 * Creation d'un objet
 * Le nom de l'objet peut contenir des "." dans ce cas de multiple objets sont créés
 * ex: O2.createObject("MonNamespace.MaBibliotheque.MaClasse", {...});
 * var créer un objet global "MonNamespace" contenant un objet "MaBibliotheque" contenant lui même l'objet "MaClasse"
 * ce dernier objet recois la définition du second paramètre.
 *  
 * 
 * @param sName nom de l'objet
 * @param oObject objet
 * @param object
 */
O2.createObject = function(sName, oObject) {
	var aName = sName.split('.');
	var sClass = aName.pop();
	var pIndex = window;
	var sNamespace;
	while (aName.length) {
		sNamespace = aName.shift();
		if (!(sNamespace in pIndex)) {
			pIndex[sNamespace] = {};
		}
		pIndex = pIndex[sNamespace];
	}
	if (!(sClass in pIndex)) {
		pIndex[sClass] = oObject;
	} else {
		for ( var sProp in oObject) {
			pIndex[sClass][sProp] = oObject[sProp];
		}
	}
};

/** 
 * Charger une classe à partir de son nom - le nom suit la syntaxe de la fonction O2.createObject() concernant les namespaces. 
 * @param s string, nom de la classe
 * @return pointer vers la Classe
 */
O2._loadObject = function(s) {
	var aClass = s.split('.');
	var pBase = window;
	while (aClass.length > 1) {
		pBase = pBase[aClass.shift()];
	}
	var sClass = aClass[0];
	return pBase[sClass];
};

/** Creation d'une classe avec support namespace
 * le nom de la classe suit la syntaxe de la fonction O2.createObject() concernant les namespaces.
 * @param sName string, nom de la classe
 * @param pPrototype définition de la nouvelle classe
 */
O2.createClass = function(sName, pPrototype) {
	O2.createObject(sName, Function.createClass(pPrototype));
};

/** Extend d'un classe
 * le nom de la nouvelle classe suit la syntaxe de la fonction O2.createObject() concernant les namespaces.
 * @param sName string, nom de la nouvelle classe
 * @param pParent string|object Classe parente
 * @param pPrototype Définition de la classe fille  
 */
O2.extendClass = function(sName, pParent, pPrototype) {
	if (typeof pParent === 'string') {
		pParent = O2._loadObject(pParent);
	}
	O2.createObject(sName, Function.extendClass(pParent, pPrototype));
};

/**
 * Cette boite à outil permet d'ajouter des fonctionnalités spéciales
 * à des prototypes
 * @author raphael.marandet
 */

var ClassMagic = {};

/**
 * Créé un gestionnaire d'evenement dans la classe spécifiée
 * La classe se voie dotée de trois fonction
 * on(event, callback) permet de définir un call back pour un event donné
 * off([event, [callback]) permet de supprimer callback pour l'event donné
 * peut aussi supprimer tous les callback, voire tout les callback de tous les event
 * trigger(event, data) permet de déclencher l'evenement avec les données données
 * @param function ProtoClass
 */
ClassMagic.castEventHandler = function(ProtoClass) {
	var WEHName = '_WeirdEventHandlers';
	ProtoClass.prototype[WEHName] = null;
	ProtoClass.prototype.on = function(sEvent, pCallback) {
		if (this[WEHName] === null) {
			this[WEHName] = {};
		}
		var weh = this[WEHName];
		if (!(sEvent in weh)) {
			weh[sEvent] = [];
		}
		weh[sEvent].push(pCallback);
	};
	ProtoClass.prototype.off = function(sEvent, pCallback) {
		if (this[WEHName] === null) {
			throw new Error('no event "' + sEvent + '" defined');
		}
		if (sEvent === undefined) {
			this[WEHName] = {};
		} else if (!(sEvent in this[WEHName])) {
			throw new Error('no event "' + sEvent + '" defined');
		}
		var weh = this[WEHName];
		var wehe, n;
		if (pCallback !== undefined) {
			wehe = weh[sEvent];
			n = wehe.indexOf(pCallback);
			if (n < 0) {
				throw new Error('this handler is not defined for event "' + sEvent + '"');
			} else {
				wehe.splice(n, 1);
			}
		} else {
			weh[sEvent] = [];
		}
	};
	ProtoClass.prototype.trigger = function(sEvent) {
		if (this[WEHName] === null) {
			return;
		}
		var weh = this[WEHName];
		if (!(sEvent in weh)) {
			return;
		}
		var aArgs = Array.prototype.slice.call(arguments, 1);
		weh[sEvent].forEach(function(pCallback) {
			pCallback.apply(this, aArgs);
		}, this);
	};
	return ProtoClass;
};


/**
 * Créé un gestionnaire de Data
 * La classe se voie dotée de deux fonctions
 * setData et getData
 */
ClassMagic.castDataManager = function(ProtoClass) {
	var DCName = '_DataContainer';
	ProtoClass.prototype[DCName] = null;
	ProtoClass.prototype.setData = function(s, v) {
		if (this[DCName] === null) {
			this[DCName] = {};
		}
		if (typeof s === 'object') {
			for (var x in s) {
				this.setData(x, s[x]);
			}
		} else {
			this[DCName][s] = v;
		}
	};
	ProtoClass.prototype.getData = function(s) {
		if (this[DCName] === null) {
			return null;
		} else {
			var D = this[DCName];
			if (s === undefined) {
				return D;
			} else {
				if (s in D) {
					return D[s];
				} else {
					return null;
				}
			}
		}
	};
};

/**
 * Class of multiple channels audio management
 * deals with sound effects and background music
 * deals with crossfading background musics
 */
 
/* globals O2 */

O2.createClass('SoundSystem', {
	CHAN_MUSIC : 99,

	HAVE_NOTHING: 0,		// on n'a aucune information sur l'état du fichier audio ; mieux vaut ne pas lancer la lecture.
	HAVE_METADATA: 1,		// on a les méta données.
	HAVE_CURRENT_DATA: 2,	// on a assez de données pour jouer cette frames seulement.
	HAVE_FUTURE_DATA: 3,	// on a assez de données pour jouer les deux prochaines frames. 
	HAVE_ENOUGH_DATA: 4,	// on a assez de données.
	
	oBase : null,
	aChans : null,
	oMusicChan : null,
	nChanIndex : -1,

	nPlayed : 0,
	
	fMuteVolume: 0,
	bMute: false,
	bAllUsed: false,
	
	sCrossFadeTo: '',
	bCrossFading: false,

	sSndPlayedFile: '',
	fSndPlayedVolume: 0,
	nSndPlayedTime: 0,
	
	oInterval: null,

	__construct : function() {
		this.oBase = document.body;
		this.aChans = [];
		this.aAmbient = [];
		this.oMusicChan = this.createChan();
		this.oMusicChan.loop = true;
		this.aChans = [];
	},
	
	/**
	 * returns true if the specified audio file is worth playing.
	 * will return false if an audio file with the same name, volume
	 * has already been played recently (same timestamp)
	 * @param nTime current timestamp (given by Date.now() for example)
	 * @param sFile audio file name
	 * @param fVolume
	 */
	worthPlaying: function(nTime, sFile, fVolume) {
		if (this.nSndPlayedTime != nTime || this.sSndPlayedFile != sFile || this.fSndPlayedVolume != fVolume) {
			this.sSndPlayedFile = sFile;
			this.fSndPlayedVolume = fVolume;
			this.nSndPlayedTime = nTime;
			return true;
		} else {
			return false;
		}
	},
	
	/**
	 * Stops sounds from being played
	 * call unmute to restore normal audio function
	 */
	mute: function() {
		if (!this.bMute) {
			this.oMusicChan.pause();
			this.bMute = true;
		}
	},

	/**
	 * Restores normal audio function
	 * useful to restore sound after a mute() call
	 */
	unmute: function() {
		if (this.bMute) {
			this.oMusicChan.play();
			this.bMute = false;
		}
	},

	
	free : function() {
		for ( var i = 0; i < this.aChans.length; i++) {
			this.aChans[i].remove();
		}
		this.oMusicChan.remove();
		this.aChans = [];
	},
	
	createChan: function() {
		var oChan = document.createElement('audio');
		this.oBase.appendChild(oChan);
		return oChan;
	},

	addChan : function() {
		var oChan = this.createChan();
		oChan.setAttribute('preload', 'auto');
		oChan.setAttribute('autoplay', 'autoplay');
		oChan.__file = '';
		this.aChans.push(oChan);
		this.bAllUsed = false;
		return oChan;
	},

	addChans : function(n) {
		for (var i = 0; i < n; i++) {
			this.addChan();
		}
	},

	isChanPlaying : function(nChan, sFile) {
		if (nChan == this.CHAN_MUSIC) {
			return !this.oMusicChan.ended;
		}
		if (nChan < 0) {
			nChan = 0;
		}
		if (nChan >= this.aChans.length) {
			nChan = this.aChans.length - 1;
		}
		var oChan = this.aChans[nChan];
		if (sFile === undefined) {
			return !oChan.ended;
		} else {
			return !(oChan.ended && ((sFile == oChan.__file) || (oChan.__file !== '')));
		}
	},

	isChanFree : function(nChan, sFile) {
		// case : music channel
		if (nChan == this.CHAN_MUSIC) {
			return this.oMusicChan.ended;
		}
		// check specified channel number validity
		nChan = Math.max(0, Math.min(this.aChans.length - 1, nChan));
		var oChan = this.aChans[nChan];
		if (sFile === undefined) {
			return oChan.ended;
		} else {
			var bEmpty = oChan.__file === '';
			var bNotPlaying = oChan.ended;
			var bAlreadyLoaded = sFile == oChan.__file;
			return bEmpty || (bNotPlaying && bAlreadyLoaded);
		}
	},

	getFreeChan : function(sFile) {
		if (!this.hasChan()) {
			return -1;
		}
		var iChan, nChanCount;
		for (iChan = 0, nChanCount = this.aChans.length; iChan < nChanCount; ++iChan) {
			if (this.isChanFree(iChan, sFile)) {
				return iChan;
			}
		}
		for (iChan = 0, nChanCount = this.aChans.length; iChan < nChanCount; ++iChan) {
			if (this.isChanFree(iChan)) {
				return iChan;
			}
		}
		this.nChanIndex = (this.nChanIndex + 1) % this.aChans.length;
		return this.nChanIndex;
	},

	hasChan : function() {
		return this.aChans.length > 0;
	},

	play : function(sFile, nChan, fVolume) {
		var oChan = null;
		// check if we should cancel the play call
		if (this.bMute || sFile === undefined) {
			return -1;
		}
		// case : music channel -> redirect to playMusic
		if (nChan == this.CHAN_MUSIC) {
			this.playMusic(sFile);
			return nChan;
		} else if (this.hasChan()) { 
			// checks channel availability
			if (nChan === undefined) {
				// get a free channel, if none specified
				nChan = this.getFreeChan(sFile);
			}
			oChan = this.aChans[nChan];
		} else {
			// no free channel available
			oChan = null;
			return -1;
		}
		if (oChan !== null) {
			// we got a channel
			if (oChan.__file != sFile) {
				// new file
				oChan.src = sFile;
				oChan.__file = sFile;
				oChan.load();
			} else if (oChan.readyState > this.HAVE_NOTHING) {
				// same file, play again from start
				oChan.currentTime = 0;
				oChan.play();
			}
		} else {
			// could not get a channel:
			// exit in shame
			return -1;
		}
		// set volume, if specified
		if (fVolume !== undefined) {
			oChan.volume = fVolume;
		}
		return nChan;
	},

	/**
	 * Joue le prochain fichier musical dans la liste
	 */
	playMusic : function(sFile, bOverride) {
		var oChan = this.oMusicChan;
		oChan.src = sFile;
		oChan.load();
		oChan.play();
	},

	/**
	 * Diminue graduellement le volume sonore du canal musical
	 * puis change le fichier sonore
	 * puis remonte graduellement le volume
	 * le programme d'ambience est reseté par cette manip
	 */
	crossFadeMusic: function(sFile) {
		if (this.bCrossFading) {
			this.sCrossFadeTo = sFile;
			return;
		}
		var iVolume = 100;
		var nVolumeDelta = -10;
		this.bCrossFading = true;
		if (this.oInterval) {
			window.clearInterval(this.oInterval);
		}
		this.oInterval = window.setInterval((function() {
			iVolume += nVolumeDelta;
			this.oMusicChan.volume = iVolume / 100;
			if (iVolume <= 0) {
				this.playMusic(sFile);
				this.oMusicChan.volume = 1;
				window.clearInterval(this.oInterval);
				this.oInterval = null;
				this.bCrossFading = false;
				if (this.sCrossFadeTo) {
					this.crossFadeMusic(this.sCrossFadeTo);
					this.sCrossFadeTo = '';
				}
			}
		}).bind(this), 100);
	}
});

O2.createClass('H5UI.Font', {
	_sStyle: '',
	_sFont : 'monospace',
	_nFontSize : 10,
	_sColor : 'rgb(255, 255, 255)',
	_oControl : null,
	_sOutlineColor: 'rgb(0, 0, 0)',
	_bOutline: false,

	__construct : function(oControl) {
		if (oControl === undefined) {
			throw new Error('h5ui.font: no specified control');
		}
		this.setControl(oControl);
	},

	/**
	 * Défini le controle propriétaire
	 * 
	 * @param oControl
	 *            nouveau control propriétaire
	 */
	setControl : function(oControl) {
		this._oControl = oControl;
		this.invalidate();
	},

	/**
	 * Invalide le controle propriétaire afin qu'il se redessineen tenant compte
	 * des changement apporté à l'aspect du texte.
	 */
	invalidate : function() {
		if (this._oControl) {
			this.update();
			this._oControl.invalidate();
		}
	},

	/**
	 * Modification de la police de caractère, on ne change que la variable et
	 * on invalide le controle
	 * 
	 * @param sFont
	 *            nouvelle police
	 */
	setFont : function(sFont) {
		if (this._sFont != sFont) {
			this._sFont = sFont;
			this.invalidate();
		}
	},
	
	setStyle: function(sStyle) {
		if (this._sStyle != sStyle) {
			this._sStyle = sStyle;
			this.invalidate();
		}
	},

	/**
	 * Modifie la taille de la police
	 * 
	 * @param nSize
	 *            nouvelle taille en pixel
	 */
	setSize : function(nSize) {
		if (this._nFontSize != nSize) {
			this._nFontSize = nSize;
			this.invalidate();
		}
	},

	/**
	 * Modification de la couleur
	 * 
	 * @param s
	 *            nouvelle couleur HTML5 (peut etre un gradient)
	 */
	setColor : function(sColor, sOutline) {
		var bInvalid = false;
		if (this._sColor != sColor) {
			this._sColor = sColor;
			bInvalid = true;
		}
		if (this._sOutlineColor != sOutline) {
			this._sOutlineColor = sOutline;
			bInvalid = true;
		}
		this._bOutline = this._sOutlineColor !== undefined;
		if (bInvalid) {
			this.invalidate();
		}
	},

	/**
	 * Calcule la chaine de définition de police de caractère Cette fonction
	 * génère une chaine de caractère utilisable pour définir la propriété Font
	 * d'une instance Canvas2DContext
	 * 
	 * @return string
	 */
	getFontString : function() {
		return (this._sStyle ? this._sStyle + ' ' : '') + this._nFontSize.toString() + 'px ' + this._sFont;
	},

	/**
	 * Applique les changements de taille, de couleur... Le context2D du
	 * controle propriété de cette instance est mis à jour quant au nouvel
	 * aspect de la Font.
	 */
	update : function() {
		var oContext = this._oControl.getSurface();
		oContext.font = this.getFontString();
		oContext.fillStyle = this._sColor;
		if (this._bOutline) {
			oContext.strokeStyle = this._sOutlineColor;
		}
	}
});


/* H5UI: Bibliothèque de composants visuels basé sur la technologie HTML 5
   2012 Raphaël Marandet
   ver 1.0 01.06.2012
 */

/*
 H5UI est un système de gestion de controles fenêtrés basé sur HTML 5, plus particulièrement son objet de rendu graphique Canvas.
 Ce système gère : 
 1) l'affichage d'une interface graphique (ensemble de fenêtres, boutons, texte, tableau, images, barres de défilement....).
 2) le traitement des évènements souris (déplacement, clic, drag and drop...)
 3) Le rafraichissement optimisé des composants graphiques dont l'état a changé.

 Principe
 --------

 Le système s'apparentant à un Document Object Model (DOM) est articulé autour d'une classe Composite : 
 Les instances de contrôles fenêtrés entretiennent chacune une collection d'instances de même classe.
 Ces contrôles sont organisé en arborescence. Chaque contrôle fenêtré possède un seul parent et 0-n enfants.

 Lorsqu'un contrôle s'invalide (sous l'effet d'une action externe comme une action utilisateur ou un timer écoulé), 
 il doit être redessiné. Sa chaîne hierarchique est invalidée à son tour,
 et lors du rafraichissement d'écran seul les composants invalides font appel à leur méthode de rendu graphique 
 et sont effectivement redessinés. 
 Les autres contrôles ne sont que replaqués sur la surface de leur parent en utilisant leur état graphique actuel inchangé.
 Les composants dont les parents n'ont pas été invalidés ne sont pas atteints par la procédure de rafraîchissement.


 +--------------------------------------------------+
 | Controle A                                       |
 |            +-----------------------------+       |
 |            | Controle B                  |       |
 |            |                             |       |
 |            |                             |       |
 |            +-----------------------------+       |
 |                                                  |
 |    +-----------------------------+               |
 |    | Controle C                  |               |
 |    |    +-----------------+      |               |
 |    |    | Controle D      |      |               |
 |    |    |                 |      |               |
 |    |    |                 |      |               |
 |    |    |                 |      |               |
 |    |    +-----------------+      |               |
 |    +-----------------------------+               |
 |                                                  |
 +--------------------------------------------------+

 Dans ce schémas le Controle A contient B et C, le Contrôle C contient quand à lui le Controle D
 Autrement l'arborescence se représente ainsi

 A
 |
 +--- B
 |
 +--- C
 |
 +--- D




 Vocabulaire
 -----------

 Contrôle fenêtré
 Elément de base d'une interface graphique.
 Le contrôle fenêtré est un objet visuel qui possède plusieurs propriétés de base et 
 Les propriété fondamentales pour tout objet graphique sont : 
 - la position (en pixels).
 - la taille (longueur et hauteur en pixels).
 - un indicateur d'invalidation (booléen) lorsque celui ci est a VRAI le contrôle doit être redessiné.
 - un contrôle fenêtré parent.
 - une collection de contrôles fenêtrés enfants.

 Composite
 Design pattern permettant de traiter un groupe d'objet de même instance de la même manière qu'un seul objet.
 Les objets sont organisés hierarchiquement.
 En pratique : chaque controle fenêtré comporte une collection d'autres controles fenetrés.
 Le rendu graphique d'un controle fenêtré fait intervenir la fonction qui gère le rendu graphique des sous-contrôles fenêtrés

 Etat graphique
 C'est l'ensemble des propriétés d'un contrôle fenêtré qui concourent à son aspect visuel.
 Si l'une de ces propriétés changent, c'est l'aspect visuel du contrôle fenêtré qui en est modifié, il doit donc être redessiné.
 La collection de contrôles fenêtrés font partit de l'état graphique de fait que la modification de l'état graphique d'un contrôle fenêtré
 provoque le changement de l'état graphique du contrôle parent.

 */

O2.createObject('H5UI', {
	data : {
		renderCount : 0,
		cdiCount : 0,
		pixelCount : 0,
		renderedList : {},
		buildCanvases : 0,
		destroyedCanvases : 0
	},
	canvasDispenser: [],
	handle : 0,
	
	
	root: null,

	initRoot: function() {
		UI.root = document.getElementsByTagName('body')[0];
	},

	setRoot: function(oDomElement) { H5UI.root = oDomElement; },

	getCanvas: function () {
		var oCanvas = H5UI.canvasDispenser.pop();
		if (oCanvas) {
			return oCanvas;
		} else {
			return O876.CanvasFactory.getCanvas();
		}
	},

	recycleCanvas: function (oCanvas) {
		H5UI.canvasDispenser.push(oCanvas);
	}
});

/**
 * Controle fenètré graphique de base. Cette classe-souche possède les
 * propriétés et les méthodes de base permettant la représentation graphique
 * d'une zone rectangulaire de l'interface.
 */
O2.createClass('H5UI.WinControl', {
	_sClass : 'WinControl', // Nom indicatif de la classe
	_sName : '', // Nom indicatif du composant
	_nHandle : 0, // Numero de l'instance du controle
	_nIndex : 0, // Rang du controle parmis ses frères (autres enfants de son
	// parent)

	_oParent : null, // Control parent

	// Etat graphique
	_oCanvas : null, // Canvas privé du controle
	_oContext : null, // Contexte 2D du canvas
	_nWidth : 0, // Taille du controle
	_nHeight : 0, // Taille du controle
	_x : 0, // Position du controle
	_y : 0, // Position du controle
	_bInvalid : true, // Flag d'invalidation graphique

	// switches
	_bVisible : true, // Flag de visibilité

	// Controles enfants
	_aControls : null, // Tableau contenant les controles enfants
	_aInvalidControls : null, // Tableau indexant les controles devenus
	// invalides
	_aAlignedControls : null, // Tableau indexant les controles alignés
	// (position/taille change en fonction du
	// parent)
	_aHideControls : null, // Tableau indexant les controles qui passent de
	// l'état visible à invisible

	// évenements
	_oPointedControl : null, // Référence du controle sujet à un drag and
	// drop
	_oDraggedControl : null, // Référence au controle actuellement en cour de
	// drag
	_bDragHandler : false, // Le controle actuel est un gestionnaire de drag
	// and drop

	// CONSTRUCTEUR
	__construct : function() {
		this._nHandle = ++H5UI.handle;
		this._aControls = [];
		this._aInvalidControls = [];
		this._aAlignedControls = {
			center : []
		};
		this._aHideControls = [];
		this.buildSurface();
		this.invalidate();
	},

	// DESTRUCTEUR
	__destruct : function() {
		H5UI.recycleCanvas(this._oCanvas);
		this.clear();
		var aProps = [];
		for ( var i in this) {
			this[i] = null;
			aProps.push(i);
		}
		for (i = 0; i < aProps.length; i++) {
			delete this[aProps[i]];
		}
		aProps = null;
		H5UI.data.destroyedCanvases++;
	},

	/**
	 *  Détruit tous les controles enfant
	 */
	clear : function() {
		while (this._aControls.length) {
			this.unlinkControl(0);
		}
	},

	/**
	 * Methode de construction du canvas
	 * 
	 */
	buildSurface : function() {
		this._oCanvas = H5UI.getCanvas();
		H5UI.data.buildCanvases++;
		this._oContext = this._oCanvas.getContext('2d');
	},

	/** ************ Métodes privées ************** */
	/** ************ Métodes privées ************** */
	/** ************ Métodes privées ************** */
	/** ************ Métodes privées ************** */
	/** ************ Métodes privées ************** */
	/** ************ Métodes privées ************** */
	/** ************ Métodes privées ************** */
	/** ************ Métodes privées ************** */

	/**
	 * Fonction protégée de modification de propriété conduisant à une
	 * invalidation
	 * 
	 * @param sProperty
	 *            propritété à modifier
	 * @param xValue
	 *            nouvelle valeur
	 */
	_set : function(sProperty, xValue) {
		if (sProperty in this && this[sProperty] != xValue) {
			this[sProperty] = xValue;
			this.invalidate();
		}
	},

	/**
	 * Réaligne les controles alignés. Un contrôle aligné est un contrôle
	 * fenêtré dont la position dépent de la taille de son parent Pour chaque
	 * controle aligné, lance la méthode de placement correspondant à
	 * l'alignement. Cete méthode à pour préfixe "moveTo" Un réalignement
	 * intervient lorsque le controle parent change de place ou de taille.
	 */
	realignControls : function() {
		var n, a, sDokoMethod;
		for ( var sDoko in this._aAlignedControls) {
			sDokoMethod = 'moveTo' + sDoko.substr(0, 1).toUpperCase() + sDoko.substr(1).toLowerCase();
			a = this._aAlignedControls[sDoko];
			for (n = 0; n < a.length; n++) {
				a[n][sDokoMethod]();
			}
		}
	},

	/**
	 * Permet de définir un control aligné * Utiliser plutôt align() la position
	 * et la taille des les controles alignés sont en fonction de la position et
	 * la taille de leur parent
	 * 
	 * @param oControl
	 *            controle à aligner
	 * @param nDoko
	 *            Où doit etre aligner le controle ('center')
	 */
	registerAlignedControl : function(oControl, sDoko) {
		oControl.render();
		this.unregisterAlignedControl(oControl);
		this.pushArrayItem(this._aAlignedControls[sDoko], oControl);
		this.realignControls();
	},

	/**
	 * Supprime l'alignement forcé du controle
	 * 
	 * @param oControl
	 *            control, dont il faut supprimer l'alignement
	 */
	unregisterAlignedControl : function(oControl) {
		for ( var sDoko in this._aAlignedControls) {
			this.removeArrayItem(this._aAlignedControls[sDoko], oControl);
		}
	},

	/**
	 * Supprime un élément d'un tableau à indice numérique séquentiel la
	 * fonction accepte un indice ou une instance si l'instance se trouve dans
	 * le tableau, on la vire et on décale les objet de manière à combler le
	 * trou
	 * 
	 * @param oArray
	 *            tableau
	 * @param xItem
	 *            indice ou instance de l'élément à virer
	 * @param sIndex
	 *            optionnel, clé de l'index à mettre à jour
	 */
	removeArrayItem : function(oArray, xItem, sIndex) {
		var nItem;
		if (typeof xItem == 'object') {
			nItem = oArray.indexOf(xItem);
			if (nItem < 0) {
				return;
			}
		} else {
			nItem = xItem;
		}
		if (nItem == (oArray.length - 1)) {
			oArray.pop();
		} else {
			oArray[nItem] = oArray.pop();
			if (sIndex !== undefined) {
				oArray[nItem][sIndex] = nItem;
			}
		}
	},

	/**
	 * Méthode utilitaire de stockage d'un élément dans un tableau Permet de
	 * mettre à jour la propriété d'index de l'élément.
	 * 
	 * @param oArray
	 *            tableau
	 * @param oItem
	 *            instance de l'élément à ajouter au tableau
	 * @param sIndex
	 *            optionnel, clé de l'index à mettre à jour
	 * @return item
	 */
	pushArrayItem : function(oArray, oItem, sIndex) {
		var nLen, nItem = oArray.indexOf(oItem);
		if (nItem < 0) {
			nLen = oArray.length;
			if (sIndex !== undefined) {
				oItem[sIndex] = nLen;
			}
			oArray.push(oItem);
			return nLen;
		} else {
			return nItem;
		}
	},

	/**
	 * Place un controle dans la liste des controle à cacher, suite à l'appel
	 * d'un hide()
	 * 
	 * @param oControl
	 *            control qui se cache
	 */
	hideControl : function(oControl) {
		this.pushArrayItem(this._aHideControls, oControl);
	},

	/**
	 * Rend visible un control qui a été caché
	 * 
	 * @param oControl
	 *            controle à rendre visible
	 */
	showControl : function(oControl) {
		this.removeArrayItem(this._aHideControls, oControl);
	},

	/**
	 * Gestion des évènement souris (click, mousein, mouseout, mousemove,
	 * mousedown, mouseup) La méthode exécute une methode déléguée "on....."
	 * puis transmet l'évènement à l'élément pointé par la souris
	 * 
	 * @param sEvent
	 *            nom de l'évènement (Click, MouseIn, MouseOut, MouseMove,
	 *            MouseDown, MouseUp)
	 * @param x,
	 *            y coordonnée de la souris lors de l'évènement
	 * @param nButton
	 *            bouton appuyé
	 */
	doMouseEvent : function(sEvent, x, y, nButton, oClicked) {
		if (this._oDraggedControl !== null) {
			this.doDragDropEvent(sEvent, x, y, nButton);
			return;
		}
		if (oClicked === undefined) {
			oClicked = this.getControlAt(x, y);
		}
		if (oClicked != this._oPointedControl) {
			if (this._oPointedControl !== null) {
				this.doMouseEvent('MouseOut', x, y, nButton,
						this._oPointedControl);
			}
			this._oPointedControl = oClicked;
			this.doMouseEvent('MouseIn', x, y, nButton, oClicked);
		}
		var sMouseEventMethod = 'on' + sEvent;
		var pMouseEventMethod;
		if (oClicked !== null) {
			if (sMouseEventMethod in oClicked) {
				pMouseEventMethod = oClicked[sMouseEventMethod];
				pMouseEventMethod.apply(oClicked, [ x - oClicked._x,
						y - oClicked._y, nButton ]);
			}
			oClicked.doMouseEvent(sEvent, x - oClicked._x, y - oClicked._y,
					nButton);
		}
	},
	
	/**
	 * Renvoie la position relative du controle spécifié Intervien lors du drag
	 * n drop
	 */
	getControlRelativePosition : function(oControl) {
		var oPos = {
			x : 0,
			y : 0
		};
		while (oControl != this && oControl !== null) {
			oPos.x += oControl._x;
			oPos.y += oControl._y;
			oControl = oControl._oParent;
		}
		return oPos;
	},

	doDragDropEvent : function(sEvent, x, y, nButton) {
		var oPos = this.getControlRelativePosition(this._oDraggedControl);
		switch (sEvent) {
		case 'MouseMove':
			this._oDraggedControl.callEvent('onDragging', x - oPos.x, y - oPos.y, nButton);
			break;

		case 'MouseUp': // fin du drag n drop
			this._oDraggedControl.callEvent('onEndDragging', x - oPos.x, y - oPos.y, nButton);
			this._oDraggedControl = null;
			break;
		}
	},

	/**
	 * Initialise le drag n drop appelle le gestionnaire de DragDrop, s'il n'y
	 * en a pas, appelle le parent
	 */
	startDragObject : function(oTarget, x, y, b) {
		if (this._bDragHandler) {
			this._oDraggedControl = oTarget;
			oTarget.callEvent('onStartDragging', x, y, b);
		} else {
			this.callParentMethod('startDragObject', oTarget, x, y, b);
		}
	},

	/**
	 * Transforme un objet d'arguments en tableau (spécificité webkit)
	 * 
	 * @param a
	 *            args
	 * @return array
	 */
	argObjectToArray : function(a) {
		var i = '';
		var aArgs = [];
		if ('length' in a) {
			for (i = 0; i < a.length; i++) {
				aArgs.push(a[i]);
			}
			return aArgs;
		}
		for (i in a) {
			aArgs.push(a[i]);
		}
		return aArgs;
	},

	/**
	 * Appelle un method du parent
	 * 
	 * @param sMethod
	 *            nom de la methode à appeler
	 * @param autre
	 *            method
	 * @return retourn de la methode
	 */
	callParentMethod : function() {
		if (this._oParent === null) {
			return null;
		}
		var aArgs = this.argObjectToArray(arguments);
		var sMethod = aArgs.shift();
		if (sMethod in this._oParent) {
			return this._oParent[sMethod].apply(this._oParent, aArgs);
		}
	},

	/**
	 * Appelle une methode si celle ci existe Utilisé lors d'appel d'évènement
	 * facultativement défini
	 */
	callEvent : function() {
		var aArgs = this.argObjectToArray(arguments);
		var sMethod = aArgs.shift();
		if (sMethod in this) {
			return this[sMethod].apply(this, aArgs);
		}
	},

	/**
	 * Ajoute le control à la liste des controle invalide pour une optimisation
	 * du rendu
	 * 
	 * @param o
	 *            Controle à invalider
	 */
	invalidateControl : function(o) {
		if (this._aInvalidControls.indexOf(o) < 0) {
			this._aInvalidControls.push(o);
		}
	},

	/**
	 * Dessine les controle enfant
	 */
	renderControls : function() {
		var o;
		while (this._aInvalidControls.length) {
			o = this._aInvalidControls.shift();
			if (o._nHandle) {
				o.render();
			}
		}
	},

	/**
	 * Efface les controles caché de la surface
	 */
	hideControls : function() {
		var o;
		while (this._aHideControls.length) {
			o = this._aHideControls.shift();
			this._oContext.clearRect(o._x, o._y, o.getWidth(), o.getHeight());
		}
	},

	renderSelf : function() {
	},

	needRender : function() {
		return this._bVisible && (this._nWidth * this._nHeight) !== 0;
	},

	/**
	 * Redessine le contenu graphique du controle fenêtré l'extérieur de ce
	 * rectangle est normalment invisible et n'a aps besoin d'etre traité
	 */
	render : function() {
		var o;
		if (this._bInvalid) {
			this.hideControls();
			this.renderSelf();
			// repeindre les controle enfant
			this.renderControls();
			for (var i = 0; i < this._aControls.length; i++) {
				o = this._aControls[i];
				if (o.needRender()) {
					this._oContext.drawImage(o._oCanvas, o._x, o._y);
				}
			}
			this._bInvalid = false;
		}
	},

	/** ************* Méthodes publiques ************* */
	/** ************* Méthodes publiques ************* */
	/** ************* Méthodes publiques ************* */
	/** ************* Méthodes publiques ************* */
	/** ************* Méthodes publiques ************* */
	/** ************* Méthodes publiques ************* */
	/** ************* Méthodes publiques ************* */
	/** ************* Méthodes publiques ************* */

	/**
	 * Renvoie la classe de widget. la "classe" est une simple variable.
	 * 
	 * @return string
	 */
	getClass : function() {
		return this._sClass;
	},

	/**
	 * Renvoie la loongeur du controle en pixels pour changer la longeur
	 * utiliser setSize()
	 * 
	 * @return int
	 */
	getWidth : function() {
		return this._nWidth;
	},

	/**
	 * Renvoie la hauteur du controle en pixels pour changer la hauteur utiliser
	 * setSize()
	 * 
	 * @return int
	 */
	getHeight : function() {
		return this._nHeight;
	},

	/**
	 * Renvoie l'instance du controle parent
	 * 
	 * @return H5UI.WinControl
	 */
	getParent : function() {
		return this._oParent;
	},

	/**
	 * Ajoute un controle enfant et renvoie l'instance de ce control
	 * nouvellement linké
	 * 
	 * @param o
	 *            Controle enfant à ajouter
	 * @return H5UI.WinControl
	 */
	linkControl : function(o) {
		o._nIndex = this._aControls.length;
		this._aControls.push(o);
		o._oParent = this;
		o.invalidate();
		return o;
	},

	/**
	 * Défini quel controle sera au sommet de la pile des autre contrôles
	 * il apparaitra par dessus tous les autres
	 * @param o Objet controle
	 */
	setTopControl : function(o) {
		var nIndex = this._aControls.indexOf(o);
		var nCount = this.getControlCount();
		if (nIndex >= 0) {
			for (var i = nIndex; i < (nCount - 1); i++) {
				this._aControls[i] = this._aControls[i + 1];
				this._aControls[i]._set('_nIndex', i);
			}
			this._aControls[nCount - 1] = o;
			o._set('_nIndex', i);
		}
	},

	/** 
	 * se placer au dessus des autres controles
	 * fait appel au top du client
	 */
	top : function() {
		this.callParentMethod('setTopControl', this);
	},

	/**
	 * Supprime un controle et appelle le destructeur de ce controle
	 * 
	 * @param n
	 *            controle à virer
	 */
	unlinkControl : function(n) {
		var oControl;
		if (n >= this._aControls.length) {
			throw new Error('out of bounds: ' + n.toString() + ' - range is 0 to ' + this._aControls.length);
		}
		oControl = this._aControls[n];
		this.removeArrayItem(this._aControls, n, '_nIndex');
		this.removeArrayItem(this._aInvalidControls, oControl);
		for ( var sAlign in this._aAlignedControls) {
			this.removeArrayItem(this._aAlignedControls[sAlign], oControl);
		}
		this.removeArrayItem(this._aHideControls, oControl);
		/*
		 * if (n == (this._aControls.length - 1)) { oControl =
		 * this._aControls.pop(); } else { oControl = this._aControls[n];
		 * this._aControls[n] = this._aControls.pop();
		 * this._aControls[n]._nIndex = n; }
		 */
		oControl.__destruct();
		this.invalidate();
	},

	/**
	 * Autodestruction d'un objet
	 */
	free : function() {
		this.callParentMethod('unlinkControl', this._nIndex);
	},

	/**
	 * Renvoie le controle de rang n
	 * 
	 * @param n
	 * @exception "out
	 *                of bounds"
	 * @return controle au rang n
	 */
	getControl : function(n) {
		if (n >= this._aControls.length) {
			throw new Error('out of bounds: ' + n.toString() + ' - range is 0 to ' + this._aControls.length);
		}
		return this._aControls[n];
	},

	/**
	 * Renvoie le nombre de controles
	 * 
	 * @return int
	 */
	getControlCount : function() {
		if (this._aControls) {
			return this._aControls.length;
		} else {
			return 0;
		}
	},

	/**
	 * Alignement d'un controle fenetré
	 * 
	 * @param sDoko
	 *            position du controle à maintenir (pour l'instant uniquement
	 *            'center') si le paramètre est omis, l'alignement du controle
	 *            est supprimé
	 */
	align : function(sDoko) {
		if (sDoko === undefined) {
			this.callParentMethod('unregisterAlignedControl', this);
		} else {
			this.callParentMethod('registerAlignedControl', this, sDoko);
		}
	},

	/**
	 * Changement de taille du controle
	 * 
	 * @param w
	 *            taille x
	 * @param h
	 *            taille y
	 */
	setSize : function(w, h) {
		if (w != this.getWidth() || h != this.getHeight()) {
			this._nWidth = this._oCanvas.width = w;
			this._nHeight = this._oCanvas.height = h;
			this.realignControls();
			this.invalidate();
		}
	},

	/**
	 * Positionne le controle à la position spécifiée
	 * 
	 * @param x
	 * @param y
	 */
	moveTo : function(x, y) {
		if (x != this._x || y != this._y) {
			this._x = x;
			this._y = y;
			this.realignControls();
			this.invalidate();
		}
	},

	/**
	 * Déplace le control au centre de son parent Le controle conserve sa
	 * taille, seule sa position change Cette methode est exploitée par le
	 * système d'alignement des control mais peut etre utilisé ponctuellement
	 * pour centrer un controle.
	 */
	moveToCenter : function() {
		var p = this.getParent();
		if (p) {
			this.moveTo(((p.getWidth() - this.getWidth()) >> 1), ((p.getHeight() - this.getHeight()) >> 1));
		}
	},

	/**
	 * Cache le controle
	 */
	hide : function() {
		if (this._bVisible) {
			this._bVisible = false;
			this.callParentMethod('hideControl', this);
			this.invalidate();
		}
	},

	/**
	 * Affiche le controle
	 */
	show : function() {
		if (!this._bVisible) {
			this._bVisible = true;
			this.invalidate();
		}
	},

	/**
	 * Renvoie la référence au context du canvas
	 * 
	 * @return Object HTMLCanvasContext2d
	 */
	getSurface : function() {
		if (this._oContext === null) {
			this._oContext = this._oCanvas.getContext('2d');
		}
		return this._oContext;
	},

	/**
	 * Renvoie la surface du parent
	 * 
	 * @return Object HTMLCanvasContext2d
	 */
	getParentSurface : function() {
		return this.callParentMethod('getSurface');
	},

	/**
	 * Renvoie la référence du controle pointé par les coordonées spécifiées
	 * 
	 * @param x,
	 *            y coordonnées
	 */
	getControlAt : function(x, y) {
		var o, ox, oy, w, h;
		if (this._aControls) {
			for (var i = this._aControls.length - 1; i >= 0; i--) {
				o = this._aControls[i];
				ox = o._x;
				oy = o._y;
				w = o.getWidth();
				h = o.getHeight();
				if (x >= ox && y >= oy && x < (ox + w) && y < (oy + h) && o._bVisible) {
					return o;
				}
			}
		}
		return null;
	},

	/**
	 * Démarre le processus de drag and drop
	 * 
	 * @param x,
	 *            y position de la souris
	 * @param b
	 *            bouttons de la souris enfoncé
	 */
	dragStart : function(x, y, b) {
		this.callParentMethod('startDragObject', this, x, y, b);
	},

	/**
	 * Invalide l'état graphique, forcant le controle à se redessiner
	 */
	invalidate : function() {
		this._bInvalid = true;
		this.callParentMethod('invalidate');
		this.callParentMethod('invalidateControl', this);
	},

	/**
	 * Renvoie true si le controle possède des enfants
	 * 
	 * @return bool
	 */
	hasControls : function() {
		return this._aControls !== null && this._aControls.length > 0;
	}
});

/**
 * Cette fonction parcoure tous les points en ligne droite sur le segment déterminé 
 * par les points (x0, y0) et (x1, y1) 
 * pour chaque point parcouru on appelle un callback fonction (x, y) qui devra renvoyer true
 * pour stopper le parcour, ou false pour le laisser continuer
 * @param x0 point de départ absice
 * @param y0 point de départ ordonnée
 * @param x1 point d'arrivée absice
 * @param y1 point d'arrivée ordonnée
 * @param pPlotFunction fonction callback
 * @returns {Boolean} true si le parcour a été interrompu / false sinon
 */
O2.createObject('O876.Bresenham', {
	line: function(x0, y0, x1, y1, pPlotFunction) {
		var dx = Math.abs(x1 - x0);
		var dy = Math.abs(y1 - y0);
		var sx = (x0 < x1) ? 1 : -1;
		var sy = (y0 < y1) ? 1 : -1;
		var err = dx - dy;
		var e2;
		while (true) {
			if (pPlotFunction(x0, y0)) {
				return true;
			}
			if (x0 == x1 && y0 == y1) {
				break;
			}
			e2 = err << 1;
			if (e2 > -dy) {
				err -= dy;
				x0 += sx;
			}
			if (e2 < dx) {
				err += dx;
				y0 += sy;
			}
		}
		return false;
	}
});


O2.createObject('O876.Browser', {
	
	STRINGS: {
		en: {
			wontrun: 'The game won\'t run because some HTML 5 features are not supported by this browser',
			install: 'You should install the latest version of one of these browsers : <b>Firefox</b>, <b>Chrome</b> or <b>Chromium</b>.',
			legend: '(the red colored features are not supported by your browser)'
		},
		
		fr: {
			wontrun: 'Le jeu ne peut pas se lancer, car certaines fonctionnalités HTML 5 ne sont pas supportées par votre navigateur',
			install: 'Vous devriez installer la dernière version de l\'un de ces navigateurs : <b>Firefox</b>, <b>Chrome</b> ou <b>Chromium</b>.',
			legend: '(les fonctionnalités marquées en rouge ne sont pas supportées par votre navigateur)'
		}
	},
	
	LANGUAGE: 'en',
	
	isOpera: function() {
		return !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
			// Opera 8.0+ (UA detection to detect Blink/v8-powered Opera)
	},
	
	isFirefox: function() {
		return typeof InstallTrigger !== 'undefined';   // Firefox 1.0+
	},
	
	isSafari: function() {
		return Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0;
			// At least Safari 3+: "[object HTMLElementConstructor]"
	},
	
	isChrome: function() {
		return !!window.chrome && !O876.Browser.isOpera();              // Chrome 1+
	},
	
	isIE: function() {
		return /*@cc_on!@*/false || !!document.documentMode; // At least IE6
	},
	
	getDetectedBrowserList: function() {
		return (['Opera', 'Firefox', 'Safari', 'Chrome', 'IE']).filter(function(f) {
			return O876.Browser['is' + f]();
		});
	},

	/**
	 * Tests if all specified HTML5 feature are supported by the browser
	 * if no parameter is set, tests all the HTML 5 feature
	 * the returned objet has a 'html' field to be displayed
	 * @param aRequire array of string
	 * @return object
	 */
	getHTML5Status: function(aRequired) {
		var oReport = {
			canvas: 'HTMLCanvasElement' in window,
			audio: 'HTMLAudioElement' in window,
			fullscreen: ('webkitIsFullScreen' in document) || ('mozFullScreen' in document),
			animation: 'requestAnimationFrame' in window,
			performance: ('performance' in window) && ('now' in performance),
			pointerlock: ('pointerLockElement' in document) || ('mozPointerLockElement' in document),
			uint32array: 'Uint32Array' in window
		};
		var i, b = true;
		var aFeats = ['<table><tbody>'];
		
		function testFeature(iFeat) {
			b = b && oReport[iFeat];
			aFeats.push('<tr><td style="color: ' + (oReport[iFeat] ? '#080' : '#800') + '">' + (oReport[iFeat] ? '✔' : '✖') + '</td><td' + (oReport[iFeat] ? '' : ' style="color: #F88"') + '>' + iFeat + '</td></tr>');
		}
		
		if (aRequired) {
			aRequired.forEach(testFeature);
		} else {
			for (i in oReport) {
				testFeature(i);
			}
		}
		aFeats.push('</tbody></table>');
		oReport.all = b;
		oReport.html = '<div>' + aFeats.join('') + '</div>';
		oReport.browser = O876.Browser.getDetectedBrowserList();
		return oReport;
	},
	
	checkHTML5: function(sTitle) {
		if (!sTitle) {
			sTitle = 'HTML 5 Application';
		}
		var oHTML5 = O876.Browser.getHTML5Status();
		if (!oHTML5.all) {
			var m = O876.Browser.STRINGS[O876.Browser.LANGUAGE];
			document.body.innerHTML = '<div style="color: #AAA; font-family: monospace; background-color: black; border: solid 4px #666; padding: 8px">' +
				'<h1>' + sTitle + '</h1>' +
				'<p>' + m.wontrun + ' (' + oHTML5.browser.join(', ') + ').<br/>' +
				m.install + '</p>' + oHTML5.html + 
				'<p style="color: #888; font-style: italic">' + m.legend + '</p></div>'; 
			return false;
		}
		return oHTML5.all;
	},
});

/** Classe de mesure de l'activité CPU
 * 
 */
O2.createClass('O876.CPUMonitor', {
	// Temps chronometrés par l'objet
	aTimes: null,
	sTimes: null,
	nTimes: 0,
	nIdleTime: 0,
	aColors: null,
	
	__construct: function() {
		this.aColors = ['#F00', '#0F0', '#FF0', '#00F', '#F0F', '#0FF', '#FFF'];
		this.aTimes = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
		this.sTimes = ['','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',''];
	},
	
	
	/** Lance le début du chronometrage
	 * Calcule le temps d'inactivité (temps courant  - dernier chrono)
	 */
	start: function() {
		var d = Date.now();
		if (this.nTimes > 0) {
			this.nIdleTime = d - this.aTimes[this.nTimes - 1];
			this.nTimes = 0;
		}
		this.aTimes[this.nTimes++] = d;
	},
	
	/** Insertion d'un temps de chrono
	 * 
	 */
	trigger: function(s, d) {
		if (d === undefined) {
			d = Date.now();
		}
		this.sTimes[this.nTimes - 1] = s;
		this.aTimes[this.nTimes++] = d;
	},
	
	render: function(oContext, x, y) {
		var n;
		for (var i = 0; i < (this.nTimes - 1); i++) {
			n = this.aTimes[i + 1] - this.aTimes[i];
			// n = time !
			oContext.fillStyle = this.aColors[i % 7];
			oContext.fillRect(x, y, n, 8);
			x += n;
		}
		oContext.fillStyle = this.aColors[i % 7];
		oContext.fillRect(x, y, this.nIdleTime, 8);
	}
});

/**
 * Canvas factory
 */
O2.createObject('O876.CanvasFactory', {
	
	/**
	 * Create a new canvas
	 */
	getCanvas: function() {
		var oCanvas = document.createElement('canvas');
		var oContext = oCanvas.getContext('2d');
		O876.CanvasFactory.setImageSmoothing(oContext, false);
		return oCanvas;
	},
	
	/**
	 * Set canvas image smoothing flag on or off
	 * @param Context2D oContext
	 * @param bool b on = smoothing on // false = smoothing off
	 */
	setImageSmoothing: function(oContext, b) {
		oContext.webkitImageSmoothingEnabled = b;
		oContext.mozImageSmoothingEnabled = b;
		oContext.imageSmoothingEnabled = b;
	},
	
	getImageSmoothing: function(oContext) {
		return oContext.imageSmoothingEnabled;
	}
});

/** Chargement de classe à partir du nom
 * Gère les Namespace.
 */
O2.createClass('O876.ClassLoader', {
	oClasses: null,
	
	__construct: function() {
		this.oClasses = {};
	},
	
	loadClass: function(s) {
		if (s in this.oClasses) {
			return this.oClasses[s];
		}
		var aClass = s.split('.');
		var pBase = window;
		while (aClass.length > 1) {
			pBase = pBase[aClass.shift()];
		}
		var sClass = aClass[0];
		if (sClass in pBase) {
			this.oClasses[s] = pBase[sClass];
			return this.oClasses[s];
		} else {
			return null;
		}
	}
});

/** Interface de controle des mobile 
 * O876 Raycaster project
 * @date 2013-03-04
 * @author Raphaël Marandet 
 * Fait bouger un mobile de manière non-lineaire
 * Avec des coordonnée de dépat, d'arriver, et un temps donné
 * L'option lineaire est tout de même proposée.
 */
O2.createClass('O876.Easing', {	
	xStart: 0,
	yStart: 0,
	
	xEnd: 0,
	yEnd: 0,
	
	x: 0,
	y: 0,
	
	bXCompute: true,
	bYCompute: true,
	
	nTime: 0,
	iTime: 0,
	
	
	fWeight: 1,
	
	sFunction: 'smoothstep',
	
	__construct : function() {
		this.nTime = 0;
		this.iTime = 0;
	},
	
	/**
	 * Définition du mouvement qu'on souhaite calculer.
	 * @param float x position X de départ
	 * @param float y position Y de départ
	 * @param float dx position finale X
	 * @param float dy position finale Y
	 * @param int t temps qu'il faut au mouvement pour s'effectuer
	 */
	setMove: function(x, y, dx, dy, t) {
		if (t === undefined && dy === undefined) {
			t = dx;
			dy = 0;
			dx = y;
			y = 0;
		}
		this.xStart = this.x = x;
		this.yStart = this.y = y;
		this.xEnd = dx;
		this.yEnd = dy;
		this.bXCompute = x != dx;
		this.bYCompute = y != dy;
		this.nTime = t;
		this.iTime = 0;
	},
	
	/**
	 * Définition de la fonction d'Easing
	 * @param string sFunction fonction à choisir parmi :
	 * linear : mouvement lineaire uniforme
	 * smoothstep : accelération et déccelération douce
	 * smoothstepX2 : accelération et déccelération moyenne
	 * smoothstepX3 : accelération et déccelération brutale
	 * squareAccel : vitesse 0 à T-0 puis uniquement accelération 
	 * squareDeccel : vitesse max à T-0 puis uniquement deccelération
	 * cubeAccel : vitesse 0 à T-0 puis uniquement accelération brutale 
	 * cubeDeccel : vitesse max à T-0 puis uniquement deccelération brutale
	 * sine : accelération et deccelération brutal, vitesse nulle à mi chemin
	 * cosine : accelération et deccelération selon le cosinus, vitesse max à mi chemin
	 * weightAverage : ... me rapelle plus 
	 */
	setFunction: function(sFunction) {
		this.sFunction = sFunction;
	},
	
	/**
	 * Calcule les coordonnée pour le temps t
	 * mets à jour les coordonnée x et y de l'objets
	 * @param int t temps
	 */
	move: function(t) {
		if (t === undefined) {
			t = this.iTime++;
		}
		var v = this[this.sFunction](t / this.nTime);
		if (this.bXCompute) {
			this.x = this.xEnd * v + (this.xStart * (1 - v));
		}
		if (this.bYCompute) {
			this.y = this.yEnd * v + (this.yStart * (1 - v));
		}
		return t >= this.nTime;
	},

	linear: function(v) {
		return v;
	},
	
	smoothstep: function(v) {
		return v * v * (3 - 2 * v);
	},
	
	smoothstepX2: function(v) {
		v = v * v * (3 - 2 * v);
		return v * v * (3 - 2 * v);
	},
	
	smoothstepX3: function(v) {
		v = v * v * (3 - 2 * v);
		v = v * v * (3 - 2 * v);
		return v * v * (3 - 2 * v);
	},
	
	squareAccel: function(v) {
		return v * v;
	},
	
	squareDeccel: function(v) {
		return 1 - (1 - v) * (1 - v);
	},
	
	cubeAccel: function(v) {
		return v * v * v;
	},
	
	cubeDeccel: function(v) {
		return 1 - (1 - v) * (1 - v) * (1 - v);
	},
	
	cubeInOut: function(v) {
		if (v < 0.5) {
			v = 2 * v;
			return v * v * v;
		} else {
			v = (1 - v) * 2;
			return v * v * v;
		}
	},
	
	sine: function(v) {
		return Math.sin(v * 3.14159265 / 2);
	},
	
	cosine: function(v) {
		return 0.5 - Math.cos(-v * 3.14159265) * 0.5;
	},
	
	weightAverage: function(v) {
		return ((v * (this.nTime - 1)) + this.fWeight) / this.nTime;
	},
	
	quinticBezier: function(v) {
		var ts = v * this.nTime;
		var tc = ts * this.nTime;
		return 4 * tc - 9 * ts + 6 * v;
	}
});

/**
 * Transforme un tableau d'argument en chaine contenant le type de chaque argument
 * u : undefined / null
 * n : number
 * o : object
 * f : function
 * b : boolean
 * a : array
 */ 
O2.createObject('O876.FunArgType' , function(aArgs) {
	return Array.prototype.slice.call(aArgs, 0).map(function(x) {
		var tx = (typeof x);
		switch (tx) {
			case 'object':
				if (x === null) {
					return 'u';
				} else if (Array.isArray(x)) {
					return 'a';
				} else {
					return 'o';
				}
				break;
				
			default:
				return tx.charAt(0);
			
		}
	}).join('');	
});

O2.createClass('O876.Horde', {
	aItems: null,
	
	__construct: function() {
		this.aItems = [];
	},
	
	/** Ajoute un élément à la legion
	 * @param oItem élément à ajouter
	 * @return int : indice de l'élément
	 */
	link: function(oItem) {
		var nKey = this.aItems.length;
		this.aItems.push(oItem);
		return nKey;
	},
	
	/**
	 * Renvoie le rang d'un élément
	 * @return int ( -1 si non trouvé
	 */
	indexOf: function(oItem) {
		return this.aItems.indexOf(oItem);
	},
	
	/** 
	 * Renvoie l'élément de la horde dont le rang est spécifié en param
	 * @param int rand de l'élément recherché
	 * @return object
	 */
	getItem: function(nKey) {
		if (nKey < this.aItems.length) {
			return this.aItems[nKey];
		} else {
			return null;
		}
	},
	
	/**
	 * Renvoie tous les items
	 * @return array
	 */
	getItems: function() {
		return this.aItems;
	},
	
	/** 
	 * Nombre d'éléments dans la horde
	 * return int
	 */
	count: function() {
		return this.aItems.length;
	},
	
	
	/**
	 * Suppression d'un élément de la horde
	 * La horde ne conserve pas le rang des éléments :
	 * Lorsqu'un élément est supprimé les autres éléments
	 * sont tassé pour combler le vide
	 * 
	 * @param xKey int or object élément ou rang de l'élément
	 */ 
	unlink: function(xKey) {
		var nKey;
		if (typeof xKey == 'object') {
			nKey = this.indexOf(xKey);
		} else {
			nKey = xKey;
		}
		if (nKey < 0 || nKey >= this.aItems.length) {
			return;
		}
		if (nKey == this.aItems.length - 1) {
			this.aItems.pop();
		} else {
			this.aItems[nKey] = this.aItems.pop();
		}
	},
	
	/**
	 * supprime les éléments de la horde
	 */
	clear: function() {
		this.aItems = [];
	}
});

O2.createObject('O876.LZW', {
	DICT_SIZE: 4096,
	PACKET_SEPARATOR: ':',
	FILE_SIGN: 'O876' + String.fromCharCode(122) + ':',

	nLastRatio: 0,		
	nMystificator: 0,

	encode: function(sData) {
		var aPackets = O876.LZW._createEncodedPackets(sData);
		var sBin = O876.LZW._bundlePackets(aPackets);
		O876.LZW.nLastRatio = sBin.length * 100 / sData.length | 0;
		return O876.LZW.FILE_SIGN + sBin;
	},

	decode: function(sZData) {
		if (sZData.substr(0, O876.LZW.FILE_SIGN.length) !== O876.LZW.FILE_SIGN) {
			throw new Error('bad format');
		}
		var aPacketCount = O876.LZW._getPacketInt(sZData, O876.LZW.FILE_SIGN.length);
		var nCount = aPacketCount[0];
		var iOffset = aPacketCount[1];
		var aPackets = O876.LZW._parsePackets(sZData, nCount, iOffset); 
		return O876.LZW._decodePackets(aPackets);
	},

	_bundlePackets: function(aPackets) {
		var aOutput = [];
		var sSep = O876.LZW.PACKET_SEPARATOR;
		aOutput.push(aPackets.length.toString(16));
		aOutput.push(sSep);
		for (var i = 0; i < aPackets.length; i++) {
			aOutput.push(aPackets[i].length.toString(16));
			aOutput.push(sSep);
			aOutput.push(aPackets[i]);
		}
		return aOutput.join('');
	},

	_getPacketInt: function(sPacket, iFrom) {
		var i = iFrom;
		var sNumber = '0x';
		var sSep = O876.LZW.PACKET_SEPARATOR;
		while (sPacket.substr(i, 1) != sSep) {
			sNumber += sPacket.substr(i, 1);
			i++;
		}
		var nNumber = parseInt(sNumber);
		if (isNaN(nNumber)) {
			throw new Error('corrupted data ' + sNumber);
		}
		return [parseInt(sNumber), i + 1];
	},

	_parsePackets: function(sPackets, nCount, iFrom) {
		var aGPI, nLength, aOutput = [];
		for (var i = 0; i < nCount; i++) {
			aGPI = O876.LZW._getPacketInt(sPackets, iFrom);
			nLength = aGPI[0];
			iFrom = aGPI[1];
			aOutput.push(sPackets.substr(iFrom, nLength));
			iFrom += nLength;
		}
		return aOutput;
	},

	_createEncodedPackets: function(s) {
		var i = 0;
		var o = [];
		var aOutput = [];
		do {
			o = O876.LZW._encodeFragment(s, i);
			i = o[1];
			aOutput.push(o[2]);
		} while (!o[0]);
		return aOutput;
	},

	_decodePackets: function(a) {
		var o = [];
		for (var i = 0; i < a.length; i++) {
			o.push(O876.LZW._decodeFragment(a[i]));
		}
		return o.join('');
	},

	_encodeFragment: function(s, iFrom) {
		var d = {};
		var i, iCode = 256;
		for (i = 0; i < 256; i++) {
			d[String.fromCharCode(i)] = i;
		}
		var w = '';
		var c;
		var wc;
		var o = [];
		var iIndex;
		var nLen = s.length;
		var bEnd = true;
		for (iIndex = iFrom; iIndex < nLen; iIndex++) {
			c = s.charAt(iIndex);
			wc = w + c;
			if (wc in d) {
				w = wc;
			} else {
				d[wc] = iCode++;
				o.push(d[w]);
				w = c;
			}
			if (d.length >= O876.LZW.DICT_SIZE) {
				bEnd = false;
				iIndex++;
				break;
			}
		}
		o.push(d[w]);
		for (i = 0; i < o.length; i++) {
			o[i] = String.fromCharCode(o[i] ^ O876.LZW.nMystificator);
		}
		return [bEnd, iIndex, o.join('')];
	},
	
	_decodeFragment: function(s) {
		var a;
		if (typeof s === 'string') {
			a = s.split('');
		} else {
			a = s;
		}
		for (var i = 0; i < a.length; i++) {
			a[i] = a[i].charCodeAt(0) ^ O876.LZW.nMystificator;
		}
		var c, w, e = '', o = [], d = [];
		for (i = 0; i < 256; i++) {
			d.push(String.fromCharCode(i));
		}
		c = a[0];
		o.push(w = String.fromCharCode(c));
		for (i = 1; i < a.length; i++) {
			c = a[i];
			if (c > 255 && d[c] !== undefined) {
				e = d[c];
			} else if (c > 255 && d[c] === undefined) {
				e = w + e.charAt(0);
			} else {
				e = String.fromCharCode(c);
			}
			o.push(e);
			d.push(w + e.charAt(0));
			w = e;
		}
		return o.join('');
	}
});

/** Collection à clés recyclables
 * les éléments sont identifiés par leur clé
 * les clés sont des indice numériques
 * la suppression d'un élément ne provoque pas de décalage
 * Les clés supprimées sont réutilisées lors de l'ajout de nouveaux éléments
 * Les trous sont peu fréquents et rapidement comblés
 */
O2.createClass('O876.Legion', {
	aItems: null,
	aRecycler: null,
	
	__construct: function() {
		this.aItems = [];
		this.aRecycler = [];
	},
	
	/** Ajoute un élément à la legion
	 * @param oItem élément à ajouter
	 * @return indice de l'élément
	 */
	link: function(oItem) {
		var nKey;
		if (this.aRecycler.length) {
			nKey = this.aRecycler.shift();
			this.aItems[nKey] = oItem;
		} else {
			nKey = this.aItems.length;
			this.aItems.push(oItem);
		}
		return nKey;
	},
	
	indexOf: function(oItem) {
		return this.aItems.index(oItem);
	},
	
	getItem: function(nKey) {
		if (nKey < this.aItems.length) {
			return this.aItems[nKey];
		} else {
			return null;
		}
	},
	
	unlink: function(xKey) {
		var nKey;
		if (typeof xKey == 'object') {
			nKey = this.indexOf(xKey);
		} else {
			nKey = xKey;
		}
		this.aItems[nKey] = null;
		this.aRecycler.push(nKey);
	}
});
/**
 * Cette classe permet de définir des cartes 2D
 * ou plus généralement des tableau 2D d'entier.
 * On entre une description texturelle composé 
 * d'un tableau de chaines de caractères.
 * Chacun de ces caractère sera remplacé par un entier
 * pour donner un tableau de tableau d'entiers
 * @param aMap tableau deux dimension contenant la carte
 * @oDic dictionnaire faisan correspondre les symbole de la carte à la valeur numérique finale
 */
O2.createObject('O876.MapTranslater', {
	process: function(aMap, oDic) {
		var x, y, aRow;
		var aOutput = [];
		var aRowOutput;
		
		for (y = 0; y < aMap.length; ++y) {
			aRow = aMap[y].split('');
			aRowOutput = [];
			for (x = 0; x < aRow.length; ++x) {
				aRowOutput.push(oDic[aRow[x]]);
			}
			aOutput.push(aRowOutput);
		}
		return aOutput;
	}
});

O2.createClass('O876.Mediator.Mediator', {

	_oPlugins: null,
	_oRegister: null,
	_oApplication: null,
	
	/**
	 * Constructeur
	 */
	__construct: function() {
		this._oPlugins = {};
		this._oRegister = {};
	},
	
	
	setApplication: function(a) {
		return this._oApplication = a;		
	},
	
	getApplication: function() {
		return this._oApplication;		
	},
	
	
	
	/**
	 * Ajoute un plugin
	 * @param oPlugin instance du plugin ajouté
	 * @return instance du plugin ajouté
	 */
	addPlugin: function(oPlugin) {
		if (!('getName' in oPlugin)) {
			throw new Error('O876.Mediator : anonymous plugin');
		}
		var sName = oPlugin.getName();
		if (sName === '') {
			throw new Error('O876.Mediator : undefined plugin name');
		}
		if (!('setMediator' in oPlugin)) {
			throw new Error('O876.Mediator : no Mediator setter in plugin ' + sName);
		}
		if (sName in this._oPlugins) {
			throw new Error('O876.Mediator : duplicate plugin entry ' + sName);
		}
		this._oPlugins[sName] = oPlugin;
		oPlugin.setMediator(this);
		if ('init' in oPlugin) {
			oPlugin.init();
		}
		return oPlugin;
	},
	
	removePlugin: function(x) {
		if (typeof x != 'string') {
			x = x.getName();
		}
		this._oPlugins[x] = null;
	},
	
	/**
	 * Renvoie le plugin dont le nom est spécifié
	 * Renvoie undefined si pas trouvé
	 * @param sName string
	 * @return instance de plugin
	 */
	getPlugin: function(sName) {
		return this._oPlugins[sName];
	},
	
	/**
	 * Enregistrer un plugin pour qu'il réagisse aux signaux de type spécifié
	 * @param sSignal type de signal
	 * @param oPlugin plugin concerné
	 */
	registerPluginSignal: function(sSignal, oPlugin) {
		if (this._oRegister === null) {
			this._oRegister = {};
		}
		if (sSignal in oPlugin) {
			if (!(sSignal in this._oRegister)) {
				this._oRegister[sSignal] = [];
			}
			if (this._oRegister[sSignal].indexOf(oPlugin) < 0) {
				this._oRegister[sSignal].push(oPlugin);
			}
		} else {
			throw new Error('O876.Mediator : no ' + sSignal + ' function in plugin ' + oPlugin.getName());
		}
	},
	
	/** 
	 * Retire le plugin de la liste des plugin signalisés
	 * @param sSignal type de signal
	 * @param oPlugin plugin concerné
	 */
	unregisterPluginSignal: function(sSignal, oPlugin) {
		if (this._oRegister === null) {
			return;
		}
		if (!(sSignal in this._oRegister)) {
			return;
		}
		var n = this._oRegister[sSignal].indexOf(oPlugin);
		if (n >= 0) {
			ArrayTools.removeItem(this._oRegister[sSignal], n);
		}
	},
	
	
	
	/**
	 * Envoie un signal à tous les plugins enregistré pour ce signal
	 * signaux supportés
	 * 
	 * damage(oAggressor, oVictim, nAmount) : lorsqu'une créature en blesse une autre
	 * key(nKey) : lorsqu'une touche est enfoncée ou relachée
	 * time : lorsqu'une unité de temps s'est écoulée
	 * block(nBlockCode, oMobile, x, y) : lorsqu'un block a été activé
	 */
	sendPluginSignal: function(s) {
		var i, p, pi, n;
		if (this._oRegister && (s in this._oRegister)) {
			p = this._oRegister[s];
			n = p.length;
			if (n) {
				var aArgs;
				if (arguments.length > 1) {
					aArgs = Array.prototype.slice.call(arguments, 1);
				} else {
					aArgs = [];
				}
				for (i = 0; i < n; i++) {
					pi = p[i];
					pi[s].apply(pi, aArgs);
				}
			}
		}
	}
});

O2.createClass('O876.Mediator.Plugin', {
	_oMediator: null,
	
	getName: function() {
		return '';
	},
	
	register: function(sType) {
		this._oMediator.registerPluginSignal(sType, this);
	},
	
	unregister: function(sType) {
		this._oMediator.unregisterPluginSignal(sType, this);
	},

	setMediator: function(m) {
		this._oMediator = m;
	},
	
	getPlugin: function(s) {
		return this._oMediator.getPlugin(s);
	}
});

/**
 * Système de génération de fenètre-mini-site
 * Permettant de créer un petit applicatif fenétré.
 */
O2.createClass('O876.Microsyte', {
	
	_sBlockId: '',
	_oHome: null,
	_oXHR: null,
	_nWidth: 0,
	_nHeight: 0,
	_xOrientation: 'left',
	_yOrientation: 'top',
	
	/**
	 * Constructeur : définition de l'élément block qui accueillera le site
	 * @param sId identifiant du block qui contient le site
	 */
	__construct: function(sId) {
		if (sId) {
			this.setHome(sId);
		}
	},
	
	/**
	 * Définition de l'élément block qui accueillera le site
	 * @param sId identifiant du block qui contient le site
	 */
	setHome: function(xId) {
		if (typeof xId === 'string') {
			this.setHome(document.getElementById(this._sBlockId = xId));
		} else {
			this._oHome = xId;
		}
	},
	
	/**
	 * Renvoie l'élément Home
	 * @throws erreur en cas de non-définition du home
	 */
	getHome: function() {
		if (!this._oHome) {
			throw new Error('home not defined');
		}
		return this._oHome;
	},

	/**
	 * Modifie la taille du Home
	 */
	setSize: function(w, h) {
		var oHome = this.getHome();
		this._nWidth = w;
		this._nHeight = h;
		oHome.style.width = w.toString() + 'px';
		oHome.style.height = h.toString() + 'px';
	},
	
	getPxValue: function(s) {
		var r = s.match(/^([0-9]+)px$/i);
		if (r) {
			return r[1] | 0;
		} else {
			return 0;
		} 
	},
	
	center: function() {
		var oHome = this.getHome();
		var p = this.getPxValue(window.getComputedStyle(oHome).padding);
		var w = -((this._nWidth + p) >> 1);
		var h = -((this._nHeight + p) >> 1);
		oHome.style.left = '50%';
		oHome.style.top = '50%';
		oHome.style.marginTop = h.toString() + 'px';
		oHome.style.marginLeft = w.toString() + 'px';
	},
	
	getSubItem: function(sSubItem) {
		var oTarget = this.getHome();
		if (sSubItem !== undefined && sSubItem !== null && sSubItem !== '') {
			oTarget = document.getElementById(sSubItem);
		}
		if (!oTarget) {
			throw new Error('target item not defined');
		}
		return oTarget;
	},
	
	/**
	 * Modifie le contenu du Home
	 * @param sHtml string nouveau contenu
	 */
	setHtml: function(sHtml, sSubItem) {
		this.getSubItem(sSubItem).innerHTML = sHtml;
	},
	
	/**
	 * Charge un nouveau contenu
	 */
	load: function(sUrl, sSubItem) {
		XHR.get(sUrl, (function(data) {
			this.setHtml(data, sSubItem);
		}).bind(this));
	},
	
	/**
	 * Fermeture de la fenetre du site
	 */
	hide: function() {
		this.getHome().style.display = 'none';
	},

	/**
	 * Réouverture de la fenetre du site
	 */
	show: function() {
		this.getHome().style.display = 'block';
	},
	
	clear: function(sSubItem) {
		this.getSubItem(sSubItem).innerHTML = '';
	},
	
	setLinkOrientation: function(x, y) {
		if (x === 'left' || x === 'right') {
			this._xOrientation = x;
		}
		if (y === 'top' || y === 'bottom') {
			this._xOrientation = y;
		}
	},
	
	linkDiv: function(sHtml, x, y, w, h, sSubItem) {
		var oDiv = this.getSubItem(sSubItem).appendChild(document.createElement('div'));
		oDiv.style.position = 'absolute';
		oDiv.style[this._xOrientation] = x.toString() + 'px';
		oDiv.style[this._yOrientation] = y.toString() + 'px';
		if (w !== undefined && w!== null) {
			oDiv.style.width = w.toString() + 'px';
		}
		if (h !== undefined && h!== null) {
			oDiv.style.height = h.toString() + 'px';
		}
		oDiv.innerHTML = sHtml;
		return oDiv;
	}
});

O2.createObject('O876.ParamGetter' , {
	parse: function(sSearch) {
		if (sSearch) {
			var nQuest = sSearch.indexOf('?');
			if (nQuest >= 0) {
				sSearch = sSearch.substr(nQuest + 1);
			} else {
				return {};
			}
		} else {
			sSearch = window.location.search.substr(1);
		}
		var match,
			pl     = /\+/g,  // Regex for replacing addition symbol with a space
			search = /([^&=]+)=?([^&]*)/g,
			query  = sSearch,
			_decode = function(s) {
				return decodeURIComponent(s.replace(pl, ' '));
			};
		var oURLParams = {};
		while (match = search.exec(query)) {
		   oURLParams[_decode(match[1])] = _decode(match[2]);
		}
		return oURLParams;
	}
});

/** Animation : Classe chargée de calculer les frames d'animation
 * O876 raycaster project
 * 2012-01-01 Raphaël Marandet
 */
O2.createClass('O876_Raycaster.Animation',  {
	nStart : 0, // frame de début
	nIndex : 0, // index de la frame en cours d'affichage
	nCount : 0, // nombre total de frames
	nDuration : 0, // durée de chaque frame, plus la valeur est grande plus l'animation est lente
	nTime : 0, // temps
	nLoop : 0, // type de boucle 1: boucle forward; 2: boucle yoyo
	nFrame: 0, // Frame actuellement affichée
	
	nDirLoop: 1,  // direction de la boucle (pour yoyo)
	
	assign: function(a) {
		if (a) {
			this.nStart = a.nStart;
			this.nCount = a.nCount;
			this.nDuration = a.nDuration;
			this.nLoop = a.nLoop;
			this.nIndex = a.nIndex % this.nCount;
			this.nTime = a.nTime % this.nDuration;
		} else {
			this.nCount = 0;
		}
	},
	
	animate : function(nInc) {
		if (this.nCount <= 1 || this.nDuration === 0) {
			return this.nIndex + this.nStart;
		}
		this.nTime += nInc;
		// Dépassement de duration (pour une seule fois)
		if (this.nTime >= this.nDuration) {
			this.nTime -= this.nDuration;
			this.nIndex += this.nDirLoop;
		}
		// pour les éventuels très gros dépassement de duration (pas de boucle)
		if (this.nTime >= this.nDuration) {
			this.nIndex += this.nDirLoop * (this.nTime / this.nDuration | 0);
			this.nTime %= this.nDuration;
		}
		/** older version
		while (this.nTime >= this.nDuration) {
			this.nTime -= this.nDuration;
			this.nIndex += this.nDirLoop;
		}*/
		
		switch (this.nLoop) {
			case 1:
				if (this.nIndex >= this.nCount) {
					this.nIndex = 0;
				}
			break;
				
			case 2:
				if (this.nIndex >= this.nCount) {
					this.nIndex = this.nCount - 2;
					this.nDirLoop = -1;
				}
				if (this.nIndex <= 0) {
					this.nDirLoop = 1;
					this.nIndex = 0;
				}
			break;
				
			default:
				if (this.nIndex >= this.nCount) {
					this.nIndex = this.nCount - 1;
				}
		}
		this.nFrame = this.nIndex + this.nStart;
		return this.nFrame;
	},

	reset : function() {
		this.nIndex = 0;
		this.nTime = 0;
		this.nDirLoop = 1;
	}
});

// Block fields manager
O2.createClass('O876_Raycaster.BF',  {
	getCode: function(n) {
		return n & 0xFF;
	},

	modifyCode: function(n, v) {
		return (n & 0xFFFFFF00) | v;
	},
	
	getPhys: function(n) {
		return (n >> 8) & 0xFF;
	},

	modifyPhys: function(n, v) {
		return (n & 0xFFFF00FF) | (v << 8);
	},
	
	getOffs: function(n) {
		return (n >> 16) & 0xFF;
	},

	modifyOffs: function(n) {
		return (n & 0xFF00FFFF) | (v << 16);
	},
});

/** Un blueprint est un élément de la palette de propriétés
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet
 * Les blueprint servent de modèle et de référence pour alimenter les propriétés des sprites créé dynamiquement pendant le jeu
 */
O2.createClass('O876_Raycaster.Blueprint', {
  sId: '',
  nType: 0,
  // propriétés visuelles
  oTile: null,        // référence objet Tile

  // propriétés physiques
  nPhysWidth: 0,      // Largeur zone impactable
  nPhysHeight: 0,     // Hauteur zone impactable
  sThinker: '',       // Classe de Thinker
  nFx: 0,             // Gfx raster operation
  oXData: null,       // Additional data

  __construct: function(oData) {
    if (oData !== undefined) {
      this.nPhysWidth = oData.width;
      this.nPhysHeight = oData.height;
      this.sThinker = oData.thinker;
      this.nFx = oData.fx;
      this.nType = oData.type;
      if ('data' in oData) {
        this.oXData = oData.data;
      } else {
        this.oXData = {};
      }
    }
  },

  getData: function(sData) {
    if (this.oXData && (sData in this.oXData)) {
      return this.oXData[sData];
    } else {
      return null;
    }
  }
});



/** Entrée sortie clavier
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet 
 * Memorise les touches clavier enfoncées
 */
O2.createClass('O876_Raycaster.KeyboardDevice', {
	aKeys: null,	// Index inversée Code->Action
	aKeyBuffer: null,
	nKeyBufferSize: 16,
	bUseBuffer: true,
	aAliases: null,

	__construct: function() {
		this.aKeys = [];
		this.aAliases = {};
		// Gros tableau pour capter plus rapidement les touches...
		// peu élégant et peu économe mais efficace.
		for (var i = 0; i < 256; i++) {
			this.aKeys.push(0);	 
		}
		this.aKeyBuffer = [];
	},
	
	setAliases: function(a) {
		this.aAliases = a;
	},

	keyAction: function(k, n) {
		this.aKeys[k] = n;
	},
	
	keyBufferPush: function(nKey) {
		if (this.bUseBuffer && nKey && this.aKeyBuffer.length < this.nKeyBufferSize) {
			this.aKeyBuffer.push(nKey);
		}
	},

	eventKeyUp: function(e) {
		var oEvent = window.event ? window.event : e;
		var nCode = oEvent.charCode ? oEvent.charCode : oEvent.keyCode;
		var oDev = window.__keyboardDevice;
		if (nCode in oDev.aAliases) {
			nCode = oDev.aAliases[nCode];
		}
		oDev.keyBufferPush(-nCode);
		oDev.keyAction(nCode, 2);
		return false;
	},

	eventKeyDown: function(e) {
		var oEvent = window.event ? window.event : e;
		var nCode = oEvent.charCode ? oEvent.charCode : oEvent.keyCode;
		var oDev = window.__keyboardDevice;
		if (nCode in oDev.aAliases) {
			nCode = oDev.aAliases[nCode];
		}
		oDev.keyBufferPush(nCode);
		oDev.keyAction(nCode, 1);
		return false;
	},

	/** 
	 * renvoie le code clavier de la première touche enfoncée du buffer FIFO
	 * renvoie 0 si aucune touche n'a été enfoncée
	 * @return int
	 */
	inputKey: function() {
		if (this.aKeyBuffer.length) {
			return this.aKeyBuffer.shift();
		} else {
			return 0;
		}
	},

	plugEvents: function() {
		window.__keyboardDevice = this;
		document.onkeyup = this.eventKeyUp;
		document.onkeydown = this.eventKeyDown;
	},
	
	unplugEvents: function() {
		window.__keyboardDevice = null;
		document.onkeyup = undefined;
		document.onkeydown = undefined;
	}

});


/** Entrée de la souris
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet 
 * Mémorise les coordonnée de la souris et les touche enfoncées
 */
O2.createClass('O876_Raycaster.MouseDevice', {
	nButtons: 0,
	aEvents: null,
	nKeyBufferSize: 16,
	bUseBuffer: true,
	nSecurityDelay: 0,
	oElement: null,
	
	__construct: function() {
		this.aEvents = [];
	},
	
	clearBuffer: function() {
		this.aEvents = [];
	},

	eventMouseUp: function(e) {
		var oEvent = window.event ? window.event : e;
		var oDev = window.__mouseDevice;
		oDev.nButtons = oEvent.buttons;
		if (oDev.bUseBuffer && oDev.aEvents.length < oDev.nKeyBufferSize) {
			oDev.aEvents.push([0, oEvent.clientX, oEvent.clientY, oEvent.button]);
		}
		return false;
	},

	eventMouseDown: function(e) {
		var oEvent = window.event ? window.event : e;
		var oDev = window.__mouseDevice;
		oDev.nButtons = oEvent.buttons;
		if (oDev.bUseBuffer && oDev.aEvents.length < oDev.nKeyBufferSize) {
			oDev.aEvents.push([1, oEvent.clientX, oEvent.clientY, oEvent.button]);
		}
		if (oEvent.button === 2) {
			if (oEvent.stopPropagation) {
				oEvent.stopPropagation();
			}
			oEvent.cancelBubble = true;
		}
		return false;
	},
	
	eventMouseClick: function(e) {
		var oEvent = window.event ? window.event : e;
		if (oEvent.button === 2) {
			if (oEvent.stopPropagation) {
				oEvent.stopPropagation();
			}
			oEvent.cancelBubble = true;
		}
		return false;
	},
	
	
	/** 
	 * Renvoie le prochain message souris précédemment empilé
	 * ou renvoie "undefined" s'il n'y a pas de message
	 * un message prend ce format :
	 * [ nUpOrDown, X, Y, Button ]
	 * nUpOrDown vaut 0 quand le bouton de la souris est relaché et vaut 1 quand le bouton est enfoncé
	 * il vaut 3 quand la molette de la souris est roulée vers le haut, et -3 vers le bas 
	 */
	inputMouse: function() {
		if (this.nSecurityDelay > 0) {
			--this.nSecurityDelay;
			this.clearBuffer();
			return null;
		} else {
			return this.aEvents.shift();
		}
	},
	
	mouseWheel: function(e) {
		var oEvent = window.event ? window.event : e;
		var oDev = window.__mouseDevice;
		var nDelta = 0;
		if (oEvent.wheelDelta) {
			nDelta = oEvent.wheelDelta; 
		} else {
			nDelta = -40 * oEvent.detail;
		}
		if (oDev.bUseBuffer && oDev.aEvents.length < oDev.nKeyBufferSize) {
			if (e.wheelDelta) {
				nDelta = oEvent.wheelDelta > 0 ? 3 : -3; 
				oDev.aEvents.push([nDelta, 0, 0, 3]);
			} else {
				nDelta = oEvent.detail > 0 ? -3 : 3;
				oDev.aEvents.push([nDelta, 0, 0, 3]);
			}
		}
	},


	/**
	 * Branche le handler de leture souris à l"élément spécifié
	 */
	plugEvents: function(oElement) {
		window.__mouseDevice = this;
		oElement.addEventListener('mousedown', this.eventMouseDown, false);
		oElement.addEventListener('click', this.eventMouseClick, false);
		oElement.addEventListener('mouseup', this.eventMouseUp, false);
		oElement.addEventListener('mousewheel', this.mouseWheel, false);
		oElement.addEventListener('DOMMouseScroll', this.mouseWheel, false);
		this.oElement = oElement;
	},
	
	unplugEvents: function() {
		var oElement = this.oElement;
		oElement.removeEventListener('mousedown', this.eventMouseDown, false);
		oElement.removeEventListener('click', this.eventMouseClick, false);
		oElement.removeEventListener('mouseup', this.eventMouseUp, false);
		oElement.removeEventListener('mousewheel', this.mouseWheel, false);
		oElement.removeEventListener('DOMMouseScroll', this.mouseWheel, false);
	},
	
	clearEvents: function() {
		this.aEvents = [];
	}
});


O2.createClass('O876_Raycaster.FrameCounter', {

	bCheck: false, // when true the FPS is being checked...
	bLoop: true,
	// if FPS is too low we decrease the LOD
	nFPS: 0,
	nTimeStart: null,
	nCount: 0,
	nSeconds: 0,
	nAcc: 0,
	
	/**
	 * Starts to count frames per second
	 */
	start: function(nTimeStamp) {
		this.nTimeStart = nTimeStamp;
		this.bCheck = true;
		this.nCount = 0;
	},
	
	getAvgFPS: function() {
		return ((this.nAcc / this.nSeconds) * 10 | 0) / 10;
	},

	/**
	 * count frames per second
	 */
	check: function(nNowTimeStamp) {
		if (this.nTimeStart === null) {
			this.start(nNowTimeStamp);
		}
		if (this.bCheck) {
			++this.nCount;
			if ((nNowTimeStamp - this.nTimeStart) >= 1000) {
				this.nFPS = this.nCount;
				this.nAcc += this.nCount;
				++this.nSeconds;
				this.bCheck = this.bLoop;
				if (this.bCheck) {
					this.start(nNowTimeStamp);
				}
				return true;
			}
		}
		return false;
	},

});

O2.createObject('O876_Raycaster.FullScreen', {
	enter: function(oElement) {
		oElement.requestFullScreen = oElement.requestFullScreen || oElement.webkitRequestFullScreen || oElement.mozRequestFullScreen;
		document.onfullscreenchange = O876_Raycaster.FullScreen.changeEvent;
		document.onwebkitfullscreenchange = O876_Raycaster.FullScreen.changeEvent;
		document.onmozfullscreenchange = O876_Raycaster.FullScreen.changeEvent;
		oElement.requestFullScreen(oElement.ALLOW_KEYBOARD_INPUT);
	},
	
	isFullScreen: function() {
		return document.webkitIsFullScreen || document.mozFullScreen;
	},
	
	changeEvent: function(oEvent) {
		
	}
	
});

/** GXEffect : Classe de base pour les effets graphiques temporisés
 * O876 raycaster project
 * 2012-01-01 Raphaël Marandet
 */
O2.createClass('O876_Raycaster.GXEffect', {
  sClass: 'Effect',
  oRaycaster: null,     // référence de retour au raycaster (pour le rendu)

  __construct: function(oRaycaster) {
    this.oRaycaster = oRaycaster;
  },

  /** Cette fonction doit renvoyer TRUE si l'effet est fini
   * @return bool
   */
  isOver: function() {
    return true;
  },

  /** Fonction appelée par le gestionnaire d'effet pour recalculer l'état de l'effet
   */
  process: function() {
  },

  /** Fonction appelée par le gestionnaire d'effet pour le rendre à l'écran
   */
  render: function() {
  },

  /** Fonction appelée lorsque l'effet se termine de lui même
   * ou stoppé par un clear() du manager
   */
  done: function() {
  },

  /** Permet d'avorter l'effet
   * Il faut coder tout ce qui est nécessaire pour terminer proprement l'effet
   * (restauration de l'état du laby par exemple)
   */
  terminate: function() {
  }
});


/** Effet graphique temporisé
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet
 * 
 * L'écran se colore graduellement d'une couleur unis
 * Permet de produire des effet de fade out pour faire disparaitre le contenu de l'écran
 * - oColor : couleur {r b g a} du fadeout
 * - fAlpha : opacité de départ
 * - fAlpha : Incrément/Décrément d'opacité
 */
O2.extendClass('O876_Raycaster.GXFade', O876_Raycaster.GXEffect, {
	sClass : 'FadeOut',
	oCanvas : null,
	oContext : null,
	nTime : 0,
	fAlpha : 0,
	fAlphaFade : 0,
	oColor : null,

	__construct : function(oRaycaster) {
		__inherited(oRaycaster);
		this.oCanvas = this.oRaycaster.oCanvas;
		this.oContext = this.oCanvas.getContext('2d');
	},

	isOver : function() {
		return this.fAlphaFade > 0 ? this.fAlpha >= 1 : this.fAlpha <= 0;
	},

	process : function() {
		this.oColor.a = this.fAlpha;
		if (this.oColor.a < 0) {
			this.oColor.a = 0;
		}
		if (this.oColor.a > 1) {
			this.oColor.a = 1;
		}
		this.fAlpha += this.fAlphaFade;
	},

	render : function() {
		this.oContext.fillStyle = GfxTools.buildRGBA(this.oColor);
		this.oContext.fillRect(0, 0, this.oCanvas.width, this.oCanvas.height);
	},

	terminate : function() {
		this.fAlpha = this.fAlphaFade > 0 ? 1 : 0;
	}
});

/** Effet graphique temporisé
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet
 * 
 * Colore l'ecran d'un couleur unique qui s'estompe avec le temps
 * Permet de produire des effet de flash rouge ou d'aveuglement
 * - oColor : couleur {r b g a} du flash
 * - fAlpha : opacité de départ
 * - fAlphaFade : Incrément/Décrément d'opacité
 */
O2.extendClass('O876_Raycaster.GXFlash', O876_Raycaster.GXEffect, {
  sClass: 'Flash',
  oCanvas: null,
  oContext: null,
  nTime: 0,
  fAlpha: 0,
  fAlphaFade: 0,
  oColor: null,

  __construct: function(oRaycaster) {
    __inherited(oRaycaster);
    this.oCanvas = this.oRaycaster.oCanvas;
    this.oContext = this.oCanvas.getContext('2d'); 
  },

  isOver: function() {
    return this.fAlpha <= 0;
  },

  process: function() {
    this.oColor.a = this.fAlpha;
    if (this.oColor.a < 0) { 
      this.oColor.a = 0;
    }
    if (this.oColor.a > 1) {
      this.oColor.a = 1;
    }
    this.fAlpha -= this.fAlphaFade;
  },

  render: function() {
    this.oContext.fillStyle = GfxTools.buildRGBA(this.oColor);
    this.oContext.fillRect(0, 0, this.oCanvas.width, this.oCanvas.height);
  },

  terminate: function() {
    this.fAlpha = 0;
  }
});



/** Gestionnaire d'effets temporisés
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet
 *
 * Cette classe gère les effet graphique temporisés
 */
O2.createClass('O876_Raycaster.GXManager', {
	aEffects : null, // liste des effets

	/** Le constructeur initialise la liste des effet à vide
	 */
	__construct : function() {
		this.aEffects = [];
	},

	/** Compte le nombre d'effets
	 * @return entier
	 */
	count : function() {
		return this.aEffects.length;
	},

	/** Permet d'ajouter un effet à la liste
	 * @param oEffect un nouveau GXEffect
	 * @return oEffect
	 */
	addEffect : function(oEffect) {
		this.aEffects.push(oEffect);
		return oEffect;
	},

	/** Supprime tous les effet actuels
	 * Lance la methode terminate de chacun d'eux
	 */
	clear : function() {
		for ( var i = 0; i < this.aEffects.length; ++i) {
			this.aEffects[i].terminate();
			this.aEffects[i].done();
		}
		this.aEffects = [];
	},

	/** Lance la methode process() de chaque effet
	 * Supprime les effet qui sont arrivé à terme
	 */
	process : function() {
		var i = this.aEffects.length - 1;
		while (i >= 0) {
			this.aEffects[i].process();
			if (this.aEffects[i].isOver()) {
				this.aEffects[i].done();
				ArrayTools.removeItem(this.aEffects, i);
			}
			i--;
		}
	},

	/** Lance la methode render() de chaque effet
	 */
	render : function() {
		var nLen = this.aEffects.length;
		for ( var i = nLen - 1; i >= 0; i--) {
			this.aEffects[i].render();
		}
	}
});

/**
 * Effet graphique temporisé O876 Raycaster project
 * 
 * @date 2012-01-01
 * @author Raphaël Marandet
 * 
 * Affichage d'un message au centre de l'écran - sMessage : Texte à afficher -
 * oColor : couleur {r b g a} du fadeout - fAlpha : opacité de départ - fAlpha :
 * Incrément/Décrément d'opacité
 */
O2.extendClass('O876_Raycaster.GXMessage', O876_Raycaster.GXEffect, {
	sClass: 'Message',
	oCanvas : null,
	oContext : null,
	nTime : 0,
	sMessage : '',
	oMessageCanvas : null,
	xPos : 0,
	yPos : 0,
	xTo : 0,
	yTo : 0,
	yOfs : 48,
	nState : 0,
	fAlpha : 1,
	aPath : null,
	iPath : 0,
	sTextAlign: 'left',
	xTextPos: 0,
	yTextPos: 0,
	nTextHeight: 13,
	fTimePerChar: 150,
	wSize: 512,
	hSize: 40,
	sFontFamily: 'monospace',
	
	// styles
	oStyle: {
		background: 'rgb(255, 255, 255)',
		border: 'rgb(64, 64, 64)',
		shadow: 'rgb(220, 220, 220)',
		text: 'rgb(0, 0, 0)',
		width: 512,
		height: 40,
		font: 'monospace 13',
		speed: 100,
		position: 48
	},
	
	
	oIcon: null,
	

	__construct : function(oRaycaster) {
		__inherited(oRaycaster);
		var s = this.oStyle;
		this.wSize = s.width;
		this.hSize = s.height;
		this.fTimePerChar = s.speed;
		this.yOfs = s.position;
		s.font.toString().split(' ').forEach((function(sFontProp) {
			if (sFontProp | 0) {
				this.nTextHeight = sFontProp | 0;
			} else {
				this.sFontFamily = sFontProp;
			}
		}).bind(this));
		this.oCanvas = this.oRaycaster.oCanvas;
		this.oContext = this.oCanvas.getContext('2d');
		this.oMessageCanvas = O876.CanvasFactory.getCanvas();
		this.oMessageCanvas.width = this.wSize; 
		this.oMessageCanvas.height = this.hSize;
		this.xPos = this.xTo = (this.oCanvas.width - this.oMessageCanvas.width) >> 1;
		this.yPos = 0;
		this.yTo = 16;
		this.xAcc = 0;
		this.yAcc = -2;
		this.buildPath();
		if (this.sTextAlign == 'center') {
			this.xTextPos = this.oMessageCanvas.width >> 1; 
		} else {
			this.xTextPos = this.oMessageCanvas.height >> 1; 
		}
		this.yTextPos = (this.nTextHeight >> 1) + (this.oMessageCanvas.height >> 1);
	},
	
	drawIcon: function(oSource, x, y, w, h) {
		var nOffset = (this.oMessageCanvas.height - 32) >> 1;
		this.oMessageCanvas.getContext('2d').drawImage(oSource, x, y, w, h, nOffset, nOffset, 32, 32);
		this.xTextPos += 32;
		this.oIcon = null;
	},
	
	setIcon: function(oSource, x, y, w, h) {
		this.oIcon = {
			src: oSource,
			x: x,
			y: y,
			w: w,
			h: h
		};
	},
	
	setMessage: function(sMessage) {
		this.sMessage = sMessage;
		this.nTime = sMessage.length * this.fTimePerChar / this.oRaycaster.TIME_FACTOR | 0;
	},
	
	getTime: function() {
		return this.nTime;
	},

	isOver : function() {
		return this.nState >= 4;
	},

	buildPath : function() {
		this.aPath = [];
		var nWeightPos = 1;
		var nWeightTo = 1;
		var nSum = nWeightPos + nWeightTo;
		var bMove;
		var xPos = this.xPos;
		var yPos = this.yPos;
		do {
			bMove = false;
			if (xPos != this.xTo) {
				if (Math.abs(xPos - this.xTo) < 1) {
					xPos = this.xTo;
				} else {
					xPos = (xPos * nWeightPos + this.xTo * nWeightTo) / nSum;
				}
				bMove = true;
			}
			if (yPos != this.yTo) {
				if (Math.abs(yPos - this.yTo) < 1) {
					yPos = this.yTo;
				} else {
					yPos = (yPos * nWeightPos + this.yTo * nWeightTo) / nSum;
				}
				bMove = true;
			}
			if (bMove) {
				this.aPath.push( [ xPos | 0, yPos + this.yOfs | 0, 1 ]);
			}
		} while (bMove && this.aPath.length < 20);
		for (var i = this.aPath.length - 2; i >= 0; i--) {
			this.aPath[i][2] = Math.max(0, this.aPath[i + 1][2] - 0.2); 
		}
	},

	movePopup : function() {
		if (this.iPath < this.aPath.length) {
			var aPos = this.aPath[this.iPath];
			this.xPos = aPos[0];
			this.yPos = aPos[1];
			this.fAlpha = aPos[2];
			this.iPath++;
		}
	},

	reverseMovePopup : function() {
		if (this.aPath.length) {
			var aPos = this.aPath.pop();
			this.xPos = aPos[0];
			this.yPos = aPos[1];
			this.fAlpha = aPos[2];
		}
	},

	// Début : création du message dans un canvas
	process : function() {
		switch (this.nState) {
		case 0:
			var sMessage = this.sMessage;
			var oCtx = this.oMessageCanvas.getContext('2d');
			oCtx.font = this.nTextHeight.toString() + 'px ' + this.sFontFamily;
			oCtx.textAlign = this.sTextAlign;
			oCtx.fillStyle = this.oStyle.background;
			oCtx.strokeStyle = this.oStyle.border;
			oCtx.fillRect(0, 0, this.oMessageCanvas.width, this.oMessageCanvas.height);
			oCtx.strokeRect(0, 0, this.oMessageCanvas.width, this.oMessageCanvas.height);
			if (this.oIcon) {
				this.drawIcon(this.oIcon.src, this.oIcon.x, this.oIcon.y, this.oIcon.w, this.oIcon.h);
			}
			var nTextWidth = oCtx.measureText(sMessage).width;
			if ((nTextWidth + this.xTextPos + 2) < this.wSize) {
				oCtx.fillStyle = this.oStyle.shadow;
				oCtx.fillText(sMessage, this.xTextPos + 2, this.yTextPos + 2);
				oCtx.fillStyle = this.oStyle.text;
				oCtx.fillText(sMessage, this.xTextPos, this.yTextPos);
			} else {
				// faut mettre sur deux lignes (mais pas plus)
				var sMessage2 = '';
				var aWords = sMessage.split(' ');
				while (aWords.length > 0 && (oCtx.measureText(sMessage2 + aWords[0]).width + this.xTextPos + 8) < this.wSize) {
					sMessage2 += aWords.shift();
					sMessage2 += ' ';
				}
				sMessage = aWords.join(' ');
				oCtx.fillStyle = this.oStyle.shadow;
				var yLine = (this.nTextHeight >> 1) + 2;
				oCtx.fillText(sMessage2, this.xTextPos + 2, this.yTextPos + 2 - yLine);
				oCtx.fillText(sMessage, this.xTextPos + 2, this.yTextPos + 2 + yLine);
				oCtx.fillStyle = this.oStyle.text;
				oCtx.fillText(sMessage2, this.xTextPos, this.yTextPos - yLine);
				oCtx.fillText(sMessage, this.xTextPos, this.yTextPos + yLine);
			}
			this.nState++;
			this.fAlpha = 0;
			break;

		case 1:
			this.movePopup();
			this.nTime--;
			if (this.nTime <= 0) {
				this.yTo = -this.oMessageCanvas.height;
				this.nState++;
			}
			break;

		case 2:
			if (this.aPath.length === 0) {
				this.nState++;
			}
			this.reverseMovePopup();
			break;

		case 3:
			this.oMessageCanvas = null;
			this.terminate();
			break;
		}
	},

	render : function() {
		if (this.fAlpha > 0) {
			var a = this.oContext.globalAlpha;
			this.oContext.globalAlpha = this.fAlpha;
			this.oContext.drawImage(this.oMessageCanvas,
					this.xPos | 0, this.yPos | 0);
			this.oContext.globalAlpha = a;
		}
	},

	terminate : function() {
		this.nState = 4;
	}
});

/**
 * Effet spécial temporisé O876 Raycaster project
 * 
 * @date 2012-01-01
 * @author Raphaël Marandet Cet effet gère l'ouverture et la fermeture des
 *         portes, ce n'est pas un effet visuel a proprement parlé L'effet se
 *         sert de sa référence au raycaster pour déterminer la présence
 *         d'obstacle génant la fermeture de la porte C'est la fonction de
 *         temporisation qui est exploitée ici, même si l'effet n'est pas
 *         visuel.
 */
O2.extendClass('O876_Raycaster.GXSecret', O876_Raycaster.GXEffect, {
	sClass : 'Secret',
	nPhase : 0, // Code de phase : les block secrets ont X
				// phases : 0: fermé(init), 1: ouverture block
				// 1, 2: ouverture block 2, 3: terminé
	oRaycaster : null, // Référence au raycaster
	x : 0, // position de la porte
	y : 0, // ...
	fOffset : 0, // offset de la porte
	fSpeed : 0, // vitesse d'incrémentation/décrémentation de la
				// porte
	nLimit : 0, // Limite d'offset de la porte

	__construct: function(r) {
		__inherited(r);
		this.nLimit = r.nPlaneSpacing;
	},
	
	isOver : function() {
		return this.nPhase >= 3;
	},

	seekBlockSecret : function(dx, dy) {
		if (this.oRaycaster.getMapPhys(this.x + dx,
				this.y + dy) == this.oRaycaster.PHYS_SECRET_BLOCK) {
			this.oRaycaster.setMapPhys(this.x, this.y, 0);
			Marker.clearXY(this.oRaycaster.oDoors, this.x,
					this.y);
			this.x += dx;
			this.y += dy;
			Marker.markXY(this.oRaycaster.oDoors, this.x,
					this.y, this);
			return true;
		}
		return false;
	},

	seekBlockSecret4Corners : function() {
		if (this.seekBlockSecret(-1, 0)) {
			return;
		}
		if (this.seekBlockSecret(0, 1)) {
			return;
		}
		if (this.seekBlockSecret(1, 0)) {
			return;
		}
		if (this.seekBlockSecret(0, -1)) {
			return;
		}
	},

	process : function() {
		switch (this.nPhase) {
			case 0: // init
				Marker.markXY(this.oRaycaster.oDoors, this.x,
						this.y, this);
				this.fSpeed = this.oRaycaster.TIME_FACTOR * 40 / 1000;
				this.nPhase++; /** no break here */
				// passage au case suivant
			case 1: // le block se pousse jusqu'a : offset > limite
				this.fOffset += this.fSpeed;
				if (this.fOffset >= this.nLimit) {
					this.fOffset = this.nLimit - 1;
					// rechercher le block secret suivant
					this.seekBlockSecret4Corners();
					this.nPhase++;
					this.fOffset = 0;
				}
				break;
	
			case 2: // le 2nd block se pousse jusqu'a : offset >
					// limite
				this.fOffset += this.fSpeed;
				if (this.fOffset >= this.nLimit) {
					this.fOffset = this.nLimit - 1;
					this.oRaycaster.setMapPhys(this.x,
							this.y, 0);
					Marker.clearXY(this.oRaycaster.oDoors, this.x,
							this.y);
					this.nPhase++;
					this.fOffset = 0;
				}
				break;
		}
		this.oRaycaster.setMapOffs(this.x, this.y,
				this.fOffset | 0);
	},

	terminate : function() {
		// en phase 0 rien n'a vraiment commencé : se
		// positionner en phase 3 et partir
		switch (this.nPhase) {
		case 0:
			this.nPhase = 3;
			Marker.clearXY(this.oRaycaster.oDoors, this.x, this.y);
			break;
	
		case 1:
		case 2:
			this.fOffset = 0;
			Marker.clearXY(this.oRaycaster.oDoors, this.x, this.y);
			this.oRaycaster.setMapPhys(this.x, this.y, 0);
			break;
		}
	}
});

/** Gestion de la horde de sprite
 * L'indice des éléments de cette horde n'a pas d'importance.
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet
 */
O2.createClass('O876_Raycaster.Horde',  {
	oRaycaster : null,
	oThinkerManager : null,
	aMobiles : null,
	aStatics : null,
	aSprites : null,
	oBlueprints : null,
	oTiles : null,
	nTileCount : 0,
	oImageLoader : null,
	oMobileDispenser : null,
	xTonari: [ 0, 0, 1, 1, 1, 0, -1, -1, -1 ],
	yTonari: [ 0, -1, -1, 0, 1, 1, 1, 0, -1 ],

	__construct : function(r) {
		this.oRaycaster = r;
		this.oImageLoader = this.oRaycaster.oImages;
		this.oMobileDispenser = new O876_Raycaster.MobileDispenser();
		this.aMobiles = [];
		this.aStatics = [];
		this.aSprites = [];
		this.oBlueprints = {};
		this.oTiles = {};
	},

	/** lance think pour chaque élément de la horde
	 */
	think : function() {
		var oMobile, aDiscarded = null;
		var i = 0;
		while (i < this.aMobiles.length) {
			oMobile = this.aMobiles[i];
			oMobile.think();
			if (oMobile.bActive) {
				i++;
			} else {
				if (aDiscarded === null) {
					aDiscarded = [];
				}
				aDiscarded.push(oMobile);
				this.unlinkMobile(oMobile);
				this.oMobileDispenser.pushMobile(oMobile.oSprite.oBlueprint.sId, oMobile);
			}
		}
		return aDiscarded;
	},

	/**
	 * {src, width, height, frames}
	 */
	defineTile : function(sId, aData) {
		this.nTileCount++;
		var oTile = new O876_Raycaster.Tile(aData);
		oTile.oImage = this.oImageLoader.load(oTile.sSource);
		this.oTiles[sId] = oTile;
		return oTile;
	},

	/**
	 * {id, tile, width, height, speed, rotspeed}
	 *   
	 */
	defineBlueprint : function(sId, aData) {
		var oBP = new O876_Raycaster.Blueprint(aData);
		oBP.oTile = this.oTiles[aData.tile];
		oBP.sId = sId;
		this.oBlueprints[sId] = oBP;
		this.oMobileDispenser.registerBlueprint(sId);
	},

	// {blueprint}
	defineSprite : function(aData) {
		var oSprite = new O876_Raycaster.Sprite();
		oSprite.oBlueprint = this.oBlueprints[aData.blueprint];
		this.aSprites.push(oSprite);
		return oSprite;
	},

	// Ajoute un mobile existant dans la liste
	/**
	 * @param oMobile
	 */
	linkMobile : function(oMobile) {
		oMobile.bActive = true;
		this.aMobiles.push(oMobile);
		return oMobile;
	},

	unlinkMobile : function(oMobile) {
		var nHordeRank = this.aMobiles.indexOf(oMobile);
		if (nHordeRank < 0) {
			this.unlinkStatic(oMobile);
			return;
		}
		ArrayTools.removeItem(this.aMobiles, nHordeRank);
	},
	

	unlinkStatic : function(oMobile) {
		var nHordeRank = this.aStatics.indexOf(oMobile);
		if (nHordeRank < 0) {
			return;
		}
		ArrayTools.removeItem(this.aStatics, nHordeRank);
		// Un static n'a pas de thinker il faut le sortir du laby ici.
        this.oRaycaster.oMobileSectors.unregister(oMobile);
        oMobile.xSector = -1;
        oMobile.ySector = -1;
	},
	

	/**
	 * Définition d'un Mobile
	 * @param aData donnée de définition
	 * @return O876_Raycaster.Mobile
	 */ 	
	defineMobile : function(aData) {
		var oMobile = new O876_Raycaster.Mobile();
		oMobile.oRaycaster = this.oRaycaster;
		oMobile.oSprite = this.defineSprite(aData);
		var oThinker = null;
		if (oMobile.oSprite.oBlueprint.sThinker !== null) {
			oThinker = this.oThinkerManager.createThinker(oMobile.oSprite.oBlueprint.sThinker);
		}
		oMobile.setThinker(oThinker);
		oMobile.fTheta = aData.angle;
		oMobile.nSize = oMobile.oSprite.oBlueprint.nPhysWidth >> 1;
		oMobile.setXY(aData.x, aData.y);
		if (oThinker) {
			this.linkMobile(oMobile);
		} else {
			this.aStatics.push(oMobile);
			oMobile.bVisible = true;
			oMobile.bEthereal = true;
			oMobile.bActive = true;
		}
		return oMobile;
	},

	/**
	 * Création d'un nouveau mobile
	 * @param sBlueprint string, blueprint
	 * @param x ...
	 * @param y position initiale
	 * @param fTheta angle initial
	 * @return O876_Raycaster.Mobile
	 */
	spawnMobile : function(sBlueprint, x, y, fTheta) {
		var oMobile = this.oMobileDispenser.popMobile(sBlueprint);
		if (oMobile === null) {
			var aData = {
				blueprint : sBlueprint,
				x : x,
				y : y,
				angle : fTheta
			};
			return this.defineMobile(aData);
		} else {
			this.linkMobile(oMobile);
			oMobile.fTheta = fTheta;
			oMobile.setXY(x, y);
			return oMobile;
		}
	},


	getMobile : function(n) {
		return this.aMobiles[n];
	},

	getMobileCount : function() {
		return this.aMobiles.length;
	},

	/** Test si le mobile spécifié entre en collision avec un autre mobile
	 */
	computeCollision : function(oMobile) {
		var xTonari = this.xTonari;
		var yTonari = this.yTonari;
		var oRegister = this.oRaycaster.oMobileSectors;
		var oSector;
		var i;
		var oOther, iOther, nSectorLength;
		for (i = 0; i < 9; i++) {
			oSector = oRegister.get(oMobile.xSector + xTonari[i],
					oMobile.ySector + yTonari[i]);
			if (oSector !== null) {
				nSectorLength = oSector.length;
				for (iOther = 0; iOther < nSectorLength; ++iOther) {
					oOther = oSector[iOther];
					if (oOther != oMobile) {
						if (oMobile.hits(oOther)) {
							oMobile.oMobileCollision = oOther;
							return;
						}
					}
				}
			}
		}
		oMobile.oMobileCollision = null;
	},
	
	getAllocatedMemory: function() {
		var nRes = 0, oTile;
		for (var s in this.oTiles) {
			oTile = this.oTiles[s];
			nRes += oTile.oImage.width * oTile.oImage.height * 4;
		}
		return nRes;
	}
});

/** Classe gérant le chargement des images
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet
 *
 */
O2.createClass('O876_Raycaster.ImageLoader', {
	oImages : null,
	aLoading : null,
	bComplete : false,
	nLoaded : 0,
	oStats: null,

	__construct : function() {
		this.oImages = {};
		this.aLoading = [];
		this.oStats = {
			images: {},
			totalsize: 0
		};
	},
	
	
	/** 
	 * Permet de vider les images déja chargées
	 */
	finalize: function() {
		this.aLoading = null;
		for(var i in this.oImages) {
			this.oImages[i] = null;
		}
		this.oImages = null;
		this.oStats = null;
	},

	/** Chargement d'une image.
	 * Si l'image est déja chargée, renvoie sa référence
	 * @param sUrl chaine url de l'image
	 * @return référence de l'objet image instancié
	 */
	load : function(sUrl) {
		if (!(sUrl in this.oImages)) {
			this.oImages[sUrl] = new Image();
			this.oImages[sUrl].src = sUrl;
		}
		this.bComplete = false;
		this.aLoading.push(this.oImages[sUrl]);
		// L'image n'est pas chargée -> on la mets dans la liste "en chargement"
		return this.oImages[sUrl];
	},

	complete : function() {
		if (this.bComplete) {
			return true;
		}
		this.nLoaded = 0;
	
		this.bComplete = true;
		for (var i = 0; i < this.aLoading.length; i++) {
			if (this.aLoading[i].complete) {
				this.nLoaded++;
			} else {
				this.bComplete = false;
			}
		}
		if (this.bComplete) {
			this.aLoading = [];
			var oImg;
			for (var sImg in this.oImages) {
				oImg = this.oImages[sImg];
				this.oStats.images[sImg] = oImg.width * oImg.height * 4;
				this.oStats.totalsize += this.oStats.images[sImg];
			}
		}
		return this.bComplete;
	},
	
	countLoading : function() {
		if (this.bComplete) {
			return this.nLoaded;
		} else {
			return this.aLoading.length;
		}
	},
	
	countLoaded : function() {
		return this.nLoaded;
	}
});

O2.createClass('O876_Raycaster.Minimap',  {

	oRaycaster: null,
	aSquares: null,
	aModified: null,
	aColors: null,
	oCanvas: null,
	oContext: null,
	
	aPixels: null,
	
	bRestricted : true, // affichage reduit pour ne pas detecter les autre joeur
	
	reset: function(oRaycaster) {
		this.aColors = [
              '#000000', // mur
              '#FF8888', // missiles
              '#00FF00', // mobiles
              '#00FFFF', 
              '#5588AA', // champ de vision
              '#FF00FF',
              '#FFFF00',
              '#555555', // vide             
              '#777777'  // placeable
		];
		this.oRaycaster = oRaycaster;
		this.aSquares = [];
		this.aModified = [
			[],
			[],
			[],
			[],
			[],
			[],
			[],
			[],
			[],
			[],
			[],
			[],
			[],
			[],
			[],
			[]
		];
		var aSqrRaw;
		var x, y;
		for (y = 0; y < this.oRaycaster.nMapSize; y++) {
			aSqrRaw = [];
			for (x = 0; x < this.oRaycaster.nMapSize; x++) {
				aSqrRaw.push([-1, false, x, y]);
			}
			this.aSquares.push(aSqrRaw);
		}
		if (this.oCanvas === null) {
			this.oCanvas = O876.CanvasFactory.getCanvas();
		}
		this.oCanvas.width = this.oCanvas.height = this.oRaycaster.nMapSize << 2;
		var ctx = this.oCanvas.getContext('2d');

		var pix = [];
		this.aColors.forEach(function(sItem, i, a) {
			var oID = ctx.createImageData(1, 1);
			var d = oID.data;
			d[0] = 100;//parseInt('0x' + sItem.substr(1, 2));
			d[1] = 200;//parseInt('0x' + sItem.substr(3, 2));
			d[2] = 50;//parseInt('0x' + sItem.substr(5, 2));
			d[3] = 1;
			pix.push(oID);
		});
		this.aPixels = pix;
		this.oContext = ctx;
	},
	
	setSquare: function(x, y, n) {
		var q = this.aSquares[y][x];
		if (q[0] != n) {
			q[0] = n;
			if (!q[1]) {
				q[1] = true;
				this.aModified[n].push(q);
			}
		}
	},
	
	getMobileColor: function(aMobiles) {
		var l = aMobiles.length;
		var m, nType, bPlaceable = false;
		for (var i = 0; i < l; ++i) {
			m = aMobiles[i];
			nType = m.getType();
			if (nType == RC.OBJECT_TYPE_PLAYER || nType == RC.OBJECT_TYPE_MOB) {
				return 2;
			}
			if (nType == RC.OBJECT_TYPE_MISSILE) {
				return 1;
			}
			if (nType == RC.OBJECT_TYPE_PLACEABLE) {
				bPlaceable = true;
			}
		}
		return bPlaceable ? 8 : 7;
	},
	
	render: function() {
		var rc = this.oRaycaster;
		var nMapSize = rc.nMapSize;
		var x, y, nColor;
		for (y = 0; y < nMapSize; y++) {
			for (x = 0; x < nMapSize; x++) {
				if (this.bRestricted && rc.oCamera.xSector === x && rc.oCamera.ySector === y) {
					nColor = 2;
				} else if (this.bRestricted === false && rc.oMobileSectors.get(x, y).length) {
					nColor = this.getMobileColor(rc.oMobileSectors.get(x, y));  // mobile
				} else if (Marker.getMarkXY(rc.aScanSectors, x, y)) {
					nColor = 4;  // champ de vision joueur
				} else if (rc.getMapPhys(x, y)) {
					nColor = 0;  // mur
				} else {
					nColor = 7;  // vide
				}
				this.setSquare(x, y, nColor);
			}
		}
		var q, mc, m = this.aModified;
		for (nColor = 0; nColor < m.length; nColor++) {
			if (this.aColors[nColor]) {
				mc = m[nColor];
				this.oContext.fillStyle = this.aColors[nColor];
				while (mc.length) {
					q = mc.shift();
					this.oContext.fillRect(q[2], q[3], 1, 1);
					q[1] = false;
				}
			}
		}
		rc.oRenderContext.drawImage(this.oCanvas, 2, 2);
	}
	
});

/** La classe mobile permet de mémoriser la position des objets circulant dans le laby
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet
 */
O2.createClass('O876_Raycaster.Mobile', {
	oRaycaster: null,						// Référence de retour au raycaster
	x: 0,									// position du mobile
	y: 0,									// ...
	xSave: 0,
	ySave: 0,

	// flags
	bActive: false,							// Flag d'activité
	bEthereal: false,						// Flage de collision globale

	fTheta: 0,								// Angle de rotation
	fMovingAngle: 0,						// Angle de déplacement
	fSpeed: 0,								// Vitesse de déplacement initialisée à partir du blueprint du sprite
	fMovingSpeed: 0,						// Dernière vitesse enregistrée
	fRotSpeed: 0,							// Vitesse de rotation initialisée à partir du blueprint du sprite
	xInertie: 0,							// Vitesse utilisée pour accelerer les calculs...
	yInertie: 0,							// ... lorsque vitesse et angle sont conservée
	xSpeed: 0,								// Dernière vitesse X appliquée
	ySpeed: 0,								// Dernière vitesse Y appliquée
	xSector: -1,							// x Secteur d'enregistrement pour les collision ou les test de proximité
	ySector: -1,							// y ...	
	nSectorRank: -1,						// Rang dans le secteur pour un repérage facile
	nSize: 16,								// Taile du polygone de collision mobile-mur
	oSprite: null,							// Référence du sprite
	xCollisions: [0, 1, 0, -1],	// Tableau des collision
	yCollisions: [-1, 0, 1, 0],	// ...
	oThinker: null,
	oWallCollision: null,					// x: bool : on bumpe un mur qui empeche la progression en X
	oMobileCollision: null,
	oFrontCell: null,						// coordonnées du bloc devant soit

	nBlueprintType: null,					// type de mobile : une des valeurs de GEN_DATA.blueprintTypes
	bSlideWall: true,						// True: corrige la trajectoire en cas de collision avec un mur
	bVisible: true,							// Visibilité au niveau du mobile (le sprite dispose de sont propre flag de visibilité prioritaire à celui du mobile)
	bWallCollision: false,

	oData: null,


	getBlueprint: function(sXData) {
		if (this.oSprite) {
			if (sXData === undefined) {
				return this.oSprite.oBlueprint;
			} else {
				if (this.oSprite.oBlueprint) {
					return this.oSprite.oBlueprint.getData(sXData);
				} else {
					return null;
				}
			}
		} else {
			return null;
		}
	},

	/** Renvoie le type de blueprint
	 * Si le mobile n'a pas de sprite (et n'a pas de blueprint)
	 * On renvoie 0, c'est généralement le cas pour le mobile-caméra
	 */
	getType: function() {
		if (this.nBlueprintType === null) {
			if (this.oSprite) {
				this.nBlueprintType = this.oSprite.oBlueprint.nType;
			} else if (this == this.oRaycaster.oCamera){
				this.nBlueprintType = RC.OBJECT_TYPE_PLAYER;
			} else {
				this.nBlueprintType = RC.OBJECT_TYPE_NONE;
			}
		}
		return this.nBlueprintType;
	},

	setData: function(sData, xValue) {
		if (this.oData === null) {
			this.oData = {};
		}
		if (xValue === undefined || xValue === null) {
			delete this.oData[sData];
		} else {
			this.oData[sData] = xValue;
		}
	},

	/** 
	 * Permet de récupérer des données de l'objet local Data
	 * ou de l'objet oXData du blueprint
	 * (local en priorité)
	 * @param sData nom de la donnée
	 * @return valeur de la donnée
	 */
	getData: function(sData) {
		if (this.oData === null) {
			this.oData = {};
		}
		if (sData in this.oData) {
			return this.oData[sData];
		} else {
			return this.getBlueprint(sData);
		}
	},

	// évènements

	setThinker: function(oThinker) {
		this.oThinker = oThinker;
		if (oThinker) {
			this.oThinker.oMobile = this;
		}
		this.oWallCollision = {x: 0, y: 0};
		this.gotoLimbo();
	},
	
	getThinker: function() {
		return this.oThinker;
	},

	think: function() {
		this.xSave = this.x;
		this.ySave = this.y;
		if (this.oThinker) {
			this.xSpeed = 0;
			this.ySpeed = 0;
			this.oThinker.think();
		}
	},
	
	/** Modifie l'angle de la caméra d'un delta.
	 * @param f float delta en radiant
	 */
	rotate: function(f) {
		this.setAngle(this.fTheta + f);
	},

	setAngle: function(f) {
		this.fTheta = f;
		var f2Pi = 2 * PI;
		if (f > 0) {
			while (this.fTheta >= PI) {
				this.fTheta -= f2Pi;
			}
		} else {
			while (this.fTheta < -PI) {
				this.fTheta += f2Pi;
			}
		}
	},
	
	getAngle: function(f) {
		return this.fTheta;
	},	
	
	/** 
	 * Renvoie les coordonnée du bloc devant le mobile
	 * @param oMobile
	 * @return object x y
	 */
	getFrontCellXY: function() {
		if (this.oFrontCell === null) {
			this.oFrontCell = {};
		}
		var rc = this.oRaycaster;
		var nActionRadius = rc.nPlaneSpacing * 0.75;
		this.oFrontCell.x = (this.x + Math.cos(this.fTheta) * nActionRadius) / rc.nPlaneSpacing | 0;
		this.oFrontCell.y = (this.y + Math.sin(this.fTheta) * nActionRadius) / rc.nPlaneSpacing | 0;
		return this.oFrontCell;
	},


	/** Quitte la grille de collision de manière à ne plus interférer avec les autres sprites
	 *
	 */
	gotoLimbo: function() {
		this.oRaycaster.oMobileSectors.unregister(this);
		this.xSector = -1;
		this.ySector = -1;
	},

	/** Modifie la position du mobile
	 * @param x nouvelle position x
	 * @param y nouvelle position y
	 */
	setXY: function(x, y) {
		var rc = this.oRaycaster;
		var ps = rc.nPlaneSpacing;
		this.x = x;
		this.y = y;
		var xs = x / ps | 0;
		var ys = y / ps | 0;
		if (xs != this.xSector || ys != this.ySector) {
			rc.oMobileSectors.unregister(this);
			this.xSector = xs;
			this.ySector = ys;
			rc.oMobileSectors.register(this);
		}
		// collision intersprites
		this.oRaycaster.oHorde.computeCollision(this);
	},

	rollbackXY: function() {
		var ps = this.oRaycaster.nPlaneSpacing;
		this.x = this.xSave;
		this.y = this.ySave;
		this.xSpeed = 0;
		this.ySpeed = 0;
		var xs = this.x / ps | 0;
		var ys = this.y / ps | 0;
		if (xs != this.xSector || ys != this.ySector) {
			this.oRaycaster.oMobileSectors.unregister(this);
			this.xSector = xs;
			this.ySector = ys;
			this.oRaycaster.oMobileSectors.register(this);
		}
	},

	/**
	 * Fait glisser le mobile
	 * détecte les collision avec le mur
	 */
	slide: function(dx, dy) {
		var xc = this.xCollisions;
		var yc = this.yCollisions;
		var x = this.x;
		var y = this.y;
		var ix, iy;
		var ps = this.oRaycaster.nPlaneSpacing;
		var nSize = this.nSize;
		var wc = this.oWallCollision;
		wc.x = 0;
		wc.y = 0;
		var nXYFormula = (Math.abs(dx) > Math.abs(dy) ? 1 : 0) | ((dx > dy) || (dx == dy && dx < 0) ? 2 : 0);
		var bCorrection = false;
		var xClip, yClip;
		var bCrashWall = !this.bSlideWall;
		this.bWallCollision = false;
		for (var i = 0; i < 4; ++i) {
			if (nXYFormula == i) {
				continue;
			}
			ix = nSize * xc[i] + x;
			iy = nSize * yc[i] + y;
			xClip = this.oRaycaster.clip(ix + dx, iy, 1);
			yClip = this.oRaycaster.clip(ix, iy + dy, 1);
			if (xClip) {
				dx = 0;
				if (bCrashWall) {
					dy = 0;
				}
				wc.x = xc[i];
				bCorrection = true;
			}
			if (yClip) {
				dy = 0;
				if (bCrashWall) {
					dx = 0;
				}
				wc.y = yc[i];
				bCorrection = true;
			}
		}
		this.bWallCollision = bCorrection;
		if (bCorrection) {
			if (wc.x > 0) {
				x = (x / ps | 0) * ps + ps - 1 - nSize;
			} else if (wc.x < 0) {
				x = (x / ps | 0) * ps + nSize;
			}
			if (wc.y > 0) {
				y = (y / ps | 0) * ps + ps - 1 - nSize;
			} else if (wc.y < 0) {
				y = (y / ps | 0) * ps + nSize;
			}
			bCorrection = false;
		}
		this.setXY(x + dx, y + dy);
		this.xSpeed = dx;
		this.ySpeed = dy;
	},
	
	

	/** Déplace la caméra d'un certain nombre d'unité vers l'avant
	 * @param fDist float Distance de déplacement
	 */
	move: function(fAngle, fDist) {
		if (this.fMovingAngle != fAngle || this.fMovingSpeed != fDist) {
			this.fMovingAngle = fAngle;
			this.fMovingSpeed = fDist;
			this.xInertie = Math.cos(fAngle) * fDist;
			this.yInertie = Math.sin(fAngle) * fDist;
		}
		this.slide(this.xInertie, this.yInertie);
	},

	/** Test de collision avec le mobile spécifié
	 * @param oMobile mobile susceptible d'entrer en collision
	 * @returnn bool
	 */
	hits: function(oMobile) {
		if (this.bEthereal || oMobile.bEthereal) {
			return false;
		}
		var dx = oMobile.x - this.x;
		var dy = oMobile.y - this.y;
		var d2 = dx * dx + dy * dy;
		var dMin = this.nSize + oMobile.nSize;
		dMin *= dMin;
		return d2 < dMin;
	},

	/** Fait tourner le mobile dans le sens direct en fonction de la vitesse de rotation
	 * si la vitesse est négative le sens de rotation est inversé
	 */
	rotateLeft: function() {
		this.rotate(-this.fRotSpeed);
	},

	/** Fait tourner le mobile dans le sens retrograde en fonction de la vitesse de rotation
	 * si la vitesse est négative le sens de rotation est inversé
	 */
	rotateRight: function() {
		this.rotate(this.fRotSpeed);
	},

	/** Déplace le mobile vers l'avant, en fonction de sa vitesse
	 */
	moveForward: function() {
		this.move(this.fTheta, this.fSpeed);
	},

	/** Déplace le mobile vers l'arrière, en fonction de sa vitesse
	 */
	moveBackward: function() {
		this.move(this.fTheta, -this.fSpeed);
	},

	/** Déplace le mobile d'un mouvement latéral vers la gauche, en fonction de sa vitesse
	 */
	strafeLeft: function() {
		this.move(this.fTheta - PI / 2, this.fSpeed);
	},

	/** Déplace le mobile d'un mouvement latéral vers la droite, en fonction de sa vitesse
	 */
	strafeRight: function() {
		this.move(this.fTheta + PI / 2, this.fSpeed);
	}
});


/** Classe de distribution optimisée de mobiles
 * O876 Raycaster project
 * @date 2012-04-04
 * @author Raphaël Marandet 
 * 
 * Classe gérant une liste de mobile qui seront réutilisé à la demande.
 * Cette classe permet de limiter le nom de d'instanciation/destruction
 */
O2.createClass('O876_Raycaster.MobileDispenser', {
  aBlueprints: null,

  __construct: function() {
    this.aBlueprints = {};
  },

  registerBlueprint: function(sId) {
    this.aBlueprints[sId] = [];
  },

  /** Ajoute un mobile dans sa pile de catégorie
   */
  pushMobile: function(sBlueprint, oMobile) {
    this.aBlueprints[sBlueprint].push(oMobile);
  },

  /**
   * @return O876_Raycaster.Mobile
   */
	popMobile: function(sBlueprint) {
		if (!(sBlueprint in this.aBlueprints)) {
			throw new Error('no such blueprint : "' + sBlueprint + '"');
		}
		if (this.aBlueprints[sBlueprint].length) {
			return this.aBlueprints[sBlueprint].pop();
		} else {
			return null;
		}  
	},

  render: function() {
    var sRender = '';
    for (var sBlueprint in this.aBlueprints) {
      if (this.aBlueprints[sBlueprint].length) {
        sRender += '[' + sBlueprint + ': ' + this.aBlueprints[sBlueprint].length.toString() + ']';
      }
    }
    return sRender;
  }
});

/** Registres des mobiles. Permet d'enregistrer les mobile dans les secteurs composant le labyrinthe et de pouvoir
 * Organiser plus efficacement les collisions inter-mobile (on n'effectue les tests de collision qu'entre les mobiles des secteur proches).
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet
 */
O2.createClass('O876_Raycaster.MobileRegister', {
  aSectors: null,         // Secteurs
  nSize: 0,               // Taille des secteur (diviseur position mobile -> secteur)

  /** Construit l'instance en initialisant la taille des secteur 
   * @param n int, taille des secteurs
   */
  __construct: function(n) {
    var x, y;
    this.nSize = n;
    this.aSectors = {};
    for (x = 0; x < n; x++) {
      this.aSectors[x] = {};
      for (y = 0; y < n; y++) {
        this.aSectors[x][y] = [];
      }
    }
  },

  /** Renvoie la référence d'un secteur, la fonction n'effectue pas de test de portée, aussi attention aux paramètres foireux.
   * @param x position du secteur recherché
   * @param y ...
   * @return Secteur trouvé
   */
  get: function(x, y) {
    if (x >= 0 && y >= 0 && y < this.nSize && x < this.nSize) {
      return this.aSectors[x][y];
    } else {
      return null;
    }
  },
  
  /** Désenregistre un mobile de son secteur
   * @param oMobile mobile à désenregistrer
   */
  unregister: function(oMobile) {
    if (oMobile.xSector < 0 || oMobile.ySector < 0 || oMobile.xSector >= this.nSize || oMobile.ySector >= this.nSize) {
      return;
    }
    var aSector = this.aSectors[oMobile.xSector][oMobile.ySector];
    var n = oMobile.nSectorRank;
    if (n == (aSector.length - 1)) {
      aSector.pop();
      oMobile.nSectorRank = -1;
    } else {
      aSector[n] = aSector.pop();
      aSector[n].nSectorRank = n;
    }
  },

  /** Enregistre en mobile dans son secteur, le mobile sera enregistré dans le secteur qu'il occupe réellement, calculé à partir de sa position
   * @param oMobile
   */
  register: function(oMobile) {
    if (oMobile.xSector < 0 || oMobile.ySector < 0 || oMobile.xSector >= this.nSize || oMobile.ySector >= this.nSize) {
      return;
    }
    var aSector = this.aSectors[oMobile.xSector][oMobile.ySector];
    var n = aSector.length;
    aSector.push(oMobile);
    oMobile.nSectorRank = n;
  }
});


/**
 * Api de gestion du fullscreen et de la capture de souris
 */

O2.createObject('O876_Raycaster.PointerLock', {
	
	oElement: null,
	oHookInstance: null,
	oHookFunction: null,
	bInitialized: null,
	bLocked: false,
	bEnabled: true,
	
	hasPointerLockFeature: function() {
		return 'pointerLockElement' in document || 'mozPointerLockElement' in document;
	},
	
	init: function() {
		if (!O876_Raycaster.PointerLock.hasPointerLockFeature()) {
			return false;
		}
		if (O876_Raycaster.PointerLock.bInitialized) {
			return true;
		}
		document.addEventListener('pointerlockchange', O876_Raycaster.PointerLock.eventChange, false);
		document.addEventListener('mozpointerlockchange', O876_Raycaster.PointerLock.eventChange, false);
		document.addEventListener('pointerlockerror', O876_Raycaster.PointerLock.eventError, false);
		document.addEventListener('mozpointerlockerror', O876_Raycaster.PointerLock.eventError, false);
		O876_Raycaster.PointerLock.bInitialized = true;
		return true;
	},
	
	/**
	 * Renvoie TRUE si le pointer à été desactivé
	 */
	locked: function() {
		return O876_Raycaster.PointerLock.bLocked;
	},
	
	/**
	 * La fonction Hook doit être écrite de la manière suivante :
	 * myEventFunction: function(xMode, yMove) { ...
	 */
	setHook: function(oFunction, oInstance) {
		O876_Raycaster.PointerLock.oHookInstance = oInstance || window;
		O876_Raycaster.PointerLock.oHookFunction = oFunction;
	},

	requestPointerLock: function(oElement) {
		if (!O876_Raycaster.PointerLock.bEnabled) {
			return;
		}
		if (O876_Raycaster.PointerLock.locked()) {
			return;
		}
		O876_Raycaster.PointerLock.oElement = oElement;
		oElement.requestPointerLock = oElement.requestPointerLock || oElement.mozRequestPointerLockWithKeys || oElement.mozRequestPointerLock;
		oElement.requestPointerLock();
	},
	
	exitPointerLock: function() {
		if (!O876_Raycaster.PointerLock.locked()) {
			return;
		}
		document.exitPointerLock = document.exitPointerLock || document.mozExitPointerLock;
		document.exitPointerLock();
	},

	eventChange: function(e) {
		var oPointerLockElement = document.pointerLockElement || document.mozPointerLockElement;
		if (oPointerLockElement) {
			document.addEventListener('mousemove', O876_Raycaster.PointerLock.eventMouseMove, false);
			O876_Raycaster.PointerLock.bLocked = true;
		} else {
			document.removeEventListener('mousemove', O876_Raycaster.PointerLock.eventMouseMove, false);
			O876_Raycaster.PointerLock.oElement = null;
			O876_Raycaster.PointerLock.bLocked = false;
		}
	},
	
	eventError: function(e) {
		console.error('PointerLock error', e);
	},
	
	eventMouseMove: function(e) {
		var xMove = e.movementX || e.mozMovementX || 0;
		var yMove = e.movementY || e.mozMovementY || 0;
		var p = O876_Raycaster.PointerLock;
		if (p.oHookFunction) {
			p.oHookFunction.apply(p.oHookInstance, [xMove, yMove]);
		}
	}
});

/**
 * Raycasting engine
 * -----------------
 * Writen by Raphael Marandet
 * raphael.marandet@gmail.com
 * 
 * Inspiration : 
 * 2 web sites gave me inspiration to create this engine.
 * #1 the first one : 
 *   Raytracing Engine
 *   C0D3D by Gunnar Leffler
 *   http://www.leftech.com/raycaster.htm
 *   Version 1.0
 *   
 * #2 the second one :
 *   http://arguingwithmyself.com/demos/raycaster/
 *   I looked at version 1
 *
 * I took one function from each (CastRay() from #1 and DrawScreen() from #2), 
 * merged them both and added some features.
 * - sprite support with alpha
 * - semi-transparent walls (with windows, iron bars, grates...).
 * - doors (one panel, two panels, sliding up, squeezing up). 
 * - secret doors (just like wolfenstein 3D secret walls).
 * - ambient light and darkness.
 * - weapon canvas layer.
 * - speed optimization.
 * - raster effects.
 * - ...
 */


/** Notes:
 * 
 * Raycaster configuration JSO
 * 
 * raycasterConfig = {
 *   canvas: string | HTMLCanvasElement,   // canvas id or canvas instance
 *   drawMap: boolean,   // drawing map or not
 * }
 */
 
/* jshint undef: false, unused: true */
/* globals O2, PI, O876, O876_Raycaster, GfxTools, ArrayTools, Marker, MathTools */
 
O2.createClass('O876_Raycaster.Raycaster',  {
	// Laby Phys Properties
	PHYS_NONE : 0x00,
	PHYS_WALL : 0x01,

	// Laby door properties
	PHYS_FIRST_DOOR : 0x02,
	PHYS_DOOR_SLIDING_UP : 0x02,
	PHYS_CURT_SLIDING_UP : 0x03,
	PHYS_DOOR_SLIDING_DOWN : 0x04,
	PHYS_CURT_SLIDING_DOWN : 0x05,
	PHYS_DOOR_SLIDING_LEFT : 0x06,
	PHYS_DOOR_SLIDING_RIGHT : 0x07,
	PHYS_DOOR_SLIDING_DOUBLE : 0x08,

	PHYS_LAST_DOOR : 0x08,

	PHYS_SECRET_BLOCK : 0x09,
	PHYS_TRANSPARENT_BLOCK : 0x0A,
	PHYS_INVISIBLE_BLOCK : 0x0B,
	PHYS_OFFSET_BLOCK : 0x0C,
	PHYS_DOOR_D : 0x0D,
	PHYS_DOOR_E : 0x0E,
	PHYS_DOOR_F : 0x0F,
	// Permet de régler les évènements liés au temps
	TIME_FACTOR : 50,  // c'est le nombre de millisecondes qui s'écoule entre chaque calcul

	// World Render params
	oWall : null,
	oFloor : null,
	oBackground : null,
	nMapSize : 0,
	aMap : null,
	oVisual : null,
	nPlaneSpacing : 64,
	nShadingFactor : 50,
	nShadingThreshold : 15,    // default 15
	nDimmedWall : 7,
	oDoors : null,
	oXMap : null, // Données supplémentaires pour chaque faces d'un block
	oMinimap: null,

	// Textures
	xTexture : 64,
	yTexture : 96,

	// Viewport
	oCanvas : null,
	oContext : null,
	oRenderCanvas : null,
	oRenderContext : null,
	
	bUseVideoBuffer : true, // true: semble plus rapide sur chromium
	bGradient: true, // dessine des gradients
	bFloor : true,	// utilise le rendu du sol (automatiquement positionné selon le world def)
	bCeil : true,	// active le plafond
	bSky: false,		// active le ciel
	bFlatSky: false,	// a utiliser si le plafond a des "trous" au travers desquels on peut voir le ciel.
		// sinon on ne pourra voir le ciel qu'a travers les fenetre

	nZoom : 1,
	wCanvas : 0, // ratio 0.625
	hCanvas : 0,
	xScrSize : 0,
	yScrSize : 0,
	fViewAngle : 0,
	fViewHeight: 1,

	// Rendu des murs
	nRayLimit: 100,
	bExterior : false,
	nMeteo : 0,
	fCameraBGOfs : 0,
	fDist : 1,
	bSideWall : false,
	nWallPanel : 1,
	nWallPos : 1,
	xWall : 0,
	yWall : 0,
	aZBuffer : null,
	oContinueRay: null,
	
	// sprites
	oHorde : null,
	aScanSectors : null,
	aWallSectors : null,
	oMobileSectors : null,
	oThinkerManager : null,
	aVisibleMobiles: null,
	aDiscardedMobiles: null,

	// weapon Layer
	oWeaponLayer: null,

	oImages : null,

	// Effects
	oEffects : null,

	// Data
	aWorld : null,
	oConfig : null,
	
	oUpper: null,
	
	setConfig : function(oConfig) {
		if (this.oConfig === null) {
			this.oConfig = oConfig;
		} else {
			for (var i in oConfig) {
				this.oConfig[i] = oConfig[i];
			}
		}
	},

	/** Définition des données initiale du monde
	 * @param aWorld objet contenant des définition de niveau
	 */
	defineWorld : function(aWorld) {
		this.aWorld = aWorld;
	},
	
	getMapSize: function() {
		return this.nMapSize;
	},

	initialize : function() {
		this.fViewAngle = PI / 4;
		if (this.oConfig.planeSpacing) {
			this.nPlaneSpacing = this.oConfig.planeSpacing; 
			this.xTexture = this.oConfig.planeSpacing; 
		}
		if (this.oConfig.wallHeight) {
			this.yTexture = this.oConfig.wallHeight; 
		}
		if (this.oCanvas === null) {
			this.initCanvas();
		}
		this.setDetail(1);
		this.aZBuffer = [];
		this.oEffects = new O876_Raycaster.GXManager();
		if (this.oImages === null) {
			this.oImages = new O876_Raycaster.ImageLoader();
		}
		this.oThinkerManager = new O876_Raycaster.ThinkerManager();
		this.oContinueRay = { bContinue: false };
		this.oWeaponLayer = {
			canvas: null,
			x: -1024,
			y: 0,
			width: 0,
			height: 0,
			index: 0,
			alpha: 1,
			zoom: 1
		};
		// économiser la RAM en diminuant le nombre de shading degrees
		if (this.oConfig.shades) {
			this.nShadingThreshold = this.oConfig.shades;
		}
		
		switch (this.nShadingThreshold) {
			case 0:
				this.nDimmedWall = 0;
				break;
				
			case 1:
				this.nDimmedWall = 1;
				break;
				
			default:
				this.nDimmedWall = Math.round(this.nShadingThreshold / 3);
				break;
		}
	},
	
	finalize: function() {
		this.oEffects.clear();
		this.oEffects = null;
		this.oImages.finalize();
		this.oImages = null;
		this.oThinkerManager = null;
	},

	/** Le shade process est un processus qui peut prendre du temps
	 * aussi proposons nous un callback destiné à afficher une barre de progression
	 */
	shadeProcess : function() {
		if (this.nShadingThreshold === 0) {
			return true;
		}
		var i = '';
		var w = this.shadeImage(this.oWall.image, false);
		this.oWall.image = w;
		if (this.bFloor) {
			w = this.shadeImage(this.oFloor.image, false);
			this.oFloor.image = w;
		}
		
		for (i in this.oHorde.oTiles) {
			if (this.oHorde.oTiles[i].bShading) {
				w = this.shadeImage(this.oHorde.oTiles[i].oImage, true);
				this.oHorde.oTiles[i].bShading = false;
				this.oHorde.oTiles[i].oImage = w;
				return false;
			}
		}
		return true;
	},
	
	drawUpper: function() {
		this.oUpper.fViewHeight = this.fViewHeight + 2; 
		this.oUpper.drawScreen();
	},
	
	getDiscardedMobiles: function() {
		return this.aDiscardedMobiles;
	},

	frameProcess : function() {
		this.aDiscardedMobiles = this.updateHorde();
		this.oEffects.process();
	},

	frameRender : function() {
		this.drawScreen();
		this.oEffects.render();
	},
	
	/**
	 * Retreive a tile
	 */
	getTile: function(sTile) {
		return this.oHorde.oTiles[sTile];
	},
	
	/**
	 * An emergency fonction which decrease the level of detail
	 * because the computer is too slow
	 */
	downgrade: function() {
		this.oCanvas.width >>= 1;
		this.oCanvas.height >>= 1;
		this.xScrSize >>= 1;
		this.yScrSize >>= 1;
		this.backgroundRedim();
		if (this.oUpper) {
			this.oUpper.xScrSize >>= 1;
			this.oUpper.yScrSize >>= 1;
		}
	},

	addGXEffect: function(G) {
		var g = new G(this);
		this.oEffects.addEffect(g);
		return g;
	},
	
	/** Rendu graphique de l'arme
	 * canvas : référence du canvas source
	 * index : numero de la frame affiché
	 * width : largeur en pixel d'une frame
	 * height : hauteur d'une frame
	 * x : position du sprite à l'écran
	 * y : *        *         *
	 * zoom : zoom appliqué au sprite 
	 */
	drawWeapon: function() {
		var w = this.oWeaponLayer;
		if (w.index >= 0 && w.canvas) {
			var fAlpha = 1;
			if (w.alpha != 1) {
				fAlpha = this.oRenderContext.globalAlpha;
				this.oRenderContext.globalAlpha = w.alpha;
			}
			this.oRenderContext.drawImage(
				w.canvas,    // canvas des tiles d'arme 
				w.index * w.width,   
				0, 
				w.width, 
				w.height, 
				w.x, 
				w.y, 
				w.width * w.zoom | 0, 
				w.height * w.zoom | 0
			);
			if (w.alpha != 1) {
				this.oRenderContext.globalAlpha = fAlpha;
			}
		}
	},

	buildLevel : function() {
		this.oHorde = null;
		this.oEffects.clear();
		this.aScanSectors = null;
		this.aWallSectors = null;
		this.oMobileSectors = null;
		this.buildMap();
		this.buildHorde();
	},

	updateHorde : function() {
		return this.oHorde.think();
	},

	initCanvas : function() {
		if (typeof this.oConfig.canvas == 'string') {
			this.oCanvas = document.getElementById(this.oConfig.canvas);
		} else if (typeof this.oConfig.canvas == 'object' && this.oConfig.canvas !== null) {
			this.oCanvas = this.oConfig.canvas;
		} else {
			throw new Error('initCanvas failed: configuration object needs a valid canvas entry (dom or string id)');
		}
		if (this.wCanvas) {
			this.oCanvas.width = this.wCanvas;
		}
		if (this.hCanvas) {
			this.oCanvas.height = this.hCanvas;
		}
		this.oContext = this.oCanvas.getContext('2d');
		if (this.bUseVideoBuffer) {
			if (this.oRenderCanvas === null) {
				this.oRenderCanvas = O876.CanvasFactory.getCanvas();
			}
			this.oRenderCanvas.height = this.oCanvas.height;
			this.oRenderCanvas.width = this.oCanvas.width;
			this.oRenderContext = this.oRenderCanvas.getContext('2d');
		} else {
			this.oRenderCanvas = this.oCanvas;
			this.oRenderContext = this.oContext;
		}
		if ('smoothTextures' in this.oConfig) {
			this.oRenderContext.mozImageSmoothingEnabled = this.oConfig.smoothTextures;
			this.oRenderContext.webkitImageSmoothingEnabled = this.oConfig.smoothTextures;
		}
		this.xScrSize = this.oCanvas.width;
		this.yScrSize = this.oCanvas.height >> 1;
	},
	
	getRenderContext: function() {
		return this.oRenderContext;
	},

	getRenderCanvas: function() {
		return this.oRenderCanvas;
	},

	/** Modification du détail 
	 * @param nDetail 0: interdit ; 1: haute qualité ; 2: bonne qualité ; 4 basse qualité
	 */
	setDetail : function(nDetail) {
		switch (nDetail) {
			case 1:
				this.nZoom = 1;
				this.xScrSize = this.oCanvas.width;
				this.drawFloor = this.drawFloor_zoom1;
				this.drawFloorAndCeil = this.drawFloorAndCeil_zoom1;
				break;
				
			default:
				throw new Error('setting detail is now deprecated. Use css resizing instead');
		}
	},

	loadImage : function(sUrl) {
		return this.oImages.load(sUrl);
	},
	
	
	filterImage : function(oImage, f) {
		if (f) {
			var oCtx = oImage.getContext('2d');
			var oImgData = oCtx.getImageData(0, 0, oImage.width, oImage.height);
			var aPixData = oImgData.data;
			var nPixCount = aPixData.length;
			var fr = f.r, fg = f.g, fb = f.b;
			/*var b255 = function(x) {
				return Math.min(255, Math.max(0, x | 0));
			};*/
			for (var iPix = 0; iPix < nPixCount; iPix += 4) {
				aPixData[iPix] = Math.min(255, Math.max(0, aPixData[iPix] * fr | 0));     //b255(aPixData[iPix] * fr); 
				aPixData[iPix + 1] = Math.min(255, Math.max(0, aPixData[iPix + 1] * fg | 0));     //b255(aPixData[iPix + 1] * fg); 
				aPixData[iPix + 2] = Math.min(255, Math.max(0, aPixData[iPix + 2] * fb | 0));    //b255(aPixData[iPix + 1] * fb); 
			}
			oCtx.putImageData(oImgData, 0, 0);
		}
	},

	/** Le shading est un traitement long et est soumis à une limite de temps
	 * Si la fonction dépasse le temps limite elle se termine
	 */
	shadeImage : function(oImage, bSprite) {
		if (oImage.__shaded) {
			return oImage;
		}
		// Récupération du Shaded en cours (ou création d'un nouveau)
		var oShaded = O876.CanvasFactory.getCanvas();
		oShaded.width = oImage.width;
		oShaded.height = oImage.height * (this.nShadingThreshold + 1);
		var oCtx = oShaded.getContext('2d');
		var g;
		var nMethod = 1;
		g = {
			r : this.oVisual.fogColor.r,
			g : this.oVisual.fogColor.g,
			b : this.oVisual.fogColor.b
		};
		// Maximiser le filter
		if (bSprite && this.oVisual.filter) {
			var oFilteredImage;
			oFilteredImage = O876.CanvasFactory.getCanvas();
			oFilteredImage.width = oImage.width;
			oFilteredImage.height = oImage.height;
			oFilteredImage.getContext('2d').drawImage(oImage, 0, 0);
			this.filterImage(oFilteredImage, this.oVisual.filter);
			oImage = oFilteredImage;
		}
		var fAlphaMin = this.oVisual.diffuse || 0;
		// i : 0 -> shadingThreshold
		// f : 0 -> 1
		// f2 : fAlphaMin -> 1
		for ( var i = 0; i <= this.nShadingThreshold; i++) {
			g.a = Math.min(i / this.nShadingThreshold, 1) * (1 - fAlphaMin);
			switch (nMethod) {
				case 0: // Méthode conservant l'Alpha (ne marche pas sous moz)
					oCtx.globalCompositeOperation = 'source-over';
					oCtx.drawImage(oImage, 0, i * oImage.height);
					oCtx.fillStyle = GfxTools.buildRGBA(g);
					oCtx.fillRect(0, i * oImage.height, oImage.width,
							oImage.height);
					oCtx.globalCompositeOperation = 'destination-in';
					oCtx.drawImage(oImage, 0, i * oImage.height);
					oCtx.globalCompositeOperation = 'source-over';
					break;

				case 1:
					oCtx.drawImage(oImage, 0, i * oImage.height);
					oCtx.globalCompositeOperation = 'source-atop';
					oCtx.fillStyle = GfxTools.buildRGBA(g);
					oCtx.fillRect(0, i * oImage.height, oImage.width,
							oImage.height);
					oCtx.globalCompositeOperation = 'source-over';
					break;

				case 2:
					oCtx.drawImage(oImage, 0, i * oImage.height);
					oCtx.globalCompositeOperation = 'source-over';
					break;
			}
		}
		oShaded.__shaded = true;
		return oShaded;
	},

	/**
	 * Clonage de mur.
	 * La texture nSide du pan mur spécifié par x, y est copiée dans un canvas transmis 
	 * à une function callBack. à charge de cette fonction de dessiner ce qu'elle veux dans 
	 * ce canvas cloné. cette modification sera reportée dans le jeu.
	 *   
	 * @param x coordonnée X du mur
	 * @param y coordonnée Y du mur
	 * @param nSide coté du mur 0:nord, 1:est, 2:sud, 3:ouest
	 * @param pDrawingFunction fonction qui servira à déssiner le mur (peut être un tableau [instance, function],
	 * cette fonction devra accepter les paramètres suivants :
	 * - param1 : instance du raycaster
	 * - param2 : instance du canvas qui contient le clone de la texture.
	 * - param3 : coordoonée X du mur
	 * - param4 : coordoonée Y du mur
	 * - param5 : coté du mur concerné
	 */
	cloneWall : function(x, y, nSide, pDrawingFunction) {
		var c = this.oXMap.cloneTexture(this.oWall.image, this.aWorld.walls.codes[this.getMapCode(x, y)][nSide], x, y, nSide);
		pDrawingFunction(this, c, x, y, nSide);
		this.shadeCloneWall(c, x, y, nSide);
	},

	shadeCloneWall : function(oCanvas, x, y, nSide) {
		var a = this.shadeImage(oCanvas, false);
		this.oXMap.get(x, y, nSide).oCanvas = a;
		return a;
	},
	
	cloneFlat: function(x, y, nSide, pDrawingFunction) {
		var iTexture = this.aWorld.flats.codes[this.getMapCode(x, y)][nSide];
		if (iTexture < 0) {
			return;
		}
		var c = this.oXMap.cloneTexture(this.oFloor.image, iTexture, x, y, nSide + 4);
		nSide += 4;
		pDrawingFunction(this, c, x, y, nSide);
		c = this.shadeCloneWall(c, x, y, nSide);
		// faire l'image map du canvas
		var b = this.oXMap.get(x, y, nSide);
		var oCtx = c.getContext('2d');
		b.imageData = oCtx.getImageData(0, 0, c.width, c.height);
		b.imageData32 = new Uint32Array(b.imageData.data.buffer);
	},

	/* Code map
	 * Numéro de Tile (byte)
	 * Propriété physique (byte)
	 * - 0: pas d'état
	 * - 1: porte coulissant vers le haut
	 * - 2: porte coulissant vers le bas
	 * - 3: porte coulissant vers la gauche
	 * - 4: porte coulissant vers la droite
	 * Transitionneur (nombre permettant de faire evoluer un etat) (byte)
	 * - 1, 2, 3, 4: Offset de déplacement

	 */
	/** Vérifie l'existance d'une série de clé dans un objet
	 * @param oObj objet à vérifier
	 * @param aKeys liste des clés
	 * @return bool true : l'objet est OK, false : il manque une ou plusieur clé
	 */
	checkObjectStructure : function(oObj, xKeys) {
		// clé composée
		if (ArrayTools.isArray(xKeys)) {
			for (var i = 0; i < xKeys.length; i++) {
				this.checkObjectStructure(oObj, xKeys[i]);
			}
			return true;
		}
		if (xKeys.indexOf('.') >= 0) {
			var aKeys = xKeys.split('.');
			var sKey0 = aKeys.shift();
			if (this.checkObjectStructure(oObj, sKey0)) {
				// Vérifier premier objet
				return this.checkObjectStructure(oObj[sKey0], aKeys.join('.'));
			} else {
				throw new Error('invalid object structure: missing key [' + xKeys + ']');
			}
		} else {
			if (typeof oObj != 'object') {
				throw new Error('invalid object type : ' + (typeof oObj) + ' ; can not contain key [' + xKeys + ']');
			}
			if (oObj === null) {
				throw new Error('object is null, and can not contain key [' + xKeys + ']');
			}
			if (xKeys in oObj) {
				return true;
			} else {
				throw new Error('invalid object structure: missing key [' + xKeys + ']');
			}
		}
	},

	/** Construction de la map avec les donnée contenues dans aWorld
	 */
	buildMap : function() {
		var oData = this.aWorld;
		// verifier integrité des données
		try {
			this.checkObjectStructure(oData, [
			'map.length',
			'walls.src',
			'walls.codes',
			'startpoint.x',
			'startpoint.y',
			'startpoint.angle',
			'visual'
			]);
		} catch (e) {
			
		}
		this.nMapSize = oData.map.length;
		this.oMobileSectors = new O876_Raycaster.MobileRegister(
				this.nMapSize);
		this.oDoors = Marker.create();
		this.aMap = [];
		var yMap, xMap;
		for (yMap = 0; yMap < oData.map.length; ++yMap) {
			this.aMap[yMap] = new Uint32Array(oData.map[yMap].length);
			for (xMap = 0; xMap < oData.map[yMap].length; ++xMap) {
				this.aMap[yMap][xMap] = oData.map[yMap][xMap];
			}
		}
		this.oWall = {
			image : this.loadImage(oData.walls.src),
			codes : oData.walls.codes,
			animated : 'animated' in oData.walls ? oData.walls.animated : {}
		};
		if ('flats' in oData) {
			this.bFloor = true;
			var bEmptyCeil = oData.flats.codes.every(function(item) {
				if (item) {
					return item[1] === -1;
				} else {
					return true;
				}
			});
			var bEmptyFloor = oData.flats.codes.every(function(item) {
				if (item) {
					return item[0] === -1;
				} else {
					return true;
				}
			});
			this.bCeil = !bEmptyCeil;
			this.bFloor = !bEmptyFloor;
			if (this.bFloor) {
				this.oFloor = {
					image : this.loadImage(oData.flats.src),
					codes : oData.flats.codes,
					imageData : null,
					imageData32 : null,
					renderSurface32 : null
				};
			}
		} else {
			this.bFloor = false;
			this.bCeil = false;
		}
		if ('background' in oData && oData.background) {
			this.oBackground = this.loadImage(oData.background);
			this.bSky = true;
		} else {
			this.oBackground = null;
			this.bSky = false;
		}
		// construction des textures animées
		this.buildAnimatedTextures();
		// Définition de la caméra
		this.oCamera = new O876_Raycaster.Mobile();
		this.oCamera.oRaycaster = this;
		this.oCamera.fSpeed = 8;
		this.oCamera.fRotSpeed = 0.1;
		this.oCamera.xSave = this.oCamera.x = oData.startpoint.x;
		this.oCamera.ySave = this.oCamera.y = oData.startpoint.y;
		this.oCamera.xSector = this.oCamera.x / this.nPlaneSpacing | 0;
		this.oCamera.ySector = this.oCamera.y / this.nPlaneSpacing | 0;
		this.oCamera.fTheta = oData.startpoint.angle;
		this.oCamera.bActive = true;
		this.oVisual = {
			ceilColor: oData.visual.ceilColor,		// couleur du plafond au pixel le plus proche
			floorColor: oData.visual.floorColor,	// couleur du sol au pixel le plus proche
			light: oData.visual.light,				// puissance lumineuse combinée à la distance pour déterminer la luminosité final d'un objet 
			diffuse: oData.visual.diffuse,			// luminosité minimale de tout objet ou mur
			filter: oData.visual.filter,			// filtre coloré appliqué aux sprites
			fogDistance: oData.visual.fogDistance,	// indice du gradient correspondant à la fogColor (0..1)
			fogColor: oData.visual.fogColor			// couleur du fog
		};
		this.buildGradient();
		// Extra Map
		this.oXMap = new O876_Raycaster.XMap();
		this.oXMap.setBlockSize(this.xTexture, this.yTexture);
		this.oXMap.setSize(this.nMapSize, this.nMapSize);
		if ('uppermap' in oData && !!oData.uppermap) {
			this.buildSecondFloor();
		}
	},
	
	backgroundRedim: function() {
		var oBackground = this.oBackground;
		var dh = this.yScrSize << 1;
		if (oBackground && oBackground.height != dh) {
			var sw = oBackground.width;
			var sh = oBackground.height;
			var dw = sw * dh / sh | 0;
			var bg2 = O876.CanvasFactory.getCanvas();
			bg2.height = dh;
			bg2.width = dw;
			var ctx = bg2.getContext('2d');
			ctx.drawImage(oBackground, 0, 0, sw, sh, 0, 0, dw, dh);
			this.oBackground = bg2;
		}
	},
	
	/**
	 * Ajoute un second étage au raycaster
	 */
	buildSecondFloor: function() {
		// Ajout du second étage
		var oData = this.aWorld;
		if ('uppermap' in oData) {
			var SELF = this.constructor;
			var urc = new SELF();
			urc.TIME_FACTOR = this.TIME_FACTOR;
			urc.setConfig(this.oConfig);
			urc.bUseVideoBuffer = false;
			urc.initialize();
			var oUpperWorld = {
				map: oData.uppermap,
				walls: oData.walls,
				visual: oData.visual,
				startpoint: oData.startpoint,
				tiles: oData.tiles,
				blueprints: {},
				objects: []
			};
			urc.defineWorld(oUpperWorld);
			urc.buildMap();
			urc.bGradient = false;
			urc.oCamera = this.oCamera;
			urc.oWall = this.oWall;
			//urc.oCanvas = this.oCanvas;
			//urc.oContext = this.oContext;
			urc.oRenderCanvas = this.oRenderCanvas;
			urc.oRenderContext = this.oRenderContext;
			this.oUpper = urc;
		}
	},

	buildHorde : function() {
		this.oHorde = new O876_Raycaster.Horde(this);
		this.oHorde.oThinkerManager = this.oThinkerManager;
		var aData = this.aWorld;
		var oTiles = aData.tiles;
		var oBlueprints = aData.blueprints;
		var oMobs = aData.objects;
		this.oHorde.linkMobile(this.oCamera);
		var i = '';
		for (i in oTiles) {
			this.oHorde.defineTile(i, oTiles[i]);
		}
		for (i in oBlueprints) {
			this.oHorde.defineBlueprint(i, oBlueprints[i]);
		}
		for (i = 0; i < oMobs.length; i++) {
			this.oHorde.defineMobile(oMobs[i]);
		}
	},

	/** Création des gradient
	 * pour augmenter la luz :
	 * this.oVisual.light = 200; 
	 * this.oVisual.fogDistance = 1; 
	 * G.oRaycaster.buildGradient();
	 */
	buildGradient : function() {
		var g;
		this.oVisual.gradients = [];
		g = this.oRenderContext.createLinearGradient(0, 0, 0, this.oCanvas.height >> 1);
		g.addColorStop(0, GfxTools.buildRGBA(this.oVisual.ceilColor));
		if (this.oVisual.fogDistance < 1) {
			g.addColorStop(this.oVisual.fogDistance, GfxTools.buildRGBA(this.oVisual.fogColor));
		}
		g.addColorStop(1, GfxTools.buildRGBA(this.oVisual.fogColor));
		this.oVisual.gradients[0] = g;

		g = this.oRenderContext.createLinearGradient(0, this.oCanvas.height - 1, 0, (this.oCanvas.height >> 1) + 1);
		g.addColorStop(0, GfxTools.buildRGBA(this.oVisual.floorColor));
		if (this.oVisual.fogDistance < 1) {
			g.addColorStop(this.oVisual.fogDistance, GfxTools.buildRGBA(this.oVisual.fogColor));
		}
		g.addColorStop(1, GfxTools.buildRGBA(this.oVisual.fogColor));
		this.oVisual.gradients[1] = g;

		this.nShadingFactor = this.oVisual.light;
	},
	
	insideMap: function(x) {
		return x >= 0 && x < this.nMapSize;
	},

	/** Lance un rayon dans la map actuelle
	 * Lorsque le rayon frappe un mur opaque, il s'arrete et la fonction renvoie la liste
	 * des secteur traversé (visible).
	 * La fonction mets à jour un objet contenant les propriétés suivantes :
	 *   nWallPanel    : Code du Paneau (texture) touché par le rayon
	 *   bSideWall     : Type de coté (X ou Y)
	 *   nSideWall     : Coté
	 *   nWallPos      : Position du point d'impact du rayon sur le mur
	 *   xWall         : position du mur sur la grille
	 *   yWall         :  "       "       "       "
	 *   fDist         : longueur du rayon
	 * @param oData objet de retour
	 * @param x position de la camera
	 * @param y    "      "      "
	 * @param dx pente du rayon x (le cosinus de son angle)
	 * @param dy pente du rayon y (le sinus de son angle)
	 * @param aExcludes tableau des cases semi transparente que le rayon peut traverser
	 * @param aVisibles tableau des cases visitées par le rayon
	 */
	projectRay : function(oData, x, y, dx, dy, aExcludes, aVisibles) {
		var side = 0;
		var map = this.aMap;
		var nMapSize = this.nMapSize;
		var nScale = this.nPlaneSpacing;

		//raycount++;
		var xi, yi, xt, dxt, yt, dyt, t, dxi, dyi, xoff, yoff, cmax = oData.nRayLimit;
		
		var oContinue = oData.oContinueRay;
		
		
		// Le continue sert à se passer de refaire le raycast depuis la 
		// source (camera), on mémorise xi et yi
		if (oContinue.bContinue) {
			xi = oContinue.xi;
			yi = oContinue.yi;
		} else {
			xi = x / nScale | 0;
			yi = y / nScale | 0;
		}
		xoff = (x / nScale) - xi;
		yoff = (y / nScale) - yi;
		if (dx < 0) {
			xt = -xoff / dx;
			dxt = -1 / dx;
			dxi = -1;
		} else {
			xt = (1 - xoff) / dx;
			dxt = 1 / dx;
			dxi = 1;
		}
		if (dy < 0) {
			yt = -yoff / dy;
			dyt = -1 / dy;
			dyi = -1;
		} else {
			yt = (1 - yoff) / dy;
			dyt = 1 / dy;
			dyi = 1;
		}
		
		var xScale = nScale * dx;
		var yScale = nScale * dy;
		
		t = 0;
		var done = 0;
		var c = 0;
		var bStillVisible = true;
		var nOfs, nTOfs = 0;
		var nText;
		
		var Marker_getMarkXY = Marker.getMarkXY;
		var Marker_markXY = Marker.markXY;

		var nPhys;
		var nPHYS_FIRST_DOOR = this.PHYS_FIRST_DOOR;
		var nPHYS_LAST_DOOR = this.PHYS_LAST_DOOR;
		var nPHYS_SECRET_BLOCK = this.PHYS_SECRET_BLOCK;
		var nPHYS_OFFSET_BLOCK = this.PHYS_OFFSET_BLOCK;
		var nPHYS_TRANSPARENT_BLOCK = this.PHYS_TRANSPARENT_BLOCK;
		var xint = 0, yint = 0;
		
		var sameOffsetWall = this.sameOffsetWall;
		var BF = O876_Raycaster.BF;
		var BF_getPhys = BF.getPhys;
		var BF_getOffs = BF.getOffs;
		
		while (done === 0) {
			if (xt < yt) {
				xi += dxi;
				if (xi >= 0 && xi < nMapSize) {
					nText = map[yi][xi];
					nPhys = (nText >> 12) & 0xF; // **code12** phys
					
					if (nText !== 0	&& Marker_getMarkXY(aExcludes, xi, yi)) {
						nPhys = nText = 0;
					}
					
					if (nPhys >= nPHYS_FIRST_DOOR && nPhys <= nPHYS_LAST_DOOR) {
						// entre PHYS_FIRST_DOOR et PHYS_LAST_DOOR
						nOfs = nScale >> 1;
					} else if (nPhys == nPHYS_SECRET_BLOCK || nPhys == nPHYS_TRANSPARENT_BLOCK || nPhys == nPHYS_OFFSET_BLOCK) {
						// PHYS_SECRET ou PHYS_TRANSPARENT
						nOfs = (nText >> 16) & 0xFF; // **Code12** offs
					} else {
						nOfs = 0;
					}
					
					if (nOfs) {
						xint = x + xScale * xt;
						yint = y + yScale * xt;
						if (sameOffsetWall(nOfs, xint, yint, xi, yi, dx, dy, nScale)) { // Même mur -> porte
							nTOfs = (dxt / nScale) * nOfs;
							yint = y + yScale * (xt + nTOfs);
							if (((yint / nScale | 0)) != yi) {
								nPhys = nText = 0;
							}
							if (nText !== 0	&& Marker_getMarkXY(aExcludes, xi, yi)) {
								nPhys = nText = 0;
							}
						} else { // pas même mur -> wall
							nPhys = nText = 0;
						}
					} else {
						nTOfs = 0;
					}
					// 0xB00 : INVISIBLE_BLOCK ou vide 0x00
					if (nPhys === 0xB || nPhys === 0) {
						if (bStillVisible) {
							Marker_markXY(aVisibles, xi, yi);
						}
						xt += dxt;
					} else {
						t = xt + nTOfs;
						xint = x + xScale * t;
						yint = y + yScale * t;
						done = 1;
						side = 1;
						bStillVisible = false;
					}
				} else {
					t = xt;
					c = cmax;
				}
			} else {
				yi += dyi;
				if (yi >= 0 && yi < nMapSize) {
					nText = map[yi][xi];
					nPhys = (nText >> 12) & 0xF; // **Code12** phys

					if (nText !== 0 && Marker_getMarkXY(aExcludes, xi, yi)) {
						nPhys = nText = 0;
					} 
					
					if (nPhys >= nPHYS_FIRST_DOOR && nPhys <= nPHYS_LAST_DOOR) {
						// entre PHYS_FIRST_DOOR et PHYS_LAST_DOOR
						nOfs = nScale >> 1;
					} else if (nPhys == nPHYS_SECRET_BLOCK || nPhys == nPHYS_TRANSPARENT_BLOCK || nPhys == nPHYS_OFFSET_BLOCK) {
						// PHYS_SECRET ou PHYS_TRANSPARENT
						nOfs = (nText >> 16) & 0xFF; // **Code12** offs
					} else {
						nOfs = 0;
					}

					if (nOfs) {
						xint = x + xScale * yt;
						yint = y + yScale * yt;
						if (sameOffsetWall(nOfs, xint, yint, xi, yi, dx, dy, nScale)) { // Même mur -> porte
							nTOfs = (dyt / nScale) * nOfs;
							xint = x + xScale * (yt + nTOfs);
							if (((xint / nScale | 0)) != xi) {
								nPhys = nText = 0;
							}
							if (nText !== 0	&& Marker_getMarkXY(aExcludes, xi, yi)) {
								nPhys = nText = 0;
							}
						} else { // pas même mur -> wall
							nPhys = nText = 0;
						}
					} else {
						nTOfs = 0;
					}
					if (nPhys === 0xB || nPhys === 0) {
						if (bStillVisible) {
							Marker_markXY(aVisibles, xi, yi);
						}
						yt += dyt;
					} else {
						t = yt + nTOfs;
						xint = x + xScale * t;
						yint = y + yScale * t;
						done = 1;
						side = 2;
						bStillVisible = false;
					}
				} else {
					t = yt;
					c = cmax;
				}
			}
			c++;
			if (c >= cmax) {
				//			t = 100;
				done = 1;
			}
		}
		if (c < cmax) {
			oData.nWallPanel = map[yi][xi];
			oData.bSideWall = side == 1;
			oData.nSideWall = side - 1;
			oData.nWallPos = oData.bSideWall ? yint % oData.xTexture
					: xint % oData.xTexture;
			if (oData.bSideWall && dxi < 0) {
				oData.nWallPos = oData.xTexture - 1 - oData.nWallPos;
				oData.nSideWall = 2;
			}
			if (!oData.bSideWall && dyi > 0) {
				oData.nWallPos = oData.xTexture - 1 - oData.nWallPos;
				oData.nSideWall = 3;
			}
			oData.xWall = xi;
			oData.yWall = yi;
			oData.fDist = t * nScale;
			oData.bExterior = false;
			if (this.isWallTransparent(oData.xWall, oData.yWall)) {
				oContinue.bContinue = true;
				oContinue.xi = xi;
				oContinue.yi = yi;
			} else {
				oContinue.bContinue = false;
			}
		} else {
			oData.fDist = t * nScale;
			oData.bExterior = true;
		}
	},

	/**
	 * Calcule le caste d'un rayon  
	 */
	castRay : function(oData, x, y, dx, dy, xScreen, aVisibles) {
		var aExcludes = Marker.create();
		var oXBlock = null;
		var oWall;
		var nTextureBase;
		var nMaxIterations = 6;
		if (!aVisibles) {
			aVisibles = Marker.create();
		}
		var oBG = this.oBackground;
		do {
			this.projectRay(oData, x, y, dx, dy, aExcludes, aVisibles);
			if (oData.bExterior) {
				// hors du laby
				if (oBG) {
					this.drawExteriorLine(xScreen, oData.fDist);
				}
			} else if (oData.fDist >= 0) {
				if (xScreen !== undefined) {
					// Lecture données extra du block;
					oXBlock = this.oXMap.get(oData.xWall, oData.yWall,
							oData.nSideWall);
					if (oXBlock.oCanvas) {
						oWall = oXBlock.oCanvas;
						nTextureBase = 0;
					} else {
						oWall = oData.oWall.image;						
						nTextureBase = oData.oWall.codes[oData.nWallPanel & 0xFFF][oData.nSideWall] * this.xTexture; // **code12** code
					}
					this.drawLine(xScreen, oData.fDist, nTextureBase,
							oData.nWallPos | 0, oData.bSideWall, oWall,
							oData.nWallPanel);
				} 
				if (oData.oContinueRay.bContinue) {
					Marker.markXY(aExcludes, oData.xWall, oData.yWall);
				}
			}
			nMaxIterations--;
		} while (oData.oContinueRay.bContinue && nMaxIterations > 0);
		return aVisibles;
	},

	/**
	 * CastRay rapide (pas de considération graphique)
	 * @param oData données à mettre à jour (bExterior fDist xwall ywall owall)
	 * @param x position camera x
	 * @param y position camera y
	 * @param dx direction du rayon X
	 * @param dy direction du rayon y
	 * @param xScreen (facultatif) Y actuellement déssiné (pour l'extérieur)
	 * @param aVisibles liste des secteur visibles
	 * @returns aVisibles
	 */
	fastCastRay : function(x, y, a) {
		var aExcludes = Marker.create();
		var nMaxIterations = 6;
		var aVisibles = {};
		var dx = Math.cos(a);
		var dy = Math.sin(a);
		var oData = { 
			oContinueRay : {
				bContinue : false
			},
			nRayLimit : 10
		};
		do {
			this.projectRay(oData, x, y, dx, dy, aExcludes, aVisibles);
			if (oData.fDist >= 0) {
				if (oData.oContinueRay.bContinue) {
					Marker.markXY(aExcludes, oData.xWall, oData.yWall);
				}
			}
			nMaxIterations--;
		} while (oData.oContinueRay.bContinue && nMaxIterations > 0);
		return aVisibles;
	},

	
	
	sameOffsetWall : function(nOfs, x0, y0, xm, ym, fBx, fBy, ps) {
		x0 += nOfs * fBx;
		y0 += nOfs * fBy;
		var ym2, xm2;
		ym2 = y0 / ps | 0;
		xm2 = x0 / ps | 0;
		return xm2 == xm && ym2 == ym;
	},

	// compare z, départage les z identique en comparant les x
	// du plus grand au plus petit Z (distance)
	// si Z identitiques du plus petit au plus grand dx
	zBufferCompare : function(a, b) {
		if (a[9] != b[9]) {
			return b[9] - a[9];
		}
		return a[5] - b[5];
	},

	// renvoie true si le code correspond à une porte (une vrai porte, pas un passage secret)
	isDoor : function(xw, yw) {
		var nPhys = this.getMapPhys(xw, yw);
		return (nPhys >= this.PHYS_FIRST_DOOR && nPhys <= this.PHYS_LAST_DOOR);
	},

	// Renvoie true si on peut voir a travers le murs, et qu'on doit relancer le seekWall pour ce Ray
	isWallTransparent : function(xWall, yWall) {
		var nPhys = this.getMapPhys(xWall, yWall);
		if (nPhys === 0) {
			return false;
		}
		var nOffset = this.getMapOffs(xWall, yWall);
		// code physique transparent
		if ((nPhys >= this.PHYS_FIRST_DOOR &&
				nPhys <= this.PHYS_LAST_DOOR && nOffset !== 0) ||
				nPhys == this.PHYS_TRANSPARENT_BLOCK ||
				nPhys == this.PHYS_INVISIBLE_BLOCK) {
			return true;
		}
		return false;
	},
	
	// Renvoie la distance d'un éventuel renfoncement
	getWallDepth : function(xw, yw) {
		var nPhys = this.getMapPhys(xw, yw);
		if (this.isDoor(xw, yw)) {
			return this.nPlaneSpacing >> 1;
		}
		if (nPhys == this.PHYS_SECRET_BLOCK || nPhys == this.PHYS_TRANSPARENT_BLOCK || nPhys == this.PHYS_OFFSET_BLOCK) {
			return this.getMapOffs(xw, yw);
		}
		return 0;
	},

	setMapXY: function(x, y, nCode) {
		this.aMap[y][x] = nCode;
	},

	getMapXY: function(x, y) {
		return this.aMap[y][x];
	},

	setMapCode : function(x, y, nTexture) {
		this.aMap[y][x] = (this.aMap[y][x] & 0xFFFFF000) | nTexture; // **code12** code
	},

	getMapCode : function(x, y) {
		return this.aMap[y][x] & 0xFFF; // **code12** code
	},

	setMapPhys : function(x, y, nPhys) {
		this.aMap[y][x] = (this.aMap[y][x] & 0xFFFF0FFF) | (nPhys << 12); // **code12** phys
	},

	getMapPhys : function(x, y) {
		return (this.aMap[y][x] >> 12) & 0xF;  // **code12** phys
	},

	setMapOffs : function(x, y, nOffset) {
		this.aMap[y][x] = (this.aMap[y][x] & 0xFF00FFFF) // **code12** offs
				| (nOffset << 16);
	},

	getMapOffs : function(x, y) {
		return (this.aMap[y][x] >> 16) & 0xFF; // **code12** offs
	},

	drawScreen : function() {
		// phase 1 raycasting
		
		var wx1 = Math.cos(this.oCamera.fTheta - this.fViewAngle);
		var wy1 = Math.sin(this.oCamera.fTheta - this.fViewAngle);
		var wx2 = Math.cos(this.oCamera.fTheta + this.fViewAngle);
		var wy2 = Math.sin(this.oCamera.fTheta + this.fViewAngle);
		var dx = (wx2 - wx1) / this.xScrSize;
		var dy = (wy2 - wy1) / this.xScrSize;
		var fBx = wx1;
		var fBy = wy1;
		var xCam = this.oCamera.x;
		var yCam = this.oCamera.y;
		var xCam8 = xCam / this.nPlaneSpacing | 0;
		var yCam8 = yCam / this.nPlaneSpacing | 0;
		var i = 0;
		this.aZBuffer = [];
		this.aScanSectors = Marker.create();
		this.aWallSectors = {};
		if (this.oBackground) { // Calculer l'offset camera en cas de background
			this.fCameraBGOfs = (PI + this.oCamera.fTheta)	* this.oBackground.width / PI;
		}
		Marker.markXY(this.aScanSectors, xCam8, yCam8);
		var oContinueRay = this.oContinueRay;
		var xScrSize = this.xScrSize;
		var aScanSectors = this.aScanSectors;
		for (i = 0; i < xScrSize; ++i) {
			oContinueRay.bContinue = false;
			this.castRay(this, xCam, yCam, fBx, fBy, i, aScanSectors);
			fBx += dx;
			fBy += dy;
		}
		
		// Optimisation ZBuffer -> suppression des drawImage inutile, élargissement des drawImage utiles.
		// si le last est null on le rempli
		// sinon on compare last et current
		// si l'un des indices 0, 1 diffèrent alors on flush, sinon on augmente le last
		var aZ = [];
		var nLast = 1;
		var nLLast = 1;
		var nLLLast = 1;
		var z = 1;
		
		// image 0
		// sx  1
		// sy  2
		// sw  3
		// sh  4
		// dx  5
		// dy  6
		// dw  7
		// dh  8
		// z   9
		// fx  10
		
		var zb = this.aZBuffer;
		var zbl = zb.length;
		if (zbl === 0) {
			return;
		}
		var b; // Element courrant du ZBuffer;
		var lb = zb[0];
		var llb = lb;
		var lllb = lb;
		var abs = Math.abs;
		
		for (i = 0; i < zbl; i++) {
			b = zb[i];
			// tant que c'est la même source de texture
			if (b[10] == lb[10] && b[0] == lb[0] && b[1] == lb[1] && abs(b[9] - lb[9]) < 8) { 
				nLast += z;
			} else if (b[10] == llb[10] && b[0] == llb[0] && b[1] == llb[1] && abs(b[9] - llb[9]) < 8) {
				nLLast += z;
			} else if (b[10] == lllb[10] && b[0] == lllb[0] && b[1] == lllb[1] && abs(b[9] - lllb[9]) < 8) {
				nLLLast += z;
			} else {
				lllb[7] = nLLLast;
				aZ.push(lllb);
				lllb = llb;
				nLLLast = nLLast;
				llb = lb;
				nLLast = nLast;
				lb = b;
				nLast = z;
			}
		}
		lllb[7] = nLLLast;
		aZ.push(lllb);
		llb[7] = nLLast;
		aZ.push(llb);
		lb[7] = nLast;
		aZ.push(lb);
		
		this.aZBuffer = aZ;
		this.drawHorde();
		// Le tri permet d'afficher les textures semi transparente après celles qui sont derrières
		this.aZBuffer.sort(this.zBufferCompare);
		
		var rctx = this.oRenderContext;
		

		// phase 2 : rendering

		// sky
		if (this.bSky && this.oBackground) {
			var oBG = this.oBackground;
			var wBG = oBG.width;
			var hBG = oBG.height;
			var xBG = this.fCameraBGOfs % wBG | 0;
			var yBG = this.yScrSize - (hBG >> 1);
			hBG = hBG + yBG;
			rctx.drawImage(oBG, 0, 0, wBG, hBG, wBG - xBG, yBG, wBG, hBG);
			rctx.drawImage(oBG, 0, 0, wBG, hBG, -xBG, yBG, wBG, hBG);
		} else if (this.bGradient) {
			rctx.fillStyle = this.oVisual.gradients[0];
			rctx.fillRect(0, 0, this.oCanvas.width, this.oCanvas.height >> 1);
			if (!this.bFloor) {
				rctx.fillStyle = this.oVisual.gradients[1];
				rctx.fillRect(0, (this.oCanvas.height >> 1), this.oCanvas.width, this.oCanvas.height >> 1);
			}
		}
		
		// 2ndFloor
		if (this.oUpper) {
			this.drawUpper();
		}

		// floor
		if (this.bFloor) {
			if (this.bCeil && this.fViewHeight != 1) {
				this.drawFloorAndCeil();
			} else {
				this.drawFloor();
			}
		}
		
		zbl = this.aZBuffer.length;
		for (i = 0; i < zbl; ++i) {
			this.drawImage(i);
		}
		if (this.oConfig.drawMap) {
			this.drawMap();
		}
		this.drawWeapon();
		if (this.bUseVideoBuffer) {
			this.oContext.drawImage(this.oRenderCanvas, 0, 0);
		}
	},

	drawSprite : function(oMobile) {
		var oSprite = oMobile.oSprite;
		// Si le sprite n'est pas visible, ce n'est pas la peine de gaspiller du temps CPU
		// on se barre immédiatement
		if (!(oSprite.bVisible && oMobile.bVisible)) {
			return;
		}
		var oTile = oSprite.oBlueprint.oTile;
		var dx = oMobile.x - this.oCamera.x;
		var dy = oMobile.y - this.oCamera.y;

		// Gaffe fAlpha est un angle ici, et pour un sprite c'est une transparence
		var fTarget = Math.atan2(dy, dx);
		var fAlpha = fTarget - this.oCamera.fTheta; // Angle
		if (fAlpha >= PI) { // Angle plus grand que l'angle plat
			fAlpha = -(PI * 2 - fAlpha);
		}
		if (fAlpha < -PI) { // Angle plus grand que l'angle plat
			fAlpha = PI * 2 + fAlpha;
		}
		var w2 = this.oCanvas.width >> 1;

		// Animation
		var fAngle1 = oMobile.fTheta + (PI / 8) - fTarget;
		if (fAngle1 < 0) {
			fAngle1 = 2 * PI + fAngle1;
		}
		oSprite.setDirection(((8 * fAngle1 / (2 * PI)) | 0) & 7);
		oSprite.animate(this.TIME_FACTOR);

		if (Math.abs(fAlpha) <= (this.fViewAngle * 1.5)) {
			var x = (Math.tan(fAlpha) * w2 + w2) | 0;
			// Faire tourner les coordonnées du sprite : projection sur l'axe de la caméra
			var z = MathTools.distance(dx, dy) * Math.cos(fAlpha) * 1.333;  // le 1.333 empirique pour corriger une erreur de tri bizarroïde
			// Les sprites bénéficient d'un zoom 2x afin d'améliorer les détails.

			var dz = (oTile.nScale * oTile.nHeight / (z / this.yScrSize) + 0.5);
			var dzy = this.yScrSize - (dz * this.fViewHeight);
			var iZoom = (oTile.nScale * oTile.nWidth / (z / this.yScrSize) + 0.5);
			var nOpacity; // j'ai nommé opacity mais ca n'a rien a voir : normalement ca aurait été sombritude
			// Self luminous
			var nSFx = oSprite.oBlueprint.nFx | (oSprite.bTranslucent ? (oSprite.nAlpha << 2) : 0);
			if (nSFx & 2) {
				nOpacity = 0;
			} else {
				nOpacity = z / this.nShadingFactor | 0;
				if (nOpacity > this.nShadingThreshold) {
					nOpacity = this.nShadingThreshold;
				}
			}
			var aData = [ oTile.oImage, // image 0
					oSprite.nFrame * oTile.nWidth, // sx  1
					oTile.nHeight * nOpacity, // sy  2
					oTile.nWidth, // sw  3
					oTile.nHeight, // sh  4
					x - iZoom | 0, // dx  5
					dzy | 0, // dy  6   :: this.yScrSize - dz + (dz >> 1)
					iZoom << 1, // dw  7
					dz << 1, // dh  8
					z, 
					nSFx]; 
			oSprite.aLastRender = aData;
			this.aZBuffer.push(aData);
			// Traitement overlay
			var oOL = oSprite.oOverlay;
			if (oOL) {
				if (Array.isArray(oSprite.nOverlayFrame)) {
					oSprite.nOverlayFrame.forEach(function(of, iOF) {
						this.aZBuffer.push(
						[	oOL.oImage, // image 0
							of * oOL.nWidth, // sx  1
							0, // sy  2
							oOL.nWidth, // sw  3
							oOL.nHeight, // sh  4
							aData[5], // dx  5
							aData[6], // dy  6   :: this.yScrSize - dz + (dz >> 1)
							aData[7], // dw  7
							aData[8], // dh  8
							aData[9] - 1 - (iOF / 100), 
							2
						]);
					}, this);
				} else if (oSprite.nOverlayFrame !== null) {
					this.aZBuffer.push(
					[	oOL.oImage, // image 0
						oSprite.nOverlayFrame * oOL.nWidth, // sx  1
						0, // sy  2
						oOL.nWidth, // sw  3
						oOL.nHeight, // sh  4
						aData[5], // dx  5
						aData[6], // dy  6   :: this.yScrSize - dz + (dz >> 1)
						aData[7], // dw  7
						aData[8], // dh  8
						aData[9] - 1, 
						2
					]);
				}
			}
		}
	},
	

	drawHorde : function() {
		var x = '', y = '', aMobiles, oMobile, nMobileCount, i;
		this.aVisibleMobiles = [];
		for (x in this.aScanSectors) {
			for (y in this.aScanSectors[x]) {
				aMobiles = this.oMobileSectors.get(x, y);
				nMobileCount = aMobiles.length;
				for (i = 0; i < nMobileCount; i++) {
					oMobile = aMobiles[i];
					if (oMobile.bActive && oMobile.oSprite) {
						this.aVisibleMobiles.push(oMobile);
						this.drawSprite(oMobile);
					}
				}
			}
		}
	},

	drawExteriorLine : function(x, z) {
		var dz, sx, sy, sw, sh, dx, dy, dw, dh, a = null;
		if (z < 0.1) {
			z = 0.1;
		}
		dz = (this.yTexture / (z / this.yScrSize));
		var dzfv = (dz * this.fViewHeight);
		var dzy = this.yScrSize - dzfv;
		// dz = demi hauteur de la texture projetée
		var oBG = this.oBackground;
		var wBG = oBG.width, hBG = oBG.height;
		sx = (x + this.fCameraBGOfs) % wBG | 0;
		sy = Math.max(0, (hBG >> 1) - dzfv);
		sw = 1;
		sh = Math.min(hBG, dz << 1);
		dx = x;
		dy = Math.max(dzy, this.yScrSize - (hBG >> 1));
		dw = sw;
		dh = Math.min(sh, dz << 1);
		a = [ oBG, sx, sy, sw, sh, dx, dy, dw, dh, z, 0 ];
		this.aZBuffer.push(a);
	},
	
	
	drawFloor: null,
	
	/**
	 * Rendu du floor et du ceil quand fViewHeight est à 1
	 */
	drawFloor_zoom1: function() {
		var bCeil = this.bCeil;
		var oFloor = this.oFloor;
		var x, y, w = this.xScrSize, h = this.yScrSize;
		if (oFloor.imageData === null) {
			var oFlat = O876.CanvasFactory.getCanvas();
			oFlat.width = oFloor.image.width;
			oFlat.height = oFloor.image.height;
			var oCtx = oFlat.getContext('2d');
			oCtx.drawImage(oFloor.image, 0, 0);
			oFloor.image = oFlat;
			oFloor.imageData = oCtx.getImageData(0, 0, oFlat.width, oFlat.height);
			oFloor.imageData32 = new Uint32Array(oFloor.imageData.data.buffer);
			oFloor.renderSurface = this.oRenderContext.getImageData(0, 0, w, h << 1);
			oFloor.renderSurface32 = new Uint32Array(oFloor.renderSurface.data.buffer);
		}
		if (this.bFlatSky) {
			// recommencer à lire le background pour prendre le ciel en compte
			oFloor.renderSurface = this.oRenderContext.getImageData(0, 0, w, h << 1);
			oFloor.renderSurface32 = new Uint32Array(oFloor.renderSurface.data.buffer);
		}
		var aFloorSurf = oFloor.imageData32;
		var aRenderSurf = oFloor.renderSurface32;
		// 1 : créer la surface
		var wx1 = Math.cos(this.oCamera.fTheta - this.fViewAngle);
		var wy1 = Math.sin(this.oCamera.fTheta - this.fViewAngle);
		var wx2 = Math.cos(this.oCamera.fTheta + this.fViewAngle);
		var wy2 = Math.sin(this.oCamera.fTheta + this.fViewAngle);

		var fh = (this.yTexture >> 1) - ((this.fViewHeight - 1) * this.yTexture >> 1);
		var xDelta = (wx2 - wx1) / this.xScrSize; // incrément d'optimisateur trigonométrique
		var yDelta = (wy2 - wy1) / this.xScrSize; // incrément d'optimisateur trigonométrique
		var xDeltaFront;
		var yDeltaFront;
		var ff = this.yScrSize << 1; // focale
		var fx, fy; // coordonnée du texel finale
		var dFront; // distance "devant caméra" du pixel actuellement pointé
		var ofsDst; // offset de l'array pixel de destination (plancher)
		var wy;
		
		var ofsDstCeil; // offset de l'array pixel de destination (plancher)
		var wyCeil;

		var xCam = this.oCamera.x; // coord caméra x
		var yCam = this.oCamera.y; // coord caméra y
		var nFloorWidth = oFloor.image.width; // taille pixel des tiles de flats
		var ofsSrc; // offset de l'array pixel source
		var xOfs = 0; // code du block flat à afficher
		var yOfs = 0; // luminosité du block flat à afficher
		var ps = this.nPlaneSpacing;
		var nBlock;
		var xyMax = this.nMapSize * ps;
		var st = this.nShadingThreshold;
		var sf = this.nShadingFactor;
		var aMap = this.aMap;
		var F = this.oFloor.codes;
		var aFBlock;
		
		var fy64, fx64;
		var oXMap = this.oXMap;
		var oXBlock, oXBlockImage;
		var oXBlockCeil;
		var nXDrawn = 0; // 0: pas de texture perso ; 1 = texture perso sol; 2=texture perso plafond
		var fBx, fBy;
		
		for (y = 1; y < h; ++y) {
			fBx = wx1;
			fBy = wy1;
			
			// floor
			dFront = fh * ff / y; 
			fy = wy1 * dFront + yCam;
			fx = wx1 * dFront + xCam;
			xDeltaFront = xDelta * dFront;
			yDeltaFront = yDelta * dFront;
			wy = w * (h + y);
			wyCeil = w * (h - y - 1);
			yOfs = Math.min(st, dFront / sf | 0);
			
			for (x = 0; x < w; ++x) {
				ofsDst = wy + x;
				ofsDstCeil = wyCeil + x;
				fy64 = fy / ps | 0; // sector
				fx64 = fx / ps | 0;
				if (fx >= 0 && fy >= 0 && fx < xyMax && fy < xyMax) {
					nXDrawn = 0;
					oXBlock = oXMap.get(fx64, fy64, 4);
					oXBlockCeil = oXMap.get(fx64, fy64, 5);
					if (oXBlock.imageData32) {
						oXBlockImage = oXBlock.imageData32;
						ofsSrc = (((fy  % ps) + yOfs * ps | 0) * ps + (((fx % ps) | 0)));
						aRenderSurf[ofsDst] = oXBlockImage[ofsSrc];
						nXDrawn += 1;
					}
					if (oXBlockCeil.imageData32) {
						oXBlockImage = oXBlockCeil.imageData32;
						if (nXDrawn === 0) {
							ofsSrc = (((fy  % ps) + yOfs * ps | 0) * ps + (((fx % ps) | 0)));
						}
						aRenderSurf[ofsDstCeil] = oXBlockImage[ofsSrc];
						nXDrawn += 2;
					}
					if (nXDrawn != 3) {
						nBlock = aMap[fy / ps | 0][fx / ps | 0] & 0xFFF; // **code12** code
						aFBlock = F[nBlock];
						if (aFBlock !== null) {
							if (nXDrawn != 1) {
								xOfs = aFBlock[0];
								ofsSrc = (((fy % ps) + yOfs * ps | 0) * nFloorWidth + (((fx % ps) + xOfs * ps | 0)));
								aRenderSurf[ofsDst] = aFloorSurf[ofsSrc];
							}
							if (bCeil && nXDrawn != 2) {
								xOfs = aFBlock[1];
								if (xOfs >= 0) {
									ofsSrc = (((fy % ps) + yOfs * ps | 0) * nFloorWidth + (((fx % ps) + xOfs * ps | 0)));
									aRenderSurf[ofsDstCeil] = aFloorSurf[ofsSrc];
								}
							}
						}
					}
				}
				fy += yDeltaFront;
				fx += xDeltaFront;
			}
		}
		this.oRenderContext.putImageData(oFloor.renderSurface, 0, 0);
	},

	
	drawFloorAndCeil: null,
	
	/**
	 * Rendu du floor et du ceil si le fViewHeight est différent de 1
	 * (presque double ration de calcul....)
	 */
	drawFloorAndCeil_zoom1: function() {
		var oFloor = this.oFloor;
		var x, y, w = this.xScrSize, h = this.yScrSize;
		if (oFloor.imageData === null) {
			var oFlat = O876.CanvasFactory.getCanvas();
			oFlat.width = oFloor.image.width;
			oFlat.height = oFloor.image.height;
			var oCtx = oFlat.getContext('2d');
			oCtx.drawImage(oFloor.image, 0, 0);
			oFloor.image = oFlat;
			oFloor.imageData = oCtx.getImageData(0, 0, oFlat.width, oFlat.height);
			oFloor.imageData32 = new Uint32Array(oFloor.imageData.data.buffer);
			oFloor.renderSurface = this.oRenderContext.getImageData(0, 0, w, h << 1);
			oFloor.renderSurface32 = new Uint32Array(oFloor.renderSurface.data.buffer);
		}
		if (this.bFlatSky) {
			// recommencer à lire le background pour prendre le ciel en compte
			oFloor.renderSurface = this.oRenderContext.getImageData(0, 0, w, h << 1);
			oFloor.renderSurface32 = new Uint32Array(oFloor.renderSurface.data.buffer);
		}
		var aFloorSurf = oFloor.imageData32;
		var aRenderSurf = oFloor.renderSurface32;
		// 1 : créer la surface
		var wx1 = Math.cos(this.oCamera.fTheta - this.fViewAngle);
		var wy1 = Math.sin(this.oCamera.fTheta - this.fViewAngle);
		var wx2 = Math.cos(this.oCamera.fTheta + this.fViewAngle);
		var wy2 = Math.sin(this.oCamera.fTheta + this.fViewAngle);

		var fh = (this.yTexture >> 1) - ((this.fViewHeight - 1) * this.yTexture >> 1);
		var xDelta = (wx2 - wx1) / this.xScrSize; // incrément d'optimisateur trigonométrique
		var yDelta = (wy2 - wy1) / this.xScrSize; // incrément d'optimisateur trigonométrique
		var xDeltaFront;
		var yDeltaFront;
		var ff = this.yScrSize << 1; // focale
		var fx, fy; // coordonnée du texel finale
		var dFront; // distance "devant caméra" du pixel actuellement pointé
		var ofsDst; // offset de l'array pixel de destination (plancher)
		var wy;
		
		var fhCeil = (this.yTexture >> 1) + ((this.fViewHeight - 1) * this.yTexture >> 1);
		var xDeltaFrontCeil = 0;
		var yDeltaFrontCeil = 0;
		var fxCeil = 0, fyCeil = 0; // coordonnée du texel finale
		var dFrontCeil; // distance "devant caméra" du pixel actuellement pointé
		var ofsDstCeil; // offset de l'array pixel de destination (plafon) 
		var wyCeil = 0;

		var xCam = this.oCamera.x; // coord caméra x
		var yCam = this.oCamera.y; // coord caméra y
		var nFloorWidth = oFloor.image.width; // taille pixel des tiles de flats
		var ofsSrc; // offset de l'array pixel source
		var xOfs = 0; // code du block flat à afficher
		var yOfs = 0; // luminosité du block flat à afficher
		var ps = this.nPlaneSpacing;
		var nBlock;
		var xyMax = this.nMapSize * ps;
		var st = this.nShadingThreshold;
		var sf = this.nShadingFactor;
		var aMap = this.aMap;
		var F = this.oFloor.codes;
		var aFBlock;
		
		
		var bCeil = this.bCeil;
		
		// aFloorSurf -> doit pointer vers XMap.get(x, y)[4].imageData32
		// test : if XMap.get(x, y)[4]
		
		var fy64, fx64;
		var oXMap = this.oXMap;
		var oXBlock, oXBlockCeil, oXBlockImage;
		var fBx, fBy, yOfsCeil;
		
		
		for (y = 1; y < h; ++y) {
			fBx = wx1;
			fBy = wy1;
			
			// floor
			dFront = fh * ff / y; 
			fy = wy1 * dFront + yCam;
			fx = wx1 * dFront + xCam;
			xDeltaFront = xDelta * dFront;
			yDeltaFront = yDelta * dFront;
			wy = w * (h + y);
			yOfs = Math.min(st, dFront / sf | 0);

			// ceill
			if (bCeil) {
				dFrontCeil = fhCeil * ff / y; 
				fyCeil = wy1 * dFrontCeil + yCam;
				fxCeil = wx1 * dFrontCeil + xCam;
				xDeltaFrontCeil = xDelta * dFrontCeil;
				yDeltaFrontCeil = yDelta * dFrontCeil;
				wyCeil = w * (h - y);
				yOfsCeil = Math.min(st, dFrontCeil / sf | 0);
			}
			for (x = 0; x < w; ++x) {
				ofsDst = wy + x;
				ofsDstCeil = wyCeil + x;
				fy64 = fy / ps | 0;
				fx64 = fx / ps | 0;
				if (fx >= 0 && fy >= 0 && fx < xyMax && fy < xyMax) {
					oXBlock = oXMap.get(fx64, fy64, 4);
					if (oXBlock.imageData32) {
						oXBlockImage = oXBlock.imageData32;
						ofsSrc = (((fy  % ps) + yOfs * ps | 0) * ps + (((fx % ps) | 0)));
						aRenderSurf[ofsDst] = oXBlockImage[ofsSrc];
					} else {
						nBlock = aMap[fy64][fx64] & 0xFFF; // **code12** code
						aFBlock = F[nBlock];
						if (aFBlock !== null) {
							xOfs = aFBlock[0];
							if (xOfs >= 0) {
								ofsSrc = (((fy % ps) + yOfs * ps | 0) * nFloorWidth + (((fx % ps) + xOfs * ps | 0)));
								aRenderSurf[ofsDst] = aFloorSurf[ofsSrc];
							}
						}
					}
				}
				if (bCeil && fxCeil >= 0 && fyCeil >= 0 && fxCeil < xyMax && fyCeil < xyMax) {
					fy64 = fyCeil / ps | 0;
					fx64 = fxCeil / ps | 0;
					oXBlockCeil = oXMap.get(fx64, fy64, 5);
					if (oXBlockCeil.imageData32) {
						oXBlockImage = oXBlockCeil.imageData32;
						ofsSrc = (((fyCeil  % ps) + yOfs * ps | 0) * ps + (((fxCeil % ps) | 0)));
						aRenderSurf[ofsDstCeil] = oXBlockImage[ofsSrc];
					} else {
						nBlock = aMap[fy64][fx64] & 0xFFF; // **code12** code
						aFBlock = F[nBlock];
						if (aFBlock !== null) {
							xOfs = aFBlock[1];
							if (xOfs >= 0) {
								ofsSrc = (((fyCeil % ps) + yOfs * ps | 0) * nFloorWidth + (((fxCeil % ps) + xOfs * ps | 0)));
								aRenderSurf[ofsDstCeil] = aFloorSurf[ofsSrc];
							}
						}
					}
				}
				if (bCeil) {
					fyCeil += yDeltaFrontCeil;
					fxCeil += xDeltaFrontCeil;
				}
				fy += yDeltaFront;
				fx += xDeltaFront;
			}
		}
		this.oRenderContext.putImageData(oFloor.renderSurface, 0, 0);
	},

	drawLine : function(x, z, nTextureBase, nPos, bDim, oWalls, nPanel) {
		if (z < 0.1) {
			z = 0.1;
		}
		//var dz = (this.yTexture / (z / this.yScrSize) + 0.5) | 0;
		var ytex = this.yTexture;
		var xtex = this.xTexture;
		var yscr = this.yScrSize;
		var dz = ytex * yscr / z;
		var fvh = this.fViewHeight;
		dz = dz + 0.5 | 0;
		var dzy = yscr - (dz * fvh);
		var nPhys = (nPanel >> 12) & 0xF;  // **code12** phys
		var nOffset = (nPanel >> 16) & 0xFF; // **code12** offs
		var nOpacity = z / this.nShadingFactor | 0;
		if (bDim) {
			nOpacity += this.nDimmedWall;
		}
		if (nOpacity > this.nShadingThreshold) {
			nOpacity = this.nShadingThreshold;
		}
		var aData = [
				oWalls, // image 0
				nTextureBase + nPos, // sx  1
				ytex * nOpacity, // sy  2
				1, // sw  3
				ytex, // sh  4
				x, // dx  5
				dzy - 1, // dy  6
				1, // dw  7
				(2 + dz * 2), // dh  8
				z, // z 9
				bDim ? RC.FX_DIM0 : 0
		];

		// Traitement des portes
		switch (nPhys) {
			case this.PHYS_DOOR_SLIDING_UP: // porte coulissant vers le haut
				aData[2] += nOffset;
				if (nOffset > 0) {
					aData[4] = ytex - nOffset;
					aData[8] = ((aData[4] / (z / yscr) + 0.5)) << 1;
				}
				break;

			case this.PHYS_CURT_SLIDING_UP: // rideau coulissant vers le haut
				if (nOffset > 0) {
					aData[8] = (((ytex - nOffset) / (z / yscr) + 0.5)) << 1;
				}
				break;

			case this.PHYS_CURT_SLIDING_DOWN: // rideau coulissant vers le bas
				aData[2] += nOffset; // no break here 
				// suite au case 4...

			case this.PHYS_DOOR_SLIDING_DOWN: // Porte coulissant vers le bas
				if (nOffset > 0) {
					// 4: sh
					// 6: dy
					// 8: dh 
					// on observe que dh est un peut trop petit, ou que dy es trop haut
					aData[4] = ytex - nOffset;
					aData[8] = ((aData[4] / (z / yscr) + 0.5));
					aData[6] += (dz - aData[8]) << 1;
					aData[8] <<= 1;
				}
				break;

			case this.PHYS_DOOR_SLIDING_LEFT: // porte latérale vers la gauche
				if (nOffset > 0) {
					if (nPos > (xtex - nOffset)) {
						aData[0] = null;
					} else {
						aData[1] = (nPos + nOffset) % xtex + nTextureBase;
					}
				}
				break;

			case this.PHYS_DOOR_SLIDING_RIGHT: // porte latérale vers la droite
				if (nOffset > 0) {
					if (nPos < nOffset) {
						aData[0] = null;
					} else {
						aData[1] = (nPos + xtex - nOffset) % xtex + nTextureBase;
					}
				}
				break;

			case this.PHYS_DOOR_SLIDING_DOUBLE: // double porte latérale
				if (nOffset > 0) {
					if (nPos < (xtex >> 1)) { // panneau de gauche
						if ((nPos) > ((xtex >> 1) - nOffset)) {
							aData[0] = null;
						} else {
							aData[1] = (nPos + nOffset) % xtex + nTextureBase;
						}
					} else {
						if ((nPos) < ((xtex >> 1) + nOffset)) {
							aData[0] = null;
						} else {
							aData[1] = (nPos + xtex - nOffset) % xtex + nTextureBase;
						}
					}
				}
				break;

			case this.PHYS_INVISIBLE_BLOCK:
				aData[0] = null;
				break;
		}
		if (aData[0]) {
			this.aZBuffer.push(aData);
		}
	},

	/** Rendu de l'image stackée dans le Z Buffer
	 * @param i rang de l'image
	 */
	drawImage : function(i) {
		var rc = this.oRenderContext;
		var aLine = this.aZBuffer[i];
		var sGCO = '';
		var fGobalAlphaSave = 0;
		var nFx = aLine[10];
		if (nFx & 1) {
			sGCO = rc.globalCompositeOperation;
			rc.globalCompositeOperation = 'lighter';
		}
		if (nFx & 12) {
			fGobalAlphaSave = rc.globalAlpha;
			rc.globalAlpha = RC.FX_ALPHA[nFx >> 2];
		}
		var xStart = aLine[1];
		// Si xStart est négatif c'est qu'on est sur un coté de block dont la texture est indéfinie (-1)
		// Firefox refuse de dessiner des textures "négative" dont on skipe le dessin
		if (xStart >= 0) {
			rc.drawImage(
				aLine[0], 
				aLine[1] | 0,
				aLine[2] | 0,
				aLine[3] | 0,
				aLine[4] | 0,
				aLine[5] | 0,
				aLine[6] | 0,
				aLine[7] | 0,
				aLine[8] | 0);
		}
		if (sGCO !== '') {
			rc.globalCompositeOperation = sGCO;
		}
		if (nFx & 12) {
			rc.globalAlpha = fGobalAlphaSave;
		}
	},

	drawSquare : function(x, y, nWidth, nHeight, sColor) {
		this.oRenderContext.fillStyle = sColor;
		this.oRenderContext.fillRect(x, y, nWidth, nHeight);
	},

	drawMap : function() {
		if (this.oMinimap) {
			this.oMinimap.render();
		} else {
			this.oMinimap = new O876_Raycaster.Minimap();
			this.oMinimap.reset(this);
		}
	},

	/* sprites:
	
	1) déterminer la liste des sprite susceptible d'etre visible
	- ce qui sont dans les secteurs traversés par les rayons
	2) déterminer la distance
	3) déterminer l'angle
	4) déterminer la position X (angle)

	 */

	/** Renvoie des information concernant la case contenant le point spécifié
	 * @param x coordonnée du point à étudier
	 * @param y
	 * @param n optionnel, permet de spécifier le type d'information voulu
	 *  - undefined : tout
	 *  - 0: le code texture 0-0xFF
	 *  - 1: le code physique
	 *  - 2: le code offset
	 *  - 3: le tag
	 * @return code de la case.
	 */
	clip : function(x, y, n) {
		if (n === undefined) {
			n = 0;
		}
		var ps = this.nPlaneSpacing;
		var xm = x / ps | 0;
		var ym = y / ps | 0;
		switch (n) {
			case 0:
				return this.getMapCode(xm, ym);
			case 1:
				return this.getMapPhys(xm, ym);
			case 2:
				return this.getMapOffs(xm, ym);
			case 3:
				return this.getMapXYTag(xm, ym);
			default:
				return this.aMap[ym][xm];
		}
	},
	
	/**
	 * Animation des textures
	 * Toutes les textures déclarée dans walls.animated subissent un cycle d'animation
	 * Cette fonction n'est pas appelée automatiquement
	 */
	textureAnimation: function() {
		// Animation des textures
		var oAnim, w = this.oWall, wc = w.codes, wcn, wa = w.animated;
		var i, l, x;
		for (var iAnim in wa) {
			wcn = wc[iAnim | 0];
			oAnim = wa[iAnim];
			if ('animate' in oAnim) {
				oAnim.animate(this.TIME_FACTOR);
				for (i = 0, l = oAnim.__start.length; i < l; ++i) {
					x = oAnim.__start[i];
					wcn[i] = x + oAnim.nFrame;
				}
			}
		}
	},
	
	buildAnimatedTextures: function() {
		// animation des textures
		var w = this.oWall;
		if (!('animated' in w)) {
			w.animated = {};
		}
		var wc = w.codes, wcc, wa = w.animated;
		var oAnim;
		var wcStart, wcDur, wcCount, wcLoop;
		for (var nCode = 0; nCode < wc.length; ++nCode) {
			wcc = wc[nCode];
			if (wcc) {
				if (Array.isArray(wcc[0])) { // Une animation de texture ?
					if (wcc[0].length === 2) {
						// convertir en mure à 4 coté
						wcc[0].push(wcc[0][0]);
						wcc[0].push(wcc[0][1]);
					}
					wcStart = wcc[0];
					wcCount = wcc[1];
					wcDur = wcc[2];
					wcLoop = wcc[3];
					// Enregistrer l'animation de texture dans la propriété "animated"
					oAnim = new O876_Raycaster.Animation();
					oAnim.nCount = wcCount;
					oAnim.nDuration = wcDur;
					oAnim.nLoop = wcLoop;
					oAnim.__start = wcStart;
					wa[nCode] = oAnim;
				} else if (wcc.length === 2) { // mur 2 ou 4
					// répéter les code 0 et 1 en 2 et 3
					wcc.push(wcc[0]);
					wcc.push(wcc[1]);
				}
			}
		}
	}
});

/**
 * Temporise et retarde l'exécution de certaines commandes
 */
O2.createClass('O876_Raycaster.Scheduler', {
	oCommands: null,
	aIndex: null,
	bInvalid: true,
	nTime: 0,

	
	__construct: function() {
		this.oCommands = {};
		this.aIndex = [];
	},

	/** 
	 * Retarde l'exécution de la function passée en paramètre
	 * la fonction doit etre une méthode de l'instance défini dans le
	 * constructeur
	 * @param pCommand methode à appeler
	 * @param nDelay int delai d'exécution
	 */
	delayCommand: function(oInstance, pCommand, nDelay) {
		var aParams = Array.prototype.slice.call(arguments, 3);
		var n = nDelay + this.nTime;
		if (!(n in this.oCommands)) {
			this.oCommands[n] = [];
		}
		this.oCommands[n].push([oInstance, pCommand, aParams]);
		this.aIndex.push(n);
		this.bInvalid = true;
	},

	/** 
	 * Appelée à chaque intervale de temps, cette fonction détermine 
	 * quelle sont les fonctions à appeler.
	 * @param nTime int temps
	 */ 
	schedule: function(nTime) {
		this.nTime = nTime;
		if (this.bInvalid) { // trier en cas d'invalidité
			this.aIndex.sort(function(a, b) { return a - b; });
			this.bInvalid = false;
		}
		var n, i, o;
		while (this.aIndex.length && this.aIndex[0] < nTime) {
			n = this.aIndex.shift();
			o = this.oCommands[n];
			for (i = 0; i < o.length; i++) {
				o[i][2].apply(o[i][0], o[i][2]);
			}
			delete this.oCommands[n];
		}
	}
});

/**
 * Un sprite est une image pouvant être placée et déplacée à l'écran O876
 * Raycaster project
 * 
 * @date 2012-01-01
 * @author Raphaël Marandet Le sprite a besoin d'un blueprint pour récupérer ses
 *         données initiales Le sprite est utilisé par la classe Mobile pour
 *         donner une apparence aux objet ciruclant dans le laby
 */
O2.createClass('O876_Raycaster.Sprite',  {
	oBlueprint : null, // Référence du blueprint
	oAnimation : null, // Pointeur vers l'animation actuelle
	nAnimation : -1, // Animation actuelle
	nFrame : 0, // Frame affichée
	nLight : 0,
	nAngle8 : 0, // Angle 8 modifiant l'animation en fonction de la
	// caméra
	nAnimationType : 0,
	sCompose : '',
	bVisible : true,
	oOverlay: null,
	nOverlayFrame: null,
	bTranslucent: false, // active alpha
	nAlpha: 2, // 1=75% 2=50% 3=25%
	aLastRender: null, // mémorise les dernier paramètres de rendu


	/**
	 * Change l'animation en cours
	 * 
	 * @param n
	 *            numero de la nouvelle animation
	 */
	playAnimation : function(n) {
		if (n == this.nAnimation) {
			return;
		}
		var aBTA = this.oBlueprint.oTile.aAnimations;
		this.nAnimation = n;
		if (n < aBTA.length) {
			// transfere les timers et index d'une animation à l'autre
			if (this.oAnimation === null) {
				this.oAnimation = new O876_Raycaster.Animation();
			}
			if (aBTA[n]) {
				this.oAnimation.assign(aBTA[n]);
				this.bVisible = true;
			} else {
				this.bVisible = false;
			}
			this.oAnimation.nDirLoop = 1;
		} else {
			throw new Error('sprite animation out of range: ' + n + ' max: ' + aBTA.length);
		}
	},

	/**
	 * Permet de jouer une animation
	 * 
	 * @param nAnimationType
	 *            Type d'animation à jouer
	 * @param bReset reseter une animation
	 */
	playAnimationType : function(nAnimationType, bReset) {
		this.nAnimationType = nAnimationType;
		this.playAnimation(this.nAnimationType * 8 + this.nAngle8);
		if (bReset) {
			this.oAnimation.reset();
		}
	},

	setDirection : function(n) {
		this.nAngle8 = n;
		var nIndex = 0;
		if (this.oAnimation !== null) {
			nIndex = this.oAnimation.nIndex;
		}
		this.playAnimationType(this.nAnimationType); // rejouer l'animation en
		// cas de changement de
		// point de vue
		this.oAnimation.nIndex = nIndex; // conserver la frame actuelle
	},

/**
 * Calcule une nouvelle frame d'animation, mise à jour de la propriété
 * nFrame
 */
	animate : function(nInc) {
		if (this.oAnimation) {
			this.nFrame = this.oAnimation.animate(nInc);
		}
	}
});

/** Classe de déplacement automatisé et stupidité artificielle des mobiles
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet 
 * Classe de base pouvant être étendue
 */
O2.createClass('O876_Raycaster.Thinker', {
	oMobile: null,
	oGame: null,
	think: function() {}
});


/**
 * This class deals with thinkers
 * it can produce instance of thinker by giving a thinker name
 */
O2.createClass('O876_Raycaster.ThinkerManager', {
	oGameInstance : null,
	oLoader : null,

	__construct : function() {
		this.oLoader = new O876.ClassLoader();
	},

	createThinker : function(sThinker) {
		// Les thinkers attaché a un device particulier ne peuvent pas être initialisé
		// transmettre la config du raycaster ? 
		if (sThinker === undefined || sThinker === null) {
			return null;
		}
		var pThinker = this.oLoader.loadClass(sThinker + 'Thinker');
		if (pThinker !== null) {
			var oThinker = new pThinker();
			oThinker.oGame = this.oGameInstance;
			return oThinker;
		} else {
			throw new Error('ThinkerManager : ' + sThinker + ' class not found.');
		}
	}
});

/** Interface de controle des mobile 
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet 
 * Fait bouger lemobile de manière aléatoire
 */
O2.extendClass('O876_Raycaster.WanderThinker', O876_Raycaster.Thinker, {
	nTime: 0,
	aAngles: null,
	nAngle: 0,

	__construct: function() {
		this.aAngles = [0, 0.25 * PI, 0.5 * PI, 0.75 * PI, PI, -0.75 * PI, -0.5 * PI, -0.25 * PI];
		this.nTime = 0;
		this.think = this.thinkInit;
	},
  
	think: function() {},

	thinkInit: function() {
		this.oMobile.fSpeed = 2;
		this.think = this.thinkGo;
	},

	thinkGo: function() {
		if (this.nTime <= 0) { // changement d'activité si le timer tombe à zero
			this.nAngle = MathTools.rnd(0, 7);
			this.oMobile.fTheta = this.aAngles[this.nAngle];
			this.nTime = MathTools.rnd(15, 25) * 4;
		} else {
			--this.nTime;
			this.oMobile.moveForward();
			if (this.oMobile.oWallCollision.x !== 0 || this.oMobile.oWallCollision.y !== 0) {
				this.nTime = 0;
			}
		}
	}
});


/** Gestion d'un ensemble de Tiles stockées dans la même image
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet
 * L'objet Tile permet de renseigner le raycaster sur la séquence d'image à charger
 */
O2.createClass('O876_Raycaster.Tile',  {
	oImage : null, // Objet image contenant toutes les Tiles
	nWidth : 0, // Largeur d'une Tile en pixel (!= oImage.width)
	nHeight : 0, // Hauteur d'une Tile en pixel
	sSource : null, // Url source de l'image
	nFrames : 0, // Nombre de Tiles
	aAnimations : null, // Liste des animations
	bShading : true,
	nScale: 1,

	__construct : function(oData) {
		if (oData !== undefined) {
			this.sSource = oData.src;
			this.nFrames = oData.frames;
			this.nWidth = oData.width;
			this.nHeight = oData.height;
			this.bShading = true;
			this.nScale = oData.scale || 1;
			if ('noshading' in oData && oData.noshading) {
				this.bShading = false;
			}
			// animations
			if (oData.animations) {
				var oAnimation, iFrame;
				this.aAnimations = [];
				for ( var iAnim = 0; iAnim < oData.animations.length; iAnim++) {
					if (oData.animations[iAnim] === null) {
						for (iFrame = 0; iFrame < 8; iFrame++) {
							this.aAnimations.push(null);
						}
					} else {
						for (iFrame = 0; iFrame < 8; iFrame++) {
							oAnimation = new O876_Raycaster.Animation();
							oAnimation.nStart = oData.animations[iAnim][0][iFrame];
							oAnimation.nCount = oData.animations[iAnim][1];
							oAnimation.nDuration = oData.animations[iAnim][2];
							oAnimation.nLoop = oData.animations[iAnim][3];
							this.aAnimations.push(oAnimation);
						}
					}
				}
			}
		}
	}
});

/** ArrayTools Boîte à outil pour les tableau (Array)
 * O876 raycaster project
 * 2012-01-01 Raphaël Marandet
 */


O2.createObject('ArrayTools', {
	
	/** Retire un élément d'un Array
	 * @param aArray élément à traiter
	 * @param nItem index de l'élément à retirer
	 */
	removeItem: function(aArray, nItem) {
		var aItem = Array.prototype.splice.call(aArray, nItem, 1);
		return aItem[0];
		/*
		if (nItem >= (aArray.length - 1)) {
			return aArray.pop();
		} else {
			var oItem = aArray[nItem];
			aArray[nItem] = aArray.pop();
			return oItem;
		}*/
	},
	
	isArray: function(o) {
		return Array.isArray(o);
	},
	
	//+ Jonas Raoni Soares Silva
	//@ http://jsfromhell.com/array/shuffle [v1.0]
	shuffle: function(o){ //v1.0
		for(var j, x, i = o.length; i; j = (Math.random() * i | 0), x = o[--i], o[i] = o[j], o[j] = x);
		return o;
	},
	
	// renvoie l'indice du plus grand élément
	theGreatest: function(a) {
		if (!a) {
			return null;
		}
		var nGreater = a[0], iGreater = 0;
		for (var i = 1; i < a.length; ++i) {
			if (a[i] > nGreater) {
				nGreater = a[iGreater = i];
			}
		}
		return iGreater;
	},
	
	unique: function(aInput) {
		var u = {}, a = [];
		for (var i = 0, l = aInput.length; i < l; ++i) {
			if (!u.hasOwnProperty(aInput[i])) {
				a.push(aInput[i]);
				u[aInput[i]] = 1;
			}
		}
		return a;
	}
});

O2.createClass('Astar.Point', {
	x : 0,
	y : 0,
	__construct : function(x, y) {
		this.x = x;
		this.y = y;
	}
});

O2.createClass('Astar.Nood', {
	fGCost : 0.0,
	fHCost : 0.0,
	fFCost : 0.0,
	oParent : null,
	oPos : null,

	__construct : function() {
		this.oParent = new Astar.Point(0, 0);
		this.oPos = new Astar.Point(0, 0);
	},

	isRoot : function() {
		return this.oParent.x == this.oPos.x && this.oParent.y == this.oPos.y;
	}
});

O2.createClass('Astar.NoodList', {
	aList : null,

	__construct : function() {
		this.aList = {};
	},

	add : function(oNood) {
		this.set(oNood.oPos.x, oNood.oPos.y, oNood);
	},

	set : function(x, y, oNood) {
		this.aList[this.getKey(x, y)] = oNood;
	},

	count : function() {
		var n = 0, i = '';
		for (i in this.aList) {
			n++;
		}
		return n;
	},

	exists : function(x, y) {
		if (this.getKey(x, y) in this.aList) {
			return true;
		} else {
			return false;
		}
	},

	getKey : function(x, y) {
		return x.toString() + '__' + y.toString();
	},

	get : function(x, y) {
		if (this.exists(x, y)) {
			return this.aList[this.getKey(x, y)];
		} else {
			return null;
		}
	},

	del : function(x, y) {
		delete this.aList[this.getKey(x, y)];
	},

	empty : function() {
		var i = '';
		for (i in this.aList) {
			return false;
		}
		return true;
	}
});

O2.createClass('Astar.Land', {
	bUseDiagonals : false,
	MAX_ITERATIONS : 2048,
	nIterations : 0,
	aTab : null,
	nWidth : 0,
	nHeight : 0,
	oOpList : null,
	oClList : null,
	aPath : null,
	aMoves : null,
	xLast : 0,
	yLast : 0,
	nLastDir : 0,

	LAND_BLOCK_WALKABLE: 0,

	init : function(a) {
		this.aTab = a;
		this.nHeight = a.length;
		this.nWidth = a[0].length;
	},

	reset : function() {
		this.oOpList = new Astar.NoodList();
		this.oClList = new Astar.NoodList();
		this.aPath = [];
		this.aMoves = [];
		this.nIterations = 0;
	},

	distance : function(x1, y1, x2, y2) {
		return MathTools.distance(x1 - x2, y1 - y2);
	},

	setCell : function(x, y, n) {
		if (this.aTab[y] !== undefined && this.aTab[y][x] !== undefined) {
			this.aTab[y][x] = n;
		} else {
			throw new Error(
					'Astar: Land.badCell: writing tile out of land: ' + x + ', ' + y);
		}
	},

	getCell : function(x, y) {
		if (this.aTab[y]) {
			if (x < this.aTab[y].length) {
				return this.aTab[y][x];
			}
		}
		throw new Error('Astar: Land.badTile: read tile out of land: ' + x + ', ' + y);
	},

	isCellWalkable : function(x, y) {
		try {
			return this.getCell(x, y) == this.LAND_BLOCK_WALKABLE;
		} catch (e) {
			return false;
		}
	},

	// Transferer un node de la liste ouverte vers la liste fermee
	closeNood : function(x, y) {
		var n = this.oOpList.get(x, y);
		if (n) {
			this.oClList.set(x, y, n);
			this.oOpList.del(x, y);
		}
	},

	addAdjacent : function(x, y, xArrivee, yArrivee) {
		var i, j;
		var i0, j0;
		var oTmp;
		for (i0 = -1; i0 <= 1; i0++) {
			i = x + i0;
			if ((i < 0) || (i >= this.nWidth)) {
				continue;
			}
			for (j0 = -1; j0 <= 1; j0++) {
				if (!this.bUseDiagonals && (j0 * i0) !== 0) {
					continue;
				}
				j = y + j0;
				if ((j < 0) || (j >= this.nHeight)) {
					continue;
				}
				if ((i == x) && (j == y)) {
					continue;
				}
				if (!this.isCellWalkable(i, j)) {
					continue;
				}

				if (!this.oClList.exists(i, j)) {
					oTmp = new Astar.Nood();
					oTmp.fGCost = this.oClList.get(x, y).fGCost	+ this.distance(i, j, x, y);
					oTmp.fHCost = this.distance(i, j, xArrivee,	yArrivee);
					oTmp.fFCost = oTmp.fGCost + oTmp.fHCost;
					oTmp.oPos = new Astar.Point(i, j);
					oTmp.oParent = new Astar.Point(x, y);

					if (this.oOpList.exists(i, j)) {
						if (oTmp.fFCost < this.oOpList.get(i, j).fFCost) {
							this.oOpList.set(i, j, oTmp);
						}
					} else {
						this.oOpList.set(i, j, oTmp);
					}
				}
			}
		}
	},

	// Recherche le meilleur noeud de la liste et le renvoi
	bestNood : function(oList) {
		var oBest = null;
		var oNood;
		var iNood = '';

		for (iNood in oList.aList) {
			oNood = oList.aList[iNood];
			if (oBest === null) {
				oBest = oNood;
			} else if (oNood.fFCost < oBest.fFCost) {
				oBest = oNood;
			}
		}
		return oBest;
	},

	findPath : function(xFrom, yFrom, xTo, yTo) {
		this.reset();
		var oBest;
		var oDepart = new Astar.Nood();
		oDepart.oPos = new Astar.Point(xFrom, yFrom);
		oDepart.oParent = new Astar.Point(xFrom, yFrom);
		var xCurrent = xFrom;
		var yCurrent = yFrom;
		this.oOpList.add(oDepart);
		this.closeNood(xCurrent, yCurrent);
		this.addAdjacent(xCurrent, yCurrent, xTo, yTo);

		var iIter = 0;

		while (!((xCurrent == xTo) && (yCurrent == yTo)) && (!this.oOpList.empty())) {
			oBest = this.bestNood(this.oOpList);
			xCurrent = oBest.oPos.x;
			yCurrent = oBest.oPos.y;
			this.closeNood(xCurrent, yCurrent);
			this.addAdjacent(oBest.oPos.x, oBest.oPos.y, xTo, yTo);
			if (++iIter > this.MAX_ITERATIONS) {
				throw new Error('Astar: Land.badPath: pathfinder, too much iterations');
			}
		}
		if (this.oOpList.empty()) {
			 throw new Error('Astar: Land.badDest: pathfinder, no path to destination');
		}
		this.nIterations = iIter;
		this.buildPath(xTo, yTo);
		this.transformPath(xFrom, yFrom);
	},

	buildPath : function(xTo, yTo) {
		var oCursor = this.oClList.get(xTo, yTo);
		if (oCursor !== null) {
			while (!oCursor.isRoot()) {
				this.aPath.unshift(new Astar.Point(oCursor.oPos.x, oCursor.oPos.y));
				oCursor = this.oClList.get(oCursor.oParent.x, oCursor.oParent.y);
			}
		}
	},

	getDirFromXY : function(xFrom, yFrom, x, y) {
		// Cas Nord 0
	if (xFrom == x) {
		if ((yFrom - 1) == y) {
			return 0;
		}
		if ((yFrom + 1) == y) {
			return 2;
		}
	}
	if (yFrom == y) {
		if ((xFrom - 1) == x) {
			return 3;
		}
		if ((xFrom + 1) == x) {
			return 1;
		}
	}
},

// Transformer la suite de coordonnées en couple (direction, distance)
	transformPath : function(xFrom, yFrom) {
		var i;
		if (this.aPath.length === 0) {
			return;
		}
		this.xLast = this.aPath[0].x;
		this.yLast = this.aPath[0].y;
		this.nLastDir = this.getDirFromXY(xFrom, yFrom, this.xLast,
				this.yLast);
		var d;
		var n = 1;

		var nLen = this.aPath.length;
		for (i = 1; i < nLen; i++) {
			d = this.getDirFromXY(this.xLast, this.yLast,
					this.aPath[i].x, this.aPath[i].y);
			this.xLast = this.aPath[i].x;
			this.yLast = this.aPath[i].y;
			if (d == this.nLastDir) {
				n++;
			} else {
				this.aMoves.push(this.nLastDir);
				this.aMoves.push(n);
				this.nLastDir = d;
				n = 1;
			}
		}
		this.aMoves.push(this.nLastDir);
		this.aMoves.push(n);
	}
});

/** GfxTools Boîte à outil graphique
 * O876 raycaster project
 * 2012-01-01 Raphaël Marandet
 */

O2.createObject('GfxTools', {
	/** Calcule une couleur CSS à partir de donnée R G B A 
	 * @param aData objet {r g b a} r, g, b sont des entier 0-255 a est un flottant 0-1
	 * @return chaine CSS utilisable par le canvas
	 */
	buildRGBA : function(xData) {
		return GfxTools.buildRGBAFromStructure(GfxTools.buildStructure(xData));
	},
	
	buildStructure: function(xData) {
		if (typeof xData === "object") {
			return xData;
		} else if (typeof xData === "number") {
			return GfxTools.buildStructureFromInt(xData);
		} else if (typeof xData === "string") {
			switch (xData.length) {
				case 3:
					return GfxTools.buildStructureFromString3(xData);
					
				case 4:
					if (xData[0] === '#') {
						return GfxTools.buildStructureFromString3(xData.substr(1));
					} else {
						throw new Error('invalid color structure');
					}
					
				case 6:
					return GfxTools.buildStructureFromString6(xData);
					
				case 7:
					if (xData[0] === '#') {
						return GfxTools.buildStructureFromString6(xData.substr(1));
					} else {
						throw new Error('invalid color structure');
					}
					
				default:
					var rx = xData.match(/^rgb\( *([0-9]{1,3}) *, *([0-9]{1,3}) *, *([0-9]{1,3}) *\)$/);
					if (rx) {
						return {r: rx[1] | 0, g: rx[2] | 0, b: rx[3] | 0};
					} else {
						throw new Error('invalid color structure ' + xData);
					}
			}
		}
	},
	
	buildStructureFromInt: function(n) {
		var r = (n >> 16) & 0xFF;
		var g = (n >> 8) & 0xFF;
		var b = n & 0xFF;
		return {r: r, g: g, b: b};
	},
	
	buildStructureFromString3: function(s) {
		var r = parseInt('0x' + s[0] + s[0]);
		var g = parseInt('0x' + s[1] + s[1]);
		var b = parseInt('0x' + s[2] + s[2]);
		return {r: r, g: g, b: b};
	},

	buildStructureFromString6: function(s) {
		var r = parseInt('0x' + s[0] + s[1]);
		var g = parseInt('0x' + s[2] + s[3]);
		var b = parseInt('0x' + s[4] + s[5]);
		return {r: r, g: g, b: b};
	},

	buildRGBAFromStructure: function(oData) {
		var s1 = 'rgb';
		var s2 = oData.r.toString() + ', ' + oData.g.toString() + ', ' + oData.b.toString();
		if ('a' in oData) {
			s1 += 'a';
			s2 += ', ' + oData.a.toString();
		}
		return s1 + '(' + s2 + ')';
	},
	
	buildString3FromStructure: function(oData) {
		var sr = ((oData.r >> 4) & 0xF).toString(16);
		var sg = ((oData.g >> 4) & 0xF).toString(16);
		var sb = ((oData.b >> 4) & 0xF).toString(16);
		return sr + sg + sb;
	},
	
	
	/**
	 * Dessine un halo lumine sur la surface du canvas
	 */
	drawCircularHaze: function(oCanvas, sOptions) {
		sOptions = sOptions || '';
		var aOptions = sOptions.split(' ');
		var w = oCanvas.width;
		var h = oCanvas.height;
		var wg = Math.max(w, h);

		// gradient noir
		var c3 = O876.CanvasFactory.getCanvas();
		c3.width = c3.height = wg;
		var ctx3 = c3.getContext('2d');
		var oRadial = ctx3.createRadialGradient(
			wg >> 1, wg >> 1, wg >> 2,
			wg >> 1, wg >> 1, wg >> 1
		);
		oRadial.addColorStop(0, 'rgba(0, 0, 0, 0)');
		oRadial.addColorStop(1, 'rgba(0, 0, 0, 1)');
		ctx3.fillStyle = oRadial;
		ctx3.fillRect(0, 0, wg, wg);

		// gradient lumière
		var c2 = O876.CanvasFactory.getCanvas();
		c2.width = w;
		c2.height = h;
		var ctx2 = c2.getContext('2d');
		ctx2.fillStyle = 'rgb(0, 0, 0)';
		ctx2.drawImage(oCanvas, 0, 0);
		if (aOptions.indexOf('top') >= 0) {
			ctx2.drawImage(c3, 0, 0, wg, wg, 0, 0, w, w);
			ctx2.fillRect(0, w, w, h - w);
		} else if (aOptions.indexOf('bottom') >= 0) {
			ctx2.fillRect(0, 0, w, h - w);
			ctx2.drawImage(c3, 0, 0, wg, wg, 0, h - w, w, w);
		} else if (aOptions.indexOf('middle') >= 0) {
			ctx2.fillRect(0, 0, w, (h - w) >> 1);
			ctx2.drawImage(c3, 0, 0, wg, wg, 0, (h - w) >> 1, w, w);
			ctx2.fillRect(0, ((h - w) >> 1) + w, w, (h - w) >> 1);
		} else {
			ctx2.drawImage(c3, 0, 0, wg, wg, 0, 0, w, h);
		}
		
		var oContext = oCanvas.getContext('2d');
		var gco = oContext.globalCompositeOperation;
		oContext.globalCompositeOperation = 'lighter';
		oContext.drawImage(c2, 0, 0);
		if (aOptions.indexOf('strong') >= 0) {
			oContext.drawImage(c2, 0, 0);
		}
		oContext.globalCompositeOperation = gco;
	}	
});

O2.createObject('Marker', {
	iterate: function(o, f) {
		o.forEach(function(aRow, x) {
			if (aRow) {
				if (!aRow.forEach) {
					throw new Error('not a marker !');
				}
				aRow.forEach(function(v, y) {
					if (v) {
						f(x, y, v);
					}
				});
			}
		});
	},
	
	/**
	 * Serialize the registry
	 * each cell outputs a structure like : {x:...,  y:...,  v:...}
	 */
	serialize: function(o) {
		var a = [];
		Marker.iterate(o, function(x, y, v) {
			a.push({x: x, y: y, v: v});
		});
		return a;
	},
	
	unserialize: function(d) {
		var o = Marker.create();
		d.forEach(function(dx) {
			if (dx) {
				Marker.markXY(o, dx.x, dx.y, dx.v);
			}
		});
		return o;
	},
	
	create: function() {
		return [];
	},
	
	getMarkXY : function(o, x, y) {
		if (o[x]) {
			return o[x][y];
		} else {
			return false;
		}
	},

	markXY : function(o, x, y, v) {
		if (!o[x]) {
			o[x] = Marker.create();
		}
		if (v === undefined) {
			v = true;
		}
		o[x][y] = v;
	},
	
	clearXY : function(o, x, y) {
		if (!o[x]) {
			return;
		}
		o[x][y] = false;
	},


	markBlock : function(o, x1, y1, x2, y2, v) {
		var xFrom = Math.min(x1, x2);
		var yFrom = Math.min(y1, y2);
		var xTo = Math.max(x1, x2);
		var yTo = Math.max(y1, y2);
		var x, y;
		for (x = xFrom; x <= xTo; x++) {
			for (y = yFrom; y <= yTo; y++) {
				Marker.markXY(o, x, y, v);
			}
		}
	},
	
	clearBlock : function(o, x1, y1, x2, y2) {
		var xFrom = Math.min(x1, x2);
		var yFrom = Math.min(y1, y2);
		var xTo = Math.max(x1, x2);
		var yTo = Math.max(y1, y2);
		var x, y;
		for (x = xFrom; x <= xTo; x++) {
			for (y = yFrom; y <= yTo; y++) {
				Marker.clearXY(o, x, y);
			}
		}
	}
});

/** MathTools Boîte à outil mathématique
 * O876 raycaster project
 * 2012-01-01 Raphaël Marandet
 */

var PI = 3.14159;
var MathTools = {
	aQuadrans : [ -PI / 2, -PI / 4, 0, PI / 4, PI / 2 ],
	fToDeg : 180 / PI,
	fToRad : PI / 180,
	
	pRndFunc: Math.random,

	sBASE64 : 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',

	iRndTable : 0,
	nRndSeed: Date.now() % 2147483647,
	
	aRndTable : [ 0, 8, 109, 220, 222, 241, 149, 107, 75, 248, 254, 140, 16,
			66, 74, 21, 211, 47, 80, 242, 154, 27, 205, 128, 161, 89, 77, 36,
			95, 110, 85, 48, 212, 140, 211, 249, 22, 79, 200, 50, 28, 188, 52,
			140, 202, 120, 68, 145, 62, 70, 184, 190, 91, 197, 152, 224, 149,
			104, 25, 178, 252, 182, 202, 182, 141, 197, 4, 81, 181, 242, 145,
			42, 39, 227, 156, 198, 225, 193, 219, 93, 122, 175, 249, 0, 175,
			143, 70, 239, 46, 246, 163, 53, 163, 109, 168, 135, 2, 235, 25, 92,
			20, 145, 138, 77, 69, 166, 78, 176, 173, 212, 166, 113, 94, 161,
			41, 50, 239, 49, 111, 164, 70, 60, 2, 37, 171, 75, 136, 156, 11,
			56, 42, 146, 138, 229, 73, 146, 77, 61, 98, 196, 135, 106, 63, 197,
			195, 86, 96, 203, 113, 101, 170, 247, 181, 113, 80, 250, 108, 7,
			255, 237, 129, 226, 79, 107, 112, 166, 103, 241, 24, 223, 239, 120,
			198, 58, 60, 82, 128, 3, 184, 66, 143, 224, 145, 224, 81, 206, 163,
			45, 63, 90, 168, 114, 59, 33, 159, 95, 28, 139, 123, 98, 125, 196,
			15, 70, 194, 253, 54, 14, 109, 226, 71, 17, 161, 93, 186, 87, 244,
			138, 20, 52, 123, 251, 26, 36, 17, 46, 52, 231, 232, 76, 31, 221,
			84, 37, 216, 165, 212, 106, 197, 242, 98, 43, 39, 175, 254, 145,
			190, 84, 118, 222, 187, 136, 120, 163, 236, 249 ],

	/** Calcule le sign d'une valeur
	 * @param x valeur à tester
	 * @return -1 si x < 0, +1 si y > 0, 0 si x = 0
	 */
	sign : function(x) {
		if (x === 0) {
			return 0;
		}
		return x > 0 ? 1 : -1;
	},

	/** Calcul de la distance entre deux point séparés par dx, dy
	 * @param dx delta x
	 * @param dx delta y
	 * @return float
	 */
	distance : function(dx, dy) {
		return Math.sqrt((dx * dx) + (dy * dy));
	},
	
	/**
	 * Détermine si un point (xTarget, yTarget) se situe à l'intérieur de l'angle 
	 * formé par le sommet (xCenter, yCenter) et l'ouverture fAngle.
	 * @param float xCenter, yCenter sommet de l'angle
	 * @param float fAperture ouverture de l'angle
	 * @param float fBissect direction de la bissectrice de l'angle
	 * @param float xTarget, yTarget point à tester
	 * @return boolean
	 */
	isPointInsideAngle: function(xCenter, yCenter, fBissect, fAperture, xTarget, yTarget) {
		var xPoint = xTarget - xCenter;
		var yPoint = yTarget - yCenter;
		var dPoint = MathTools.distance(xPoint, yPoint);
		xPoint /= dPoint;
		yPoint /= dPoint;
		var xBissect = Math.cos(fBissect);
		var yBissect = Math.sin(fBissect);
		var fDot = xPoint * xBissect + yPoint * yBissect;
		return Math.acos(fDot) < (fAperture / 2);
	},

	/** Renvoie, pour un angle donnée, le code du cadran dans lequel il se trouve
	 *	-PI/2...cadran 0...-PI/4...cadran 1...0...cadran 2...PI/4...cadran 3...PI/2
	 * @return entier entre 0 et 4 : la valeur 4 indique que l'angle est hors cadran
	 */
	quadran : function(a) {
		var i = 0;
		while (i < (MathTools.aQuadrans.length - 1)) {
			if (a >= MathTools.aQuadrans[i] && a < MathTools.aQuadrans[i + 1]) {
				break;
			}
			i++;
		}
		return i;
	},

	// conversion radians degres
	toDeg : function(fRad) {
		return fRad * MathTools.fToDeg;
	},

	// Conversion degres radians
	toRad : function(fDeg) {
		return fDeg * MathTools.fToRad;
	},

	
	/**
	 * Défini la graine du générateur 8 bits
	 * @param int n nouvelle graine
	 */
	rndSeed8: function(n) {
		MathTools.iRndIndex = n % MathTools.aRndTable.length;
	},

	/**
	 * Générateur de nombre pseudo-aléatoire sur 8 bits.
	 * Générateur sur table très faible. A n'utiliser que pour des truc vraiment pas importants.
	 * @param int nMin valeur mini
	 * @param int nMax valeur maxi
	 * @return int
	 */
	rnd8 : function(nMin, nMax) {
		var r = MathTools.aRndTable[MathTools.iRndIndex];
		MathTools.iRndIndex = (MathTools.iRndIndex + 1) & 0xFF;
		var d = nMax - nMin + 1;
		return (r * d / 256 | 0) + nMin;
	},
	
	/**
	 * Défini la nouvelle graine du générateur de nombre pseudo aléatoire sur 31 bits;
	 * @param int n nouvelle graine
	 */
	rndSeed31: function(n) {
		var v = n % 2147483647;
		if (v == 0) {
			v = 1;
		}
		return this.nRndSeed = v;
	},

	/** 
	 * Générateur de nombre aléatoire sur 31 bits;
	 * Si les paramètre ne sont pas précisé on renvoie le nombre sur 31 bits;
	 * sinon on renvoie une valeur redimensionné selon les borne min et max définies
	 * @param int nMin valeur mini
	 * @param int nMax valeur maxi
	 * @return int
	 */ 
	rnd31: function(nMin, nMax) {
		var nRnd = this.rndSeed31(16807 * this.nRndSeed);
		if (nMin === undefined) {
			return nRnd;
		} else {
			return nRnd * (nMax - nMin + 1) / 2147483647 + nMin | 0;
		}
	},
	
	
	/**
	 * Générateur aléatoire standar de JS
	 * Si aucun paramètre n'est spécifié, renvoie un nombre floatant entre 0 et 1
	 * si non renvoie un nombre entier entre les bornes spécifiées
	 * @param int nMin valeur mini
	 * @param int nMax valeur maxi
	 * @return int / float
	 */
	rndJS: function(nMin, nMax) {
		var fRnd = Math.random();
		if (nMin === undefined) {
			return fRnd;
		} else {
			return (fRnd * (nMax - nMin + 1) | 0) + nMin;
		}
	},

	/**
	 * Fonction abstraite 
	 * nombre aléatoire entre deux bornes
	 * @param int nMin valeur mini
	 * @param int nMax valeur maxi
	 * @return int
	 */
	rnd : null,
	
	benchmarkRnd: function() {
		var x, i, a = [];
		console.time('rnd js');
		for (i = 0; i < 1000000; ++i) {
			x = MathTools.rnd(0, 10);
			if (a[x] === undefined) {
				a[x] = 1;
			} else {
				++a[x];
			}
		}
		console.timeEnd('rnd js');
		console.log(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);

		a = [];
		console.time('rnd 31');
		for (i = 0; i < 1000000; ++i) {
			x = MathTools.rnd31(0, 10);
			if (a[x] === undefined) {
				a[x] = 1;
			} else {
				++a[x];
			}
		}
		console.timeEnd('rnd 31');
		console.log(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
	},

	// Relance plusieur fois un dé, aditionne et renvoie les résultats
	rollDice : function(nFaces, nCount) {
		if (nCount > 3) {
			return (nCount - 3) * ((1 + nFaces) / 2) + MathTools.rollDice(nFaces, 3) | 0;
		}
		var n = 0;
		for ( var i = 0; i < nCount; i++) {
			n += MathTools.rnd(1, nFaces);
		}
		return n;
	},

	// Choix d'un éléments dans un tableau
	rndChoose : function(a) {
		if (a.length) {
			return a[MathTools.rnd(0, a.length - 1)];
		} else {
			return null;
		}
	},

	// Converti n (decimal) en base 64 
	base64Encode : function(n, l) {
		var s = '';
		if (l === undefined) {
			l = 0;
		}
		while (n > 0) {
			s = MathTools.sBASE64.charAt(n & 63) + s;
			l--;
			n >>= 6;
		}
		while (l > 0) {
			s = 'A' + s;
			l--;
		}
		return s;
	},

	base64Decode : function(s64) {
		var n = 0, nLen = s64.length;
		for ( var i = 0; i < nLen; i++) {
			n = (n << 6) | MathTools.sBASE64.indexOf(s64.charAt(i));
		}
		return n;
	}
};


MathTools.rnd = MathTools.rndJS;
O2.createClass('O876_Raycaster.Transistate', {
	nInterval : 160,
	oInterval : null,
	oRafInterval: null,
	pDoomloop : null,
	sDoomloopType : 'interval',
	sDefaultDoomloopType: 'interval',
	bPause : false,
	nTimeModulo : 0,
	_sState : '',
	bBound: false,

	__construct : function(sFirst) {
		this.setDoomloop(sFirst);
	},


	/** Definie la procédure à lancer à chaque doomloop
	 * @param sProc nom de la méthode de l'objet à lancer
	 */
	setDoomloop : function(sProc, sType) {
		this.sDoomloopType = sType;
		if (!(sProc in this)) {
			throw new Error('"' + sProc + '" is not a valid timer proc');
		}
		this.pDoomloop = this[this._sState = sProc].bind(this);
		this.stopTimers();
		switch (sType) {
			case 'interval':
				this.oInterval = window.setInterval(this.pDoomloop, this.nInterval);
			break;
			
			case 'raf':
				this.oRafInterval = window.requestAnimationFrame(this.pDoomloop);
			break;
			
			default:
				this.setDoomloop(sProc, this.sDefaultDoomloopType);
			break;
		}
	},

	/**
	 * Returns the timer proc name
	 * (defined with setDoomloop)
	 * @return string
	 */
	getDoomLoop : function() {
		return this._sState;
	},

	doomloop : function() {
		this.pDoomloop();
	},


	/**
	 * Stop all timer procedure
	 */
	stopTimers: function() {
		if (this.oInterval) {
			window.clearInterval(this.oInterval);
			this.oInterval = null;
		}
		if (this.oRafInterval) {
			window.cancelAnimationFrame(this.oRafInterval);
			this.oRafInterval = null;
		}
	},

	/** 
	 * Met la machine en pause
	 * Le timer est véritablement coupé
	 */
	pause : function() {
		if (!this.bPause) {
			this.bPause = true;
			this.stopTimers();
		}
	},

	/** 
	 * Remet la machine en route après une pause
	 * Le timer est recréé.
	 */
	resume : function() {
		if (this.bPause) {
			this.setDoomloop(this.getDoomLoop(), this.sDoomloopType);
			this.bPause = false;
		}
	}
});

/**
 * Classe de personnalisation des 4 face d'un block Cette classe permet de
 * personaliser l'apparence ou les fonctionnalité d'une face d'un mur
 * Actuellement cette classe gène la personnalisation des texture du mur
 */
O2.createClass('O876_Raycaster.XMap', {
	aMap : null,
	nWidth : 0,
	nHeight : 0,
	nBlockWidth : 0,
	nBlockHeight : 0,
	nShadeFactor : 0,

	/*
	 * attributs de bloc utilisés Il y a 4 groupe d'attribut 1 pourt chaque face
	 * ... par cloneWall : la fonctionnalité de personalisation de la texture -
	 * bWall : flag à true si la texture du mur est personnalisé - oWall :
	 * canvas de la nouvelle texture - x - y ...
	 */

	setSize : function(w, h) {
		this.aMap = [];
		var aBlock, aRow, x, y, nSide;
		this.nWidth = w;
		this.nHeight = h;
		for (y = 0; y < h; y++) {
			aRow = [];
			for (x = 0; x < w; x++) {
				aBlock = [];
				for (nSide = 0; nSide < 6; nSide++) {
					aBlock.push({
						x : x,
						y : y,
						oCanvas : null
					});
				}
				aRow.push(aBlock);
			}
			this.aMap.push(aRow);
		}
	},

	get : function(x, y, nSide) {
		if (x < 0 || y < 0) {
			throw new Error('x or y out of bound ' + x + ', ' + y);
		}
		return this.aMap[y][x][nSide];
	},

	set : function(x, y, nSide, xValue) {
		this.aMap[y][x][nSide] = xValue;
	},

	setBlockSize: function(w, h) {
		this.nBlockHeight = h;
		this.nBlockWidth = w;
	},

	/**
	 * créer une copie de la texture du mur spécifié.
	 * Renvoie le canvas nouvellement créé pour qu'on puisse dessiner dessus.
	 * Note : cette fonction est pas très pratique mais elle est utilisée par Raycaster.cloneWall
	 * @param oTextures textures murale du laby
	 * @param iTexture numéro de la texture murale
	 * @param x
	 * @param y position du mur (pour indexation)
	 * @param nSide face du block concernée.
	 */
	cloneTexture: function(oTextures, iTexture, x, y, nSide) {
		var oCanvas;
		var oBlock = this.get(x, y, nSide);
		if (oBlock.oCanvas === null) {
			oBlock.oCanvas = oCanvas = O876.CanvasFactory.getCanvas();
		} else {
			oCanvas = oBlock.oCanvas;
			delete oCanvas.__shaded;
		}
		var w = this.nBlockWidth;
		var h;
		if (nSide < 4) {
			h = this.nBlockHeight;
		} else {
			// flat texture
			h = w;
			oBlock.imageData = null;
			oBlock.imageData32 = null;
			
			//oFloor.imageData = oCtx.getImageData(0, 0, oFlat.width, oFlat.height);
			//oFloor.imageData32 = new Uint32Array(oFloor.imageData.data.buffer);
		}
		oCanvas.width = w;
		oCanvas.height = h;
		oCanvas.getContext('2d').drawImage(oTextures, iTexture * w, 0, w, h, 0, 0, w, h);
		return oCanvas;
	},
});

var RC = {
  OBJECT_TYPE_NONE: 0,
  OBJECT_TYPE_MOB: 1,			// Mobile object with Thinker procedure
  OBJECT_TYPE_PLAYER: 2,		// Player (non visible, user controlled mob)
  OBJECT_TYPE_PLACEABLE: 3,		// Non-mobile visible and collisionnable object
  OBJECT_TYPE_MISSILE: 4,		// Short lived mobile with owner 
  OBJECT_TYPE_ITEM: 5,			// Inventory objet
  
  FX_NONE: 0,					// Pas d'effet graphique associé au sprite
  FX_LIGHT_ADD: 1,				// Le sprite est translucide (opération ADD lors du dessin)
  FX_LIGHT_SOURCE: 2,			// Le sprite ne devien pas plus sombre lorsqu'il s'éloigne de la camera
  FX_ALPHA_75: 1 << 2,
  FX_ALPHA_50: 2 << 2,			// le sprite est Alpha 50 % transparent
  FX_ALPHA_25: 3 << 2,
  FX_ALPHA: [1, 0.75, 0.50, 0.25, 0],
  FX_DIM0: 0x10,				// indicateur dim 0 pour corriger un bug graphique d'optimisation
};


/** Liste des code clavier javascript
 * 2012-01-01 Raphaël Marandet
 */

var KEYS = {
  MOUSE: {
    KEY: 0,
    X: 0,
    Y: 1,
    BUTTONS: {
      LEFT: 2,
      RIGHT: 3,
      MIDDLE: 4
    },
    SCROLLUP: 5,
    SCROLLDOWN: 6
  },
  BACKSPACE:     8,
  TAB:           9,
  ENTER:        13,
  SHIFT:        16,
  CTRL:         17,
  ALT:          18,
  PAUSE:        19,
  CAPSLOCK:     20,
  ESCAPE:       27,
  SPACE:        32,
  PAGEUP:       33,
  PAGEDOWN:     34,
  END:          35,
  HOME:         36,
  LEFT:         37,
  UP:           38,
  RIGHT:        39,
  DOWN:         40,
  INSERT:       45,
  DELETE:       46,
  ALPHANUM: {
    0: 48,
    1: 49,
    2: 50,
    3: 51,
    4: 52,
    5: 53,
    6: 54,
    7: 55,
    8: 56,
    9: 57,
    A: 65,
    B: 66,
    C: 67,
    D: 68,
    E: 69,
    F: 70,
    G: 71,
    H: 72,
    I: 73,
    J: 74,
    K: 75,
    L: 76,
    M: 77,
    N: 78,
    O: 79,
    P: 80,
    Q: 81,
    R: 82,
    S: 83,
    T: 84,
    U: 85,
    V: 86,
    W: 87,
    X: 88,
    Y: 89,
    Z: 90
  },
  NUMPAD:       {
    0:  96,
    1:  97,
    2:  98,
    3:  99,
    4: 100,
    5: 101,
    6: 102,
    7: 103,
    8: 104,
    9: 105,
    MULTIPLY: 106,
    ADD: 107,
    SUBSTRACT: 109,
    POINT: 110,
    DIVIDE: 111
  },
  F1:        112,
  F2:        113,
  F3:        114,
  F4:        115,
  F5:        116,
  F6:        117,
  F7:        118,
  F8:        119,
  F9:        120,
  F10:       121,
  F11:       122,
  F12:       123,
  NUMLOCK:   144,
  SCROLLLOCK:145,
  SEMICOLON: 186,
  EQUAL:     187,
  COMMA:     188,
  DASH:      189,
  PERIOD:    190,
  SLASH:     191,
  GRAVE:     192,
  OPENBRACKET:219,
  BACKSLASH: 220,
  CLOSEBRACKET:221,
  QUOTE:     222
};


/**
 * Outil d'exploitation de requete Ajax
 * Permet de chainer les requete ajax avec un système de file d'attente.
 */

O2.createObject('XHR', {
	oInstance : null,
	aQueue : [],
	bAjaxing : false,
	oCurrentTarget : null,
	sCurrentURL : '',
	
	
	getQueue: function() {
		return XHR.aQueue;
	},
	
	// Renvoie une instance XHR
	getInstance : function() {
		if (XHR.oInstance === null) {
			XHR.oInstance = new XMLHttpRequest();
		}
		return XHR.oInstance;
	},

	dataReceived : function(oEvent) {
		var xhr = oEvent.target;
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				switch (typeof XHR.oCurrentTarget) {
				case 'function':
					XHR.oCurrentTarget(xhr.responseText);
					break;

				case 'object':
					XHR.oCurrentTarget.innerHTML = xhr.responseText;
					break;

				case 'string':
					document.getElementById(XHR.oCurrentTarget).innerHTML = xhr.responseText;
					break;
				}
				XHR.bAjaxing = false;
				XHR.nextRequest();
			} else {
				throw new Error('xhr error while getting data from ' + XHR.sCurrentURL);
			}
		}
	},

	nextRequest : function() {
		if (XHR.bAjaxing) {
			return;
		}
		if (XHR.aQueue.length) {
			var a = XHR.aQueue.shift();
			XHR.bAjaxing = true;
			XHR.sCurrentURL = a.url;
			XHR.oCurrentTarget = a.target;
			var xhr = XHR.getInstance();
			xhr.open('GET', XHR.sCurrentURL, true);
			xhr.onreadystatechange = XHR.dataReceived;
			xhr.send(null);
		}
	},

	loadFragment : function(sUrl, oTarget) {
		XHR.aQueue.push({ url: sUrl, target: oTarget });
		XHR.nextRequest();
	},

	storeString : function(sUrl, sString) {
		if (typeof sString === 'object') {
			sString = JSON.stringify(sString);
		}
		var xhr = XHR.getInstance(); 
		if (xhr) {
			xhr.open('POST', sUrl, true);
			xhr.send(sString);
		} else {
			throw new Error('xhr not initialized');
		}
	},

	/**
	 * Get data from server asynchronously and feed the spécified DOM Element
	 * 
	 * @param string sURL url
	 * @param object/string/function oTarget
	 * @return string
	 */
	get : function(sURL, oTarget) {
		return XHR.loadFragment(sURL, oTarget);
	},
	
	post: function(sURL, sData) {
		XHR.storeString(sURL, sData);
	},
	
	/**
	 * Get data from server synchronously.
	 * It is known that querying synchronously is bad for health and makes animals suffer. 
	 * So don't use synchronous ajax calls.
	 */
	getSync: function(sURL) {
		console.warn('Synchronous Ajax Query (url : ' + sURL + ') ! It is known that querying synchronously is bad for health and makes animals suffer.');
		var xhr = XHR.getInstance();
		xhr.open('GET', sURL, false);
	    xhr.send(null);
	    if (xhr.status == 200) {
	    	return xhr.responseText;
	    } else {
	    	throw new Error('XHR failed to load: ' + sURL + ' (' + xhr.status.toString() + ')');
	    }
		
	}
});
var CONFIG = {
  game: {
    interval: 40,         /* timer interval (ms)                */
    doomloop: 'raf', /* doomloop type "raf" or "interval"  */
    fullscreen: false
  },
  raycaster: {
    canvas: 'screen',
    drawMap: true,
    smoothTextures: false
  }
};

O2.createObject('WORLD_DATA.demo', {"map":[[4097,4097,4097,4097,4097,4097,4097,4097,4097,4097,4097,4097,4097,4097,4097,4097,4097,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[4097,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,4097,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[4097,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,4097,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[4097,2,2,2,2,2,2,2,4099,4099,4099,2138117,4099,4099,4099,2,4097,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[4097,2,2,2,2,2,2,2,2138117,6,6,6,6,6,4099,2,4097,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[4097,2,2,2,2,2,2,2,4099,6,6,6,6,6,4099,2,4097,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[4097,2,2,2,2,2,2,2,32775,6,6,6,6,6,4099,2,4097,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[4097,2,2,2,2,2,2,2,4099,6,6,6,6,6,4099,2,4097,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[4097,2,2,2,2,2,2,2,2138117,6,6,6,6,6,4099,2,4097,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[4097,2,2,2,2,2,2,2,4099,4099,4099,4099,4099,4099,4099,2,4097,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[4097,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,4097,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[4097,4097,4097,4097,4097,4097,4097,4097,4097,4097,4097,4097,4097,4097,4097,4097,4097,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]],"uppermap":[[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,4100,4100,4100,4100,4100,4100,4100,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,4100,0,0,0,0,0,4100,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,4100,0,0,0,0,0,4100,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,4100,0,0,0,0,0,4100,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,4100,0,0,0,0,0,4100,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,4100,0,0,0,0,0,4100,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,4100,4100,4100,4100,4100,4100,4100,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]],"visual":{"ceilColor":{"r":0,"g":0,"b":0},"fogColor":{"r":0,"g":0,"b":0},"floorColor":{"r":0,"g":0,"b":0},"fogDistance":2,"light":200,"diffuse":0,"filter":false},"walls":{"src":"data:image\/png;base64,iVBORw0KGgoAAAANSUhEUgAAAwAAAABgCAYAAACqnRVJAAAgAElEQVR4nOy9f0xbaZbn3Ts9lalUJQQKaKDACQFCOZDA8MPgmNiy5QvYsnWNL9f4l2xsbEyMSAgBBIKEEJyAoJKqTpRM\/chUd5WqlOquru50Zaq2e7tVrW51a1rb6taMZjSj0Y52NKN3Na92tX+stNIrvVq983n\/MM+ta4eka\/tHXLOZRzry5f547nPucy7ne85zzrlfamhooLGxkdbWVhoaGqirq6OqqoqqqioaGhpoamqiubkZo9HISy+99BC1trbS0tJCS0sLra2ttLe3c\/LkSdra2rRjR44coampifr6eqqrq6mrq6OyspLy8nKqqqqorq6mpqaGmpoa6urqqK+vp6GhgYaGBgwGAwaDgSNHjmjU2NiobYvj9fX11NfXU1dXp11bX19PbW0t1dXVVFVVUVlZqVFDQwNlZWX0HdlfQMPGmkfuM9aWYawtw3ykEvORSoaNNXtSsOOzX7EtSFwnjgU7aoj1NBScJ\/r\/vPS46x41RnHsaef\/S0950z+jveZL\/7zE8eJn+7jriudaXK\/vM9bT8NC9imXt88rAXnJQLJf6Y6WQ\/+6Gcg4f+iP2P\/MHPPfMH3D0hf0MHDmEvaXqicv\/hr2aDUc13RYj66crOW3tZM1Rw0VrGavWA0yMjjERjJAMxxiPxolH48SiMaKRKOFwmNHRUUZGRh4in8+nkdinKIpG5eXl7N+\/n2effZZ9+\/YVHHtcH3oaHR0lHA4TjUSJRWPEo3HGo3GS4RgTwQgTo2OsWg9w0VrGmqOG09ZO1k9XYrIY2XDUsOGspqKigpqaGo4ePUpNTQ1VVVWUlZVRVlZGTU0NBoOBw4cPc+zYMZqbmx+io0eP0tjYSGNjI0ePHsVoNHL8+HFaW1u1Yy+++CIGg4Hq6moOHTpEVVUVBw4cYP\/+\/ZSVlXHo0CEqKiqoqKh4SB\/W1tZSW1vLiy++qFF9fb22LY5XV1drek5cW11dzQsvvMChQ4coKyvjwIEDGtXU1PDss8\/+G\/\/\/xv9TzX+p9W\/JW2dnJ62trZhMJpqbmzXg3NTURHt7Ox0dHZhMJjo7O+ns7KSjo6Pgt7Ozk66uLrq6uujr66Orq4uenh46Ozs5efIkJ0+epL29nba2NlpaWmhoaKClpYX6+noqKyupra3VJqu2tlYzAASwF+C\/sbFRM0aam5u17aamJgwGgwb8GxsbteuEQSP6F8JVV1dHS0sLZWVlmkLsO7L\/sSCmGBDsBWz2UviPAj+P6+O3ATuPOn8vgK3n5Wnlv9TvX6nb5wGNn3duHnddrKehwNArNgT3MgB+HcgulrlHgf7HyXUp5L+7oZzag3\/EH\/1h3gA4Uv5HDBw5hO941ROX\/1xPGTlzORtSDetSLWtOKy7JiXdwmBGXh7nR5zg\/9hwX1TKS0TjjsTjxWJxoNEokEkFVVUZHR1FVlbGxPAWDYwSDY4yMjBAOBwmHw4TDYSLhMJFIhEgkQkVFRYEBIPZHds\/NU5CRkRGtP9G\/\/p6RSIRoNEo8lh9bMhrnolrG+bHnmBt9jhGXB+\/gMC7JyZrTyrpUy4ZUQ85SQc5SwfHjxzl8+DBdXV0cPnxY0xUGgwGj0Uh7ezvd3d2cOHGCEydO0N7eXvB74sQJOjo66OjooLe3l46ODrq6ujhx4gTHjx\/n+PHjGI1GWltbaWxspKamhsbGRqqrqzlw4AAvvPACFRUVHDp0iBdeeEHTUQLYCPAjdOLhw4c5fPiwtm0wGKitrdWAj3B6Cb1aVVWl9S\/AVlVVFY2NjTz77LP\/xv+\/8f9U819q\/VvyZrPZMJvN2Gw2DbR3dHTQ19dHX18fp0+f5vTp0\/T19dHT00NPTw+nTp3Stk+fPo3VatXIbDZjsVgwmUz09PTQ1dVFd3c3XV1ddHZ20tbWRltbGw0NDVRUVNDa2kpTU5M2aQLI673+Avy3trbS2trKSy+9pIF\/\/WpAc3NzwUrBkSNHtFUBYVjU1NTQ0NCA0WiksrLysZ4\/sV94\/oy1+RWD34X383Eg4jdR8I86v9grqT8m+Hma+S\/1+1fqpp\/bX0efZx4+z3z9prTXeD7vPR\/FUynkv7vh0EMGwGmdAfAk5f\/ro9V8XanmLV81O8M1rEt1fN1dy4LTzrwkMTk6xtzMLGtra1xeX2c6m+VM5gy5XI5MJkM4HCaTyRAMBgmHg7zyyg0ymRzT0zOcPTvL7GwhxWIxZmZmqK2t5eDBgxw4cIDa2lpmZmaIxWIPnX\/27CzT0zNkMjleeeUG4XCQYDBYcO9cLseZzBmms1kur6+ztrbG3Mwsk6NjzEsSC047X3fXsi7VsTNcw1u+Gr6uVPP10WrMZjO9vb1YrVYNtLS3t9Pb20tvby8WiwWLxUJvb6\/m6Orv79e2LRYLAwMDGplMJsxms6bz9A6zEydOaDqspqaG559\/nqNHj2IwGHjhhRc0ACQ8n3qPp8Fg4OjRoxw9epTm5mYN\/Oi9oYcPHy7wlL744oua40sAK+HxPXbsGAcOHCgp\/\/v3P938P+3z\/0Xgv9T6t+TN4\/HgcDiw2+2YzWbMZjOnTp3C4XDgcrlwOp3acZvNVgD4LRYLNpsNj8eD0+nUyOPxYLPZOHXqlNafEIy2tjaMRiNHjhyhoqKC9vZ2WlpaaG5u1kJ\/9AC+qalJA\/oixEgYACL0SID\/kydPcvr0aZqamrTr6+rqqK2tLVhNaGlpoaOjg8bGxs\/lGSwGBL8r7+fnAcBPwvv5NPNf6vev1E0Yx48i8Y7pSewXnh9Be+173Dkmk+kh0h9raWnZ89jjri2+Tux71DhKIf8vVR\/83AbA71v+bw0e4aZq56ujDjaG63jbW8eao4FVRwPzDjtzZ+e4ePEily9fZnNri+3tbXZ2dojH48RiMXZ2dtjZ2eHll1\/mxo0bfPWrr\/DKK69w48bLXL58mbW1NdbW1rh48SKrq6usrKxw\/vx5Wltf0gwAo9HI+fPnWVlZYXV1lYsXL2rXXb58mRs3XuaVV17hq199hRs3bvDyyy9r943FYsTjcXZ2dtje3mZza4vLly9z8eJF5s7OMe+ws+poYM3RwNveOjaG6\/jqqJObYxK35Abcbjc2mw2bzUZvby8mk4n+\/n7sdjsul6tA9wmdJ8CO2WzGarUidKggj8eD1Wqlv79f66+7uxuTyURrayvHjh3jxRdf5Pnnn8doNNLY2Mjhw4e10Ac9gNGHuIoQCwGAROiFAD\/Hjx\/HYrFgMBi066uqqnjhhRcKvKmNjY20t7dTX1\/\/RPnv78\/z39yc53\/\/\/uc5fvzp4f9pn\/8vIv+l1r8lbz6fD1mWicfjSJKk0ejoKIqi4PF4GBwcZHh4mMHBQU0gxLbT6SQajeJ2uxkeHsbtdiPLMsPDw1itVm0FQRgDwiIUHvj29nZ6enowmUy89NJLmM1m2tvbtbAho9FYkH\/Q09ODxWLhpZde0lYp9HkIsixrRoUQlubmZtra2rR+TSaTZkgIT6Lw8P06QPQoUPQokCSoo6ODurq6Au9l8b0fde3nuc+vA2x6Kr7v08x\/qd+\/UrdHgehistvtBduDg4N7kjhPv08dUx\/6FdvifPG3uIc4R0\/64+Ie+nEVj1O\/T+zXb5tMppLIf0P5fiqf28cf\/sG\/Y9+X\/4CyZ\/+Q+vL9NDY2PnH5vxdt4F64nm8lDeSG61l31pM81UzSbGTC3M7c+XnW1tZY39hgS2cACBC+vb3DtWvXyOWu8dFHH\/Hpp59y\/\/593njjDXZ2dlhf32Bzc5M2xasZAgsLCxiNRg4ePMjBgwcxGo0sLCxowL9N8bK5ucn6+gY7Ozu88cYb3L9\/n08\/\/ZSPPvqIXO4a165dY3t7p2gs22xtbbG+sZFfBTg\/z4S5naTZSPJUM+vOenLD9Xwr2cC9cAP3og3IsowsyyQSiQInlqqqmv6TJImhoSEkSdLAkNh2OBzEYjHcbjdDQ0Oa\/hsaGmJgYEDzoAowJEInhAfSaDRqq+RHjzbnZXJX5wmwpI+\/7urqwmw209zcrHlp9XHYsixroOrYsWNayERra6vWb3d3t6Ybf1\/8S1Ih\/2ZzP\/39Jo4fz\/Pf3HyM\/fsPcPy4kY6OLjo78\/x3d\/+fwf9vMv\/NzUf\/j5n\/\/x3+Ozu76Orq5ujRJ89\/qfVvyVs4HMbn8zE9Pa0lYYXDYWKxGMFgEJ\/Ph9frxe12Mzg4WGAkSJLE8PAw8XgcYUh4vV4URdGUs7AaT506xenTp+nu7sZiseBwOGhsbKStrY2TJ09y6tQpOjs7tVUGYTR0dHRw8uRJzGYzRqORtrY2hoeHCQaDuFyuPSkcDmM0GnE4HFoegri\/2Wzm5MmT2oqD8OyJ5X29wi5W4J\/Hw1nspSz2QD4qlMJYW1ZwbvG9H+VNLR7r485t7sivmhhryx7ybj6t\/Jf6\/St12wvsF5PP59sTkAtKp9Parx74p9PpAhLA3mQyaTHfYt9EJslEJqkd1\/ctwkFE\/3rjodgYsdvtWuLoXsaH\/ny73V4S+Td+5SCVz+3jmS\/nDYCq5\/ZRX76ftra2Jy7\/99NN3E8f4f1wA\/fUXQPA3MKpU114bVLeALh8mY2NjV3Qva2B7Tz43ySXy7GxkePrX3+Lr3\/9LW7fvk0ud42dnR1yuRy5XI5r166xvhues7q6itFo1JINjUYjq6ureUNjfX3XoMhfl+\/jGrdv39b639gQfW6yvb1TMKZr166xsbHB2uXLzJ2fx2uTOHWqi6S5hXVnPffUet4PN3A\/fYT76UYikQiyLHPu3DlN\/0UiEeLxOKFQqED\/SZJUAJKcTidDQ0MkEomH9J8kSdhsNs1T2t\/fj8ViobOzE7PZjMNup76+fndV+zj9\/f2cOHFC05cCNLW3t3P8+HFMJhPHjh2jtbWVoaEhQqHQI\/VfJBLh2LFj2O12LQ5b3N9kMmlx39XV1b81\/5L0eP6t1s\/4HxjI82+3m3E67Rw21GM0tnLixHEGBvrp6DiBzbbL\/0DeaPii8\/+bzr9dm\/9j2vj+Nc7\/r+NfP\/8F8u\/I83\/sWLPG34kTJxgYsGKxmJ8Y\/6XWvyVv4XAYVVWJx+MFlRiCwSBjY2N4vV48Hg8ul6vAAHA6nZw+fZrBwUHi8Thut1sjSZI0wH369GksFguDg4N4vV5sNhtutxun06nF9uuTe0VCssgh6O7ufqjaUEtLC11dXdp2T0+Pdl17eztWq5X29na6urq0lQORsCz6EWFCQhEKAKD3RLe0FIYSPCoE4XFhCQKk2O32AgBcHApjrC3b04MplPpeXs5HhVY8jooBwNPOf6nfv1I3PSAWoFkPrO12+55AX79PkM\/nK1ghKDYSBIAXv3pgr98WIF70UXxc35c4V3\/P4nuLfaJPvRyVQv6NXzlI3cE\/4pkv\/zue\/cM\/oK7sj6gv388f\/\/EfP3H5fzDZzEeTjdxPH+GeWsfG6Uqypyo5ZenG4xgkrajkNjf3MAB22Nzc3PXGbzE3N8fs7CxbW19lY+MakUiY+fl5DZTnjYQNLl++THpiAuNLRsrLyykvL8doNJKemODyrqEhDIbt7W3m5+eJRMJsbFxja+urzM7OMjc3x7VrW+Ry19jc3NRWAvQGQG5zk7Si4nEMcsrSTfZUJRunK7mn1nM\/fYSPJht5MNlEJBIhEAiQSCQK9F8oFCIYDBboPz0AcjgcWCwWJEkikUgU6D+n06kBjjyZcTolZNmLzWbd1ZEO6g311BsMGA4bMBw+zOHGwxw9epTu7u6CvLniaiuNjY10dHRo211dXdp1RqORgYEBjEYjHR0dml4VCZuiHxEm8fvgX5KcGuDX8+\/3e5EkKz6fG6\/XwbHmeo4dM+zSYY4dO0xr61F6e7vp7d2NIf9XyH\/x\/JvNZiRJP\/8unE4HBkO9RocP13P4sIGjRw\/\/q5\/\/veRfkqRd\/PeZ\/BsM9RgOv4jh8It5\/hsNHD3a+ET5L7X+LXkTpdyCwSCyLOPxeBgeHi6w6NxuNy6XSwsDEoaA3tsmy3JBGJDNZtMsMlG1QXjtHQ4HkiRpE+hwOLTSboODg8iyjN1uR5ZlHA6HrsrEWN4bqeYrQfh8PuLxOGNjY8TjcWRZ1o6JMYt7K4qCz+fTkp3b29sxGAwPeQD1IODzhhTo9xWHRAhwIs77PAC4OIyiuH\/R5+cZXzGYEKEOj1oBeNr4L\/X7V+pWDJzFsxNgWT+PeiCvB+PiWr2Hfi8DQW8o6M99VJ9inn0+HysrKw8liOo9+vpfu91eYCSIvvYKVyqF\/BurH28APEn5f5Bp5sFkIx9NHuGGq46cs5Z1Rx2LDgcLTonFkYPktrbY3Npia3s77\/kvANs51tc3CAaDKIqCqqq7lXuC7Oxsa2E5egNgcXGR2tparSRzbW0ti4uLBQbAZ+FG2wSD+WpAIiwhGAyyvr7BxsZnhoIY09ZuHkBua4vFkYN5HhwO1h153m646vho8ggPMo08yOQNAAF4hP4bGhraU\/+JMAgBhGw220P6b2hoCJfLjdVqZWjIxdCQi0AggKqqhEIh3B4XkmTH5XJy9Gg9R4\/WIw3Z8St+\/IqfoSFpV+\/ZkL0yDocdRVEJBALainwgECAQCODz+UgkEgSDQRKJBLIsa8fEmMW9hf4TyZ5Go5Ha2trfG\/82mxVJciFJLoLBAKGQSioVwu934fXY8fudtB+v5\/jxejweO7Gon2jEjyxLKIqMJNnw+2WcTjuBgLrbR57\/YPCLz79+\/vPj3Z1\/twuHw44kOXfB\/4s4HXZ8PhmfLCNJEh6PZxf\/ePMOGPVf3\/zr+VeUAMGgSmRX\/ockO263k2PH6mlufhF+VAVbVfh3Vw40+Zfz8q\/+HuW\/1Pq35G1sbEwDzV6vV1OMkiQVLKt4PB7cbjcej0cTUI\/HQzgcZmRkRDtveHhYO2dsbIxIJML4+DjxeJxwOIwkSTgcDvr6+jTrTVEUxsfHmZubY35+nsXFRZaWllhaWmJhYYGJiQlisRgTExPMzs5y\/vx5jWZnZ0kmk6ysrGjXLywssLCwwOLiorY9Pz+vkd1up7u7m\/Ly8oc8gHpg3NLSgrHH+EiPnp70nk99yIQenOgBcHFynh4AF3s2hRdWD3A+D+nHrQc3em\/n085\/qd+\/UrfiFQDxzPfynj8K0BevDugB\/ezsLCsrKwUAXr8t7q3fL1YB9GBXHVMLwL8wJPSrFsVjFH8Xg3G9TJZC\/l+qPsjhQ\/kk4L0MgCcp\/2IF4BVXHS8P1\/KnnhquSdUsOSUWpGGSPoXZ7DTnz57l8uXLrK+v74b\/5IH95cvrrK1dZmxsrKCG\/9jYGOfPz2le+s3dVYT19XXm5+e10n1VVVXU1tYyPz\/P+vo6Gxsb2vm53DXOn59jbGys4FsCY2NjrK1d5vLldc1Q2N7eZn19ncuXL3P+7Flms9MkfQoL0jBLTolrUjV\/6qnh5eFaXnHX542AyUYNMAQCAbxerxa64HQ6H6v\/RPGLSCSC3+\/XzhsaGtLOCQaDxONR0ukk2akEqXgE2evE47FjtfRy3FiPuauDaFQhO5Xk0qVFLq0tsba2wtraKqurqywvL5NOp0kk4qTTaRYWLmg6bWFhgQsXLpBKpVhbW9P05vLyMsvLy6ysrGjbQp8uLS1pTrD9+\/f\/zvl3uYZwuTx43B6CoSAzM1EuXEhy4UKC6ekIgYATVXXgcvXS1VmP09lBOqWwsJBk8+oim5tLXN1c4erVVXK5VdbWlpnK5PnPZL74\/OvnPxQKEotFSaWSJJMJItEILpeToSE7\/aZejh17kY6OEyiKTCYd59KlFdbWLrG+vrYbKndJm\/94\/F\/H\/Ov5V9W8\/E9NJclkEiTjEbxeJx6PA4ulF6PxRcydJwgGVbLZJJfWF1lbX2JtfYX19VUuXfr9y3+p9W\/JWzAY1DzkQgD03iYx+bIsa\/+AhUdeVVXOnj2rWYlerxdZlgmHw4yNjZFMJhkfH9dqRovYMIfDgdlspqamhsHBQUZHR5mcnCSTyTA+Ps7IyAiSJOHz+XC5XHi9XoLBIJFIhGQyyezsLJOTk1oN6Gg0SiaTIZ1Oc\/78ec6cOcP8\/DyZTIZMJsPk5CTxeFxLdJZlGafTyXPPPVcAAB5VFnCv5ffHKV6917FYIQuv914AuKOjo8ADq46pBdfrwY4eDBSPp9jrV1zJZC8+n1b+S\/3+lbrpQav+2T7Og18M\/os9\/hdzKxroF6Be\/7uyssLF3EpB+M\/F3ErBKoDJZNJWCvQhQ8X31cuGAMr6FYTi8elly+fzlUT+xYfAig2Atra2Jy7\/99Rqbrpr2JFq2HLWcM1Rw8tSDYu7BkDMO0JsRGV2epqzMzPMzMwQjcSIRmJks1kiux8Ey4N0RTPKxsZU5ubWd8F8PgRIURQ2NjaIxWIPGQCxWIyNjQ0URSGXy7G5mTcc5ubWGdt9lvkPguUNgHA4TCQSJZvNauOZmZnh7MwMs9PTxEZUYt4RFqRhFp0SL0t53racNexItdz01HIvXEcoFNI8hF6vV\/NsikRHvf7z+\/3aKocATXNzcw\/pv0gksluqNEU2mySdjpFOR4lGFfx+J7Jsx+k0cehQBYoikYqrLCxMsbiYZXo6STDoR\/Y48ft9eDwuZNlLKBQiGo2SSqW4cOECU1NTRKNRYrEYsVh+LjKZDAsLC0xPT7O0tEQ2myWbzTI1NUUikdASPcXK+pe\/\/OXfKf8eT57\/VCpCKBLkwoUUFy4kmT0XY\/ZclGxWIRF3Eo06UFUTjY0VJOISF+YCXM1NcTU3zfJSkmTcTyDgJBLyoSguVMVLNBoiFouSTn9x+RfzHwpFCIWCpNMp0ukkyWSMZDJKKKQgy3kD0OkwUVZWhsvtJBj0w08OwD8+D\/\/4PH5Fxu0qnP\/Iv4L518t\/JBIkm00xNZWX\/1QqL\/8+vxOv7MDpNLF\/\/yH8fifJZIDFpSyLS9NMT6cIBf3Ibid+xYfH60L2\/f7kv9T6t+RNhAAJASheAfB4PNqXGEdHRzUQHovFNGUsMsmFcIhzotEowWBQC8MRKwUOh4PBwUEMBsOupZj37omyo\/rqQVarFVmWCwyA8fFxzbAQQjA5Ocnk5KR2XOQwiC9Kjo6O4vF4OH369G6VAol9+\/Y95AHUAwB9KUB9PPDjAIDwNgrlrf9beAD1AFhfH7yurq7A4ydIv+T\/KC+g2L+X169Y+evBztPOf6nfv1I38fz0oTwinEeAzr3A\/l7hOnov\/faNTQ3Up9NpDfQXkzguDAK9cbCysqL1X+z5199X7\/nfK\/Z\/rxUBcW4p5F9vAIgyoK3VB\/nKV77yxOX\/HaWCm+5KvioPYrMPYrNJ2G0SDrvEoGMYl+TCM+jBI3nxSF5mslmyZ84QHoswOTlJOp1mbCzI6Ohny+yy7CMYHOPixbXdVYMNDdxfu3aNaDRKa2urZgC0trYSjUa5du2aZiSsr2\/slvNcIxgcQ5bz85x3QKmMjQVJp9NMTk4SHouQPXOGmWxWG6dn0INLcjHoGMZhz\/Nks0nY7IN8VR7kpqead9RqQqGQFve8lwdU6D+\/34+qqhoIicfjmoNJlmV8vrz+CwQCxGJRpqdTpNMxkskQyWSAREIlHvcTirhQVTuBgITJVEs85CGTDrC5eYFIyEVAdeBxD+AasiA5LUjSAD6\/XACAk8mkpoNFGdSpqSmmpqZIpfLHRQy33+\/XwmY9Hg8Wi0VzgH3pS1\/6nfGfD7\/N85\/NRpmbSzF7LsbMdIhz54LMzarMzfrJTrnIpB2cy0r4fbXMzXpYWQ7w+msXmD3nJpV0EgwMoCoW\/D4LsjxAKCiTiIdIxKNMZVKkUklSqeQu718s\/oOBwK5DMkUqGSMeDxGLBYhGVSIRP6rqwuezo\/id9PZWEVCH4MfPw0+eh5\/uz9M\/78fuGMBmy5PfLxOJhIhFv7jzL+RfVfPyn83m5T+RCJFIBIjHVWIxP8GgC0VxEAhI9PbWEonk5T+Xu0Ao5EJVHQwNDTAkWZAcFiRnnv9o9PfDf2m17xegRSIR3G63Fl8vkj4EiWVd\/ZcXp6eniUajTExMcPbs2V2Pz9jukmec8fHxvGcmGtX+aXu9XlRV5fTp05rCMhgMWu5BOp3G5XJp1qcwBEQcv6hMJFYTRKa6MAamp6eJx+Ma8B8dHdVI8OB2uzWDwu1288wzzxQAgL3CAfQgYNhYsycQ0Hv6imOA9fHHewFgsa33gOsBSjEoK\/YqFnsC9\/L6Fdc0f5QB8DTyX+r3r9RNP0\/6Z62Pz39c4q8eoOvDfgS4F9fsBf6LSZwrjIBcLsfs7OxDnnD9GIpzCIoTlvVJxPowGnGsFPJfvAJwpDy\/AnD8+PEnLv+x9jIm2sqZbK8g01FBprOCM92V9PT14LQPsuYwsOY0oFqOYGg24JG8eId9yO4R1NEx1NExRhUVZURhZETB65XxemWtrr8o7Xn58mWuXcuX74zFYtpXOsWHf2KxmHZcfD\/g4sWL2ncDRL8jIwrKiMKoomr3l90jeId9eCQvhub8WNecBtYcBpz2QXr6ejjTXUmmM8\/jZHslk8ZK0i9VEIlEcLlcBRXvivWfAD+BXXB37tw5zQE2NzeHz+cjFAoSiYRIpRJMTSVZXJghnY4Rj\/tIJhTiCS\/ZqQDBwADRqI14fAj7QA2rKyEyaZmruQzJpAu\/34rXY0VRHLhcA\/j8LqLRAKlEhFQqTiIRIxaLEotFSSQSGhg6d+4ciURCAz5ihV54d\/1+P263m4GBAU3\/felLX\/qd8R+JBEkmQ8zMJJidTbK6OsPcbIxzMz7m5hRmZ2UuLQfITg1wYdbO8uIQsWgNt25FubQqc\/fNKZYX3GRSNiIRK8mEk4AyQCzmIp0OMDUVYWY6TioVIx7\/4vEfDAYJhUIkkwnS6SQXLsyQTMaIRHzEYgrRqJd0OoDit6CqNkJBJ\/39VfDt5+Fnz7N+KUU86sIn2+AX+\/H5JIYkK36\/i0gkQCwWIZmME4\/HNMfnF4n\/UChIJKST\/8UZUqkY0aiPRFwhFpPJZgOoqpVg0E40NoTZXDF9NHsAACAASURBVMPiYoh0WubKeoZkwoXfZ8PrteLflX+\/kpf\/ZDxCKhknEY8Ri0aJ\/Y74L6Xu\/UK0aDSqCYCI4xwdHdU8a8L7rw\/9EZ5+cZ4+e1ycMzo6+lDysNPppK+vD5vNxuDgIOXl5dpkTUxMaKVGRRKyEEBVVXe\/NBnWzh8bG9OsP0EiEU3Ei4qwJX2iishGdzgcDxkAe3nMiqvl6L2Be3ni9HHJxUv2nxcA672aAsDoAZkeBOjjmh+l\/D9vCNDTyH+p379SN33Iih6sFnvX9WB0ryRfYQAI7\/1eBoGetm9sFpDeABArCOI6Ad7199GPTdxjL6+\/\/primPzHrQD8PuW\/u+HQYw2AJyn\/NfWV1BoqqW+sxNBcSWNLFU2tNXT2dGG3D7LhaGDdKaieHecRZJcX76CM7PIhu\/Pk9ch4PF48bi8zMzOcP39ei8cVH\/fK5XKsra0xPj5Orc4AqK2pYXx8nLW1NXK5nPbRMBG7e\/78eWZmZvC4vXg8XrweWbuv7PLtjsXLjvMI6856bbwbjgbs9kE6e7poaq2hsaUKQ3MVhuZKDE15ikQiWllBfSKzXv8Vhz4IT38goGr6T1UVgkGFSEQlFhMeTzfxmItE3EUiIZFIOAgFe0kmrExnh+jofJ7NqyFWV4Ps7KSYmXGTTEikU0NMTfmIRj0kkwqJRIBUKkQyESEWDREMBjRnmwhtEOBHgB2\/36+Fbej1n9PpxOvNJ5d+aRcA\/jb8+\/2+Xc+\/QiSikEyqZDIBpqdVZqbdnDvnZm7WxcLCEEsLTuZmO1hZtsN\/PIRfPsC9d6O89lqQ995Ns3nVzerKECvLLlaWfcye8zA3qzI9HWBmOsTUVIREIkQolE8ITiRKz79+\/gMBhVBIJRrJe\/xDQTeRkItIyEU0KhGNOFD83UQjVhJxJ8eO7YfvPc\/CQoDc1RSZtIt4bIhE3EUq6SMa8hCPKcTjAZKJELFYhOgXbP73kv9oNEAsphKNuIlG3USjLmKxIeJxCd47RCxuJ5UaorX1edYuRVhcDHA1lyYz5c6\/J\/EhUikfkYiHREIhEQ\/kV9ISv3v+S6t9vwBtdHRUq52vNwK8Xq\/24Lxeb0ElHQH2BcAWS2AinEcAcBG\/L8jtdnP69Gl6enowm83aCoAwGFwul5Zoog\/dEYBfJCwLD7+w\/qLRz+JQxbhE0ooYmxjLqVOnkCSJvr4+nn322QIA0NHR8ViQXKxYi5NWH0d7AWB9PLz5SGVBf3ovYHHYQ\/H9xN8ilr7Y67dXqcO9jj2N\/Jf6\/St103vV9eB1r3AavSd+L5BdTALsP8oAKP5bHw4kSIQB6ffvZVysrKwUGC562dGHK+llpzgJ+EnJv1gBEFWARAiQPgn4Scl\/naGKOmEANFWSba\/kTEclTS21NDXX0dhUT06qZ3u4jmtSHTckA0lTJYbWOhTZh3fQi2fQi3vYg2vYg8vlwe3yaOU65+fnWVpaYn5+nrm5uXxS30SaupoarQpQXU0N6Yk0y8vLe14zOzuL25Xv2zXswT3swTPoxTvoRZF9GFrrSJoquSEZuCbVsT1cR06qp7GpnqbmOppaajnTkefN0FylgX9DUyWKojA0NEQkEikAQcX6T19JRK\/\/8gBDxu+X8fs9xOMBolE\/8bifeNxFIiGTSslMZb3MzLhJJC3Eo11k0v1EgtVcvx5i82qQ3JUAc3Mu5mbdnJvxMHvOTybjI5sNkE4HSCaDxONBotEAkUiQQEAllUqRSqWIxWJa3sGv03\/9\/f04nU56e3v50pe+9Fvxnw\/78OP3ywRUmUDAw9RUgKkpP+fO+ZmZcXNhTmZxQWZ9TWZny8vqihX++hDbm\/2sr9Xy4NsxvnkvyHvvBLh1082rNzxsbXm5elVhddHH8lKAubkgM9NB0ukgyUSAeDxIMKiSTpeWfzH\/IgTG5\/MQiwaIhPIVjUIhF9Gol1hMJpH0ksm4iUUtqGoHibgJn1xN7mqE1dUAy8sq2ayL6ayHdMbDdNZPKuEjlVLzIWTxINFokEgkb\/x8EeZ\/L\/mPxQJEIn6iMT+RiIt4XCYRl0mmvUxnPfDLQwSDx0mmzPh9NeSuRFhbCbCyHGBm2s3MjIf0lIeZrJ9UykcmrZJKBUgkgsRiQaKR3638l1b7fgGaWAEo9uILEC8sJyEIbrd7z21B4uGLBy7LckE4zuDgIFarVUvCFV+dGx8f184X5TyF1SmAv358iqJoBoCYfLEiIUqZFpctdTgc+djYvj66u7s5ePBggcLXf1BnLw9gcUhA35H9j0wMFPfVewFFEqA+7r24Co7e8yeu13v79CEBYv9eAKUYuOjrmwsAUFz68Gnkv9TvX6mbfr6KPft6o0B\/jpgXfeiPfjVAD\/r1Sb97UTGI1+cPiFUA\/a8+R0CfXCxCjgRQ3ssg0YcBCfkphfxbGwsNAH0VoCct\/xNt5bzhq2BxUGJpWOKmr5I\/GRnmbtDNtruWTVct11y1GJpqueGu4a63hnRPBYbWOlRTMyPmZjwuNy7JzfAuuYfdzM6e5fxuxbZMJsP58+dZ2K3QNnv2LA3VNZRXVFBeUUFDdQ2zZ8\/mK3vMzxdcc352ltnZs7iHP+vfJbnxuNyMmJtRTc0YWutI91Rw11vDDXcNhqb8mDddtWy7a7kbdPMnI8Pc9FWyNCyxODzIG74KzhgriEajDA0NFeg\/VVU1L+Lj9J\/H48bv9+HzeVEUL6rqJRSSiUQ8xGIuEgkvmYzM5lWV6zsqr15XyV0ZYn3VyvaWA5+0D370LDdfDfLW3QS5K15WLnlZWJTJXQkwe05hdjbA7Lkg6XSAaFQhGs17WVVVIb0LgKLRqJbMKfTf0NDQQ2Ub7fZ89bve3l46OzvZt2\/fb82\/ovhQFC+BgJdoxEsqJZNOe8hmXVy44GVp0ce9dwN8+4MAH38c5JvvueE\/HwIOwX8v48G3XXzyIMiPf5Lkg\/d8vP01Hzdf9fPOO0HW11Vyl4KsrwWZnQ2QTiv5cKq4SjCo5JNsUylisdLw73bn51+Wvfj8eRkIBmRCQQ+hoItYzEsiKZNbU7maU9m8qrK0MsSFOSv8+HmsA\/tYXXWwmQvw5ltp+N5+Fua8zM74WF8JMpVVmJkOMD0dJJkMEAkphEL5VQZFUTQAXMr5F\/Lv83tRFS\/BoEwo5CEU2uU\/kec\/d0Xl6qbK6ooLfnKAtWUnA5Z9XFpx5vl\/LcXKiszSoszCnI+11QBTU7v8Z4OkkgEikfwqUyiUl\/\/fBf+l1r8lb5FIhOHh4YJQGRHyI\/aJiXc4HLhcLkZHR7VtvcUlSkHpFZY+Bt\/n83Hq1CnMZjNms5lnn32WU6dO4fV6mZ6e1s4dGxsrSCDWl5jTC2QkEiEWixEOh8lms9pYRDKxPqHYYrEUxMn29PTQ1NT0kAdQH+NbrOyLPWv6fXoQoAdKwrv6KAAsQmEEANaDK30iYXF4geiv2GO51\/gEUBEhAo8KAXoa+S\/1+1fqtlfoSnGMf7EBoA8X0hsAxeC7GOAXe\/8FmBfX6IG+\/jxRLrS4T5FcXGy0FBsAxaFD+rCcUsi\/tfGQZgA890yhAfCk5X+ivZw7Pok\/GRnk7kgla16J10dd\/MmoizuKiz\/1VfOncjWGpmq+6q3mzoibxeHTvKfWMTtoYdTcxDXJQE5qYFByMyi58Qx7CI+FmZ+bY+78eWbPni2g82fPcrKign0HDrLvwEFOVlTkS3cW0dz588zPzREeC+MZ9mj956QGrkkGRs1NzA5aeE+tY3H4NHdG3HzVmx\/rn8rV\/KmvmjtKnpfXR12seSXujuQNnDsjw2ROlhOJRJAkqSBUQIQ8iH1C\/9ntdi0nzW6343a7UFUFRZFRFA+K4iIYdBEI2IlEbCwt+tnZCrB9VeHmdYVbr\/rJrVvYvGrm+vV+QoFn4H8egP9RBu8c47XbKnduqdy5FeT27TjbmyEurQZZXgiSnVJIJPxEoz4CARlF8RGLRYnH40QiEWZmZgr0n8PhwOFwMDAwoH2MymazFXxkyWAw\/Nb8B4OKBvoiEReJhItk0k52ys72pp\/33g3w\/nsqH39X5YffV3lw3wr\/smsAUMb3v2cGDsD\/d4Affj\/AJw8CfPIgxIPvJnj3nQg3Xw2xvR1kaVFlespPKuknFpMJBnzE41ESiTz\/5849ef7z24rm\/fb7XaiqC8VvJxCwMTfnI3dFZW1NYTOnsLXpZ2XZwtKimdVLJrzuZ1hf62dr082Dj+fgvz4PP3ye69dDXN+Jk7sSYmkpyIW5IOmUQjzmJxLyoaoyfr+PaLS08y\/4VxQZxZ+X\/0Agz38waGNu1seVNZVLqwpXryhs5vysLlm4tGpmbbUfl\/sZ1i6Z2d708uH9WXZ2AmxvquxsB9nZjrN+KcTiQpC52V3+434ikc\/4\/13If6n1b8lbOBzWKuOIDz8IgC1WAYQADA8PayB\/cHBQ+\/KbCAMSMf\/imMfjKTAAZFnGZrNpgPzZZ5+lq6uLcDjM+Pi4dq6iKAWhQcKyEwkqg4ODmM1mrSrQyMgIkUhEy2Lv6+sr+Aqx+BKxuL\/H46Gnp4eWlpaHAIA+wa8YBBR7zB\/lDdQrbL1XsKOj49cCYAGC9V7AvUDFo6p8FHv+WlpatPsXA4Bi3p5G\/kv9\/pW6TbvqCFsqH6Jsn4FgR82ex\/TXrErNhC2VLKnNLKnNbI6fLDhvSW3Wzhfb4lxB4pi4rtjbrr938Zj2GqP+HpvjJ9kcP1mwne0zMO2qY9pVVxL5tx0tf6QB8KTlf7yjgtu+QW75KrirVHJHqeKtsSreGHPxllrNbaWat0aquei2MWOq5L2Ym\/fDdXwj0sDtEQPfCBq4o7q4NlxP8HQ5N6Qm3JKXEbeP+fPntdKhWonOmRnmpEo6yj8zADrKK5iTKpndPUd\/\/vz584y4fbglLzekJoKny7k2XM8d1cU3gob8GCINvB+u472YmxlTJRfdNt4a2R27Wp3nZayKO0oVd5VKbvkquO1zkekuJxQK0dvbu6f+E15Qof\/yHzkS9c6l3dKHbiIh\/67nNx\/znEgMMZVxs3jBy6vXA9y8oXLnlsLd1\/y8dtvOm69befstCwvTz3Dn9lGgLA+K\/\/4QX3tTyRsCt0Nc3w6wvpqnqYyPeMxLJORBUSRsNpNWkcXv9xONRrUyjr29vQVfof3sS7QyVqsVj8dDV1cXjY2NvxX\/Ho8bWXYTj+dBeSLuJp12Mz09xMqym61NL\/c\/CPLgfoAffj\/An\/9M5ec\/G+IvfuXM80xZHvzz\/Gf0vw7w\/U9CfPIgyjfvhbhzO8Ctm0EuzPmYysgkkx6CEQmn3UQyka8KUwr+JUnaxThuQiE\/qiqjqm5CITfR6BDJpJsLMx42NwNsbapc31a4ecPPzpYD\/uYAt161kIl\/ma3N4zz4buyz5\/Bfn+fGdZUb1yNczQVYWQmwvBwglfIRjXgJqB58PgmrtcTzL\/j3uokE9Pzn8x0SCTfT0x6uXglw9YrC1qbCzraPrU0721tWdrYs8ItD5NaP88H7Ub79QYo37+TflZ0tle3NEFfWAywtqCxeCORzIqJeAoE8\/78r+S+1\/i15s9vtOBwOLTHW6XRqsVMiDkwIh6BIJKJZiyKESB\/vLwRIH0o0PDyMJEma972rq4vnnnuOvr4+rcynWEkQKxL6MCQhhCKcx2az7daCjmjViRwOB3a7XftEtSRJBeFH4XCY4eFhrcrQXgZAXV3dQ8v6IiRgr4TAYhAgvIHFscZ6AKBPgtWDYQFA9gof0Cce7qX096piUlyt5POsADxt\/Jf6\/St1uzltZnP8JOJXD5YfZRzowbcgAaiLrxF\/FxsD4m\/9\/YqNgr3utdd+\/d\/FBoP+XvpxivuUQv4fVQa0ra3ticv\/lrOG7WGJu6qb2yNVfH2smm\/Ea3k7XMPbY9XcUaq5p5zmmruanKuGb4Tr+E66ifs6+s7EEb4RruejiUZ+lJaJnTrI0nAl49FxprNZpqezTE9PMzM9zdnpaeacVXSWV7C\/rIz9ZWV0llcw56zi7O4509PT+WuyWcaj4ywNVxI7dZAfpWU+mmjkG+F6vjNxpHAM6Sa+Ea4j56rhmjs\/5jtKNW+PVfN2uIZvxGv5+lg1t0equDvmZtvlYmuwHKvVis1m0xIDHQ7Hr9V\/0WhUK0uaycTwyS4UJR\/vnUx6OTcjs7zoY3s7wPUdhdduK7z5mou370rcfbOfd9428e7bHWxeeYb37\/Xz\/U88GiB+92teXrvj4s4thRs7Clev+FlZ9jE3K5NIeAgEJPx+J5JkJRaLEItFteosDocdm82G2WzWVsD11VBEwqfVasXhcNDY2Pjb8e\/3kc3GUFUX0aiLTMbLwpyXtVWZmzf8fPB+gPsfqvzwewF+8iMvf\/ELN3\/5Cwt\/\/ReWIvC\/X0fPw78c4HufBPjgfZV37ircftXPlXWZ6ayHZEIiFHLidllJJCLE41GCwSfPv8A\/8XgMr+zC73cRCnmJx71MZ2UWF3zkrgbI5RSu7yjcuO7m9k0X\/H0Z\/L9lvHbrGCtLz\/DO3f7d53AA\/tcB3nzNw6vXh7i+o7B5VWHtkp+lRR\/nZmQSMTeqKuHzOXE6rUSjhfNvtz9Z\/v1+H4l4DNmb5z8Y8hKLekmlZc7N+MitqVy5pLB1VWF708WNHYmdLRPXr5u4vt3Ohew++Jcy7r3r5\/6HEe6+JnPrVS87Wy62ripcWVNYXvYzN5s3\/uJRN4E9+P9t5r\/U+rfkzev10tfXp32cSwiE8PaLOHox+Q6HQ6ulKsD24OCgVttfGAA2m42+vj56enro6+vDarVqXnez2UxHRwdlZWXIsqzF+BfXoZUkSVtN0Mf0i+Unl8ulhfYoiqJN\/uDgICMjI4TDYdLpNBMTE1qugM1mw2q1aspQH4Ou9wDqPXd6b+CjwgGKj+0FAlpaWh4CwLGehoIkWAEA9NfrQUDxcv+jvIDFin+vEAC9F\/Np5b\/U71+pmwDD2T4Dq1JzgXe82Nsv\/taD6M3xkw8ZAo\/yyov9whDQA\/HifosNir2MC70BMGysIdtnINtn2NNA0VO2z\/BQbP+TlH99FaDn9325IAn4Scv\/prOau75Ktj2V3Bmp4u1gDR8k63g3Uss74Rr+xNfA+6NmzvRUsOgy8a1oPR9NNn9G6SY+HDfwrVg9H0Tq+NE1KxfNB1neNQCyZ85oNJ3NMpPNMidV0VFRxr7nDrDvuQN0VJQxJ1Uxk82Dfv0149FxlocruWg+yI+uWfkgUse3YvV8OG7go3RTwVi+Fa1n0WXiTE8F74+a+RNfA++Ea3g3UssHyTreDtZwZ6SKbU8ld30VbA6Wa95A8ZwGBgawWq2at1PEEQv9Z7fbMZvNu7rQhs1mxuuV8PnsRCMSmYyXuVmZuVkbC3P9XFru5eaNft66a+ftt\/r52ptGPv62he9+eILX7zyjeb5\/+QuVH\/3Aw\/v3hnjzNTu3b0nsbA9xZS3vTc9Ou0gmhwiGJLweGz6\/C1l2YbGYcThsKIqi6TUR0hGJRLQPZIpYaavVysDAAN3d3TQ2Nv7G\/Hu9Mk6nDclhRlEkgkE76ZTE0qKXq1dkrubs7GyZeevNLj7+xAxU8Ze\/sPBXv6wvAv8\/AX4K\/PwzA4AD\/OATF9+85+Luay5u3vBwadXFuRkXqZSE328jFHThV1wMDJSG\/\/y2DZvVjMcjIXvtBIMSyYSXc9My01kbs9P9LFzoYjNn5vYtO\/zzIfiXF4AX+OY3W9nZeoaf\/czD3\/xVlF\/+IsInn3h5522Jm6\/auL4jkbsisboyxMIFN9kpF\/H4EIGAhMtlw+fLz7\/ZbMZuLyH\/NjMet4THaycYkEgkvGSnZFJpG5m0iZlz3ayv9bOzbeP6tontTSOv3TFz+1arTg72872PQ7z7tpc7t4bY3rKxmZNYW5VYvDDE7Dk3mXS+klAgIOFy2\/DJLrzez+Zf\/Q35L7X+LXnr6emhp6dHi4vq7Ozk5MmTtLe309raml9q7uvTSBgJZrOZU6dOYbVaMRqNdHV10dfX99ASerHyqaiooKOjA4PBQENDg5a8qygKHo9HMwCsVqtmjAwO5kuDipAjfZzXqVOn6O7upr29ne7ubkwmkxbn1d3drfUTj8dRFEULDXI4HNTW1j4EAAQI2AsA\/O96A\/XePNHHozzge4XAFCcrPq7Ch37Jf69nv5cHcC8D4Gnjv9TvX6mbAMQCOBeD6L2MAP3+RZtBMxqKQ3set4JQDPL1RsOjVhP01+r7Lx5v8YqAWBUQ8qY3GEoh\/3utAOwVAvQk5D\/cWcFdXwW35Uru+Kp5J1zLtybq+Faynncjtbw+WsPbajXRriNsDNfxnXgDDzItfJRuzv9ONvOdiSN8mGzgw3g9n0w2Mz54kOTwQcaj40wk05zJZDiTyZDdpfOuag4Y6tm3\/zn27X+OA4Z6zruqtePi\/IlkmvHoeL6vwYN8MtnMh\/F6Pkw28J2JI3w02Vwwlu\/EG9gYriPadYS31WpeH82D\/28l6\/nWRB3vhGu546vmtpw3ANJ9+Tnv7OzU5v7EiRMcP34co9HI0aNHtaRBQQIk9febsFj6kZwDdHcdw+nsQPb1Egz2kkr2Mj3Vy8qSia3Nfl6\/3c\/bX+vn3beN3H19Hz\/+Xjfff9C4C3afAZ7lL3\/l45c\/c\/OjH0i88zU7d27Z2Nm2sX7JzuryEHNzLrJZN4mEm0Q8\/4Vcr9eOxdJPZ2cnRqORzs5Ouru76ezs1GhgYICBgQESiQSKomihEXa7nRdeeOE34t9qzfM\/MNDP0NAAZvMxPJ4OIiETmVQvF+Z6ubJu4rXb\/Xz7QzM\/\/qEZeAGo2MPz\/0vgvwG\/KDAAPv3Uzjfft3P3NQe3XnVxdd3FyqKHmWk3U1M+QiEXspznv6vryfKvn3+HY4CurmM4HB3I3l4Cai\/xWC+ZdC+LCybW1\/p59VUzb75mhv9RBVTtPovX+P7HBv7h7xP8p78J8je\/DPDnP\/XwyccSb75m58Z1G7krNlZX7CwtDjE9PUQmnZ\/\/eNyHz+dCkr4A\/Nvz\/NvtHXhcvfh83QQD3SQTvcxke1leMpFbM7G9ZWJ78ziXLn2Zu6938fqdw7uy8AzwDN\/\/WOHDb3p5667Ezo6Nq1dsXFqxsXDBxtzsENmpIVKpfIhdLCbjk10MDdkZGPjt+C+1\/i156+zsxGw2IwyBnp4e2tra6O7uxmg00t3dzalTp7SH29PTg81m04wGh8OhPWxxXmdnJ11dXZjNZrq7u7U4rM7OTkwmE21tbRiNRurq6giHw1rcv34FwOFwPPQ5apGXoKqqVlJ0YmKC+fl5NjY2uHnzJnfu3OHWrVvkcjlUVS0wBvQJIN3d3Y\/NAdgLAOgV6eOU8F7eQJPJ9NgQGGNtWUH4gYghNplMD\/X9KE\/k4xR\/sQdwrw+BPY38l\/r9K3V7lNdc5ACI48Ve9OJcAfFb7LEXcfZ6EL5XbP9e4L94peFRBoY+x6A4jOhxxoF+JeBJyv+jDICvfOUrT1z+t035KkAvu6s0A+DDiXo+nKjnvWgdb4zW8M5YDcMtNUyeLOdBpoU\/y7TyyZmX+A9bJ3kw2cx30kf4KN3Eg8lmPr1mQm6pJdlRxvzcHBPJCTKZDJPpSTKTeUq3NXGkqZF9+55l375nOdLUSLqtSTs+mZ4kk8kwkZxgfm6OZEcZckstn14z8WB31eE76SM8mGzmP2yd5JMzL\/FnmVYeZFqYPFnOcEt+zG+M1vBetE7jRxgAL3sqecNXzraljOPHj2MymTSd1dXVRWtrK52dnRw7dozOzk76+\/s5ceKEdo7VaqW7uwuTqZMhyY7V2oEknSAY7EdVO4jHOslmuri+bWZrs5f337Pw4NsWHtzv4Kc\/MvPTT1t14OfLu7\/7+Mtfevj5z4b47ocOvvm+k5uv2rm+LZFbd7O67GFpycfstJ\/Z2SCq6sbptDAzk2ZpaYmtrS1ef\/113nrrLd588022t7cJBAIFYEiQAH2NjY2\/Ef82m5Xe3i7M5k48bjt2RwdudweplJlEooNzs52sr3bx\/jsWPv52F3\/1i4Fd0HsI+EQH\/n8F\/OddA+CXmgHwd39t52\/\/Yoj79x3ce2eIN1\/zsLPtZfOKn5VlP8tLQUIhN263henpNMvLS2xvb\/Hmm0+O\/+7uLrq7d+d\/oAPJeYKA2o\/q6yAa6SSd6mQzZ+bKWi\/vvm3hux9auP\/NE\/A\/8wbAz396lD\/\/iYH\/8n\/F+fu\/C\/D3fxfgL37h4yefDvHBPTvvvONkZ8fO1qbE2iU3S4seFhd8TO\/Ov+LPz392qjTzL\/h3Ou1YLR3YbCdQlH683g5UJf8Mlpf6WV7q5vq2mTt3zNy53ck7b\/fztbdad2XheU32f\/RDhY+\/K\/PBvSFu37Tz6nUna5dsrCxLLC24mZ31MHvOR3bKz8x0AJ\/Pjd1uYeq35L\/U+rfkrbW1VQPrNpuNtrY26uvrqauro6mpSQPLwhAQH\/I6ffo0ZrNZyxuwWCz09PRoQqL3vou+xYM3Go2UlZVRXp6vwjA8PFzwJWKRTKz\/LoBIBo5Go4yOjmKz2Qq+ThyNRrWqJZlMhmg0ysbGBufPn+fs2bMoiqKtEJw6dQq73U5z88MxwL8OBOg9bMUf3RG01xJ9MQDWk\/lI5UMx8OKej1ri1\/dfrOj3Ai57AYDiuOGnkf9Sv3+lbsLw0pOYIzEvxfP0qGs+LxWH9AhjMGwpPM9YW7bn9m9CdxclltTmh\/aXQv67G8qpPfjZh8Aqn9tHa\/VBTRk\/SfmPtJfzulzBbfkzA+A76Qa+k27gXrSON5Ra3g3WILXUkjaWa+BfA92TLdyfbOTBZDN\/lmnh359pxdtcT6T9Jebn50km07vL8JN5mkgzMT6BobmJfc\/sY98z+zA0NzExPkF6Iq2dl8lkSCbTzM\/PE2l\/CW9zPf\/+TCt\/lmnhwWTz7j1bHhpP2liO1JIf8xtKLfeidRo\/n60AVPG6r5x050EOHz7MiRMndj3bVlpbW6murqaqqgqDcBofKgAAIABJREFUwaDpLAGEent7d8MILFgsJoaG7Cg+B4piRvF3EVBPkEx0MTvbzd3XLbz\/npX737bwox9Y+cEn7bse4Apg3y74+X80I+Bv\/9KbNwJ+6uaHP3Dzwftubt\/0sHnVy\/amyvp6kPX1GJmMiuy1EomoBIMB4vEo8XiMTCZDJpMhm80Si8XY2tpiYWGBubk5FEXRnHj9\/f3YbDYOHz78G\/Fvs1mxWi1YrSbcbjuq6iASMRMJdZNKdrC40MXmlV4++e4AP\/+Jnb\/9qwH++b84dKDvB8A\/7tI\/7BoBv9pdGSjjv\/83mX\/6Oy+\/+nMvH37Tw9fuern7ZoBXb+Srw5w7p+LzWYnFHuZ\/aurJ8K+ff5\/PgeI34\/d1oSonSMS7OHeumzu3LLz7to0P71n4\/vesfO9BBz\/9mYk\/\/\/NmfvyDfbtG4Jf5p3\/w8n\/\/U5T\/9Dd+fvUfZX76Yxff+9jFO19zc\/OGh62rXjavqqyvBbl0KUY6reJ2W4lGSzf\/gn\/JaWfI5cDtMePxdCF7TxBQO0nGu8itDbCzPcDNm2a+9paVN1\/v4J13u3j33WMFBvBPPnXz858F+fR7Pj6+L\/PNex7uvunm1eturqx7WFn2srqisrgUYGkpRiql4nFZCYbyHybLfxn7N+O\/1Pq35K2lpYXm5mbKyso4cOAAbW1tHDx4kJqaGo3Kyv5\/9t4\/qKk73\/\/31qsrVq1WucJFKgVFCkpugggGkk2GgHDJJCQmJCafhISEYPJFKBQ+8IFCQfxxRVHxi9VqcfXqR1uvXa39ASTbTp067WynnXbaaafTnXa2s53d2c52dmd3dmd37ux9fP9I3sdDxLb7Q+nMfs\/Me0JOTs77vPI+h9fz+fq5jOzsbClpd8GCBSxYsICtW7dKlXzS09NZunQpWVlZLFmyhCVLlrB48WKJVS5evJilS5eSkZHBsmXLWLZsGampqbjdbrZt2yY1IhN1aOvq6ti+ffuMikSiB4DITfB6vTOSfEXVIKvVKiULi7bZbrcbtVotERlBAORKe926dbeFAHyTQi0uLr5jF9FkECCU72wARcwvzvl1wEI+xPUlNwe60\/Wmp6fPsAD+o8s\/18\/fXG\/JZEwO9mOx2AuxWOyF6enp69Fo9Pnp6ekfxmKxK7FY7JloNHoxFotdiEaj\/xmNRv9zenr6fCwW+7\/T09OXotHo5Wg0+lwsFrsajUafF+cRIzlERxCASHX6XZtzLFI6wxuRbEm\/l\/d\/XupSVi5eyIL5\/8TC+fexavFCMpankJWVdc\/vf3f+MsZrl3PcuIqnt6fyZF2cAFwNZnLJk8FTdelc2JFGxbo0grkreGlnLi\/vzOPlnRt4KYkAvBTK5Ud7ldRkr6Exfzleb2OCAOykqSlEU1OCAPgbWb4um4ULFrBwwQKWr8um0R8nAE1NTTQ1hQiFduL3B\/F6G2nMX05N9hp+tFeZmPMWAXgplMvLOzfw8s48XtqZSzB3BRXr0riwI42n6tK55MngajCTHwbX8GRdGk9vT+W4aRXjxmUEC5eQmZlJZmYm999\/PwsXLiQ3N5eFCxeyYsUKaSxatIjMzEzmz5\/P5mKpgRBlZSXMmzcPTVkhGwtWkfGvCzHWZlK8eSE1VQvwOuczcUrFs+dVnDpxvyz84wHgXeAT4M+JEbeEfvyelY\/edXHzhoXXYnYuTlgYHbWwZ9jCQL+Vrk4bbnc1VmsV7e1+7PZbSY52u13qlyNqn3s8HmkIL7wcAP2l8hfL5Ndo4vLr9YWUFK9i48YFuF2Z2K33EfTMo6dzHq9MKXn7rULeunl\/gvg8kCAAMeDXwO+BrxIhQA8ATvijmy8+t\/HTj11EX7Vy4ZyFk8etjI7YGBywEfBXY7dX0dkZl\/\/WuPvyy9dfrS5J3AeFFDyyin\/914XUVmeyefNCqgwLcDrmc+rYZp69oOLk+HwunV8An5TwWnQhN19dkFjzL4FfASn88nM3P\/nQxkfvuXnjhpVo1M6Z0xZGD8XXv78vvv5O5631v7X2915++f3\/SO4qVq1aSIUhk4JHFlBcvAC9bj4D\/Zs5MLKZ3s55DPfN56srDzM2upDTJ4T8vwCmgAW8+bqTV6dsxF5ycOmChQvnbBwaMTM4YKan20Jnp5XWFht2WzVmcxVtrb6\/Wf650brfoa2goEBKAhGhNQ6HA51Ol3B1qti0aRMajYa6ujq0Wi06nW5G1rio1S88A0qlkrVr16JQKKSuv8XFxWzatElilytXriQ1NZXt27fPIACiy291dfWMbsIi7t\/hcEhtoGtra2d0GRbEQVQSEp2KRQc7kZgsPBSz9QGQA4BkK+BsSlXs\/zplLY+5lcfdyyvgCADyTeEEcsUvn1\/EC8uBQLJlcN26dTMAwNd5AP5R5J\/r52+ut9ni5IUlXgDxWCx2LQGun4nFYhdisdi5WCw2EYvFnopGoyei0eiJ6enpk9Fo9PTU1NQPEgD9YjQavTw9Pf3DZEB+p1h9QQDuxpxjkdLbQpDkJOBe3v+qNctJX\/o9UhbEQ4BWygjAvb7\/PflLGa9dzkljAce3l\/OkOY2rwTU835TJ88FMnjJncMmdjn5dOsHcFbycRADiFYGyuNqUzUuhXCbDG6jOXkOwYjmPPfYYO8MRdu4MJ0hAU7wog7+RzHU5EgHIXJcTJwDBOAEIhXayc2eYneEIjz32GMGK5VRnr2EyHJ\/zalN8zh8Gs2cQgJcTBEC\/Lp1L7nSeMmfwfDCT55syuRpcw5PmNI5vL+ekaVOcAGxaQm5uLhs3bkSj0WC326mpqcHpdKLVaikrK0OhUPDII49QVlaG1WpBq9Wg02kxmYxUVGipqdERDNppiTgJeDWEm8sINysIBTIZGVFy4VwJr0yV8foN9SwEQID\/P8lIwCI++LGN116p5ZWolRPHahg9ZGJ4yExnRw39fU66upx0d\/uwWmuxWIyYzfGmTHa7HYvFIjVCEp1ahf7TaDRs3rxZsupmZmb+RfJbLDPlr6qOyx8O2elod9LWqqWnp4y+HiX9vQVcflbBa7ESPvuJhl98UQaoE\/IHEyTgD8BvEuONxGce\/vQbBz\/5SQ0ff2jjucu1nD1tYuyImcGBGvbvczLQ76Sv34fNVov1HsqfvP4GQ1x+f8BOJOLE69XQ3FxGc1BBcyiTPQNKzk6UEJ0q47UbZfCJHj5R8+N3RB7El8AXibEoYRV\/kPfesvPqK9VEo1bGx2oYHTExNBhf\/77vwPqLqkHi\/vd44p2qnQ4NXo8ar0eBw55Ba4uCfXuKmThTysS5Yn57ZTNfPZfFxAWRC\/J74ttXEgF+43UXk1dtnJmo4cwpC8PDNfT1xrtJR8I1dHY4aW1x0tHuw2yuxWwyYjL99fLPtf6d802lUlFfX4\/f7+exxx6TRnt7u+RS2blzJ11dXfT29rJ7924ef\/xx+vr6GBwcpLu7m5074\/\/cd+7cKbVyl59HNOERYUIZGRnk5eWxdOlSKQRIbskXjb\/k9f+3bdt2G8Cvra2dMUQvAvGZ6ChcX18vEYf6+nrKy8upqKhgxYoVkpIVAFRebk+n091WG3y2JEG5wp0NBMgV7teFMsiPlVvGkwHFnSyRX2ellHc5TfYA\/CPLP9fP31xv8hh6EcMvPAACiMss8P8Zi8UmotHoiampqSNTU1MHotHo3qmpqT2J1wPRaPRo4vMfJKz1l6PR6HNyQJ5c819OBO7WnKe7DLMmNc\/F\/b8hyQMgQoCUaxbd8\/vfW7CE8dplHDeu4Ontq3iyLo0L7gyeb1rL9aYsRopW8ownI0EAlicIwAZeDm0gul\/FFf+tUJyXd25gOpzHtuw1NOlW0NXZSTjSQlMwdMsLEGyKewByZB6AnLgHoCl4y\/rfFAwRjrTQ1dlJk24F27LXMB2OEw8RenTFn0V0v4qXQxsSJCCXYO5y9OvSecaTwUjRSq43ZfF801ouuDMSHoBVHDetSBCAxRQWFmK32wkEAnR3d0ujq6uLcDhMOBwvYdrb28vAwAD79+9ncHCIgYFBjhzZx549ffT2RujuaWbkQIQLZ7u4drWb6Es9vHmzlw\/e7+enH\/bx7tu1gC8Bct9OhLx8AvwxQQDeToCgFL68Wc3N16y8+qqTSxctjB4yMjBQzZ49Djo7LHi9tdhsVQkAWIvJVIvReEv\/VVVVSfrPbrfjcDhwOp04nU4cDgdqtRq9Xs\/999\/\/V8s\/OHhL\/v7+CAN9zYweinDl2S5iL\/Xw5uu9fPpJP1\/9op8\/\/7af335VBX9SAu0yIhQFfpvwBiwDUoE0+LmSzz+z8enHbl66bmXilJFDB6o5Muqgr9dCMFCL3V6VIABzI79Y\/+Hh+Pr3JNb\/\/Jkurl3rJhbt4cdv9vLR+\/188XEf779XBR\/qEl6QFcAV4GeJ8ecEAXgg\/tu8sZE3Xrdx47W4JXz0kJGBwWr2DMfX3ydbf7P53ss\/NDTE0NAg+\/fH5e\/qitDR0cy+fRFOnOji7JluLl3o4drVHl6d7OFmrIfnLuv48rnCxBoLEvzbBAH4tUR+b7xk58cXqrl0wcqFcw7GRi309hjpaK+mp9tOJGzB6azFbK7CIpP9r5V\/rvXvnG9ms5kdO3bQ3d1NY2MiYUtYahobaWxslOLqu7u7GRgYoKenh56eHrq7u+ns7JSOFyTg0UcfJRKJSK\/hcBi\/34\/H45HyAoqLi1m8eDEOh4PKykqpi5vRaKSurg6DwSC9inh\/UQpUeB5EjVrRhXjbtm1SBzh5EzJ5MzJRmlSlUrFs2bJZAYCoBy4sgnLLYPLrbEOc7+89RJKsvKqIfIj9d7o2AQLk5\/xHl3+un7+53uQJtYIAhLdkUrp2JdFo9HlhhU8A8aempqaORKPRvZOTk49Ho9H\/HY1GOyYnJ9sToysWi\/VFo9G9CVB+WgDyWCx2NQHuJQKQnAwcqU6\/a3MKD4BIJnYUrqZLmzkn9\/+a5SksXfTP\/PN9\/8Q\/3\/dPLFv0z2QsT2Fd6pJ7fv97C5ZwvHYZT5kKeHp7KicTBOB601peaMrmSWMmLwSz0a\/LILhhedziHtrA0bq1\/Gj\/Fp7xZPFC0wZeCuUxuTOfHx1QsS07k1D+Slp2tRFp2UU4fIsENDYGyW\/wk5WdJRGArOws8hv8NDYGb4H\/cAuRll207GojlL+SbdmZ\/OiAismd+bwUyuOFpg0848niR\/u3cLRuLS+H4t6B4Ibl6Ndl8EIwce1N2VxPEICTiRCgp0wFHDcuJ7hpMbW1tTidTvr6+ggGg4TDYZqbm6XygUL3hcNh+vr6GB4epr+\/n76+foaG+hge7qGnp5mh4RAHDjRzYjzCtee6ePFaG2\/e7OatN9v59IN2fv12Bbz3ECCviJMi8wK8RTwvIMSvb1QQixqYmrJyYqyKoSEtoyM22tqqCAWqsNu0mM067HYzFosJo7GWmppqqqurJDJaW1srhUOIV4vFwubNm6Vqf4sWLfqr5e\/v72doOC5\/X28zw0PNjB5q5uTpCC+91EVsso2P3u\/ls0\/b+e2X7fBzA3yVC78vS5CAVOAMMJkYqcBq+GMhfKbngw8qeO9dKxfPVzE6ouP0STs93VU0N1fhtOkwm3U4HGasVhNG072Vv6\/v1voPDcXXf3Do1vpfvdrF9WttvPlGN++93c5PP2rnd+9XwIe5fPZxGdAGPAtc4taWkrgnXPD6Rl59RU8sauXEMQP7hrWMjdhob6uiOVCF3X5r\/a1zuP7Dw30MDffQ2dlMb2+I4eFmDoxEOH26kzMTbVy93MW1K2289mIb7z2r5ReXlfzhWrGMAPql8B9BfvnSx1tnKzh9soKTJy0M9hlob9PS32cjGKzC7a7CbNZirNVhtZkxmxPyV1dTXfWXyz\/X+nfON4\/Hg8vloq2tjaamJile3uVySUO8d7vddHZ24na7CYfDPPbYYzNi7BsaGqTvBINBab\/VapVCdtRqNWazWcofqK+vl\/aZzWaqq6ulykEqlQq1Wi2RA1EGVPQGSG4SJroQi6pBorqQAP+iM6dGoyEzM1MiAFvWpnxjEqE8CXK2caea43ca8hAEeUWcO8Vj3+mavum42cId5JbFf3T55\/r5m+tNVMlJrv6Tnp5OIv4+GYgPRaPR\/z09Pb1reno6NDk5GZienm5MvIamp6d3TU5Odk1OTg7GYrHDSYD8WiwWe2Ffwya2rE2ZkfwrCMDdmvN0l4FIdfoMAtBty5mT+1+T9cCMJOC1y7\/Hv2U8gPmRVff8\/m8oWMKTxuU8WZ3GM\/50GQHIYvrAJk6a4kRAn7OGpvzlvNCUy0tNG9hfuYbRHZWM79jGxcYaXt5ZwGS4gFdGiqjJWcvBbRnsanuUXbvaGBk5yMGDo4lxkJGRETbkxWONFy5cyIa8XEZGRjh48NZxIyMH2bWrjV1tj3JwWwY1OWt5ZaSIyXABL+8s4GJjDeM7tjG6o5L9lWt4qWkDLzTl0pS\/HH3OGl5oyuakaS3TBzZxvSlLIgDP+NN5sjqNJ03LCW5agsfjwe1209HRQXNzsxQvLNdr4r3H46G7uwev10NrawsDA90EAh7CYQ8tLR56e\/z09rrZv8fDhfMhnr3oZWrSy2uvmPnsg2Z+904FfFaQAD8PJoDwA4AiYQFeAoR58aXNXH1OzfFjpYwcKOPUCRvDQ2ba22sJBmtwuapwOmrweCy4nWbM5lv6T141T67\/LBaLFAZbVlZGWloaixYt+ovl7+mJy9\/W1sLAYFz+SNhDR4eHoUE\/Q4Mejox5eO5KkMlrXt543cs771r53Zch+EUVfGVIAODUhNzX4sCf60Apv\/q5nnfeVnLjNTXnz5Zw8ngZ587YGB0x09NVSyRSg8ddhdNZg9dnwe24N\/J7kta\/re3W+kfCHtrbPfT2+unrdTNywMPFCyGee9ZLLOrl5utmPv84xH9\/YICf6OE3iring\/WJ30GA\/wfhLQ2vRhVcv1bKyeMljB0q49RJG3uGzXR01BIKxjsNO53xDsyuOVr\/1tYWenq68fk8BIMemps9dLT76exw09vjYexIiGPHPJyZ8HD+vImp5\/x8eFnHF89p4NVH4iTgvYfjpPcPS+Kvf17ClUsGRkeVHDigpq9HRVenmj3DVjraTYRCtXi9NdjtBqzWGtxuC1arGZPpr5d\/rvXvnG8ejwebzSZZ\/F0uFzt27LhtuFwuGhoaJI+AvMGWOMbhcEg3itfrlYY4rra2lvLycsxms9RoTIBy0TxMWKtMJpPUcEIcK+L9RU6AIATxluwzPxN9BQSxEMShqKiI7OxsMjMzWb58+W3KfzYFnAxQv0nRft1x32b8JQp9tmO\/7hghrzy++B9Z\/rl+\/uZ6Ew3AHIWr2dewSarrn56eTiIM50IsFpuQAfGOWCwWjsVi\/snJyYZoNPq\/xHj55Ze90WjUNzU1tTMajXZEo9GhRNjODxKJus9Fo9HnRZfh2aoA3a05xyKlM0qECnnn4v4XIUALk0KAitasuOf3f0P+Up6qW85J8yom6m2crEvjonsN15uyeaEph\/9qyOJ6KAd9TiahTcs5vyOdo45KDtZX8nilloFKLY9XlrO7Yh2Nqk34CzfRWb6FoyMjHDgwwuOPP87AwBMcPDhKS6SF3buH2b17N3n5uVIxiLz8XHbv3s3u3cO0RFo4eHCUgYEnePzxxzlwYISjIyN0lm\/BX7iJRtUmdles4\/HK8sTcWg7WV3LUUcn5HemENi1Hn5PJ9VD82l9oyuF6UzYX3Ws4WZcWl9G8iqfqVhAsjBMAm80mWTyTjV9yI5jf7ycQCBIMhhIVZ4JEIgFCIRfhsIu2didDw16OHPIxccbHlct+YpN+3nmzmU\/fD\/HO20b+\/F4FfLIZPi2ETx8GmoHBW6Ehb2u49mIpL71o4cSxUk6fMLNvTzU9vTV0dZpoaTHh85twu0xYrTUYjd9e\/xkMBpRKJZmZmaSlpZGSkvI3yR8OC\/ndtLa6aG9zsn\/Iy8lxL5cv+XjpeoCbr\/n59CfNfPmLZj7\/vBZ+buCrnxfzxy+V8Nv1CStwXhwQf1HCx5\/oePN1NW\/92MyZ02rOnzUzNlrF4EANPT0m2tpMBEMmPO65lz+SkL+52UUk4qK93cnQkJfjx3ycP+vj+lU\/r7zq54N3m\/ni42Y+eL8WPqrgpx8X88vPlPBlTiIsLDVhFS\/hx29U8EqslFdjZk6dKGXilJkD+6vo7aumqyu+\/n6fCXdCfpPp3sovPALxEaQ5FCDgdxEMumhudtLZ6WHPoJdDoz6On\/Bz7oyPq8+GiF4LcvlSFR9e0nH5ooo\/XS\/kDy9lwZ8egd8\/ECfCvy\/h7Gk9h0ZKOTFuoqe7lMEBEx3t1UQi1USa45223W4jdrsJszm+\/rW1f738c61\/53wTHgC\/34\/b7Z4RKy+PnRckwOv1zmCJLpdrRvKusLSbzWbp5hGdfuvr66moqMBkMlFZWcnChQuxWq1s2bKFiooKioqKKCwspKioKJ5Yl9gv74gpFlmv10vEQPwtPtPpdFKDMHnYUFFREbm5ueTn57Nt2zZWrFgxQ3kK5f1N1mr5mE35z3bMtwG83xY0J1vL\/5Jj5ABAgIB\/ZPnn+vmb601e\/19eWz9BAJ6JxWLnEkm3e6PR6P+enJyMRKNRXzQa\/V\/T09Pu5JEA5r5YLBZOhOvsnZ6ePpkA9VcEAfiaKkB3ZU5BAIQHQPQNmIv7f8O\/zMwBSF\/2PZQZD6Bbl3rP739v\/jJOW1dwsm4VE7ZUTtalx+P\/Q\/HmWpf92VzdmcOYYR2H9bn06LYQVi0mXJxCZMti9u7ez8jBg4wcPMgBMUYO0tPTQ1tbG319fZIHYHR0FI\/HS+W2uoQHdjnLli0nMzOTym11eDxeRkdveQD6+vpoa2ujp6eHAyO3zi\/m27t7P5Et8WsJqxbTo9vCYX0uY4Z1XN2Zw2V\/NtdD67geyuH5prWcrEtnwraak3WrOG1dQbBwqaTHAoEAHo9nRqywPHZYgCCfz4fX68Xn8+L3ewgG3QQCTkIhB5GwjZaIhfY2C319Fq5c8vDiix5iU05uvu7gzZs18HYpv3tvPjdurocPcuDjHHhvYyL2ezPRV7RcuVTKlWf1jB4oZfRQBQMDBlpadITDVTSHjPg8RoxGHWZTFdU11ej1OqqqqiT9p9VqKSmJNwirqqqiqqoKrVaLUqnk4YcfJjc3l6qqKu6\/\/\/6\/q\/wtERstLRY6Oi0MDli49pyb2JSHG6+6eO9dJx99XAs\/UcPP7uMnH+fCz3PhV+vhy8I4Afi4mHff1xF7qZSpa3qOj5cyPq5nz7CBjra4\/JGIEZ\/XSG1C\/po5lD8QiMsfCjppbnbQ0mKjtdVCZ6eF4SELVy57mJz08NorTt55y8F779bC+2r+9NE8Pnw3Fz5bD79eD79ZD6zmjRubef11PdevlXL9qp7jR0o5dkTP\/j0G2tt0RMJVRMJGfD4jZrMOs3kO5fd68fk8BPxuvF4nPp8Df8CG328hGDDTGjIzNupm4rSbUyedXDhv58K5ar66UMLNC\/MZP5HDF+cfZmw8C\/7sjJPfX23m5HEd+\/aUcGC\/jq7OEro7K2hrMRDwafF4qvB6jTidRmprdRiNf7v8c61\/53xzu92SBd9sNktJuMlDkAC5e8jj8bBjxw4J\/BuNRskNs2XLFqmOv4jBN5vNqNVqqUTn4sWLKS8vl+JTRQfi\/Px8NBoN+fn56PV6cnNz2bRp022dhnNzc6WmFaWlpbd1LBbJvhUVFRQXF7NhwwaUSiV6vZ7CwkIyMjJuA8GzKf1vCwDuZH37Nkr92wLib2Nl\/KZjkiuM\/CPLP9fP31xv8oRY+d\/p6ekkym5OTE1NHZmcnHx8enp6VywW8wsgHovFXMkjCZC3JOL2j05PT5+NRqPPxmKxq3ICkFwF6G7NeSWyVbL6ywnAXNz\/yWVAhQdAleQBuBf3f0PeMp6yruC4eRVP21J5si6d6GFVHDSH1vFMYzY\/DK+jOieLJw8e5NjBEUYOjjBy8CAHR+NjZPQgTww8ISUNisTBlpYWWlpaGBgYYHR0lNHRw4keLR7Wrl1LSkoKKSkprF27Frc7Xsd7dPQwo6OjDAwMSN8XeWRiPDHwBCOjsvkPHmTk4AjHDo7w5MGDVOdk8cNw\/NqfTxCA6GEVT9al87QtleN1q3jKupxg4dIZFk+z2YzNZpPAj3wIECQMYF6vB7\/fS8Dvwu93EAzYCASMhALVhJsNhILFDA3E6\/hfu2InFrXxWqwa3rfws9fnEZvMhXcK4O31vP16AdwshNdymZrUcupEIWcmdAwNPMKeIR0Oew52WwE222aqa1To9So0GhWPPPIwDz\/8MIWFGxM6cWbHVpHsqNfrUalU5OTkUFhYiE6no6CgQCrD\/TfL70vI7zcSDFQTDsflHx6sZeJULS9esfP6a3befL0aPrPy1XvzePNGHnxUwDs3cvno7Y3wgYLrz+bx+itazpxWcOGcjqEBFfv26HA7cnDZ4\/LX1Gz+zsgf8HsJBFwEAg5CQRvBoJHmUDUtEQORcDGjh2o5M1HL1It2bt6w8ebNavjYwi\/fmcfN13LhowLevJEDn+YAhbx0JZcbU1ouni3k4gUd+\/cpGTmgw+3OweUswOnYjNG4GUOFCq1WxSMFD5OTMzfyezwe\/D4vXq8Lj8eB12PD7Tbidlfj8VTgdGymrbWGwf4axo\/YOHncyskTVfz3ZTOvTtzHoUPr+c3ZR9i3\/2G4kgtfbuST4+s5Oaahu+sRhga0BP15tLXqMRgeprr6EWqrN1NhiK99aamKnJy\/Xf651r9zvomQn4aGhhn19OVeADGEF0AQBo\/Hg9Vqler3iyTeiooKysvLpbbLBoNBWgjRSGzLli0sX75civdXKpXk5+eTk5MjAfUNGzZQVFREXl4eBQUFqNXqGY0p5EOtVs94v3XrVikZrqioiIKCAgoKClAoFOh0OjIzM8nIyPhGJTqb4vcUrcFTtGaGgv06C+CdwMSdvpN8TcnHfZtz3elzOQBIBj+ANdCxAAAgAElEQVT\/iPLP9fM315s8FEcekpOXtoyEBf2pycnJg4kY\/NDk5GTDnYC4HJC\/\/PLL3unp6VDCgn9wenr66Vgs9sz09PQPkz0AciJwt+aUJwHLOwfPxf2vWnN7DkD52gcw56fe8\/vfn7eM\/foVHDOvZNycyg92pHM1lM3zoVyuhnK5cHSMsdFRnugdYKBvgCceH+CJgScYHNxNJLKX8fFxdu8eprGhYUbVuORx+PBhDh8+Sn5+ARs25JGamkpKymJSUhaTmprKhg155OcXcPjwUQ4fPjzrOcT5Gxsa2L17mPHxcSKRvQwO7uaJgSd44vHENfYOMDY6yoWjY1wN5SZkyeYHO9IZN6dyzLyS\/RXxRmAC\/Pj98prq9hlWUDFm5sO58Pu92B1W\/H4nPp8Vn89EMGAi4K8g4C+jJaymo13NqeMGzp2p4MalefBjE1NXVfwypuU3r67ns9fmcf7sej6cvI9Tx\/N47lkNBw4UsmdoMx1teYQjKpyOXCy1edjspeh1BZSVbaS4ZCObN29EodhIYeFG1OpSNm7cKI2SkhIKCgpQqeKd7\/Py8sjLy2Pjxo1otVrS0tJITU39m+W32eLy+xPyh4IJ+QNltETUtLeqOXHcwJlTBm5engcfmHnlxc38+oaW37yWy+evzuPK5Vw+mbqPMyfzuHZRw+iBQvYMFdPRmke4WYXLmYvVkoc9Ib+6bCPFMtkLCzdSWnrv5Q\/4vdjtVgIBJ4GAlYDfRLjZRChYQbi5jI42NX09ai6cMXD1koG3X5wH75u5+cpmfvumlj++tZ4vfzyPF59bz2dT87l0PpepaxpOn97I6GgxAz15tHeo8HrzsFrzcLlLMegL0Gg2op7r9Xe58Pni8ns9TtxuKy6XCbfbiNOpx25X43KW4vOV0tdrYF+\/ngsH5vHHi0ZGR5S8cUzD22M5vHpkCf19D\/Pigfvp7HiI\/fs1tLY8QiSiwu3KxelQUVubi0GfR62xFLW6gJKE7GLt\/5b1n2v9O+eb2+2mvr6ecDgsWfOTw4DEjSGG2O\/xeKTjhYXfaDRSWVmJVqtl69at0lCr1VJYj+gvkJOTw6ZNmyQLflpaGmlpaSgUCtLS0lAqlVIzMpVKJTE5lUqFTqejtLSU0tJStm7dKln65Rb\/4uJi8vPzycvLIz8\/n\/z8fKkT8erVq2eEAH1TBZrkYyRr3l9w7Awr4LeoevNN3\/u683zTtSUTgH9U+ef6+ZvrzVE4MwlXEIDStStJ1NY\/MT09vW9qauqxqamp4NTUlOfbgPGExb5xcnKyfXp6el+ifv\/FaDT6nCAAApQmVQG6K3PKcwDk883F\/b8hdem3qgJ0L+5\/f95SdoX3cvTAfo4eHOHk6EGOHR5l\/OhRzo+N0ZSoyR+36O9i165dtLTsorGhgdHRgxw+PEqD1xPPD0vECIuqcOJvkQPW0NAgWRBXrUqVPACrVqVKeWMNDQ34\/X4aGxtvO0+8h0D8PA1eD4cPjzI6epDGhoYZ1xaJxHsPNIV2cn5sjPGjRzl2eJSTowc5enCEowf20xbeS1CxBLfbjd1up6WlRQpnTQ6DsNvtM0b8GAc+nxe3y4HP68TrseL1mvH7jPi8Bvx+LUG\/mtZWNV1davYMlxEdnweTJfzhymY+u6KF2Hp+dmU9p0\/m8sWFjZw4ruSNcTX79mzG636AlhYVNdUrKCt7EKtVgdOhQ69XoClTUGXQUlpaTElJMSUlJZKBTW7xVKlU5Obmsn79eslbvnHjRtavX8+KFSu4\/\/77\/2r5HY64\/C6XA6\/Xicdtxesx4xPy+7QEA6W0tpTS1aFmaDAh\/7USfndlMz99Tsv\/vLKen11ez6kTuXx+fiOnjit5c1zNnj2b8biXEYmoqK15AI12xS35dQrK1AoMs8hfUREf90J+af3dDnw+Jz6vFb\/PnPCCGGgOaYk0q+nqVDM4qGZ0tIzXz8+DV0v4n6nNfBnVwpvr+fXkep69uJ6vrm7k4nkl759XMza2mebAKrq7VJhND6DXrcBhV+B26zBU3Fp\/tbqY0tJiSkvnZv29Xi9OpwO324nTacXpNON0GnHYDdjtGuy2UlyuUvzBUsJhNad65\/HbE8V8OqLilQMafn48g5v7M2jv+Fd+PFBAZ5eCK12lhEIqDNoHcTmVlKhWUFC4gtoqBWaTjjK1gpJSBTqdNrH2f9v6z7X+nfNNWPS9Xu9tcf8C\/AvPgAD5ZrNZ+lsQgrq6OikEqKKigi1btqBWqyXwLxpz6XQ6ampqUCgU5OTkkJ2dTVZWFsuXL5eSwkS34IyMDJYuXSqNzMxM1q5dK3UZTklJYcmSJRQVFUkl\/AoKCuKJZXl5rFmzRhqLFy+moKCAxYsXs2TJEpYuXXpbU5z09PQZpQBnKwMowpVEST3556Ju+GyfiX1fBw7kc4tyVsnv5fW+79S1VH6N8vJ\/Yl\/y3N\/Wepgc+iCsockWRvn5vyls4ttYTWcDQl9nsf1LQiKyVt7PxvQH2Jj+AKVZD0p\/J4+slffP6bF3a+7kBlOGdSn3hADMVgWo25Zz1+Y83WWYEfIjL\/95r59\/eRnQhfPvY+X98RCgrKyse\/78N+YtZfiJYYYH99Jo87L3iX343V5URYWoVAr8DY34\/Y00+hvp6uyKh+NEIvhlYN47C3hvbGyk0e+X3icTgOzsHBYtSmHRohSys3NmJQB+v59G2fnk5\/AmwhC8Xi\/+hgbCkQiRSISuzi4a\/fFr9jc0olIpUBUV4nfHZWu0eRke3MvwE8MEFYtxu904nU58Pt9tcc8C\/AjD12z6z+m04\/E4cLksuFxGXK4a3G49Tmcxfp+acHMpnR1q9uwxMLVfz80jevhgMx9MaPnTVQ0\/mcjlp6c2Ej1xHyMjSsymBQR8GahLF2G3ribn4YVkZS0kddUiVJvTUCr\/lXnzFjBv3nzmzbuP+fMXoFIpycrKIisri7y8PBYtWsT69esl49nq1auZP38+eXl5zJ8\/nwULFrBw4UJWrVr1N8vvcNhxuxw4HRacTiNOZzUulx6Hoxivt5TmUCntbWqGhwxM7tFzY1QP72zmvVNafntFw0cnc\/n8xEaujt\/Hnv1x+X3eDJSKRbicq8nKWkha2kIefHARSmUaCsV3S36x\/m6XBY\/biMdTg8+rx+MpJhhU0xZR09erZvSQgRvjet6Z0MMnm\/nJFS3ENPzyci5fXSokduE+Th9X4ncuoCWSgUG3CJctjUfyFpKbu5CHMuPyb\/4Orr\/L6cBut2C3GbFZq7Fa9ZhMm7FZS7HbS\/F6S2lvq+Bch45LXTp+HVMRG9Tws5EyXh3I4I2+Aia6U2hpVbB54yKMln8lM28RBu1qVq1eyIMPLiQlZSEbN6aRlzdT\/gUL\/jb55xp\/z\/kmknTlsfxyK78gAPKSSuK9aLQlkn9Fwy4RAlRZWcm2bduk8zocDqqrq6WEDOEBKCwsRKvVUl9fT3V1tZQs7HA4MBgMM6oR1dTUoNFoUCqVKJVKtm7dKnUcNhqN2Gw2GhoaqK+vp7a2VpJj+\/btlJeXSy6hDRs2SApZgFZRZ1uuOGfrCDpbnW2RpJz8\/WTgcCfLXunaldJxZrOZxpAfW328EVpxcTG2etttQzyMOp0uTsaS9suvQT6+ycr4bcIf7kQYxG+ZDP6\/a2FD4hgBlkuzHvxasKx\/OGVOj71bc8sr42zLWz2DAExPT59PJNPu\/2vA+OTkZCAajXbMBsblHgBRijRRBvSuzHlln1kiAN22HIRHYC6e\/7ykKkCrEjkA\/\/Zv\/3bPn39\/3hJOb1\/GcMVyGlVLiYQeJdQ0jKpIQYO7Ab\/HTzDYRKPXT2NDY7xD784wxUVF1NTU4PF4KCpS4fV4UKpUcet8QwP+xGt8eGeA\/7y8PLKzs1m4cBELFy4iOzubvLy8GSRAfCf5XEpVfK6iIhUej4eamhqKi4qk62psaKTRG79mv8dPg7sBVZGCUNMwkdCjNBYtZbhiGae3LyFYuFiygArrpwiBkFs\/BfgRw2azYbHE9Z\/DYcfhsOF0WHA4jDgcVTidFTgcZQSDBtrbqhjod7Bv2M5zQxWcG17AL86a+PjIQ\/z3Wwoujy7iywk1Fw7Mp7tbxfCQhv377HR36OnpdtAcqiASdhEKuQgGXFgsNeh0ZahUhSiVhZSWllBYuBGlUonRaMRut+P3+3E4HNTW1kpy2Gw2KUy2sLCQnJwcsrKy\/mr5hf4X8jvsFux2IzZbFXaHHrutjEDAQGtLFb09DoYH7Dzbr2dicAE\/O23hwwMP8Ye3FFw6sIhfHFdzds98ejpVDAxp2Ddkp71VT0+ng2CgguZmF6GgC7\/fhcVcg1ZbhlL53ZHf6bThcgoCVIXHXYHLXUZb2EB3VxV79jk4MmJn8kAFl0fv4zdXTfx8Ig8+UDB5cgG\/u6TmufH5DA+rOHJEy9gRO729egb6nbS2GGhrc9ESid8DVmsNVdVlbN783ZA\/7hWwYbdZsFqNWCxVWMx6zCY1bqcBn89AW6uDzjY7JyJ6RtsW8tGwhZt9mfwyVsixzmV8MljKaOsiAgElrRENHW02ggEdkbADp7OCQNCFz+fC63VhNN5af4WikJKSEjZu\/Ovln2v8PeebKN+5Y8cObDabBKKT4\/9tNpsE+F0uF0aj8TaCUFdXJwH8mpoabDablF\/g9XrZsWMHFRUVklLNzs5GoVCwfft2wuEwXV1ddHV10d3dTV9fHz09PfT19dHV1UVjY+OMjsSdnZ2Ew2GpC3EwGOSxxx6TmpXt3buX3t5eenp66OrqorOzU+pOXFdXh16vJzX1VsxtXtqy2yxqQrHO9rdImhGyCAUsV8riXLZ6m\/Q+L23ZrGC0dO1KaY7Kykra2tpoa2vD5XJhq7fRGPLfVprLVm+TXOTi+N7eXmmfmLeyslIaAgAIK+i3CcX5OtIiB9zfxlL\/XRtysFy57hZgTgbOcsv6XBx7t+YW1nfDupkegG15q4nFYv83Go2enpycPBiLxXqmpqZ2ftt4\/MRxoURVnkOxWGwiUeHn6likVLLAywlAIgfgrsx5ZZ9ZCvm5ss8sEY65eP6TcwBEErDoh3Ivn3\/\/hiU8vX0pw6VLGa5YgV+\/BL8qhwZtCiqV8tYoig+\/u4EilZJilTJRnWcEj9uDskiJ153wBng8qIpUqIqK8HrceD1uxsbGGBsbkwpIZGVlSQRAABG3+9Zx4nuqoiJUCYLh9XjwJubyuD0cGBmhp6eHYpWSIlX82sR1yq+9QZuCX5WDX7+E4YoVDJcu5ekEAZBXObHb7RKISI5\/ttvtEuBxu90YjcbEZwkA7LDicFiw26qxWDS4XTVEInZ6e90c2OdndL+fI\/s8HO9dxG9vKvn0wEN8ccJIS6eSr24oCQYyaWlWce5sPxOn+jl3dpCTJ\/o5fXqQ0ZFeWtuCdHVFGBzsZd++eDPOSCSeIC0aNwm9OTw8zMjICAMDA\/T390t6UHR5tVgs6HQ6Hnjggb+b\/Ha7FZvNgtVajcmkwemsIdxsp7vLzb5hPyN7\/IwMeRjrXMRXN5R8OvwQnx+zEmxV8tVrSjyeTEJeFadP93PqeD9nzwwydqyfU6cH2T\/SS2s4SGdnhMGBXvbs+e7I70wQAKfDitNpweGoxm7V4vXW0N5uZ2jIzZFRP8fH\/Bw\/4uHs8EL+8GMVXx7L4lfna+npV\/L7d5W0RjLp6VZx6WI\/5872c\/HiIGdO93P27CDHxnppbw\/S3R1haKiXkZEBent6pAT5uV5\/u92GzWbFarVgsVRjrNVgs9bg89lpa3XT3+NnuMfPYJeHPaFFfD6l5N3uh3h3wITdo+CnLykwmjNwuZSMj\/dzbKyfEycHOXSon\/HxQfbs6SUSid\/\/AwO9DA7G1\/\/vIf9c4+853+RJvYIAyMOABDkQSSAiE1xeBUjuBaipqZESg4VFR8xRV1dHRUUFer0enU7H6tWr0ev11NfX093dTTAYlKpH9Pb2Sgqtt7dXSgJrampi\/\/79UkJYU1MTu3btkurTdnV10dPTw969e6XPm5qaJBIiOgxbrVZWrbrVeCcZAMiVplCmQrnb6m1UVlZKCthsNktKWLwX+4RVTlgO89KWzWrpLl27Uprv8eFeHh\/ulX4DcV75vAIkyOcVv5f8O8FgUCqjKrdCipAP8bewgMqHCIeQD7F\/tvCG2ayNf8kxs3ViTQ67+Loup8XFxaxbt+62fcnWT3kYiADDletmgmX5+9KsB9E\/PLfH3q25BfAuXRtPDt2hXkl4Sybb8lYzPT19KVFPf2xqampgamqqbXp6uvHrLPLCEh+LxfzT09O7otFofywWOxaLl\/a8HIvFrokQIHn4jyABd2tO4QHYlrca4YEQhOBeP\/+arAd46IHvkbIgTgDSl32P3NSlfP\/737\/nz39DggAcNy9j3LQCv2opftVaGlQ5NKjW4Vctwq9aRKNmEUVFCop0GoqVhRQrCtkZChEKBnE73CiLFCiKFCiLlCiLVCiLVKiKi1AVF2MwVHB4bIyjR49KOmTp0qVSCNDSpbeScY8ePcrhsTEMhgpUxcWoiouk8ymLlIk5FLgdbkLBIDtDIYoVhRQrCynSaSgqUtCoWSRdd4NqHQ2qHPyqtfhVSxk3Lee4eRlP2+IEwOVySQBI6D95GIT4zOl0SiTF5\/PN0G23QLAFm60Gl8tKc7OT7m4vA\/0++nvdDPe7Geyxc7pFx88HlLzemcUfbwxzuU3DT4fK6GjRcKR5EcePtTM21sHZswPs2dPBqZMDnDgxQFdXhM7OMG1tzRw5Mkpzczgxmmlvb5e6tfb29tLf38\/IyIjU1bW5uRm\/34\/P56OiogKLxYLVamXZsmV\/N\/njINCC2VyD3W4lFHDS2eWlt8dHb7ebwR43vR12TjVr+Ly3kMnWLH53o40LYQ0f9ZfRGtZwILiII0faGRnp4PTpAfr7OzhxfIDx8QE6OyK0tYWJhL978judggRasDtqcLuttEScDAz42DPsY3jIzYE9bvb327nYqeOr\/Ure6Mviz28Oc61Hwy8Oaejr0TLWuojTJ9o5dbKD82cHGDnUwcSZAU6eHKCnJ0J3V5jW1mbGxr5b8svX32SqwWaPJ4a3tXnp6vTR3uqmq91NW9jGIY+WTzoKmQo+xJeTbZzylfFeRxk+r4Z+1yL2Dbezb6iD8fEBBgbiryMj8fu\/rS1MONzM6OioVBHsb5V\/rvH3nG\/bt2+\/ZVFKxHqJ+H8B+nt6emZ0hpOXjhLuFfmoq6uTQn5sNpsUM2YymaS6\/ZWVlaxdu5bKykocDgePPvoooVBIcgGLUnLxhK6dM8pPCXewVI4qERsqrkvEjArSIcqbyhuRbd26lZUrV34tAJhN4Yv94r34XG6JkwMHOQgQFsA71QoX1sLe3t4ZICAYDPL4cO9tCr+3txdbvW2Gspdfh\/x9MgiRyy0nAHcKb0gOdZhtiOPk+8RvJsIjZjteHCPmmC3cQf65OI\/8upKvU74vGfzIvRZfB5b\/Pe9f+Pe8f6E060G2F8ztsXdrbpEUKwiAYV0K4S2ZIgfgsujIG41G\/yMWi\/VEo9H\/Rw7Ik8fU1JQnFm\/YFZmamuqOxWL7Y7HYUzFZTf5zDUUSARBNuQQRuFtzvvbkDgnwf1sCcLeef+3DyyUCsHhBvAqQ8ADc6+e\/ITdOAJ7evown61YwYVvFU\/UGnq6vwF+xGL9qMY3aFBqVKTSqF9OoWIomP5MthflsUeRTrCxAVVSAongTiuJCFMUKFMVKlMUqlMVFqLYUo9pSTNGWYoqKi6msNOByuVi8ZAmLUlJYlJLC4iVLcLlcVFYaKCqOHyu+pywuQlmsQlGsTJy7EEXxJlRFBRQrC9iiyGdLYT6a\/EwaFUvj16hMoVGbgl+1GH\/FYp6ur+CpegMTtlU8WbeCp7cv42nbUoKbFmM2myWdJpIcRfyzAD39\/f2Srrk1hB50JghAfLjddhx2Cy6XnXCzk0DAjsdjpjVsZ9i3BIdbyZV2Peea1bzfq8brVzIVfhiXT8mJgJYB\/\/20R3wM9LbS09NGV2crnZ2RBOjy4vF48SdyK0SjzUAggN\/vl0p0izV3uVxSB1SbzUZtba3kZSopKWHJkiV\/tfziO\/FjRXKoHafDjs1mweGwEww68XvsOJ1mwgEbA+4lWBxKLkUqmPCreadLjdOt5LrvYewOJcc8Wno999MS8tHT00pXZxsdHa20t0fwen14E\/L7fHMv\/2zr73Ta8bjsOB0WPG47rS1OAgEHPr+ZjjY7h0JL8PiVXO\/W82yrhk+GNDSHVbzS+jD+gJKJsJY94fvpavcxNNjKYF8bvb2tdHVFCAZ9krzf5fV3OOxYrRbsDjuBgBO3247dbsbvs9HjWILRpOBssILj7jLejpRhtiq54HwYi1XBqENLh\/N+wn4fnR2tdHbE17+1NSL1H\/h7r\/9c4+8539RqtdQETJ4LIEiA6AAn+gXIG38JgC8vH5qcM1BXVyd5BqqrqykvL0en07Ft2zaysrJwuVzU1dVJiyYldsmSvwTYv1WC6xYBEZ4I4WWQl6xKDlGqqamhvLwck8mEXq+XPAACAIuYXwEu5XG1ckUrV\/hygCoUr06nu80FL2Jy89KWEd4S77YqYuIFAZCfQ1jyHh\/ulZT9bBY\/+XUIy598v\/ya5QAgOflTDoDkQD35N5ADejkoEgDnTiBe7CsuLpbWTuxrDPmlmGc5IbDV22aEO4jrms0DMBvgl5MOuQcgmQAIi3hyuIx8CMv6XB17t+aWl8KcJQn4uWg0enFqauoHCYv68OTkZJcA5IkOvB4xEiE4jZOTk5FYLNYZi8WGhSVehOJMT09fH7MVzvA2iATgBAG4K3MKArBlbQryikBz8fz\/e+4q1j2YwuIkAvD973\/\/nj\/\/twjAck7WreQH9amcq0\/jGe8azjtWcb5+Bedty2hULKFRvYTB0tU0blqBbsNadHlZ1Cs28ER5DgrNVgoL16Eo34piiwJFuZpGs5VdmnKUGg2qRDnmIpUKt9vN4sUyArA4Xo2nSKWiqCjuNVBqNOzSlNNotqIoVyfOmZhDs5UnynOoV2xAl5eFbsNaGjetiF+begmNiiWcty2LX7tjFc9413CuPo0f1Kdysm4lT9uWSwSgpKREAg9CbwjwI7zYokmS0DdygCRPkrxFBERIkBWn04rHY8HhrGHcmcmN0EO8E1Fz2V\/IZZ+CCZ+GNzosfH5RwafhR7jgy6A55KWtJUhrS5BIJEhzyI\/X48Xt9kj6Tt6LR3jkhaVWALfkGO6amhrUarVUjGPZsmV\/V\/kFCIy\/t0rD4bBgtddwxJ7Bq76H+HFQzQV3IRdcCk66NNxotfLpeQUfBB7hnDuDoM9LSzhIJBykuTlIMOjH8x2X3263SSTA6bThdFpxuay43VZ8PgtuTw2nvJm80fIQ73eoudqs4FqzkvMhDW\/3W\/niWQU\/bS\/g2VAGrREvHW1B2tvi90C42S8ZQN1uN17vd0\/+O62\/3WbFYbdgttZwyJxBzJ3Jj\/1qzjoKOWtXcMym4bVmK5+cU\/Cu7xHOOePrH2kOEm5OrH\/Aj8d9d9Z\/rvH3nG9bt26VAL5YfHlegNyyLnIDBKBOTg4W+4TlrLa2lsrKyhlhPwqFAq1WS3V1NdnZ2RJwFzehuMlE1QfB9MQ1iP4DIr9gx44dEjkRxEQkqshzE8xmMyaTCYPBgNFoZOvWraxevXpWAJAcv5vs0p\/N4iaPw5W76+XWQHkOwGweAHm4gVD+wvI32xCfya2QySBA\/ncyAEgOBUomAEJ+cW75qxwEibAHufVUDpzkoQji9euuUW5hTf48OaxBxFsnk5FkwiKX\/f8nAF9PAEQIUCwWu5oIobmQqKkvAPn\/mZqaapuamtqZSNIVY+fU1FRbLBbrkQHxiURzryvRaPT5WCz2wukug0QA9jVsIrwlU4rHv5tziiRgkQNwJwJwt59\/1ZoHZvUAaLXae\/78N25YwmnrMp7evoIn61ZxuSGdc440nvFmcM6RyjnHSs7Vr0C7YSV7C5cR3LQc26Z1VOSuoWJDJg5lLrvL17K7PIvG8tXsVmejKC1EWapAuUWJcosIBYrH8qtUSlRKBSmrUyUCkLI6FZVSkcg1uHW8cosqfo5SBYrSQnars+NzlGexu3wtDmUuFRsyqchdg23TOoKblrO3cBnaDfFrPudYyTlHakKWNC43pPNk3Sqe3r6C09uX0VS4mOLi4hnWQ3nIg6iPLj4TsdECUNyeHGnFbrdhsZixWs2YTLXU1hqoqdVTU6vlkuMh3g0U8PF5Jbxnhk8m4OMJeM\/Gn84F+Nn5Qp71ZBLwe+LALxygORQgEIiHXLhdbikEVyRuulwuSW8KYGa1WmcAH2EFNZlMVFRUYDQaKSkpYcWKFX93+eMJ0mYslrj+r6o2UFWlp7pWy3nrQ7ztLeDDM0p4xwwfTcCHp+EdG3+eCPDJmUIuODPxejyEm4OEggGCwQB+vw+324PrOyy\/BHjtNqxWMzabGbO5FpPJgNGkx2jRctn1EB+EC\/jsvBJ+YoZPJ+LjIxv\/cyHAzy8quOzLJBTy0NYapCUSIBwOEAr6JND\/XZX\/m9bfUKXlrPkh3nIX8MEZBbxlhg8m4P3T8LaNP58J8PGZQs477u36zzX+nvOttLRUsvTLw3rMZjP19fUSARA\/rLDmm0wmTCYTtbW1mM1mydIvqgHV1NRgMBikikAqlYq1a9eydu1aqUFDTk6OBOp37NgxI8lYHuojCIAA+R6PRwox+rqSpSaTSVLe1dXVGI1GqTGZRqMhPT39NgAgtyIL4CiGsKIlJwnK3f1yi9ydAIAcgM5GAITiFgBAfl7xPhkYzGYZTAYMtnrbbRZAeTLynWKgZwtzSJZTgPLZgH8yUZAfe6dzyqubyOOaxRBrk\/wqrK\/yOeQVUb4NAchaef8M4C0q5sz1sXdjbnn1H1GaU+YBeH56evqHApAnkmqPTU1NHYjFYk9MTk7+n8nJyS4xEiD8iWg0+p40Sp8AACAASURBVB\/RaPT\/lQPxWCx2LRaLvSDAuAD\/oieA6EFwt+aUVwESTcFmIwD34vnP+5d4FaDv\/fPsHoB7+fwH85YyblzOuGklx82p\/FdjBmfr0zhbn8aTdas5W5\/KxYZMtLmp6HNTeSa4jqfdZgzrMmhSrKapfDXD5WsY1mQSLM2jSb2KQXUWA+XZ9PX20OTy0uRpoMnvj9fmVipRKQpvCwFSKQrjn6lUNPn98e+4vPT19jBQns2gOosm9SqCpXkMazIZLl9DU\/lqmhSrMazL4Gm3mWeC69DnpqLNjV\/z2frUhAxxef6rMYPj5lTGzSsZNy8jpFxCXl6epFPkYQ3xEocOCQA5nU4JTMym\/+JxxRYsFgsmk5Ha2hqqqiqoMOjQaEooKSkkJyeDU8YCfn8mAL88B78\/C1+cgU8m+MM5P1FXFi6XBa\/HTTDgIxTyEwz68ft9M0CO1+vFZrPNiNOerWTjbPqvtLSUiooKysrKWLVq1d9VfjFu6f8K9BU61GUlKJSFZGRkMG4o4KuTCfl\/dxZ+fgbeneBXE36ijiwcdgsetxu\/z0cw4CcQiMduxwHgd1t+qzU+TCYjRmN8\/auqdOh0JZSpC8nLzWDCXMAfzgbg5+fgj2fhF2fg0wl+d87PK54s3G4Lfr+bUNBHc7OfUMgvEcDvuvyzrX9FhY4yTQkqVWL9qwr41akAfHEOfnMWfnoGPpjgqwk\/U\/Ys7LL1D9yD9Z9r\/D3nm06nQ6\/XSyE8ggSIcB8xRK1\/8UOKmv9Go3HGD202m6mpqZlRDlStVqPRaDAYDBLIr6mpIScnRwLwohOxyEG4VQ4uPuQeCNGBWHgjxKsYgpCIsKNt27ZJZKSoqAiNRkNpaSmZmZkzwmDklm95CIAclCbHBAtAO5slMFkh63S62yrnfB0BSD6fiA0Wr3KrvHy+5KREOSCRAx7567a81TOs\/3LreTIBSAY6yWERydcsB\/DyvwU4ku8Xv5OYVwCv5N9UrEVyuIacaMhB2LfxAAjALK+jL6rlJAPre33s3ZpbkL9kApCenk4sFnshGo0+nwjLEVb5s9Fo9PTU1NR4LBY7HIvFRqLR6H8kAPrhqamp8Wg0ejpRz18A8avT09PXBRgXAPxKZKsU+iMIwN2aU14FSE4A5uL535D67QjAvXj+QwVL6dVpGTakcty4midNaQzXpvO4sZwnjWnsrUmjqGgTG9al0aJYSa9Wyz5NOocr0zloSGevJoM+rZr9ujXsLl+DQp3PztKVhEpX0KPJYldLC4+1t\/Poo23xnK5whHA4jLKwUCIAysLCeM5XOJ7z9eijbTzW3s6ulhZ6NFmESlews3QlCnU+u8vXsF+3hj6tmr2aDA4a4teyT5NOr1ZLi2IlG9bFr3lvTRpPGtN43FjOcG06T5rSOG5azXDlKnortrGzaAllZWVotVophEGe4ybPeXM4HFgslm+l\/+Lgvwq9Xk9ZmZqyshK0ujKqayuw2EzcdJfxh4kAb58p4U2vijc9Sl6zP4zdbsLpsOJyOfD7fQSDfgkEyS2wXq9XKrQh9KU8B08AMqH\/qqqqJC+8UqmkrKyM4uJi0tLS7or8NTUz5S9Vl6DRlmGorsBkMXHDWcavTgX48HQJb7hV\/x977\/fUVpalC3ZXVjoBC4xSUgEJ2LLBICOQLAkJSSCFFOcISS2FJIQsgXQBg4FEGmigDA0XSHCZMm7bN91pX9vtnExPVnbmzarOzuqu6oooQIrp6Bs9MRH3aZ7u67zM2\/wF8\/bNw9Ha3joWtrtugbqvORE7JM6PvffSOYf1rbXX+hb+z7QJ\/3v8IhLxCK5di0MqsvUSAFKEwr8X+UOhIAIBSX6XS7r\/Hm8\/giEB8VQE\/zLej\/\/vFzfwf\/2iD\/\/thhn\/bdKE\/zpyEamRCNLpOMYyKUzfkO4\/PQNjY\/9+5C97\/13F+x+N4L+m+vH\/yu7\/P1Xo\/lcaf1d8SyaTrHpcKBRiOQD8A0C8qpFIBOFwGKFQiDV6APhG4N\/lckEQBMRiMdjtdvT09LBqvMTFmk6nGQ0oefilOLdxlgNA2ebk5SdjRG4A0ApFOBxm4NDlcmFgYAADAwPwer3MAKCYcAJAcgAgZwDhQ1\/kCYFyjzcPcvljRxkANAfyXtN1cjDAJwfySYHllv95OkA6z+fzob29vQT089\/JAyr3zh\/V5KE25Jkk0M8zOfHGgDyhkcAM7SNaRd6TLwczvDeWNxR4sCYPA5InQJIBwDPjkLecb7xnvZLnHsfY9DvkAk2wX5DoQMX2amYAECCn0JzDw8NfFj3zXxcKhReHh4dfFkN1XhwcHHxVTOD9thh\/\/0OhUPgND8TJAFhLtOGeeAbz1irEuxQlBsBxjMmzAD3K2dl4lXj\/5QZAU90HMDWfg9PpPPH3\/9MHn+Lhg4d4MZbGb1dn8dVYGp89eoKHj5\/g2ePHePD4Ce4\/eYKnT57gyZMnuPfoEe49fIiHn36Kuw8eYO\/BA9y5f19qDx5g98ED3HvwABsb69jdu4OFhXnMz89jfj7HDIDcXA49nR04U1WNM1XV6OnsQG4uxwyA+XmJCW5hYR67e3ewsbGOe8W+73Dj7T14gLsPHuDhp5\/i3sOHuPfoEZ4U53r\/yRM8KMrw8PETfPboCb4qyvhiLI2HDx7i0wefIpVKweVywe12IxQKsRVwii+mGOiRkZG31n8E\/vr7+yEIXsTjQ+jrs6LbaMAVoxG3vC58OiTgZ6IHtwa92AwKWAsPIjMiJdGOj2UwOXkds7PS\/ZM8oC9jmgmMyQEQeWhJ\/4miiP7+fjidTjidTng8HgaA9Ho99Hr9scvv9XoxNFQq\/7bHhf8UFXBL9OCTQS82AgJWg4NIp64hde0axopMM\/T8\/nuWXxAk+e12KwwmA0xWI34muPBpQsDPAh7cCnrxSUjAengQk2PXkB65hvHx0\/t\/Uve\/0vi74psoihgYGIDb7YbT6WQPAsXlE6tOJBJhIT504ynOPxqNlliF1CclGFOIj9PpREtLC6N8pBwAsuoosZg3APgaAlR9Lh6Pw2azIZlMsnoDsViMPaA2m43NgZq8ErFWq4XBYHjFA8grf97jR541OTjmFbzck80raAKpRxWr4lmA6Bo+DKBcLDAPAuTeQhpT7s1vb28vocHkQ4HIACCwwoPwcsmQcrBNY9\/7dK8kdEEOXOShDSQHbxwQgOH75b2bco9sOYOEX1HhedhfZwD42stz75cD1id57nGNXW4FQG4AFAqF3xUB9W\/y+fyvi7H1f1soFH5VLLT1XdHz\/qui1\/6HInj\/Ld+HfAVg3lrF2H8IjB\/XmOVYgOTvwEm9\/zrOAKj68assQCf5\/udmZzA\/N4vF7CyWcnNYzs1hOZvFzWwWN+dyWJnJYWUqhzthL+6EBNwJiVjNLuP23h5rt+7cwc7uLlaWl3FzcRHLC4tYWlhAdm+pFPwXDYAXQgMsmhq2AmDR1OCF0MAMAN4IyO4tYWlhAcsLi7i5uIiV5WXs7O7i1p07JXNYzS7jTkiU5hj2YmVKmvvNuRxuZrNYzmaxnJvDUm4Oi9lZLMzNIjc7A0EQ0NfXh\/7+ftjtdrhcLgaEbty4wVhFIpEIC3F4k\/4TBKEIOuy4ceOGFNKaTqPf1Y+GhkZsul34pyEPbgleHIxH8C+TEQxFwxJ7zrVrGBuTANDs7DQLgUin0yX6r7e3F6lUCsFgENeuXSuGHkn6r7e3l5uD1AYHBxGJRFiNnubmZuj1+mOV325\/KX8mnYazv1T+bcGLg7EI\/uV6Uf740CsAkOgb\/z3KX3L\/M2n0u\/uhVjfiE48L\/xT34JboRX48gv9jMoJoJIxriaFXDMD\/We7\/mPz+R\/9t3P9K4++Kb8SM43A44HQ62WcgEEAwGEQoFML09DSCwSCCwSAEQWAxVaIoMiUTCARY0q\/D4YDJZIIgCJicnITP50M8Hkcmk4HJZEJzczNaWloYCxAl9FIMfzKZLAkBogx1yuSmYmPk9U8mk4hGo\/D7\/fD5fHC73axqMJ8fkEq9rETc3t4Oo9HIFCGFwPAAgAe3PJAkBc2HqsiVsDw84HUGAF8HgAcTW7sbDEzLucF5UCAHyeW8ljRfWv6Xg5+UofwKwOsSf3mgwoMPPjwhkUyUBf\/yRueSEbC7u8tkk8dhy2Xkf\/Ny86VwI\/kKQMrQwAAy3wggyz8ree5xjc2vAMhzAP752Sh+2Iuy9sWqiEc5Ox7l7Pgh58CjnP2tzvlhL4pHOTs7Rgm589YqrCXasCm2IWtrxd5ED37Yi+Kfn42W9Mv3Se2LVVHanzDg6wkL9iZ62H7KLZA3PgSIqEcr8f53ygwAvg7ASb\/\/LrcfVocDghCAKASwIvqxKvggCiLWBQHrghcbghcbohebooANUcCGT8SGz\/eyiSLWi+eveb1Y8Xhx0+PF4sI8FubnEV3IIpeTeLuzc1l8NalBvaGdGQD1hnZ8NalBdi5bpH\/OIrqQxcL8PBYX5nHTI\/W55vUW5yRiQ5TNwSdiQxSKc5TmvC5I54uCiFXBhxXRD58YgF8MYMDlRtAn6RK73Q6r1Qq73Y6+vj7Y7fYS\/Tc7O8v0n9frZfqPdKEoikz\/iaKIvr4+GAwGeL1e3LhxA6IoIh6PY3IsA3OvFSZrH35zPYJtr4D\/\/r\/24yAdRTQSQmJoCIl4HKlr11gIBJFgUAw26T+Xy8W8npSzNzg4yPLb0uk0gsFgSXz0yMgIu1ar1aK7u\/tE5b8uk\/8Tj4D\/\/vyl\/HGZ\/DwJyP8M8k+OZSSGq74+\/GZSdv\/DISTiEj\/96f0\/uftfafxd8c3tdsNut2NgYAA2mw02mw0ejwdOp5N58ZPJJNxuN3w+H0RRfKX5fD54vV6IogiPxwOdTsfAP4X\/uFwuOJ1Otqyk1Wqh1WpLKg0TV2symWTef94AGB4eRjAYZN5pyhmgECC\/3w+Px4NIJMKSV6hGgLwSsd1uh8lkKgHCfAIgrzjJyJF71OTL\/3x4gBww8wBAXgmYDADyvvPhNHzMr3yJn5p8Prznm77T+HwIAA+Gs7bWEgpP3vspD32gvJDp6WlG4cnmtrzAvtN+fgVgd3eXtXuf7jGAw68u3Pt0r8TDyYMikkW+6lDO6y8PfyhnAHQ3ncOf6X7yVuC7kuce19hyA4B+F2LmWUu0sU9qo04VUoaGkmOvO4cahd1Qi3cpSo4d1Shen+971Kl6hcqWmIXok2\/Ul+1CNVsBkK8CnNT7b26pL6kETAbA1atXT\/z9H4tEsSiImI7Fsba6im++\/gpf\/+IrPHryFJvCpSKILgJqUcC6KGLN58NiMIgXX73Ai6++xMOHj7AUCGBNELAmCFj1erHi9WJpYQELC\/OILsxhdm6OMwDUMLa3oaqmBlU1NTC2t+GrSTUzAGbn5hBdmMPCwjyWFhaw4vVi1etl\/S8FAnj48BFefPUlXnz1AovBINZ8PqyLItZFgQP\/XmwKl\/DoyVN8\/Yuv8M3XX2FtdRXTsTgW\/QFMxeJwuVwwm81wOp3o7e1Fb28vSCeSF5PCJCiPTN5I7wmCALfbjcuXLzPwMzQ0BKvVKnlYnU58PJ6BsdeKX1+PYtsj4P95fgPrwiBWBgNIDA0hGAgide0a837yAIhy59xut3SvGfWiFAIxODgIt9uNSCSCGzdulHCkkxfV6\/XC7XYzUoRKyv+J+6X8P+Xkv\/aOyM\/uv1h6\/98V+f8t3P9K4++KbwT6TCYTjEYjjEYjLBYLDAYDHA4HIpEInE4nvF4v7HZ7yUoBfacwG6vVis7OTnR2dsLr9SISiTCjgqq0ajQa9PT0oLOzE1qtFoIglHj\/Q6EQowEtZwAQ1Sif9JHJZNgxSmSem5sroTelomD0sLpcLmg0mpI4eB4A8KEmPM0kDz7l4SdywCkPVbFarWUNAPK4EvimsJnd3d0jQwDKxQHzyp+fPw9ieADAswDxBkC5cBpejnIgu2x4QtEYkHv75V7Ne5\/ulYQDyYsg8fvLrTZsbGy8kpQpvx+JZKLEAOCTgHmwXM5LTiE1lT73OMbmDQA+KZ1n51lLtDEvOv+dwPmbziHgTfkFBNLlRgOdK+\/rqHF4EC9\/n\/gqw3ySMU8DKi+Gd1Lvv7mlHk2cAUAhQFevXj3x938sHMGC6MOiz4clnw9L2Sxu3XuKzc0trAlC0eMutTVRwKpPxIrfh5WAH8uzWezcfYLt3T2s+XxYE8WXRoDgxcryEhYXFoohQC9XAL4MqmFTK5gBYFMr8GVQXbICMD+fw+LCAlaWl7AqvAT\/a0UDZHt3Dzt3n2B5NouVgB8rfh9WfSLWRNmcBQGbm1u4de8plrJZLPl8WPT7seAPYDoag8lkgslkQnd3N2smkwl6vR59fX2IRCKw2+0shJA8pH19few7hRkQs11bWxtzRBGoMvf24uLFi1AoFDCYevHXcQHbbgH\/99NZ9PU7MS5WIR6NIhgIYGxs7EgARDqOijZdu3aN0WIT\/WEmk0Eul2P87aQDh4aGGEjr7+\/HuXPnKib\/03dQ\/ra20\/v\/b+3+Vxp\/V3zT6\/Ww2WwSRZvZzB4IegjMZjN6enrQ09MjFXKxWF4pvkT7e3p6YDab0dXVBb1ej4GBAbhcLpaIazQamTGg0+mg1WrR1dXFADp58ynxmDz3MzMzLI+AVgx4I4BqFvDnUNIwJQYTLRStEni9XrS1vaQBpBAAPgmQV\/Ryb\/hRXkA+BliugOUGAAEV3gCQJ\/zJAa\/cO8jv572PFKrAhzPwLCBHGQDlgAv\/e\/C\/izwJkebFA3M+8Vfe5MwmfP4ArQLwn3JPqLxYEoGecgYJFR4rZwDwnvKjQmp40FyJc49rbB4g2y5Us0Rg4uUnIC0H69Te5hzek09GABkC\/DU84JevCpAxwZ9LNQRoVaDcyhrt542FRzl7yTkn\/f6TAVD9\/qsGwEm\/\/2OhMBZ8PixMT8NkdyDgEzEdj0P0CViZW8DK3AK2gxKwXhVFrPh8mA8GcTMQQDQYxHQ4jGgggDW\/D2tFAL4mCNiKClhZXsbS4iIW5ueL8f9Z5LJZfO5Xw6quQVVNNapqqmFV1+Bzv5odz+VyWJifx1Ix5n8rSuBfkMbw+xANBKSxi3OZDwax4vNhVZTmsB0U2fxFn4DpeBwBnwiT3YmF6WnJAIhEodPp0Nvby5xfRA5hMBig0+lgNBpx5coVXLlyhelF0pVynXnlyhUYjUZ0dHRAp9PB6XSiv7+fJSIaDAb02u3oNpqgN\/Xi+7E4fsgk0NbWivGRESTicVxLJFjiJXkuP\/744xKKbvJ48pVbecY+yqOjsFmJolLSf+Ql9Xg8OH\/+\/Kn8p\/K\/0\/JXGn9XfGtvb4fJZILNZmMgnbzzBNCJuYcyp+l7T08PjEYjenp62H6TyQS73Q6dTge9Xg9RFOF2uxkFE5176dIlaLVauN1uZqERcKc6AHzZaZ7vn+f6p5wBAv98NWI5M1AwGGQZ716vF5cuXXoFAPAgQK7E5a2cF5xXyvLryxkA1IgFiL9ODpZ50MwDZ\/rOz4sHMDxfOSUByhvlAMjl4g0AHvBEo9FXkhyP+h3k4T+8h58H\/nIDgPogFiD5b8uHP8i9sPx5BJDkdRjsF1QlwFhOufm6z0qe+8fsjwfnci897+WnJi9g9zbnyFs5oC4H6bzXnhof\/sNXEaZ4fqqwLQ\/\/oXHfxgA4ifff3HKOGQBEA0osQCf9\/ouCD\/M+H+b9PswMD0NvsqKjQw+DxY41n4DNtTUp7EcUmQEwFwphJxyAQqEotlpsB\/1Y5VYBVgUBKzdvSgbAwgLmmREgGQI9uk5UVVehqroKPbrOIvinBOB5LCwsSAbAzZtY5bz\/qz4ftoN+KBS1bPydcABzoRBnAIhYF0Vsrq1hzSfAYLGjo0MPvcmKmeFhzPt9mPf7EfT70draKgGT3l44nU50d3ejra0Nzc3NaG5uRkdHBzo6OtDd3Q2dTgedTse+X7lyBd3d3bhy5QrbT3lUly9fZqGwLpdLoiE2GnGlWw+t9jx+5vbgl5kh\/NNfTeNpIoLxdBqpawnGvDc+Ps4a8bBTPDPPdU4OMNKbBIr4c3hu9v7+fjaf1tbWU\/lP5X+n5a80\/q741tLSgtbWVnaju7q60NHRgfb2dmm5WKdjxy5cuAClUon6+no0NzdDqVRCpVJBp9Ox8+mham1thVarxaVLl9iyUFtbGxobGxn412q1GBsbgyiK7AZSZV++kVefv6l85WEyDMji46v\/0qfPJ1UkttlscLlczADgAYm8CJBcycvjc+UMHHwIQLljfA4ATwM6ZmlhLEByMCFP\/isHbsvt50E5z4VfjgGIDAA+BIk3APjv\/HE+bl8+Z96DyYf6yMN\/+P3T09PsO88kxOcSyD2s8t9cXnOAn6vP5ytrAJTzoMv\/lgPpSp37x+5PvgJAjEBZWyujy5R73lfdrWz\/25zDU27KwfmbjAAevPOx\/PyYvDHwuv7pXecNgEq8\/+aW+hIa0Isf1jAWoJN+\/71eETlRxEwigZlUCm1tZrS3W3A3JWIv4cOzsRi21tYQ8PmQjYSl734fJorL9XV19QgHApgNh7G+tob5YrXN1ZWVogGwJBkAuXnM53KYz+Ywn81CZexCVdUZVFWdgcrYhflsVjqWy2E+RwbAkmQArKxAEATMRyJYX1vDbDiMcHHsYCCAiWgUAb8PW2tryEbCCPik78\/GYthL+HA3JaK93YK2NjNmUinMJBLI+Xzwiz40NDSgsbERWq0WFy9eREdHBy5evMj00+XLl3Hx4kVcvHgRH330Ec6ePYvq6mpoNBqcPXsWCoUCly9fZuc3Njay1tzcjNbWVpw\/f541pfIctNpWPI4IeBwV8b9F+rA2KOB6kSklI3N+UQEoSmS8du2arPpqggEjSpTkq5\/SpyiK8Hq96O3tRX9\/PwNAp\/Kfyv8uy19p\/F3xrbW1FTqdDjabjQFlStyNRCIQRZGF9+h0OrS1teHSpUvo7OzEpUuXGMDv6OhAMBjEzMwMpqenGSUTUYcGg0GYTCYYDAZ0dXVBq9XiwoULGB4eLjEA+GUcWhUgq488+jz9VCwWw9zcHDsejUZZxjq1QCDAEpXdbjdb8ejs7ETK8FIZtre3lwUA8thyipOXgwACnPw+ftn+KAOApwE9SqnLgQXviSwHCORzJwDwuhUAvjAXD3jkwOJ1Xs+3Yfzhk3zlIT+0CkB\/0zgMBC0vYGp28pV58PORA6\/p6Wmk02lmAMhpQHlgzCfMvgmAn+S5xzU2AWWiAaUQIKKFJcpeavS3wWBgxdUooYo86Px3+d8+nw+5QBMLM5KDdf58g8FQAl7llXn5\/qnRfn6f1WrFo4SBjfHFqlhiYJz0+29uOVe2EJjcADiJ999stcJgtuCC9hK02jZotQa0tXVA12OB3mRDJpHGzUAAFqcTFqcTN30iTHY7jFYrGhuboNE0QKORQMRNUYTBbofJ4cRNrxc3l5exuLCIpcXFEvC\/kM2iy9CDM2fO4MyZM+gy9GAhmy0xApYWF7G4IBUEu+n1wuRwwmC346YoorGxkRu3CUarFSa7HTd94st5BgLIJNLQm2zQ9VjQ1tYBrdYArbYdWm0beixWmG12NDY2oq2tDb29vUzfUeJipGjMUHjD5cuXcf78ebS2tqKtrY05us6fP4+LFy8iGAzi448\/xuzsLNN\/RJ0YDAZhMBrRbTLiirEb85463BLc+KvoIC5fbsP19IgEgLhqrLTyPTIywryacv03NDSEXC7Hjh+l\/\/jcN\/L4kkPuVP5T+d9V+SuNvyu+dXZ2stAdivUv1\/R6PYvt1+v16OzsZGFAwWAQS0tL2N7exurqKtbW1nD79m1sbGywfcvLyyycx+VyQa\/Xo7W1lWVm84w+6XSaFf8aGxtjsfzk2acHlSrQ8YXAwuEwBEFgBSr4\/IBkMgmfz4eBgQF4PB60tLQwAMCHAMjZQHgvGsXy8hVs5cBYHiJAy\/ByGlDeCDiqDoAc1Mr3HeWp5EETPz4lAfKJgLYLksdXTkNaLuxhcfElu09JGM\/yAhaXF0poPN\/G2\/\/5i8dlvZ28p58YhzY2NjA1O1kW4B9lAPD3j0KA+HCUtwXf\/xqgflznHsfYPADnQ4DsF14W5To8PPzHfD7\/28PDw78v8u3\/qsjB\/22x+u7fHB4eflMoFP7L4eHhL\/P5\/PdF7v6yvPxkAFCYEe+pP64xN8U2VvmXVgB4A+Ak33+qA\/D+e3\/6xjoAx\/3+Z2dmStv0DLJTM5hKpzE3OYXJZBJTySTujNfjzkQ97gfNWMzNY2NlBRtra9hYX8fG2hrWVlYY\/\/9SEfQvLy1hfn6hWPwri3vhFqwKLqy6bNBzBoDe0INVlw2rggv3wi3IzUnhQPPzC1heWsLS4qLUZ7EewJps7I2VFSzm5nE\/aMadiXrcGa\/HVDKJyWQSc5NTmEqnkZ0qyiaT9+LFiyx0gWKdyzVaCacwiLa2NhYGEQwGsbKygt3dXWxsbGBzcxN3797F9vY227e6uorr4+OYzGTQ73HhvleLW143tr1uGHqtSCUk+kMCPlT8aHx8vGRlm\/jOBUFg+o8vhBQOh+H1epn+4+OjU6kURFFk9X4aGhpO5T+V\/52Wv9L4u+JbV1cXenp6GOsPMfCk02k4HA4YjUY4HA6srKxgZWUFOzs7WF1dxerqKnZ2drC2tobV1VVsbW1hZWUFMzMzWF1dxfb2NtbX15HNZrGyssLAv9frRSwWg9lsRn19PUZHR5ly4gE90XZShjcfzkNFJ\/jk3rGxMcTj8ZIKddTH6Ogou44YjOx2O1paWsrygNOnPOmVT7SjarXlPHO8subjcNvb218xAPgVAV5hy5l2+PH58fgkPwrT4WkMiX2JZDrKAOBDgAj8y8MJePAhT+7l9\/Mx\/+XYf\/gVAH6\/PK65nLdTHoN9VDiQ\/F4QsJPnYMgTZt8ErCt57nGMTYYQhQDpGusw6lQxA0BWjOtXfEXeQqHweT6f\/+t8Pv\/Xh4eHz\/P5\/BdUmbdYqOv734gKRwAAIABJREFUw8PDv5cD8r2gjhkaxD5EgPzYxizmKhANKJ8gfNLvf+dPXhoAZ957SQPqdDpP\/P3PzcxgcnQCM+kpLMzMYGFmBncmGzGdHEU8EsZUIim1ZAq56RkszM5hOjmOm\/MLWFlcwlwshTWfH2tCA24WQfri\/AIW5otx\/9kcpidmMTU2g7VwEA9CjViYnYVBr8f7VVV4v6oKBr0eC7OzeBBqxFo4iKmxGUxPzBaNgHkszEt9Li0s4ObCItaEBqz5\/JiLpbCyuISb8wuYTo5jYXYOuekZTCVTbN7xSBjTyVHcmWxk8s2kpzCTmUJuZgZtbW24fPkyrly5gr6+PsZAkslk0NfXh+7ubvT19WF9fR3r6+v4+c9\/zv4\/\/fznP8fm5iY2Njbws5\/9DOvr6\/j4448Zg9Mnn3yC+fl5rK+v4\/r4OMbHxuD1ehCPRPDXohk63WXcD3tgMPei39WPUCjEQAvRFo6Pj+PatWsl4Qyk\/\/jkxvHx8Vf0H\/WRTqfZdcTgYrVa0dDQcCr\/qfzvtPyVxt8V39LpNObn59lNp8IQ6XQagUCA0XjG43EWk0XUm5lMhlleFLs\/NzeHqakprK6usrj9WCyG4eFhBsCjUamQRE1NDVKpFOx2OywWC8soD4VCSKVSiEQizLtP4J8eEp4OlOYWDAaZURAMBktYgKgKMDESUVViHgBQCAB5i3lKQF4B8wl1PGvO9PQ0gjPBV4AoDxrK0YCSIUCKm+cb5wEEX3SIBx48MOA9iPxcSRaSt5wBQGO+yfP4iqe+SPcpL1JEBgB5\/ct5+1+XFyBfBaBG90Qe8y8HYfJ7wP\/+R7EA\/ZnuJ2UTZglEV\/rcP3Z\/8hUAXWMdsrZW2C+oQECc88D\/TaFQeJHP5\/\/64ODgrw4ODu7l8\/k7BwcHPy9+3svn858Vj39V9NZ\/n8\/nf80DcgrHoZh+nor0uMak4mNEA1quENhJvf\/mlnMldQBUNWdKVgBO8v2vqalDTU09FAol6uvVaGxsQnNLE1pbm9Ha2oTm1gY0tqqhVNajrr4emmYN6uvVaGhshFLZAI2mESpVA9QNGqgb1VAqlVCq6qFpUSKXyyGbzWJychoTmWk40hPITs9gfmYWTlUN3q+uxvvV1XCqajA\/M4vs9Awc6QlMZKYxOTldpATNQdMi9alUKqFuVEPdoIFKJY2tVDagobER9fVqaJo1qKuvh1JZj8ZWNZpbG9DaKsnS3NKExsYm1NeroVAoUVVVjzNnapFISP\/vZmdnMTY2hkAgAKvVynQh0RjG43GWlEjUg2NjYywmmVarc7kcW62kuOWhoSEkEgmEQyH02fsQj0Rg7O3F\/bAb3SYzDCYzug0GRsMYCoUwMjLCVrATiQQDP7z+IyYUmlswGGSgiIpg8l5Toj8kfveGhoZT+U\/lf6flrzT+rvg2MTGByclJeL3eEk5\/j8eDyclJBINBOBwOFqbDJ2DQTSDqzqmpKeZ1n56eZnH5dCNCoRCcTicikQh8Ph\/OnDnDjAKbzcaKc5HBYbfbEY\/HIQgCAoEAo\/GUxwL7\/X5Eo9GSY2R4EOWT2+2Gy+ViBo3T6URra+uRAICPBeaX\/3lFTN5COfuGfEmeFDgBgHKMKGQA8BSbvLeb5lMuzICOy0MAqC+av9VqZYBfXguADADqh0\/+nZ6efgWglzMAKARIHgb0+YvHePjwYVmgz68A8I2MB4r5p9AfSgwmwCNPkvwfNQB4AP0mYF2Jc\/\/Y\/fE5APQu0ApAPp\/\/LXnhi0D884ODg7\/K5\/N39vf3t\/L5\/F\/k8\/mf7u\/vLxfbaqFQ2Mzn83eKoPwLAuSFQuEfiuD+dzylp3wF4LjHpBUA\/t076fffpa3H+XMvaUD5FYCTfv8nDHXY8miwLWiwIzZgx9eIHX8jtv2NWAsEsOIPYMunwpypHrPmemwJamyJDdjyNWLL1yR9ig1YFzxY9Xqw7lIiZ6qD+kI9Y\/6ZmJrG+PgUxjOTeBLV4GlYCX+zAmfqqnGmrhr+ZgWehpV4EtVgPDOJ8fEpTExNM0Yg9YV65Ex1WHcppTEET9k5bAlqzJrrMWeqx5ZPhRV\/AGuBALb9kkw7vkbsiA3YFtXY8qowba0rVly9UVL8iEIEbty4gWAwiL6+PqZT5PqPChGR55S8jrOzsywumZITQyGpr6FIGMZeMz5x9WMyFCzSJ5pgtVrR3d0Ns9mMeDwOq9WKeDwOr9fL9B9VO3W73awNDg4iGo2WHCPgRax3LpcL\/f39DNDZ7VL+w6n8p\/K\/y\/JXGn9XfJNX2RVFkVXjJT7+VCqFgYEBllRRzhIbHR1lcVbksaflGfLeU+xWOByG2+1GVVUVq0DscrlgsViYAUCxWqIowm63w263s5trt9tZPQGr1QqbzcYKPPAhPlTemihOqVCZw+GAKIrQ6\/UlrBj8Ujmv+HlAwC+xE0guFyIg9\/6RB1BO\/8knAcvBxFHhL3SMD8vhvYZ8aIDcCyj3APLhMHwVYHkYgjy8p4S\/n4v\/588h8P\/5i8evsPscZQjc+3SvhC6UlhPJEOCTHOk+lQv94T2pJA8BMDkLkJwzX6s6+4q3fFhfvmbASZ57HGPzgJCejbVEG60A\/H0ZIP6zfD7\/F4eHhwuHh4ez+\/v7Nw4PD6eKn7OHh4cL+\/v7q\/v7+7cKhcJDGSD\/TaFQ+N2jnL2E1pNn\/zmuMSnXgOST18I4yfffpT3HDAA+CZgKgZ3k+z9hqMNttwa7ggY61yXs+htw29+AnYCArYCI9YBE\/Zk1KzFrVmJbVGPb3wCdow07\/ibs+Bux5RvApujGuteDFbcHWXM9Zo11WFhaxOrNmxhenEY2O4e52Vk8jarxLKJEoKkWVdU1qKquQaCpFs8iSjyNqjE3O4tsdg7Di9NYvXkTC0uLmDXWIWuux4rbg3WvB5uiG1u+AQnU+5ugc7Rh2y8B+1mzElmzEis+H9YDIrYCInYCAm77G7Drb0Cn6xJ2RTVuCypMWepYkUmqMioIAluBJj7ykZEROJ3OI\/XftWvXkC4mMFLBIj48gbyX0eIqdCQcwmZ\/P7pNJnQbjTAYjbA77TAajeju7kZvby8EQYDdbocgCEzPEaWi1WqViisVedh7e3vh9XrhcrlKQhzMZjM7ly\/U1NfXB0EQoNPpTuU\/lf+dlr\/S+LviWyaTYWE2gUCAJU9QMm4mk8HExASSySTcbjcCgQACgQC8Xi97CHiKTvL6JxIJhMNhdg71zYN3hUIBh8PBgD9fjZgYPOhvMgyojDMVHKMaBTabTUqyK\/Yvb1R8TKPRlNQj4L2APNMJv8IgbwQS5Mvt5TyF8uRBKrqVtbVizNLyCgsQv5TPA1m5R5H\/W34+7xXkPZnkAeRjgEl23gCgpFuKnUun05iancTW7gYePnxYUuGXDIPd3d2SUBzy\/j98+LCk8QZAOp1+xVgot1JwlMzyRMdyv0k0+rKY2b\/GAJB7y18HrE\/q3OMYmwfhRKVJBkAxDOfbQqHwggPiPy0UCtlCoTC5v78\/kc\/n\/wO13\/\/+9+P5fP76wcHBXD6f\/2k+n\/9ZMWznq2Ki7q\/z+fxvyQAoRw96XGPKKwfL6xGc5Pv\/Zx1qtH9YjZr3X2UBOun3P91zAc\/DajwLq\/Aw+LI9D6vwMKzClxEVXkRUEC6pcMunwjcxFb6La\/DdcAO+n2rFN7EG3Ato8EVIjT2fCjmPEv52JWZM9dhYW8P66iqGl2cQX5zGZ9EGfJlS48uEEmJ9LapralBdUwOxvhZfJpT4MqXGZ9EGxBenMbw8g\/XVVWysrWHGVA9\/uxI5jxJ7PhW+CKlxL6DBNzFpDt8NN+C7uAbfxKQ5CpekOX8ZkWR4LpPtWViJ5xElJs0NjGkkkUiU6D8qJjQ2NsacYC6Xi+k\/j8fDdBtPUUhez2vXrpXVf71WK0xmMwwmEzbsfRJ\/Ohf+QI3INuhvYi5xuVwwm82s4BJxtPf29jLdSF5OvpnNZly+fBnnzp1jCZ86ne5U\/lP532n5K42\/K74RO874+DgikQjz2JNHn9rExAQLtyFOVaJYoqUh8vqTx9\/v9yMQCMDv98Pv98Pr9ZbE+iuVSlY4jK8sZzAYGEjnq81RiJC8Yh0lKpOxQH+bzWa2pOV0OpkRQcXOurq6SjixSfnztIVy5c\/T6bFwozLKlo\/h5Zfg5fSf5QwA\/hoeQMi98zxA4K8p953mJg8BKJcESaCfwAVl8peE23Befx7s855+as+fP2fgXk75SbSfR60UPHz4ELu7u3j+\/PkrAIjk4j2w8jho+m3KJQHLaUApMfZ1wLqS5x7H2HxxrTIGwK8KhcLXxaTbO\/l8\/i\/29\/dz+Xz+ej6f\/w+Hh4cZeSsC8+uFQiFbDNe5c3h4+LwI6n\/I5\/O\/\/WJVLGsApAwNxzZmuYJlPPg\/yfff3FJ+BYAMgJN8\/yf0dXgSVuNZRIXHYSUehVV4FFbheUSFx1EVvoyq8CKqgtCmxqxZhW\/ianybUOO7pAbfT7fg72Za8SCgwRdhNe76VLjtUeGWW4U7ASW2NjawfHMJS0sLmJicwWaoEROdKijVSihqFVDU1EitVgGlWomJTpV0zuQMlpYWsHxzCVsbG7gTUOKWW+r7rk+FL8JqPAho8Hczrfh+ugXfJTX4NqHGN3FpjkKbGi+Kc38clWQhuR6HlXgWUeJJpB5TxlrGIX79+nWm\/4aGhpjzi9rk5CQLNxAEAR6Ph+k\/ikMmryd5PAcHBxEIBDA4OIjBwUF4PB6JCttohN5gwEZfH\/Td3egt0taS7tLr9Qyk8A4xorflARKBJErYpNbX1wej0chWz+12OwNRVOypo6PjVP5T+d9p+SuNvyu+pdNpDA8PI5fLseq5tPxDIT1kIASDQaZYiFvf7\/cz\/n1qoVAIsVgMPp+Phe1Q9TWLxcKsOKohQDeKwoFMJhNcLheMRiPcbjeGh4fZTbRYLMzjTwaB0+mEIAiseb1epvBcLheLAyPjgmoR6HS6V4pi8awZR4EA\/ph8iZ9XuDwIKOeBLlcHQB63Kw9B4I\/xv7k8L4LG5j2Wr1sB8OteJgFPT08zgP82bXd39xUvP4Xx0DEyInhmIAL6GxsbzIDY3d1lhgC\/4kCrEHxIEsktT1KWJ2ySAWAwGF7JwTgKLB+VXFvJc49jbDkgpu\/FHIDvyBO\/v7+\/dXh4uFAoFCYJiBcKhbS8yQD5fDFu\/7PDw8Nf5PP5vy0UCv8gXwHgC30d15i8ASAvOHbS7z+xAJWrA3DS7\/9kVx2eRtR4FlXiSUSJZ1EVnkRVeB5T42lUjS9ianwZ1UBs12A2oMbXcTW+SajxbUqNv5ttwaylDrcFDW4LGtz3azBjVWLaqsSOqML25iZ2b93G0tIi1tfWsL6ygtxcFmOZGdTWKlBbUyO1WgXGMjPIzWWxvrKC9bU1LC0tYvfWbWxvbmJHVGHaqsSMVYn7fg0bb9ZSh7+bbcG3KWlOX8fVmA2oIbZr8GVUgy+KMjyPqfEkqpJkiyjxLFqPp9F6TPXUMiKLP\/\/zP2cr2CMjIxgfH2chDQSQKERWFEXGLT44OMhY6nj9NzQ0BFEUWdhCf3+\/VIPGbIazvx8Go5EVx9R3d8NqtcLpdKK3txcGgwH9\/f3o7u6Gy+VCIpFgz5vJZGIeT\/Y\/zW6H1+tlzePxsPjo\/v5+Vv2UwJVer0dHRwcuX758Kv+p\/O+0\/JXG3xXfqNjW+Pg4S\/IlIyCVSjFvfjKZRCwWQygUgt\/vRyQSKTEI+KILfDIugX+6hixHr9fLHoD29nZQPQI+tIdAeldXFywWC6xWKywWC3Q6HTo7O1kzm81sP8X5d3Z2sgJnVqsVXV1dMJlMrD86Rw4ADAYDLEELK3j0JhDAe\/z4GGG5h46uK2cAUFKqfBzek8cDWvmYvGeSn0M5wFIuCbjcCgA\/d3nsMQPbXNw\/gXtq\/H5qz58\/xzfffMOAPt8WFxfx8OFDtlLAf9\/d3WUrEfIE33Lzovho\/nejfxby1ZdKg\/pKGwD8CgCtAuQCTbQC8G2hUPh8f3\/\/QTEGf3Z\/f3\/iKCDOA\/Lf\/\/7344eHh7NFD\/6Dw8PDLwuFwq8ODw\/\/Xu6Np3egGAJ0rGOWqzh80u8\/1QEgA4CSgK9evXri7\/+kro4B5CdRFZ7F1Hga0+B5vAGfxxvwONKANb8Dj0MNuO3T4LOQBjt+NXbs9Zg212LaXIsdez06ujSwOPS46YtgZ3MT21tb2N7awtbmJjY3NhglaHYui87ODqhVKtQqalCrqIFapUJnZweyjP9\/HpsbG9ji+tnZ3MRNXwQWhx4dXZpXxt\/xq\/FZSIPbPg0eh4pzjkgyPI834GlMg2dMTiWex+oxra9lTq7r16+zlWwCQSMjI8ybmUqlMDQ0hFAohMHBQab\/CBDx+o9PRiTwQ9e43W4Eg0F4PB5WPfXixYtoa2tDd3d3SWgDgZSOjg6YTCa2En758mWmO8mBRvspzpnoHSn8oaOjAwaDgfVH55zKfyr\/uyx\/pfF3xbfR0VEMDw8jmUyy6m1+v59V8I1GJf7UQCDAaDXD4TAzCOhm8uFBtDJA8WL8ygLFjwmCIFl\/ej1j6gmFQhAEoSQnwGw2Q6fTQRRF5s23Wq3w+\/0YHx9HMplkBkwqlcLExASWlpaYISLPWqdmNBrR3t5eFgAQWOQVp7zxypVXxnLPHb+\/3AoAXwhM3ne5PuSKXw5GyoEV\/jx5JVA+KZBkpth\/eZwxA9pFz\/9Rx8s1SuCVFw7jWzljggot8eNSUjCtDNBc5NSlcg8pGQB8DgYPiN8WWFfq3OMYey3RVmIQyVYA\/qbIt793cHBw8+DgYPrg4GDsbcB40WM\/tb+\/v3x4eLhX5O\/\/Lp\/P\/3pvoocZHrlAExt3LdF2rGPKjY2jDIDjfv\/5FQC+ENjVq1dP\/P13tzfieUyNx1E1Hsc0eBZvwERPMyZ7WjBpvIBJsxYDDj1ui02Ysmmw49Nge2MTWxubuL+3h611qejP3bt3sbW+jvlsFplECulkCunUKNLpDDJjYxgbnyi2Seg6ddCoNahVKFCrUECj1kDXqcPY+CQ7LzM2hnQ6I\/WRTCGTSGE+m8XW+jo3XnEOG5vY3tjEjk+DKZsGt8UmDDj0mDRrJRl6WjDR04xn8QY8jmmksKCYErFOJdLpNBKJBKOdDofDGBwcZBVMef1HbHbhcJgBomAwWMJGIggC84yS\/uM9q4FAAG63G16vF+fPn4dOp2Mr1KFQCF6vVwqT4MJbL1++DEEQmDfTbDZjcHAQ169fZ46669evY2RkBJOTk1hZWWFA7Cj9193dDa1Weyr\/qfzvtPyVxt8V3\/gE3nA4zJQLLfNQ\/D4l\/o6OjiKVSsHj8bCHhyxBj8cDr9fLzqf6ABMTE4welOLHLBYLs97C4TBWV1exsrKCpaUlpNNpdi3RQAWDQSwuLmJ5eRnLy8tYWlqSgOXUFMbGxrC8vMwKlRFwXF9fx9raGlZWVnDz5k3WKDu9paXlFY+YwW2AzqJjCYHycACeKeRNCrecAi5nAFAr59n717Y3eSx55V\/OAJBfI5\/T6+TlAbe88fkk8sYnHhPQ5z9LqD0540O+MiGnQOQ9oYlkgoUA8SsvlQb1lTYA5HHxuUATWwE4LjBOnPw0FhUiywWajtUA4FcAKN+hEu9\/p6bUAGiq+wBXm8+xHICTfP8nOuvxPK7Bis+DSWMrJgytuKBrwYThEpZENx7cvYudrS3cu3sX9+7exdbGRrEq76JU8Cs3j\/lsDrm5OWTn5pBKJJFKJJBMJDEcl0JL9+7cwd6dO0ilMzD0GNDcrIdG0\/DSANA0oLlZD0OPAal0hp2fy+UwHB9GsthnKpFEdm4Oubk5zGdzWMjNFwuESfPZ2thg89zZ2sKDu3exJLoxYbhUlKkVk6ZWrPi9eB7XYNpQV5LAGA6HmeeSqKcpfpkcV+l0GiMjI3C73chkMrh27RpjTyFHFp1P\/OiTk5OMHtHr9UqhECYTzp8\/j+7uboTDYaavVlZWkMlk2LXxeBwej7Rq\/tOf\/pQV4VxZWcHs7Cymp6cxPj6O1dVVVqjp3r172N7exieffILNzU2mB6mR\/mtoaDiV\/1T+d1r+SuPvim9E20mWHQF5An5+v7+E7YcAfTqdZnz\/CwsLWF1dxdzcHDMIQqEQJicn2bl0M+kBsFgsaGhogF6vZ8kn9CA5nU6kUik4HA5m4aXTaczMzLCscwpPIkMhnU5jamoK29vbJVWI5+bmMDMzg\/HxcYyNjcHn87Ewp8bGxhIvPIHCcjz99Dd5j6ltim14lDCwtim2lW3yPnWNdVI4QDEel4wC+s6PW25Mallba1laUf78lKEBYvurwJ9PguRXAMgDepQX9G28o\/K\/y3lG5Y1PaJQnN\/J86LxhQXHXrwNDPHjjf+vXGQD0XX6skucex9g8+CcvPEcD+k0xmfbuHwLG9\/f3b+Tz+Z8etQJAtQB4A+A4xyxnAFTi\/Te31KO26sc4896f4sc\/+lPUVf0YHZpamFuUJ\/7+j3VqsSM0YdkvYGI4hfHkKMZTady\/exdbm5vIzmWRTqSQm8tiPpvFfC7HPPAb6+sYTY0imUgiMZyQKrlHoohFYxiODyMWi+PWzg5uF5uvrR0mowmGHgPq6mqZAVBXVwtDjwEmowm+tnZ2\/q2dHcRicamvaAzRiEQlnRiWDIzR1Cg2uBWB+VwO89kscsU5Z+ey2NrcxP27dzGeSmM8OYqJ4RSW\/SJ2xCZMGtsYbSHpPwIybrebeTJ5thMCNJlMhvGdLy8vY2NjA7lcjgGiUCiEGzdusHMJ1Hg8Ul4akWDodLoS\/ef1emG32zEyMoK+vj4WipHJZPDxxx+zSqkUnkFAKZPJsDBJvgprLpfDxx9\/jOvXr2N8fByiKLIwjw8\/\/PBU\/lP532n5K42\/K75RCBA9APIVgFAoxH4wogSlinBTU1PIZDKIRqV\/zDMzM4w+kmLDeGrQWCyGQCDAEjIuXboErVaLcDjMkkd4C9TlcsHn80mKpZiHQAnKk5OTzACgB3N2dhbZbBYrKytspYLCmIaHh1khslgsBpvNhoaGhrKeeHmF3tedIwcN8uvlgIKoP8uN8Tbtdde9Tg6556\/cCsBRYP+osAieiUnOnPImI+GocIZyXlW54VHu3NeNxc\/xDzUA\/jUg\/LjP\/WP29zoDoFAo\/Jd8Pv\/F\/v7+g0KhsH5wcDD3tvH4xfNmi6w8\/6lQKLwoMvz8ww85B1KGBpAhQAbAWqLt2MaksfjwH6p4fNLvv0v7shLwmfd+BNVZqRKwpUV54u\/\/eMclzIxP4v6nn0rtwQPMTM9gdnYWo8kUUokkksMJRMIRRMIRjKZGkS16+6ORKNsfDocRDoUZjaAUQhpHOBxBMBhCR3s7REGA1WJBU1MzamtroVAooFAoUFtbi6amZlgtFoiCgI72dgSDIYTDEcRiLyu5l4xRHDcaibL5jKZG2f7ksLRiMJpMYXZ2FjPTM7j\/4AGTc2ZiCpPGDlakiHeA8R5Q0n9U\/ZS8mdevX8f09DTGxsaY\/vv4448xOzuLTCbDCCl4asShoSEEAgGW4Nja2orm5uYS\/Ud6z+v1or+\/H6IoMv2XSqVYguaNGzcYACKAlM1mMT8\/j\/X1deappTCORCKBUCgEu92OoaEh9Pb2QqlUnsp\/Kv87LX+l8XfFt3Q6jWAwiGQyyeK9QqEQa5QfMDY2hvHxcUxMTLAHYXJyksWL81542m+xWBCNRtmSSyqVYkW5zGYztFptybFwOFwyPv1N4J9WH8gIofCl0dFR5HI5Nr+ZmRnGbUv5B1IlOskA8Hg80Ol0aGxsfK3ylHviyjU5GJBTe77uOJ3zNgr\/bY0FHpTw1xzl\/ecNAHmV3HLeT\/I6vqnJvZSv85q+yXs6aapmn3yLdylY4\/sud29IDt4AoDoA\/xZAfSUNAD72n6cBPTw8\/GWRT\/\/RwcHB9sHBweLh4eHU6zzy5IkvFAqTh4eHC\/l8\/pNCofC4IFF7fl8oFH5DLEC8AbDqlu7fcY3JGwA0JuU6nPT7z1cCPvPej6CqOcNWAE76\/Z8en8BEMo1MYgyZRArRUASpRApzs7NYX1tDOBhGKCS1cCgsed+TKaQSKQn4h8IIFcF6MBhCMBgqegyj0nXBMO6nmnA\/4IDoEyAIXng9HqhUKmYAqFQqeD0eCIIXok\/A\/YAD91NNCBXHlvoKsf7D4Yg0ZkgyBFKJFJLJFBLDCWk+NN9gGOtra5ibnUWqKFsmkUImMYaJZBozk1NIp9MYHBxEKpUqq\/8oPnp8fBzXr1\/H5OQkAyA3btxgDjDeC0n7TSZTif4bGRlhRYmMRiOam5tLjr1O\/\/HeVwJhFL6RTqfx53\/+52x+H3\/8MUZGRhjwIg8vASC3243Lly\/jww8\/PJX\/VP53Wv5K4++Kb5lMhiV4UJIvT+tJXvZEIsESboPBIAPXwWCQXcOfk0qlGIc\/LSnR0g9x9CuVSnZT6SbHYjEkEgnEYjG2akBzoDH4VQUyUMjjTw8K9UHWLfXj9XoRiUTQ1dWFpqYm2C5Uv7UX8G09bn\/sVYFycyoH2P9Qr+C7LH999Y9QX\/0+NGfPlG311e8f2Y66pqn25Sd95\/vjjzXVnkHzuaqS8940Tn31+zj7wY\/ZMf7zbecoHf9RyTNAYSJkAOTz+e+pIm8+n\/\/LQqGwns\/n\/xcekMvbwcHBWEEq2JU7ODhYKxQKdwuFwucFjpP\/Uc7OVhoIjO9N9CBraz22Man2AIF+fvXrpJ9\/eR2Aix\/WoP\/COXja1Sf+\/F9oa4bRbMDYcArpeBIhIYigEEDQV2z+ICLhKIL+IIKBkAToP\/0Udx88wHBsGFuBdgQDQQT8AfiLLRAIIhAIIhKJIhqL4\/7eHu7v7SG3sAhB8ELweqBUqVCjUKBGoYBSpYLglQyA3MIiOz8aiyMSibL+WP\/+AIKBILYC7RiODeNu0bMfCoYRDIRK50xyCAGEhCDS8STGhlMwmg3QdTUjk8lAFEVGd0i6jvQfeRmvXbvXVFn4AAAgAElEQVTG9EswGGTggvQfFT+ic0ZGRhiHOZFX9Pf3w2AwMI7ys2fPIpPJ4MaNG4hGo8xjee3aNQwNDTGvKc2BxuC9qgTQyONJ3lDqg\/Qf9ePxeBCJRNDR0QG1Wn0q\/6n877T8lcbfFd+oAjABaDICQqEQW9ohS5D2+\/1+RKNRRvtElhoZBvSje73ekgJfxOxjMBjQ3NyM1tZWZDIZ+Hw+ZLPZkkxzqiVw1DxoqZmMlFgsxgyPZDLJrqdG1zscDvT09MBisaC5ufmVkJC3AQDlPH5HXfOm\/t5mTL9OAsny43IQ8Id4Bd91+WurfgxVzRmoas6gsfaDVxod4xsdaz33Ac6fkz6PuuZN\/b3NmI21H+CCsvqV4zT3o+bJX3\/+3Kv9f1jzHvOEUxjOqrsVexM9ZAD8Op\/Pf3dwcPBV0aO+u7+\/v0qAvFiBd4xaMQRnan9\/P1coFFYKhcIueeIpFOfw8PAfKQmYZwOiz+Ma81HOzowdMjZygaaKPP9EA\/r+e3\/KkoBNzefgadec+PM\/patDzj2AcWMb7DYTHHYzBhwWuJxW+Nw++Dw+BEQ\/fF4\/gmIAfjGI2alpzE1NIR6JY1vswLbYAZ\/og1hsQvHT5fZgbm4Ot7e3cXtnB9GuTjjtdjhsNihqa1FTU4OamhooamvhsNngtNsR7eqUcgC2tzE3NweX21PSpyj64BN9bNx4JI65qSnMTk3DLwYRFAPwef3SnD0++Nw+uJxWDDgscNrNsNtMGDe3I+f1YNpQi3g8DkEQGIDg9Q+vd6jYEdEgHqX\/6DyKd+aLU1IYol6vh0ajQWNjI8bGxiCKIubn5xEIBFhIBnGpHzUPXv8RuCHglUql2PXU6Pq+vj5cuXIFJpMJGo3mVP5T+d9p+SuNvyu+pdNplrFNjTzv9MPTjx0MBhkrEHH9U8IHLdnQMhJ\/g1KpFObm5jA6OopIJMIoGRUKBeLxOHw+H2KxGCs2Jl8B4Jem+HnQmHwFY\/pOFiytElDz+\/1wOp0wm81obW0t8QCWCxt5k\/fvqHCTciDhbcOC5OOTl7ycF1CeNPi6ecqPy1cA3kX51Yr3oFF8gOZzVbiorELzudKmUXzwajv7ATt+UVn+OvlxajTWUcflfWkUH+CisgptqprS\/Wc\/wLnq93Gu+v2SPjVnpfnRXPlx2PHiMbXiVQPgUcLADIBCofAPxRCab4uc+gTI\/+PBwcHiwcHBXDFJl9rcwcHBYqFQWOeA+Itica8f8vn8bwuFwu9+2IsyA4BYiCgp+LjG3JvoKWsAVOL5N7fUsxwAKgTWf+Ecol2aE3\/+p3S1+Dymxh1PEzJmLe64LiBpbcPtgQu4PdAKt9MGt9MOj9MBwe2D4PFB9PggekS4HBb4vAJErwDBK8Ara07XAARBQCwWRzQWg9DZCcErhQApFIqXBoBCIYUAeb0QOjsRLeYPCILUh7xfoTimzyvA5bBA9IgQPdLcBLcPHqcDbqcdbqcNtwdacXtAkumO64Iko6cJn8dUmDYoWLwyr\/\/I81hO\/xErCnGdv43+GxkZQS6XQzqdRiQSgSiK0Ov1eP\/99xGPxyGKIoaGhlixJbkHtJz+o+RMXv8R0OH1H79inkgkMDg4CLvdDqPRiMbGxlP5T+V\/p+WvNP6u+DY6OspoE3mPejweL+GA9fv9rMqaz+djVdfIAgyFQoz31ev1shvDrwhEo1FWmMtkMqG6upolDFMSSGkS2ct50MoDJanQUg5LDivOUxAEVnSMN2goDMhqtcJsNqOnpwc9PT0sFEAOQF+n9F93rJziH7O0lIS5HOVFfF3sejlgcJQH8G3BCR8T\/K7K31D7Hs4rq3FZ9bKdV1ajsbbqlXZe+eZj1Pj+dD9RQPcTRUnf5c7jxy\/XF7+vsbYKypozrK9yczmqP2oNte+9kgT89YSFDwH67eHh4d8TIC8m1T4+ODi4VygUdvb39\/\/j\/v7+KrUiCN\/J5\/N\/mc\/n\/zMPxAuFwm8KhcLvyACgpF85\/ehxjfn1hIU961QTgAyAk37+dZpaNL2lAXDcz79kAKjwOKTGmKkFYxYlRi0XkLJeQMqiRcZSh4y1FredaoxZ6zA2UA+hsxkuixEDViMG7EYMOE0YcFkw4LZhwOOB0+2Aw+WEy+OB3eGAx+NFT49eStx3e+Bxu6FWq1FdU4Pqmhqo1Wp43G7pmMdTPNcLu8MBl8cDh8sJp9uBAY9HGsNlkca0S3NwWYwQOpsxNlCPMWsdbjvVyFhrkbHUIWXRImW9gFHLBYxZlBgzt+BxWI3PY\/WYNiiQTqcZsxjvUZTrv8HBQXg8HsaOQiQE5fSfx+Nheoz3iEajUVaYyGAw4Ec\/+hEDYHL9x4c+0DHiWSfe9HL6z+v1sqJLPKCjMAiz2Qyj0YgrV67gypUrp\/Kfyv9Oy19p\/F3xzePxwOl0lvyYvEedlnYCgQCjBfX5fBBFkfH903VUDY4KiYXDYfbjk3fe7XZjYGAATqcTFosFo6OjbHzqgyw93iAJh8PMACAjhKw8Wt4hI4H64HMA6EFyuVzo6elBZ2cnenp6mBftD22vW3o\/anle11hXFvi+qS\/++nL0oW8bElCun3dVftXZM\/9D7aO66te2i6qzr+xTnT2DKz85+0p7U1\/89fLx+b\/LjXlUP0SFSYD4h5yDrwT8u3w+\/9tiWA555X+Rz+e\/ODg4eFIoFB4WCoX7+Xz+L4sA\/eHBwcGTfD7\/RZHPn4D4PxweHv4jbwCQx9+vayipB3BcYz5KGBjY54uQVeL5b6mvLskBIAPgbViA\/tjP\/1RXLT6PKfEkosKjkBpPwxrc8zbirrsB90U1xs11uONQY8JSi9tOFSac9RA7G+HrbEXc1IFhSwduDbThlqsNDrcRFo8LFq8bFo8HtgEbbA4brEWnj42axQKFQoHqmmpU11RDoVDAZrGw41arFVabdK1twAaLx1Ps0wWH24hbrjbcGmjDsKUDcVMHfJ2tEDsbMeGsl+ZoqcUdhzT3+6Iad90NuOdtxNOwBo9CajyJKPF5vA7TPTWw2+3o7e0tq\/+GhoZK9B\/RIoqiCEEQGN+5XP9RIaVwOMwAEHknXS4XnE4n7HY7TCYT0uk07Hb7a\/Uf9UUAiEBYOf03ODjI+uBjoEn\/9ff348qVK2hra8OVK1dO5T+V\/52Wv9L4u+KbzWaDy+VCKCRVYRMEAcFgkFl19J1vBMhpyYcsP37ZJ51Ol3jeCbzbbDbYbDY4nU5UVVUhlUrB7XYjHA6z8Sm8h8bmQ37sdjvsdjscDscrYJ8eGrL++BwAGt9kMrGy0B0dHSUFf8o1OdXlmxpPVymnxzQYDIyLnq9GywPg1\/Up\/\/42czmKspPauy7\/hx9++NrW0NBQ0hobG9HY2Fjynd\/X3NzMPml\/c3Mz+\/vDDz+ERvEB+lrOoa\/lHK5+VIeeRgV6GhVora9+pT+6nsanfsrNRT5XGpeul8+3sbHxFQNgf1UsMQAIkFNozuHh4S+LnvmvC4XCi8PDwy+LoTovDg4Oviom8H5bjL\/\/oVAo\/IYH4oVC4Xf\/\/GyUhf5QAvCjnJ1CgI5lTEo8lhsAlXj+W+qr0f5hNc6+\/x7OnnmPGQDmFuWJP\/9TXbX4PF6PJxElHodVeBpR47OQGp8F1XjoV+Guow57tlrcsdbijluJXacak04l\/J1NSJjakLS04bZLi9seLW55pbYjaLEtXIJbEGARRVjttpdzsVhgNZuhaGhAVXU1qqqroWhogNVslo7ReXYbLKIItyBgW7iEHeFl\/7c9Wtx2aZG0tCFhaoO\/swmTTmlud9xK3LHWYs9Wi7uOOjz0q\/BZUJLpaUSNx2EVnkQlA2BKXwODwQCn04lQKASPx8OKTr5O\/xEgeZ3+y2QyJZ5HAi+9vb3o7e2F3W7Hn\/zJn2BkZAQulwvhcJiNT+ENvP6jffT79PX1vQJ25PqPj4Gm8Q0GAy5evAi9Xo+LFy+eyn8q\/zstf2XR97+BzWw2My51u93OMrb56r9+v5\/dcI\/HA4fDgXA4DLfbDYfDwUKCKPQmGpWKNxHbj81mg9vthtVqRUdHB5xOJ9xuNxQKBRwOB2w2G7xeLxwOB1ve4T39Pp8PbrcbNpsNXV1dsFqtrGomzZG\/+R6PBzabDSSb1WqFy+WC2WxGW1sbU4789z+k8dVxyyl7+vT5fCX7dY11R8YH03V8cSx5Iay3nd\/rimLJ5\/muyv\/RRx\/h\/PnzaG1txfnz549s\/HH63tnZifb2dpw\/fx4fffQR64v+bm1tRVNTEzo7O9l1H330EX5S+wF0P6mF6aPSdkFZw\/ro7OxEZ2cnjFeN7NN41cjGe9N8z58\/XwJkj5LHr5OKRBEDUDkDoFAo\/K4IqH+Tz+d\/XYyt\/9tCofCrYqGt74qe918VvfY\/FMH7b\/k+5AYAFeOiZOBiHYBjGZMMAJKT5K7E899SLyV0l1sBOOnnf0pXiy\/idXgarccvxyWA\/DiswrOoCo9CKnwWUOGHqSb4dCqkjC3YtdRhd0CNYGcDJixqpKwXcNvbgl2hBbdFqd0SW7Dta4HoDyI5nEQqmUIqmYLNasVwIol4PAHtpUvMANBeuoR4PIHhRBI2q5WdnxxOQvQHse2T+qT+d4UW3Pa2IGW9gAmLNJfdATV2LXVIGVvg00lz\/iwgyfAsqmJy\/XJcjafRenwxXIspfQ30ej1MJhPTT\/39\/ejv7y+pfjo4OMj0n9vtRl9fH8LhMFwuF\/r6+piuotCDaDQKURQZ20lvby\/TPxcvXmR69v3330dfXx96e3vh8XjQ19eH\/v5+uFyuEk+nKIpwuVzo7e1FR0cHzGYz7HY7q9XDh8PSKntvby+MRiMj4Ojv74fRaMT58+eh1+thNpvZ91P5T+V\/V+WvNP6u+GY2m2GxWGAymUqYekwmE7q6umAymZjX\/ahGPyh55h0OBwRBgN1uZx5\/q9WKzs5OqFQqNk59fT3k45PB4HA4YLfb4XQ64XQ6YbVaodfrodfr0dXVBbPZzEBST09PWeVmsVhYM5vNaG9vh0qlYopYqVSWVD3mDQ7aT8YMv5\/2UbVaUs70N694eeVNyl3OPMIDYB400HjpdJr1wQOPcoqdH1fe5PPi972r8tMz1NXVxT7pe2dnJ65evcr20X7aZ+m14OrVq7D0Wli7evUqu5b6o2MtLS3QarVorKvCpQ\/P4tKHZ6FvrIO1RWqXVGeh1WrR0tJSMl5fXx\/rQ6vVlsxPq9WWNH5ceZPPq6urC49yduaB\/2JVLDEAvlgV8cNeFP\/8bJS1H\/airH2xKuJRzo5HOTt+yDmkz70o64v\/5Fs5A4CMAH4+1L5YFaV+EgZ8PWEpmS9d+6ZGBgAlAdM4lXj+W+qrS1iA+BWAk37+p3QKfDFch6cxaRXgSUSFJxEVnsdUeBpR4cuECt9PNcLXqcKUoRZTplo89Ckx6anHrtCAb8NN+CbShMehJnwbbcL3k634LtaAX8Y1yE7PYDQ5itGU1EKhMOx2G\/z+ABQKxcsVAIUCfn8AdrsNoVCYnT+aHEV2ega\/jGvwXawB30+24tuoNNY3kSZ8G27CrtCASU89HvqUmDLVYspQC1+nNOcvE5IMz2MqJteTiBJPYy8NgO7u7hKGEr7RSvGbDC2dTgej0QirVfJM9vX1wev1wmq1Mo8nOZ8UCgUbr7q6GkajkTHjEVtKb28v+vr6YLVamY41m83Q6XTQ6XTo6OiA0WhEW1sbC2Xg2fbkrHsmkwlGoxFarRYKhQJmsxl6vR5nz549lf9U\/nda\/krj74pvBJ4JiFssFhiNRvZJvP38j\/n\/t\/e9T2mlW7o1c8\/tq7basYMNtBAJICAINBANEKUhQIADDQRoiXjQgISAB4MoFBYomvir1Ji0VpIxk\/QkqbaSnj4950z3VN9TNZ\/ux\/kv7p\/y3A\/4vr3ZwXSfnlOx6uquWgXsH+9ey72T9aznXWu9hNnX6\/UN38kCD1qtloJ3sp+MQSqwVSoVxGIxlEolZeuJkMiN6KFSqSCXy6HT6aBQKCAWi6FQKCCXy6FQKKBUKjEyMkJfIqbOJAAh1\/J4PKjVaggEAnR1ddFaAqZjZDpT4uxJvlkzYQKB464lTN7g4OBbOcJsAMwEDk6nE6lUCqlUCvl8HqlUCpHRCFKpFB2bDeSZ7CHzONlP9Gb+Pq32q9VqXLp0iQJitVoNsVgMsViM\/v5+GAwGeo7BYGj6edl4GQaDAZeNlxuuvXTpEm05e9l4mY4t5bRT0Xz6EUwXPoLxwkeQctrpvwm1Wk2vIQX3ZKn0y8b6f7BEL7Va3aA\/EaKXWq1Gf38\/3U90V6vVNP2H5OSTVXqZhcEkR58U7pJPIiSVh7mPpPgwx2AeO07Y55Lrm61iS\/azC5mb3Yvsd0hbG9KPTuL9l7PagLIDgPf5\/idl7Xge7sBhaASPA\/UA4HGAg6dBDp6Fz+MgyMG3kzw4ZEcBgKUdLz2dSDo6serqxusAD4chPp4E+HgS4OG7RA+Shi4EFOexuFBBbCyG2FgMY2Nj9cW6IhEYTUa0tbXRAKCtrQ1Gk\/FoHZlofVHJo+sWFyoIKM4jaejCd4kePAnw8CTAx2GIj9cBHlZd3Ug6Ous6WdqR1HTAITuPbyd5ODiy4WmQg8cBzpFtXTgMWfA80oGksg19fX3U1xD\/NjAwQD81mnrfciYwIsymVqtt+G40GjEwMICBgQEKXsh+Msbg4CAGBgagUCggFAohk8koW0mEgDKih0KhoLPVfX19EAqF6Ovrg0QiQV9fH2QyGa5cuQKVSvWWzgSAkWs\/\/vhj9Pf3g8vl4sMPPzyz\/8z+U23\/SePvE9\/kcjl9+MPDwzQYICk3JD2HLO1MwAhTCOtPpmuYYrfbYTabYbfbKSjXaDSQSCQQi8Xg8\/nQarUYGhqCz+ejxzUaDdRqNQ0UtFototEo7HY7tFotZDIZXQwsFArRwuNgMEj19Pv9NBJUKpU0JYPL5aK7u7thBoDtSMk+tmNlM35M1o85BhMcEKdNxmgGgElnDiZbRwADGY+MRcDAcfqxpRkbeBzTedrsJ\/9hXb58GZ999hn9TfaR75999hk+++wzXL58GeZhc4OQ85hjECbEPGzGtWvXYB420zHk3R1UdIJzGBGdg05QF3IOuWdfXx8dj4x17do1fPHFF8fqxxZyrJmwA4BmYJsUmA71tlKgz2TtyffjgPpxq0+\/az\/72HHnk3fnXfdmCtPOqIZ7Iu+\/4pO3A4DPeuoLgb3v9z8pbcfzSAeehc7hSfA8ngS64Vdw8SzEwdMQBy9Gz+NltAt2WReSmnYkbe145e1A0tmJdXc3\/jQhwJsIH6+jfLyO8vA62o2krhMJXTsWK1WMkwAgOobR0VH4AwF4fT50dnSgpaUFLS0t6OzogNfngz9wtOJ7tB4AjI\/FsFipIqFrR1LXidfR7qN78PEmwsefJgRYd3cj6eys62RrR1LTDrusCy+jXXgxeh5PQxw8C3HgV3DxJNCNJ8HzeBY6RwOATz\/9lIIGQliRxYsIeLBardTXMd8PIuTfGfGRTLHZbDAajfXA\/QiUqFQqmobH4XAwMDCAS5cuwefz0eMqlQr9\/f0UKA0MDODGjRuw2WwYGBjAxYsX6WJIoVCIFl5ev36d6un3+ynbKpPJwOPxwOFw0NXVhY8++ggffvjhmf1n9p9q+08af5\/4JhAIQIKAdDoNlUpFmXTDUVEWcyGHoaEhWsFNUnzITIBCoWgA7mTKhjDwzIchkUggEonA5\/PB5\/PR09MDpVIJrVZLr1cqlXTKp7e3F0KhEBKJBL29vTSIEAqFEAgEEAgEDSk\/TJ2JLuS+YrEYAoEAXC73LQfKBgBMJ8p0xMc5fyYjSJw1EXLNu7rgEOaOrROTCWSOxz6HqR8zVYENEtj\/iE+r\/eQ9Yb83Wq2Wpp+RjlVkn8VqoUJyC8k55LjZbMbvf\/\/7BiHXCLvaYBV3wSrugu3o0yruQj+3EwaDARar5S2dDAZD0\/HY5zD1Izqxx2PO1JGiWNKTnwD8MfN5WphLmPWohouSRfgWy85k28l4JH3ouFSgXzrGTP0h55KOQaRwuVnwQIIBpgz1toK5+BhzVuAk3v\/jugDpBV3v\/f1PSjrwPNyBb8J+PAmex0GAC6+Yi+eh7noAEDmPl6NdsMnO1QMAexueeiVIujqw4eHgTZiHN1E+\/jwpwLdjPLwe4yCpbUfC2cYIAMYwFo3CFInAHwjC5\/ejpbWFBgAtrS3w+f3wB4IwRSIYi0YRGxv7OQBwtiGpbcfrMQ6+HePhz5MCvIny8SbMw4aHg6Sro66TvQ1JTTtssnN4OdqFF5F6APA81A2vmIuDABdPgufxTdhPA4Curi4KMLLZLGQyGWUSSVoqCbJVKhUuXbpE07RIigNhQvv6+hqAS19fH\/r6+igDSca4ePEiLly4gJ6eHnA4HHA4HHR3d0Mmk2FgYIBeL5PJ0NfXh4sXL+LTTz8Fj8ej9UUERDGL\/5mz9EydiS7kvkKhEFwuF11dXWf2n9l\/qu0\/afx94ptAIIBarUaxWMT6+jo2Njawvr6O9fV1rK6uolqtYn19HZubm9ja2kKlUsHOzg52d3exsLCAnZ0d7OzsYHt7G1tbW1hcXMTm5iY2NzexsbGB+fl5xGL1KeBgMIjh4WGoVCqo1WpEo1GUSiV6PyK1Wg337t1DtVrF8vIy5ufnkcvlkMvlMDs7i+XlZZRKJWSzWWSzWarn6uoq1bVSqWB7e5vK5uYm5ufnkclkkEgkoFKpwOPx3jk9zizAYzJ6TAfPnmZnOn7mlH0+n0dkNIJYLPbOLjiDg4O0N6\/Vam2Y7mcygEQ3q9WKVCpFnXozwJFKpRoAQrNZgNNqPwlgyWyXxWKhs19XHVfpJ9l\/1XGV\/g4EAvQ7GYfsDwTqC+CRc6LRKK46rsLlcqH3\/IcIKz9BWPkJPIpP4JB+DIf0YwzwPkJ\/fz9cLhdNh7vquIpAIED1IGMT3fR6PQKBACwWC\/3OPIdcwyzGJ7YODQ01zACwU2aa5dj\/teRoANfNgri9aeMv9qBnXk8CCua4zPQfAviZAJ+8P2ygT+7LHG+otxX\/58nYW6sPkxmn9\/3+17sAtTV0ARpmpAC9z\/c\/Ia0XAR+EzuFZ6DwOghJ4RHzs+vh4EequBwCRc0iqO5DUtuNloB0vfR1Iutux4eHgzwkh\/ndUiB8SQvwUE+JNlAQArVisVBCPxhAMRzA2OorRSATKgA8+f6AeADDE5w9AGfBhNFI\/NxiOIB6NYbFSQcLZiqS2HW+iHPwUq9\/rf0eF+HNCWA8A3HWdXgbakdS2I6nuwMvIObyInMeLUDd2fXx4RHwcBCV1G0NHNQDKNnz88cdQKBRYWFjA9vY27t+\/T33G1tYWVlZWsL29jd3dXTx8+BC1Wg37+\/t49OgRlpaWsL+\/j\/39fezt7eHhw4e4e\/cudnd3sbu7i\/v376NcLmN8fByxWAzXr1+H2WyGQqFAf38\/bty48Zaf2t7exurqKjY3N7GysoK1tTWUy2Xk83nk83kUi0Wsra2hUqlQn0j03NraorrWajXs7e1R2d3dRblcxvT0NKampqBQKGinszP7z+w\/rfafNP4+8U0mkyGRSKBSqaBWq2F5eRnLy8uo1WpYWFjAzMwMcrkcFhYWkM1mkclkkE6n35Jbt24hlUphdHQUyWQSo6OjmJycRCQSwfj4OMLhMG0tpdVqMTw8jGw2i8XFRSwvL9PPWq2GxcVFVKtVVCoVlMtlLCwsoFAoYGFhgX7P5\/Mol8uYmZlBoVBApVJBsVikOrJlcnISqVQK4+PjGBsbw\/DwMMRicYODJ06SyfAxnScTFBwHBpifbCdMrn1XFxyn04lYLNbgyEkqAFO3Zroy75VKpRCLxWgB4btSAU6z\/SaTCdfc13D16lUMDg7Wf7uu4Zq7LuFwmO4nx0wmE65evUrPuXr1KsLhMD2ffIbDYToW2W8ymXCR8yGuXDwPj6wu7qNPzacfwWQywev1NqxebTKZMDAwQHW95r7WqCtD32uun+9NeyO7rjWk6jGFOQPAzO8fM5\/H9xuBtwp0\/+\/BeAP7vzGpRskibGDmSbtNNhN\/XBBAvpP3oFntgUPaCP7ZY4+Zz9P3in2Pod5WvJo0NKQ6kfucxPvfrAvQ8FEXoPf9\/k\/KOvEkcA5Pgl14FuLgeZALobgHO94eHAQkeBnm4FnoKP9f244XgY56AOBqR9LTjkc+Lv4aFeLHpBA\/JAU4HD0KAHRtSGcyiEfHMD46Cr3dinh8EpHgGEKBKLraWin472prRSgQRSQ4hnh8Enq7FeOjo4hHx5DOZJDQ1WcADkc5+CEpwI9JIf4aFeKRj4ukpx1JVz0AeBGo65jUdOBZ6Dxehjk4CEiw4+2BUNyD58F6atOTYBeeBDuRVLVDJBLh5s2bqNVqWF1dxdraGtbW1rC6uoqlpSXqa5aWlpDL5TA9PU2JJ6bcvn0b6XQa0WgUqVQK0WgUiUQCX375JeLxOCKRCPV\/AwMDMJvNyOVyuHv3LtbW1ujn6uoq7t69i5WVFdRqNVSrVSwtLaFUKmFpaYl+n5ubQ7VaRaFQQKlUov6a6MiWRCKBdDqNeDyOWCwGs9kMoVB4Zv+Z\/afa\/pPG3ye+KRQK5HI5vH79Gi9evMCf\/vQnvHnzBk+fPsXm5ibK5TLK5TKePn2Kly9f4tmzZ\/T706dPcXBwgBcvXmB3dxeVSqWB\/S+XywiHwwgGg3RdgHg8DqlUinQ6ja2tLXz\/\/fc4PDykY62uruLg4IDqQI49ePCARpaVSgVff\/01nj9\/jqdPn9JZiJWVFfp9b28PGxsbePz4MQ4ODvD06VM8f\/4cmUwGY2Nj0GjqPbnZzpPpVNkMH5ONY7JzxwnbKTMB8HFFsM2YPuY9mSkGTNayGdhg5g0ziwvZ6Qqn2f7fe3\/fIMPDw\/T7jRs38Hvv7+F0Oun+GzduYHh4GEajkf4+Tpjjkt\/Dw8OQdLdD13MOup5zsEg48CnqoumO5sIAACAASURBVOs513Afcg3znk6ns0Gn4eFhOJ3Ohvsx9Sa\/NRoNjEYjPZ98EsDOZP+ZAQA7xYcEAATwEyaeyaoz2ftmBcXHpfAcFyCMmevvCrvgl10szO7xz5wBILqwVyA+iff\/uC5ABkYK0Pt6\/yfk5\/DIdx6PA+fxLFgPAHwaAXZcAjzxS\/HNhBAvQxwktfUOQF\/7O7Hv6UTSWQfe34Q5+CElwCM\/H\/t+Hvb8HCQ07dgJdmCxVMbE6CjGI2GoA16ofG4EfF6E\/WMQtbeipa0FLW0tELW3IuwfQ8BXP0cd8GI8EsbE6CgWS2XsBDuQ0LRjz8\/Bvp+HR34+fkgJ8E2YUw9EnO3Y93Tia39nvROQtgMvQxx8MyHEE78UOy4BfBpBPQAIcvA4UF8LIKHqwMWLF5HL5fCXv\/wFb968wU8\/\/YR\/\/\/d\/x6tXr7C7u4tqtYpqtYpXr17hX\/\/1X\/HNN9\/Q769evcLLly\/x5s0bPHr0CLVarYH9rFariEQiuH79Ou2LPjExAZFIhGw2i4cPH+Kvf\/0r\/u3f\/o2OtbW1hZcvX1IdyLHHjx\/j0aNH9D6vX7\/G4eEhXr16RVnYjY0N+v3g4AD379\/H119\/jZcvX+LVq1c4PDzE9PQ0YrEYVCoVRCLRmf1n9p9q+08af5\/4ptFoUCgU8OLFC3z99dd48OABNjY2UK1W35oBePDgAfb29nDv3j06tbKyskKvIdHh+vo6KpUK0uk0kskknM76ysEmkwmZTAYSiQTlchnPnz+nUzY7OztYX19HsVhEpVLBysoKFhYWaArQ7OwsnQYqFArY2dmhswSFQgGzs7MoFAooFou4d+8eVldXUalUUCqVMD8\/j0KhgFu3bmFmZgYulws6nQ5yubyp42c72WYM23EAgFzLbN1HfpNj7+qCwwYA7Ol+wgYSh97sXLbzZzKGbCBx2u3\/IvAFvgh8gc8\/\/xxfBL6AP+CHx+PBF4Ev4PF46sVEAT899kXgC\/zhD3\/AlStX4A\/48Yc\/\/KFByLXhcJiOTX6TY5cEXVRsfd0IKutiEHRRPZhjfhH4AlarFVeuXMHnn39O8xyvXLnS9FyiO9HPH\/DTaz\/\/\/HNcuXKF6kJAMxv8uxRcypozhQQA5HfVIXmriJj022cCcWb3HXbnH3KMrEfAXrHWIW2lRcjswIAZYBCgz56hGOptpbMZ024+LVh2Kbgn8v4rjroAfcAIAIZZNQDv6\/2PKgTY93bjINCNR34uDif42HIJ4JMIsW0X4qWfj30fDwldJxL6TmxYu7Bh78LGcAeSzna8DHPwapSLH9M9eODjYtfPwU7gHJZLZaTTaUxEIoiHglD53VB6nVB4HJB57GjvaPt5JeCONsg8dig8Dii9Tqj8bsRDQUxEIkin01gulbETOIddPwcPfPV7vRrl4mWYg6SzHRvDHXWdrF1I6DuR0HVi38fDSz8f23YhfBIhtlwCHE7w8cjPxUGAg30fBzE1DwqFAsViEW\/evMHr16\/x+PFj3L9\/HysrK28xoIRM2tzcxMHBAQ4ODijJdP\/+fdy5cwe5XA7b29uo1WrIZrNIpVK0Gcbly5cxPT2NCxcuoFqt4vDwEHt7e3j06BH29\/exvb2NhYUF1Go1bGxsYGlpiaZAFItFzM3NYW5uDqVSCfv7+5QlLZVKKBaLKJVKWFhYoOm6tVqNzqKXSiXcvn0bhUIB165dozV0Z\/af2X+a7T9p\/H3im1arxfz8PJ4\/f479\/X1sbm7SP1yhUEAul0MymUQul0OtVsODBw+wvb2N9fV1PHjwgJ5fKpVosHDv3j0sLCygXC5T9srhcMDj8SCbzUIsFqNQKOD58+d48OAB7t27Rx9mpVJBpVKhAcjCwgJKpRKdysnlcrTmYHFxsUHP6elpzM\/Po1KpYHl5mT78YrGIQqGAdDqNRCIBp9NJAwBm3i\/T8ROny2TMmM6WybwxnS8bWLOZwOMAMLMLDjmP5BCz2T2ST8wsDmx2LpPpa5bnTGw8zfbb7fbGVQ7D1+kn6WTg8\/lgt9txPXwdiUQCiUSC7ie\/E4lEw7VEyH6mDF34mIpT9gkiA5\/AKfsEDtknuHr1Kj3vj3\/8Y8PYZLw\/\/vGPuB6+Xq9JuHqV7rt58yZu3rxJzyV6kwVcmPYQPZn59gQ0\/9eKB68mDfhryYH\/WvHgv1Y8+H7ahO+nTbQImADtkqU+A0DA\/HEdfZp1BWL+Jgz\/Lwm7XoGZEjTt5qPqkND1Ar6fNlH9\/1py0DUESIoSed\/e9\/svbxIAMLsAvc\/3P6wQ4is3Fwc+LvZ8PDz38\/GVRwCfpBchtQh7bik2h3swoRNhUt+LZ95u7LjOY93cifWRDuy6OfhLpgc\/ZvnY8XVjtVjGSqmMdDqDeCSCeDgIld8DpdcFpccBudsOqdsGTns7Wtvb0NreBk57O6RuG+RuO5QeB5ReF1R+D+LhIOKRCNLpDFZKZawWy9jxdePHLB9\/yfRg183B+kgH1s2d2HGdxzNvNyb1vZjQibA53IM9txQhtQg+SS++8gjw3M\/Hno+HAx8XX3m5GFXz0d\/fj3K5jMPDQ\/zzP\/8zdnd3sbq6Sn0a+bvm83msrq7i8ePH2Nvbw\/b2Nh4\/fkzPJ34on89jc3MTS0tLqFarSKfTFAB5PB7kcjkIhUKUSiUcHh7i8ePHdMac3LdWq1EAtrS0hEqlgjt37uDOnTvI5\/M05\/ru3bsNet65cwflchm1Wg1ra2s0hYL40Gw2i6mpKTgcDgqAzuw\/s\/8023\/S+PvEN61Wi2KxiGfPnmFrawsbGxtYXFzEwsICisUiDQASiQRqtRp2dnawubmJ9fV1ytovLCxQsD0zM4Pl5WXK4KdSKYRCIRoAJBIJiEQiVCoVPH\/+HLu7u7h3795b+f8EwK+srCCXy9Fcs5mZGezs7NBzK5UKZmZmcOvWLaTTaRQKBbqf2FEulzE\/P498Pg+PxwOHw0EXEmM6SbazbFY4R5wnk0VrxtI1c8xkPxsAExB8XA48GbvZeMxc4GYpCEx92d1N2CDhzP7TZz+bASf7meMSu5kglAgTjLL\/HuQ4W8hx5u93SbNx2XY229es0xXTDnb3nvf1\/BWsdQD4nY0zAO\/z+dvEAmzY+Nhw8LDh5GPD0QOvQgivWIiQSoyoRoJVswBJ\/XlM6sW4Z+Hhno2Lbb8LqSEBdlzd2HF3Y8XeiZnsNMYioxiLRBALhxELB6E6Sv1RehxQuuyQO62wOm3oPteJtvY2tLW3oftcJ6xOG+ROK5SuehCg8rmhCngRCwcRC4cxFolgLDKKmew0Vuyd2HF3Y8fVjdSQANt+F+7ZuLhn4WFSL0ZSfx6rZgGiGglCKjG8YiG8CiE2HD11G508bNh58Ep4UKlUWFhYwDfffIOHDx\/i\/v37uHv3LpaWlrCwsED\/3lNTU1hdXcX+\/j52d3exvb1NWculpSUKNgqFAtbW1iiDmU6nEQqFKACamppCT08ParUaDg8P8ejRI2xubr6V\/0wAzMbGBvL5PC14LBQK2N\/fp+fWajUUCgXcvn0b2WwWpVKJ7id2VKtVlMtlzM3NwePx0FbaEonkzP4z+0+1\/SeNv09802g0KJVKNM+ePMhisYjZ2VnkcjnaOYew+2SqhnTcIcx9sVhEPp\/H\/Pw87eZTLpfh8\/nqwMdopDMA09PTePbsGXZ2dhoCAFKIvL6+jpWVFWxubmJ5eRkzMzPIZDLIZrPY2dlpKBoulUoNL0ipVKJFw2RGgdgTj8dp9xSBQPCWg2c6SSYQYjtRNpPGTh1ggyUmo9gMALoUP3fBYYOd4z6bpfOwz2ODXXbx4Jn9p9t+cu7fq9C1GVvdDOizfzudv63Qlc3Cs8F4s9Vxyd+EzfC\/r+fPXgiM31mfASBdgN7n8x+XcbFq5cMu4sMh4sMp5sMt7oFHXE8DWjULcc8kxLK+Gwm9FMuWHhwE+NgOubHs5GLbzUWtMI9aYR5BXwChQACRUAjhgB8qvw9RvxdqjxMqlx1KhxViQQ+UBh26OjrQ1t6OtvZ2dHV0QGnQ1Y85rFC57FB7nIj6vVD5fQgH\/IiEQggFAgj6AvR+225uXYeQGwcBPpYtPXUd9d24Z6rr7pMI4REL4Bb3wCmu2+gQ8bBq52FSwYVKpUKlUqF5xqurq5S8Iv6MdA4h7Obe3h6WlpZo+iphLhcWFjA3N4dyuUy7mVSrVfh8PjgcDgwODlIG9M6dO\/jmm2\/orDsBQKQQc3t7GxsbG9jd3cXa2hoKhQKdAd\/f328omqxUKvTfWKlUoqmvBJgR3YrFIiYmJmjrRi73zP4z+0+3\/SeNv098U6vVKJVKODg4wPr6OmXPS6XSWwHA9PQ0qtUqtra2MD8\/j5WVFWxsbGBlZYVGWSRHn+TlV6tVRKNRjI6Owu12I5PJQCwWY2ZmBl999dWxAQBTyPRNJpOhMwCk8ntxcZGC+9nZWczPz6NUKr0l5XIZs7OzuHXrFoaHhyGXyxsCAKaDblYsx2bS2ACJ7fCZrBwBKSR3lw38mACQzeaxARgTQBH92ECLDW6PY3vZQO\/M\/tNnPxMoMu9N\/g5MXZpJM9ubgf93sf3HAVo2SGcHF0yw\/S7Gmy1kLObzfZ\/PX9HdAX7H\/8L\/+t0\/vhUAvO\/nL+ztgaCXD4GIB4G4LkIxH0JxD4QSAYrDBhTMBkTkvRDJe5G3mDBrs0CiEKA6O4uZ7DRy2WlMZzII+P0IBYMIBfxQ+bxQ+zwI+TzQuB3QjBihNg5CJBCAz+XiXEcH2tra0NbWhnMdHeBzuRAJBFAbB6EZMULjdiDk80Dt80Dl8yIUqI8d8Psxnckgl53GTHYa1dlZSBQCzNosyFtMEMl7EZH3omA2oDhsgFAiqNsi5kMo5tVFRIRPZ6NfvnyJ7e1tyh4yCS0CgO7cuYOVlRU8fPgQ5XIZGxsbuH\/\/foMPJDnKJC95ZWUFN27cQDQahdvtxvT0NIRCIQqFAv7pn\/7pWADEFNLycHp6mjKglUqFsqAE3BSLRZTLZUp6MYWQerdv34bZbIZEIgGXyz2z\/8z+U23\/SePvE99UKhVKpRKePHlC\/1gkZ4qkzeRyOYyNjdEgoFarIZlM0iCAmWs1OzuLTCZDGfh0Oo1YLAaXy4XBwUFaBJzJZGgHH3YKEBHmmNlslhbxbm9vN7xkxWKRtgMlgUixWKTFv4VCgdqSyWRoEbBQKKROn80AstlCtvM\/DgQwmUO2w30XAGT2wWeDLjIuce5kP2nzF4vFkEwnkM\/nkUwnGhjHZp9MPc\/sP932M4E\/G8gSRp4N2Jmgm\/03ehfL\/650H6Lfryl0ZdqfSqWQL8z8fI+j78y\/N1uYaTAn8fwV3R3gsQIA0gb0fT\/\/4d4eWHp5sIq4WJVzsK7kYEPNQVLVDY+kBxsOIeI6OSZ1CiR0CiR1SiSjMeQyWeQyWUxnMohFxzAaicDv88Hn88Ln9UDtdcPncUHrdsDscEBrt8JktaJXKASPy0V7ezta29rQ2taG9vZ28Lhc9AqFMFmt0Nqt9WvcDvg8rvpYXg98Pi\/8vvpaAbHoWD0QONIjGY0hqVMioVNgUqdAXCfHhkMIj6QHSVU3NtR121blHNjEXNhEPNh6eRQA\/cu\/\/AsloEjeMUkbyOfziMViFAStrq4ilUpREERY06WlJRSLRUxPT1MGMpvNYnx8HNeuXYNer6dFkNPT07SDCTsFgghzzFwuR4sY9\/b2Gnw1aY1dKpUoECOpr0wCbG5uDtPT07QIksc7s\/\/M\/tNt\/0nj7xPflEolSqVSQxEGAdHMICCTyeDWrVtIJBKYn5+nHX6q1epbxRYEeJPC4Hg8jvHxcRgMBqTTaUilUsTjcWxtbb0VAJDOPszqbXL\/dDqNfD7fwPyTmYZcLkcLQEjQQPbncjk6M5HL5RCPx6HVamkAwHT4zOn+ZukCbGEybGxmmQ0mCChg536zASCT1WMylc2AFBN0sVlWJnhhChsAn9l\/uu1nst1MNp2AZTYYZYJb5vnvmi1oNgsQGW0sdCW6REbrXXNIIMDWgXk\/ZpoPu+89OdYsACDHTuL5yxkBQNv\/rAcAVxgBwPt8\/t9O9uD1OBev43U5jHHxapSHPTcfOy4BVq292LAoMKFTIpPJYH5mBtlMBtlMBh6PCyazGaORCMKhELxeDzweDzxuN9xuF7QuB3ROO5btMixbpRiRiKHX66DVatDW1oaW1la0tLaira0NWq0Ger0OIxIxlq1SLNtl0Dnt0LoccLtd8Ljd8Hg88Ho9CIdCGI1EYDKb4fG4qD7zR2miEzolNiwKrFp7seMSYM\/Nx6tRHg5jP9v5Os7Ft5N1ALSwsID79+9ja2uLghnmOjQEONy+fRtTU1Mol8u0w8nKykoDAGL6LVIYOTExgXg8Dp1Oh2w2C5FIhImJCTx8+PAtAEQINaYvJPfPZrOYm5trYD4JCZbP5+limAQ0kf35fJ4ys\/l8HhMTExgYGKAA8Mz+M\/tPq\/0njb9PfFMqlZiZmcGjR48oGG8G6HO5HAX9ZOGvZDKJQqHQULxLIq9yuYxCodBQoEsCAKvVCpvNhnw+j6dPn2Jra4suBkaiOiaLT\/L\/k8kkZmdn6f1I1TmpDahUKrQFabVaxfz8PO0eRGYIyAupVqshk8neYvWYwuyd3ew4W45jEtnjswEgc9VUwgCygRUTnDEZPvZ+NivLTllgA5wz+8\/sZx5jX8tOsWEDZjYgZQcCxwUF7NkAMjY5Rq5j6sFkvImwdWXb3Qz8k+8ajeZEnr+CFQCQNqBWafd7f\/5fB7l4PVGX7xI8fJfowXcJAfacIjywSxFyuTHmDzYs+mgymeBxu+B2O2E0DyMcCsHjqYN+t9sFl4v8HRwwOOxwD+ngNmhgHBqEzWpFdzcXra1taGlpQUtLC1pb29DdzYXNaoVxaBBugwbuIR0MDjucTgecTidcLicd3+NxIxwKwWgehtvthMftgslkatBxzB9EyOXGA7sUe04RvksIjmzj4fVEN15PcPFijIuLFy8in8\/j2bNnFIw0AzT5fJ6CHrLwUSqVQqlUaiheJEWH1WqV1qKRAkUCgCwWC6xWK+bm5vDq1Ss8fPiQLoZEGFimLyX5z6lUCsVikd6PLIhEcqNrtRptwbiysoJyuUy7pxBCrlQq4ebNm+jv78fFixfP7D+z\/1Tbf9L4+8Q3pVKJYrFI23uSCIyAcTYLT8A8+SR5\/uR85rQMAfFkGsjtdiOdTkMul0OtViMWi2F5eRnb29tYXl6mq\/4yZxEI+CctPJktPokeZGbi3r172NjYaOhIRJwiaRE6Pz+PTCYDlUoFuVwOjUbTlCXUaDTHHvslYQMP4mzZKSDMNphxg4AywIQpZLKPTMaTCXQIiGGzm8fpwAYyZ\/afbvuZwgSMTNDIvpYdBDBBKnsfGxw3Y8rZ+5iBA1O3ZsfZbD\/5zpzBaPZcmfK+nz+pAWAuBGaVnKczAO\/z+b+Z4OHNBBdvJrl4M8HD6zgfh9EebLqEiBik0LjM0Lgt0LrtiIYjGI1EEIlEEA6FIZcPQy4fhtPlgNLpgMrpgNPpgMPhgMVug8PhgNXmgNXqgMPmgM1ih9vlgc1iRUtrKz5oacEHLS1oaW2FzWI9OmaH4+gaq61xLOfRPZROB5wuB71\/OBRGJFLXLRqOQOu2Q+O2QOMyI2KQYtMlxGG0B6\/j\/Lq9k8ReLl2ThrQ3JDPhBIywWUgCZsgnyXMm5xMAwwQxZNbZ7XYjm83S9ovj4+NYW1vD3t4e1tbW6KqnTL9LwA9pYchscUj0IMzs5uYm7t+\/39CRhQREpEViuVzG9PQ0FAoFJBLJmf1n9p9q+08af5\/4plKpMD8\/TxdPYAYAzGkgktufSqUo8CZsHcmxYqfuVKtV5PN5jI+Pw+PxYGhoCBMTE5DL5dDpdLQv7NOnT7G9vU1Ze7LoFyn8iMViSCTqOa5kpqBarWJ0dBSjo6OYmJigFeqbm5sNdQMkAJiZmaG1AuPj4w0BwK8BAs3OOe7YccCS7GsGAEkKCBmrmSMn1zdjKd8FcH6tfWf2nz77\/7vSjDVvtp8JYtkBA3M8dnoNsYnJapP9zL9Js2cplUrp93f9Xd7385d\/Up8B+J9NFgJ738\/\/z0kRvkuE8V2Cj++TPfjPZAKHUQE2Xb0IGWTQuMzwuJywO1xwOF0wmcxwuQjL74DDYYdCoYJSqYZpeJiuNWGx2WC1OWC02+GwO2Cz1gMAk2EQRp0eLW1t+KClFR+0tKKlrQ1GnR4mwyBsFjtsVgcc9vq1VpsDFpuNjmsaHoZSqYZCoYLjaIbA5XLC5arr5nC6YHe44HE5oXGZETLIsOnqxWFUgP9MJvB9sgffJfj4LhHGn5NC9PX1oVwuY3d3Fw8fPmwAQMz6NpLbnE6nKfBIp9OYm5ujM87s1IWVlRXMzc0hHo\/D4\/Hg0qVLuHnzJiQSCTQaDTweD\/L5PF69ekUX1WQuepTP13ubj4+PY2pqCnNzc5QpXVlZQTQaRTQaxc2bNzE3N0dXYWXmTRMARGryCoUC4vE4BUBn9p\/Zf5rtP2n8feKbXC6nrTXJ6mmkfz7zoS4uLjYw\/7du3aJdeebn51EsFhsKL1ZXV7G4uIhbt25hbGwMNpsNQ0ND9I8fi8UwOzuL5eVl7Ozs4Pnz51heXsbs7CyN+Mh9SAvSarVKK84XFxcRi8UwPj6O6elp+sItLy\/TvP+ZmRnMzMzQPDBSTW6z2WgKkFQqBZ\/Ph1QqpcLn88Hn8yHRSOh39jnkPKaDJecxfzOdNvlkr3TKzAHXaDQNTCwzvYHp9I8DGHw+\/y0wQPRg68e048z+02t\/MznO7magshnI\/rWBwrsCk781aGlmf7NnxPx+Es+fuQ7AB\/\/j5xoAEgC8z+f\/n\/cG8X1SiO+TQvwpIcS3E0K8HuvFplOMoEEGu1QCmUQCqUQCmVRaD84cTigUSrrAj9FowpDRBKPZjIDfD5vNjhGrFXa7vc7kW+2wWe2wSqSwCnth5fLQ2tZOawBa29ph5fLqxyTS+rnW+rV2e30sm82OgN8Po9lcv5fRBLvdDofDAYVCCaejHjTKpNK6rhIJ7FIJggYZNp1ivB7rxbcTdRuJvf+5oYdEIqGtBR8+fEjBz9LSEs1vJvuYzOft27dpVxIyc01Yz0qlgq2tLdy9exe3b99GLBaD1WrFpUuXMDExgb6+PoyPj6NYLGJtbQ37+\/s4PDzE2toaisUiXVGV3Ie0YFxZWaFdV+7evYvx8XHE43HcuXOH9kxfW1uj\/o6kvJIVVGu1GvL5PKxWK02BOLP\/zP7TbP9J4+8T36RSKTKZDB4\/fox79+41FOFWKhXUajXa0z+Xy1FGnQQC2WwWhUKBtmAqFAoU\/C8sLCCZTGJiYgJOpxMjIyO0FmBmZoauALyyskJzt2ZmZmjHHzLLMDk5iZmZGdp2lESZJA+YdCYizP\/09DR9CcjLSVqb+nw+jI6OQq1WNwWAzRz9ccJ0vs32MZ0++S6VSt8CgExG+DhGkw22rFYr+Hx+Q+pDM+BAziPC\/n1m\/+m2X2FQQGFQNOz7JRkcHGz4ToTZ1ejXBgB\/i7ADkGa\/mYEKG9AfF9y87+fPDgA4H36Az3rqRcDv+\/n\/xy0ZfrwlwQ+3JPjhlhg\/3BLj9ZgE+w4pvrLJoDeo4ZBK6wDb4YTD4YTJZIbZPAyHwwm73XEUABixvr6FjY0tTOdm6oSPzQaXUQ+LxQbLiBVD+kG4lHJweXy0dXSgpbUNLa1taOvoAJfHh0spw5B+EJYRKyyW+rVDNhtsNhumczPY2NjC+voWhozGowDAAYfDCbN5uM7+H+nodDjhkEqhN6jxlU2GfYcUr8d+tu+HWxL8eEuC\/0hLcfHiRWSzWXz99dfY3NxsKEKs1WpYXV2lPc3z+TxlFAkQyuVyKJVKlDArlUoU\/CwtLSGVSuHmzZtwOBy4cuUKzYUuFAp0BdSNjQ3s7e1hdXWVNqogqQ0k9bVQKNC2iyRHe3x8HOPj47QzC2E+79y5Q0EPSasgrR19Ph+i0Sj6+\/shEonO7D+z\/1Tbf9L4+8Q3kUiEUCjU0DmHCJkyqdVqmJ+fRyqVQjKZpAXApCAkl8thfn6epv+QGoDZ2VmMjY3RRSAGBwdhs9lgMBhgt9uxvb2Nra0t3Lt3jwYMJG0nkUggmUxicnISk5OTqFQqlP0vFAqoVCo0ACiVSlhfX0c+X1+EjKwYTH4Xi0WUSiUkEol6\/mo4DKvVCrFYDAWvEyFlO\/3MDgkRUrY3FWa6BrN3O1PI8eyQkAqz0JMwvc16wBt7zzdcR+SX9CLHs0NCVB0SZIeEbzHLx+l42u0\/TkcyFluO25\/QtdLP44ScuxfRNB2DeY9fkl97zbvOYf4NTqv9J\/H+yz95ex0AWXcH9IKu9\/7+\/5SW4T\/SUio\/pmX48ZYMezYZHljkkMlkMOiPgimZDE5bPQBQKpVw2J3weQOwWx0IBUdRrdZQqVSRm8nDaqmDeKvVhpERK\/Qjw9Dr9BD2aqFTa9HW3hgA6NRa9PZqodfpoR8ZxsiIFVarrT6GxYrcTB6VShXVag2h4CjsVgd83gAcdieUSiVMJjOcNiekR7O6Br0GMlndhj1b3aYfmbZmZPgpI0NPTw98Pl9D5xAiS0tLdDa7XC4jnU4jlUrRAsh0Ok07zJEOdARwkPFisRjsdjv0ej30ej2sVit0Oh1sNhv29vbw8OFDbG5uUsBE0hampqaoH0wkEqjVapT9JGvgEABUqVSwvb1NF2EiC2KS34QAm5qawpdffolIJAKLxQKhUHhm\/5n9p9r+k8bfJ74JhUKIxWI6JZNOp+kf9tatW7SLDmHyE4kEJicnEY\/HKUgfHx9HOp1GJpPB7OwsnXqx2Wz0wev1emg0Guj1eigUCtjtdkSjUczPz2NxcRGzs7OYmJig92B+ZrNZLCws0IXBKpUKTUHy+XwIhUK0JzgzNYkUEKdSKYyOjiISqbcXDAaD0Gg06O3tPXZVVuLcFbzOt3K2mZ\/s6PDg1QAACjlJREFU73+rsMEBG2Cw9xl7zyNuECBuEDQF0MctMnUcYDnt9g\/1tr51r3ddc9y4zHae7DGYYIxI3CB4J5D8JXnXde+ynX3Nabf\/JN5\/5krApAvQld6PEOjnvPf3\/6e0FD9ljiQtw09pOX5Ky\/GVRY7dETm2h+UIun3wDbvgsbjhtrnhdfvgtLvgdLjg9wZgHDIiHBxFJjMDw+AghoaMGBkewciIBSPDFugNg9Bq9dBotBAKRRgxmdHWxggA2jswYjJDKBRBo9FCq9VDbxjEyLDlaIwRDA0ZYRgcRCYzg3BwFMYhI\/zeAJwOF5x2F7xuH9w2NzwWN3zDLgTdPmwP1234yiKndv2UrgN\/IlwuF0KhEPF4nBJQ8Xgc8Xgct2\/fpl1ECJM5NTVF\/RIBKfF4HNlsFtPT05RsKpVKsFqt0Gq1VFQqFbRaLfr6+mCz2XDjxg2Uy2XcvXsXxWIRN2\/epPdgfuZyOSwtLdGFkWq1Gk3BIP6P+GBmagYpoEyn04hGo\/jyyy8xPj6O69evQ6VS4dNPPz2z\/8z+U23\/SePvE98EAgHEYjEkEgm0Wi2sViu8Xi+i0SjGxsZonv34+DgmJycRiURgs9kwMTGBUChUL8wymWAymeD1emG1WjEyMgKdTgetVgulUgmlUgmtVotwOIxUKgWZTAa9Xg+Hw4GhoSE6ja3X6+l9JicnkUjUF7UhLZxIcTBh\/sl01OTkJEKhEILBIJ1t0Ov1GBoagsVigd1uRygUgt\/vRzAYhN1upzmxbMfJdKxkPxME\/L2FOe5xYLgZg\/73AN\/NANBps5\/YdhyAYu\/7pYCl2TnsMX\/Jpl8Cp7\/2WTYD2McB3NNq\/0m8\/3rBR7QNKKkB0PU0BgDv6\/3ft\/fikVOExy5xQwDwYFiOXb8DYa0cYa0cIa0cAb0cXqsHPrcPI+ZhuKwu+A0qOKx2GPR66HQ66HR66PUG6A2DMJvN0On0kMnkkEplEIulEAh6MWI2o62tHS0trWhpaUNbWwdGzGYIhCKIxVJIpTLIZHLodHqYzWboDYPQ6w3Q6er3MOj1cFjt8BtUcFldGDEPw+f2wWv1IKCv60r03vU78GC4MQB47JbgkUuMfacI3d3d6OnpgVAoxMDAACwWC7xeL27cuEF9HwFEiUQCX375JaxWK27evIlQKASbzYbLly\/j8uXL8Hq9sFgsuHLlCjQaDQYGBiCTySCTyTAwMIBIJIJ0Oo2LFy9Cq9XCbrfj0qVLsFgs0Ov10Gq19D6JRAJTU1NIp9O0pzopjiT+OJvNIpvNIpFIIBQK4fr165Rt1Wq1uHTpEkZGRmCz2aj\/u379Omw2G1QqFTgczpn9Z\/afavtPGn+f+CYQCCCRSGhqj06ng1KphMfjgcPhgFarhUgkgkQioTmuY2NjUKlUMBqNGB0dpQ8kHA7DYDBAr9c35Mqq1WooFApaBCyRSBCPx+niDaTC3Ov1QqPRQKVSQaPRQK1WQ6\/XY3BwEEajEdFoFMlk8qgLhYsGCqFQCOl0mqYhkf7\/IyMjUKvVUCqV6OnpAZ\/Ph1AohFarhVgsBo\/Ha3CGhJlsBpKaAaVmoODvBcTZQOnXALBf0u2X9DuN9jPt+qXz2TocB\/B+CwD+LQD3XUCWCYDfNc5pt\/8k3n\/FJ\/UZgA9IDUDbB5B1d8Ag6Hrv7\/+DESES1m58G+vFo7gJIaUMQZUcQbUcgSE7who5IhoFwloFgmYP\/G4fPE43XDYXnBYnfAYlAjoV1GrVEdOng1arg1Kpg0ajhUqtgVQqh0cmg0KuxLCgFyMmM1rb2o4CgFY6AzAsEEEhV8Ijk0EqlUOl1kCj0UKp1NFxtVot1GoVAjoVfAYlnBYnXDYXPE43\/G4fgmYPwlpFXWdN3YagWo6gSo6QUoZHcRO+jfUiae3GA2svOBwOenp6aGqDRlNPHfJ4PLDb7RgYGEBPTw8uXLgAkUgEvV6PWCwGhUKBwcFBRKNRCpAikQglvkQiEZX+\/n709fXRIsgLFy5gYmICc3NzWFlZwcLCAu7cuQOv1wuVSgWFQgGVSoX+\/n5otVrqA2\/cuIFUKoVr167h2rVrFCiFQiFks1mahkH6n1+5cgX9\/f2QyWTo7u4Gh8MBj8fDwMAAhEIhPv744zP7z+w\/1fafNP4+8Y0EAIODg5icnMTo6CgtoBOJRLRogkRmExMTsFgsSCQSGB8fh91uh8\/ng9frpUw7yfsymUwQiUQQi8W0MM9oNKK3txdarRYWiwVut5s+yMnJSYyNjUGtVsNkMkGr1cJkMiGZTMLpdMJsNsNut8Pr9cLv99NC4VgshrGxMZrmEw6HYbPZYLFY4HK54PF44PP56EttsVjQ09PTEAAcB2yYIOnXMnxkjOOA0m8FxO8CB78GHP0SaDqN9g\/1tjYcb3bPXwNC2TqRNA2mfr8WAP8aUP1bwTn7b3Da7T+J95+kAJEA4PyHjQHA+3z\/EzIOjBIhZDIR5DIJ5DIZnDIZ3DI5fHI5gnI5ImoFImoFQlo5Vobl8DjccNqdcNgcWB5WYtCgp9P7KpUKSqUKCoUScrniZ\/ZfIoNIJIFA0IvubnV9JeCjNQDa29vB5aogEIogEkkhkcjoLIBcroBCoYRSqWq4x6BBj+VhJRw2B5x2JzwON1aG6+w\/0Tcor9vglsnhlMmgkMmgkEuhkIthVIiQ1HAoANLr9UgkEohGo1CpVBCJRDQ\/+saNGzTl4ebNmxgZGcHU1BTi8ThsNhv1f4RpHB8fp8woYVdFIlFd78FBfPrppxgYGMDIyAjcbjempqZoakUsFkN\/fz8uX76MgYEBXL58GalUCg6HA0ajETabjfo\/Uig5Pj6OWCxG0xwikQidib927VqD\/7PZbBgZGUF3d3cDADyz\/8z+02j\/SePvE99IACCTyejCEGKxGAKBAD09PRAIBBAIBODxeOByueju7qZCQLRQKERvby8VwrQLhcKGjhNkDCLkOhIkkFkGIhKJBFwuFxwOB11dXVRIJMfn8yESiei92HoIhUKqP1OI3uwZgLeYuiPm7zj279de+\/eQv1XPXwO0f8u4\/7\/Zf9zYv1WXX3vv\/4400+e3Blan3f6\/9b36rToyRXCuFR0tv8Pv\/vEf8Lt\/\/Ad0tvwOPedaIe1uf+\/vv0ajqItaAbVKCY1CAZ1CAYVMjiGFEmGlHBGVAhGVAmG1HD65DG65DBaTEfYRO6xmCwYNBuj1Ouh0WhiNRhiNRqjVGiiVKsjlSkgkMojFcohECshlSijlarS1tR6tAtyKrq5uKGQqyKVKiEQKiMVySCQyyOV14K9Wa+i4Op0Wer0OgwYDrGYL7CN2WExGuOUy+OQyhNUMfZV1GxQyOXQKBTSKIxvVCmg1Cuh0CgqALly4AKFQSD+JryO+6uOPP0ZXVxc++ugjKgRE8Hg8fPrpp1SIf+LxeOBwOFTIGETIdQQkEZaVyIULF9DV1YXOzk58+OGHVDo7OxvAG7kXWw+2vyVC9GaOcWb\/mf2n0f6Txt8nvf0\/NoX105hDtDwAAAAASUVORK5CYII=","codes":[null,[0,0],null,[1,1],[3,3],[4,4],null,[6,6]]},"flats":{"src":"data:image\/png;base64,iVBORw0KGgoAAAANSUhEUgAAAYAAAABACAYAAAATWKC\/AAAgAElEQVR4nO19v28bZ9a1ikWaAIaRGFgZCmBClmUsM4AYS1BIZPSKQUbAIplioCXiwYLYsEiwUzgLLpYF8UIFCxdTpGDBQoUKly7ewn9Aivc\/u28xPI\/OHN6hlS+K+QESgYHI+f04yDn3Offc+2zt7+\/b4eGh9Xo9Ozw8NP59dHRkR0dHdnh4aIeHh9Zut63dbtvOzk5tOzs7szRN7fT01E5PT+3s7Cx8Pz09tV6vF7azs7Ow4Rh+93q98Ix2ux2eyxuej+NnZ2d2fn5ueZ7b+fm5pWlqZ2dn7rl8j\/39fdvZ2bG7Pv5Wq2XPnz+3drttz58\/X\/nN2+7uru3u7trjx49r24sXL+z4+NgODg7s4ODAXrx4Eb4fHBzUxvTixYuw4Rh+t9vt8Izd3d2V5+MdHj9+HI6\/ePHCer2enZycWK\/Xs+PjY3vx4oV7Lt+j1WrZ48eP7eXBn+3lwZ\/tb59\/at8++zT8\/frpJ\/b1009s\/9HHtv\/o4\/D722efWu+zj8I13vk479tnn9aux\/lf7Dywr59+Yl\/sPLD9Rx\/bD4c7K8\/TZ2L72+efrhz7YueBvTz4s\/tMvBv\/xrt\/\/fQTi6JO2NIosldxZBeD6m\/erfbNhqmVg9RmccsuBpEV\/dhexZENO9vWb21ZHrUsj1qWRdv2Ko5sPkptXgzsYhBZOezaNO1b3u1YlmU2Go1sNkztshhaOUhtmvatHHatzBN7+3pk82Jgw8625Z2HlmWZZVlms2Fqs9nMfr2c2uUkt7evR\/br5TRsb1+P7O3rkb0rL2ySJTYcFjabzWw2TG0+n4dtsVjUrpkXA9u66x8FM9329\/fD1nQOgAjgxwDY6\/XCfgY7HOdr8RuA1ev1LE3TFWADSOO+OMb3TtPUDg8Pw\/vhPmdnZ3Z0dOQC+V0cv4K5bq1WK2xN5wCIAf5MAO12O+xnsMdxvha\/AdjtdtuOj49XgB0khfviGN\/7+PjYnj9\/Ht4P91Fy+OFwxwV\/gLMHxF8\/\/SQALoAUxz0CAODrPdYRAK5R8OdnKAHgXfR6POfbZ5\/aD4c7LgGkUQX4DP5556FNsqQC0mJg5SC1ctgNBMCg\/yqOLI0qwAewv4qjijiGqcVxbKNRBbpvxkUggDxq2as4sstJbvNiEEgn7zy0OI4DaVxO8kAAk6wii8tiaPNiUAP1LMssz3Obz+c2Ho+tKArLssyKoghEsVgsAolsGn83\/mGgA6ikaWp5nts\/\/vEP+8c\/\/mGnp6e2v78fwAzgAVA8PT218\/PzWgQMAMPGYAggxHcAGCJgPOv8\/LwGfojS2+12DRwZQBV8d3Z27OjoKIAj7qeAflfHz0APUD0+PraTkxPr9\/vW7\/ft4ODAWq1WAHOAJ0jh4ODAer1ebQYAAMfGZAAiwHcAOGYAeBb+7fg4wJvJgQlEyYcJCrOF4+Pj8O7\/\/OpJAFYG595nHzWCNwCXI2wv0sbvkycPavuwAZjx\/JMnDxoJALMHb5bBBPDFzoPatS8P\/hzuxwSAd4nj2JIks724a3m3Y+WwGyJwgD8IgLdp2q+AegngIID5aGBlnlSR\/RL8i34F5OPxuLp+NAgEMUkqwric5JZ3O5YkmcVxHN4ryzKbZIm9Ky\/s18tpRRJRK9wfM4LLSW6Xk9xGo5GNx2ObTqfhXntxd3m\/5Po95nN7+3p0TwAKfgAJBh6AHgMMywhNEggkhyYJJE3TFQBEdApQ5XcAqAEccFxlFpx7enpqOzs7tXMxPkTHd338Cv4ASQZegD4DLMsoTRIQJJcmCej4+HiFAADwIBV+B4A6CADHVWZi+enx48e1czE+zA5AAAzyDM4AU5yD4\/qbr9MZwMmTCpRVLsJx3IsJ4OTJg5pcA9DGe+H6v31eEQfO49mBzhj+9vmnYcaDZ3bSfgDIvNsJwAzpJ0T\/eRL+AuAZ\/F\/FkfVbWzYvBvZ2NqzOG1Tg30n7VhSFjcfjQAKv4simad8ui6G9Ky9sPB6H6B3A30n7AbAhAc2G1awBxDEbpvZmXAQymM1mVhRFAP8suyaUOI5tb2\/PsiwLhLJp\/N34B3IDAEPBD5EtpAqWGQAiDEQANlzH92c5RAET+wCafA+WV\/BcROp6TO+JaBr3x3Px7nd9\/JBbAJgK\/ojsOYpmgH\/8+HENiAHsuI7vz3KQEgb2gTT4Hiwv4bmYqegxvSdmE7g\/nssEoKDMBKAyDEC4iQAQ7QOwNZrX2YQ3A8D5nGfg6B9yDks5yGV4BMAk9sPhTu09iqKwoihsNBoFEmDtv+jHNsmSsF0MogDur+LIsmjb8qhlaVQRQNGP7c24qPIGw24F2HkeIv\/ZMLVJ0rVXcWSzuGW\/9Fv2Zlw9H9F+nlcyDwgAks\/V1VUggDyq8hGQpmZxyy4nuZVlaVmW2d7enu3t7VmSLPMOs5nNZrMgJWHbNP5u\/MOgxODHYIHolIEF4AYA9GSI8\/PzWsTK1zcBFqI4BUAFSZZROILW5wAAdf\/R0VFN1vmQ418H2B96\/AzKDP4MlojOVeOHFNQkw2DsiNj5+ibARgJYCUBJgmUknkHoc0AAuh+5BNbfNZnLwMkEcPLkQW3W0EQAkGS88zk6xzGQDktGHgFw0pcJgAmHicmbAeD45SS38XhskyypIualpp9GVZI3i7YtSapjXj4gi7ZD8hhEMBumFVEsI\/TxeBw0f04av4qjGkkgQXwxiGoJYAbty0kechDTtG+zYRr+8gwDMwpE\/sNhUUseIx+wafzd+Ie1YQY\/Bh0AhgLX0dGR7ezsWJ7nLsjgXgxYHpBqdLu\/v1\/TtxU0cQ8vAtZjAF+8A44BAO\/6+FkbZ\/Bn0AVgaqSNKPrk5MQFWdyLAdsjEo3uW61WTd\/XKB\/38GYAegzkg3fgBDETAOv\/LOUwEOM7A7pKOzjG0TlLRnwN6\/nrks4s9eA4zw4gAfEMQBPaSiaYGSAqLvoVUEKXzzsPLY9a1m9tBRCdDVMr8+u8APIAIXG8JIC827FhZzvIRmEGkXQD8OdRy2Zxy8phNxDOJEvsVRwF6QaEw8BdFEW417CzbZOkIhAmp8tiGK4pyzJsnnNo0\/i78Q9ryKxXs0zhAdfZ2VkNrHQ\/71OQw3e+P45BA28CY+jm+K5ArZEwSzf8bID3Jsev0f8mxs8aOuv1LNN4wM1RtBIGJJwmkFcZSGWl3d3dRjJC3sBz\/7CdFO\/L0pUmqWED1cQs\/2YCgOyiswIGVXXacCTOVk3V59fZPz03DxMAk5DmIPhefA3GOskSy7udED3HcWzDznaVCO52Agnk3U4ggItBFGScfmsrfEdkjw2gXPTjWtQP4J\/FraDdXwyiIAONRiMbjUY2yZKay2c6nYaZQdGPrejHNk37lUyVVHZTJIfLQZUbuLq6Ctfz93sJaPlR2yFAgoFRgYrlhXa7HVwmAFG1LvL1DLCaFAVgsa6O8xnsFGDXPYeTuzjO0fsfPX5+po5f77mJ8avtEiDJxKAyDcsr7McHiah1k69ngvHqAjSvgPMZ7JVg1j3Hm7nwc5gA1GLZBNzrCECjc8\/Gie+cZ1D3j0cCrP9zNA+ZCdKREppHang2ov\/p9BpgA2B3Hl5vSwK4GES1mgFE\/DwD4MSwbrCIYmYA++fFIAoR\/CRLbDqdrvj9QRCYITCxgIRABPNisHK9bvczgK0qCQwA9CJKTVwqWMEjz4lJyCl8rgdSKmFAsoCswufwXwY0fV8FO5Y9GBy5SOo2x396elobP6QjHqsS4CbHz0VXXkStiVsFa9QIcGIW5KO+fG8GwBIOJBvISnwO\/9XEsJKIuoaY0DAmPOcmBMBROCQgXOeBvcos3ixBbaNaMOY5jZgAmFC+2HlQ0\/YhB\/GM4OXBn1dqAPYffWzzYhCidLhtij7NAogI0qgCf3b\/DDvb1mp1ai4bALGCMoAZ+jwnl\/Ee8\/nc3pUXdjnJ7c24qCSdpdUTnn4QAZLFkKPKQRrOfx\/wX05ymw3TewLgilIGPP3LIMhOEk0yckLUk3lY1tBEJgMT6+p8Hr9TE4nwO6stEtEvLJy3PX4FYs4dqISDmcMmx88RPAO+\/mXQZieNJlk5IezJPCzraCKXgZnzCnye5yZSMuB3VlsovzcTgNo4Pf2fQVXBGfq\/RuMsyWA\/zmNJRyN1ADnsoJwA1tnEyZMH9s+vntTyCxiXVwDGBIAEbJ7nIeGadztW9CvNHyAPEgDww4sPu2aSXFs4odED9KdpP1QQI7pPkgr4USOA6B\/J3CzLwqwDGxxL4\/HYRqOKELS61wP8siyDjfTq6ioUk02S7j0BQPqA44SBT8FDQQgAiDYEXAyFTTVrPg\/ACxDj9gX6Pl50qyCoWnfTePjdb2v8GJtec3R0tDJ+AD+O3XT8OrbbGD+kHzhuGPgVPBWEAaRow4B78KaaPZ8H4vHaN+j7eNG9NzPR4954+N1V02cZheUfBtUvdirAxcbRt0bgfK2CMGYc\/Fy1lTJ5PHv0p5rnn8EcBICxaJL6n189qbW9YAJIkswGgypxOp\/Pa3mBUKG7lFkA5gD2SZYEXX6SJZWddJDafFRdM+xsV+0ZOtshocszACR\/ofXPhqmlUSUtgTDgQkI18XRagToSuU2R\/tXVlS0Wi\/COODcQQJbcEwBAWgFEfeoAD\/TGwf9Q6xwrLHV4BU2cAwAh8D29c5hUmghBo3bvO7T22xo\/zuOIv9frrYA8no2\/PAtYN34G89scP8szKtmopg7Q5r5A6xw7rPV7BV2cA+AEMO7pncOk0kQIOmvxvnMOgO2eHIUDSBk4Ean\/55unK5IKZgl8rjqAOHoHCOtxOIm4RQXPFthlhGt\/ONxZsa1itgH7pzcDKIrCBoOhRZ3EyrK08XgcIu\/LSV4jhNkwDT194LyZTqcB0LMsqyyiZRmi+dFoVGn1y1nFfD630WhkSZKEnAJI4O3rUejhgxkDZCduV8EzFI8AdFYAEsG5GFPRj+8JoAlE1FuuoMebgj0nRQGaXmQK3Z0lFUTADHKexKI9dBi01yVuVWu\/rfFjjAzquM4DeRzj5PO68auUdFvjf19UzclUBn3eFOw5KcyRvkbmyDuwpIQZAIN8k49f73mTxLXmGmAD3X\/08UohFYM5\/kK+QdSPSB9SDVfaIqr3KoAhGTEBaI6AcweaI\/AIgIlL9X+8p+YHELUnybLiFpLLsnBqNptVrp8lYCIahx6fZZlNp9Og7U+n01CRyzIOZhKz2SzUFADEQTCTLAn3hbaP8+I4DrMCzAw88J\/NZiGXgRkCxsSzgvF4fE8AW1tVIZgXTep31qPRJRMgwiAGHZsBiROkrFO32203+mVgVncOR+gcGTO4NSVuOarGc24yfgVrb\/xwAwGs+N9CQX5\/f792Ls8qePzcifSPGr+Ca1PkzHq8duZkBxF0fAZkrjRmnX53d9eN\/tFfCEDvRfQ8o1A3UVPimmcVeA6AE8VVasPUbqGYAaCCGEAPaYYjbZZ1NJnMThydAWjdgRZ4MYh7BMBFYUwYXluJvNsJlcDz+Txo5gzwAFBE0tjHjhzUE0BGyrLM8s7DWjsJ3DuKOis5AMhAb1+PLM\/zlSQxNrwTksDw919dXdlsNgv3hMMICV+Whf73ah5mO5vG341\/AFDYAG4aESuAA8w4kQpwBMAxyOkzAHYcXXODNo6o2Z\/P78WkxJFvU+KWwZFdQDcdPwMy3ludRBiHjl+P819v\/Lyfx8\/vdxvjb2q73KT9e5ZNtpFyt06eNXhtnZFAVvDnBm7aT0hnEartr0tcMznoDABgqgTgFXWBANTL7wEsJ2p1BqAEoNE\/AzwqhPkZLFvxODQBjJmCFr19sfPAsiwLUs\/V1ZWVZbkE+iz004HMU+ULkpCoReUuN4u7nOQ2nU6t6McBgFHghd9ZloX7IKLPu53rPMBsFpw+OLf6mwUXEGYLSO5C28fGuQbMaDAzAdHN5\/N7AmgCPC\/pqjICvORe22QP0DywAwgCkPh+6qNnkvG08fclbvlcgPdvHT+u1Xe+6fgZ\/N83fswOlHxuc\/xNgO8lXVVGAQF4baMV0JkI+BhqCXSdAeQB1L0DwmBn0E0T13wu3l1BUQmAu2cC0HkGACDnQiu4d1h\/ZwlIvfjeDMCzi3oFYDiGHADnDHTGwDZRjINllMViUQPcNIpWunJCtimKIoA+JCImAr7vbJiG2QDr8tgQsXPR17vyIpAAZih4D8g766ye4\/E49AOaF4PQ6wjvXpalXV1d3ROAB3hNCVcvMaoRK7tdoDWzRMFOINxPXTAAUk4sc\/TKrRW8xC3eQ8GQ319zADcZPwCUJZudnR37r8937dvDZ\/b9l8\/sZX\/Xvv\/ymf39q7\/Yy3613zv+sr8bzvn+y2f27eGzcC7GzzkUgD4D\/W2M3wP8poSrlxhmgGdXD5LCaMXAMgzeH\/dTFxCIhBPLmlNQ2UclJ00G6\/t7MwAGc00Cs54O2yVr+RxpIwJXx85NCMCrQeBcgc4KsCmRgYDUAspEtP\/o4xULJUfOSZKFBGySJCHi5zbRaPdwMajsoq\/iqJacXSwWVpZlLcJHtM6Wz\/F4vALi6FOE\/v2YXXjgr64g5DbgZALZYI0AtITeNP5u\/KM6MQM1A55G4xxFAvxPT09rwA4JRCUcSBLQoptW5dIe+\/jLmjgf5wSpSiOcoGbwvun4OQLnDQTw\/ZfP7MeTtv140ra\/f\/WX8P37L5+F4y\/7u\/bTd8\/t71\/9xX767rn9\/E3bfvruuX3\/5bNAAt9\/+SyMH89k8NeI\/veO37NRsn+fk7Vq8VQJ6ODgoAbsWmXMRAJi4UIylZDYVsoEpTMWnZ3o8zRBrQvCcH9\/baTGET0IALZLBlO1ZuIYR98qAyGhrLMD\/a09\/pk8dFEZLVpT\/Z\/lKCYAr1hqNBpZFHWuI\/WiCMCN1tDcHiL0+FkSAKJuLMbiAXxRFEFiYvfOb9lQMDYvBrV2D9D6kYCeF4PgesLzNo2\/G\/9wZKgg2GRj5KQokqAcyeNemgNQJw8iUUT9LK3gmQp6eK\/3STSsjyvwsTTze8aP+3x7+CyAPSJ5zAJ4BsCzAo3+QSA\/f3Ota+PfjSUqHffvHT9HxkoCLLdo0hVACr1eE7Mc0WurCY7a2VnE5+OZTQnpJomKZwhNiWuWpgCciKq50RuSupBUWF\/XLqIMsgz2ni2UAd4jAHbzMNjjO5OCzgC89hOcA+DZzBc7D9ZWyiJivk4AZ7ZYLEK7Bm7dgHYQ5SC1X\/pVkRh799Wfz1LNcHhd4atN29YRFJaB5MVnGPybZhtJkt0vCIMPonYvsvSiYQA\/SzUKkHwvjuybHD1wy7CGrq0PcH6apiuavW7ec\/hZ7OC5yfgZQD07KEfwAFaAO36\/7zhmAz9997yWM9DNm4Xov8dvGT+idtXKGah1NqBSjRKE+u35Os\/RA0cQ5xC09QMndL0ZgJcr8HIanHT2CIC\/a9QMMOeZAM8UOPpnCygTgII\/tH19NjZdI4BlJyYBFILxal+aAGZ3EHIAHrjC\/gkvP4qzkiS7tnMuawK42VtoxzBKg3UTLiFP4vn1chpW7sL2PhIAecxHA5sk3ZD0nSRdG41GKw3fIGkhhzAYDG00qpxGxezeBbSlHSc9cFYNXIlA9XMlAAZSdaowyHNUrYVlfH+VRPS5nDz1jkMmAdH81vEzCbTb7RD1M8D\/9N3z2u8fT9prj\/9rcGA\/fffcXvZ33cQ5ZCgQkZfs\/X8Zv3bc9MCZwdSLqDV\/oATAMwp16jDIc4sG1v8VyL3ZhM4quAmcHucENhK0DOjcHkKLvBDd8372\/quUpDMABmiAe9MMQKN\/Pk\/bSkCSUmLSymNIPzhPZRcUY0EyQfQfRVVlMPvqh53t4M2fpv2wSpcWiCVJEq5tSthykrcoisbCLmzzUbUIzCRLQvJ6Om2eMcDaihwCnrdp\/N34Ryt0m0ADgM9ADsBWO6KCJZ+P75B5lAgQmbIso5WvXFzl6faad2iSnnim8XvG780Azs\/P7b8+360BPP\/+6bvnK8fPz88DAaj8o1LObY1fK3SbQBOAr8Vh3AvIs2myHMPfIfMoEXAhGO\/n8\/hdvLyF5h2apCdeElKBXgmAwRTtFTz3jzqGdFbAQPy+JDDAWmcODP5cmIYZBFcEe\/o\/P\/Pq6qoWNYdq3KVtEuC\/F1cRNhPAbJiGhWGmad8W\/ZYt+q1QMAYJCa0b1jl2IAHFcRysndNp1f9\/OCxcEngzLkLhV5ZloeeP1xDu6uqqtqYxago2jb8b\/3CvHs9Rsi6KB4h4koQH+gxkSMAq8EJaUYDD7zRNa2CswMaJZyUhHEf0yxW3Nxk\/348TqezuuSkB6G+WgCAtsW3Wk39uY\/zcq8dz1KyL4rkQTDcP9HkGgbWElXg4H6CJXZaAuBJYiUqXoeQZA+cuQAAqvXgEwFLOwfafVvZrnx22gHr3vgkBAKy5IRz283etA\/DWFGY3Eye95\/N5AFcUcYUq4GFqUVR1+kTDt18vq6pfXpXrl34r9OCfjwbBp8\/LPHoyEIqxsMhLHF93JEWTuaiThCplj0Surq4CeXBuYjweB2IDyWHdAax1kEbRPQEAJBTgPPcOR5I4D156Ps5Az5ZNvr8SACJ7EEC7fV1N7M0eeAahETmDJ8821AGDHMC68Tfp\/pyv+PHk2s3TFOH\/9\/DYDvefNB7\/+Zu2vezv2o8n7ZX31\/ED5G9j\/OySUY3cA29OxGoSuEkq8u6vBKA2UK4m9mYPPIPQGQmvU8CzDXUAPX782P7zzdOVGQBH\/V4+4GD7Tyuyj+f2UVLgfQzwTAqe\/OMBvto5lQBwDr8njvEzp9NpAH2unJ0Xg1DpmyQVGOd5HogCXUEnSdfKYdfmozS4bFj3X+fX56QsiACLwXDhF5w7TACYVZRlWZs1ICfQlDtAQvieAJYfrWxl4GAg9xKh3AvHS6J65MEg7sksTdWwbBfl\/+kVjLUwiwmFgQ\/bbYwfMwCWgH7+pl0D+DzPVwBff\/\/9q7\/Y37\/6ywcdP0fsCvwM5AygmgRWrV5JgMmBQdyTmbR4TJ\/FTiHtS6SFZCCCpmKzJgJQKyUTAIAZSVUFf68Hj+YLVOLRGQBr9Vx8xolfvQffl6\/jimV2D4EA4JUH8L59fR1JR1EnVNsiMmf5BYTxZlyE1hFxHIdZA+yjfJ0mgEejUYjyud8\/NPokyWw4LFbugXPw\/kj2rrOSXl1dBVcTmsptGn83\/vGiTUTeiPS9Ns\/czuF0jZOGJRMmAs+qqNGpbhp9N21N1zfd87eM3yMBLwn840m7FvGr5PPjSbtWSY0kMFxAH2r8Gi0DqLl1Qq+32uaZgXmdk4iJg4mgyarpgbRXbbxua7re2\/7zzdNa9ayXSFWJCElX7bDJBVpKAEok7MXnGYcSAJ4NEmBwZ1Dn5DJLQEoA\/G5fP\/0krAeAlgyYCUDDv4klsyiKEK2Px+NQO4Bomxu3gUw4+QvQT5Kq1xBaQUCK8hZz575AeE6WZaHNQ5N1FDOUOI7vCWBra2sLkSZkEHbFALDViqmSjRIAAymAn\/MHnlSE40wAmF2gejjPczs9PV2xn6L4jJ\/F17HMg378OtNYN34Gfo2+2+128PyzBMQJbU\/yUQL47+FxIIEPOX5E2pBp2BUEwFYrpko2SgBMJOzG8ZLF+I3jTACYXaB6+OTkxA4ODlbsp71er2YP1apjlrl6vV5tpsFJ4KbVwFgK4mZwXn9\/gKw6gHA\/uI64jYMSAPfyYQLgnIDu0xkKP08JhAktLK6y7McDz\/77Wi3wTABRPsBXq3UxUwBw88wCbSeyLAtOo18vq1YQXgQ\/LwZBeuJGdUgCN71nWO5yWQWMZ24afzf+AfgxkGhBkVoI+TikHLZScjTP4O\/JQgAt\/g2AOzo6qr0TA6GuuatuHSYWtJ7gdXbxnN86fi8n8ONJO7R2YElHNX\/+\/fM37ZAMZwL41+Dgg46fi64ApFpQ1dQqgm2gbCXlaJ7B35OF2NOvOj6qgbkmAESA\/V4RGM8uAPrYOKfQarWCfZL98Qr8HG0DYP\/zzVM3+csSi64XAFJgGYcXdOcNwM5ExADObiNu+sZJYk4C41xdo2CSJdWKYN1O8OG\/Ky\/eSwDIE\/BSj++7Bj2BIBNBurmc5MEBxPZT1vIhNU3TflichhPP3rPR+RPXJ0kS5CkkjTeNvxv\/MPixhMPJQ5ZEPJBXzz6Da1NDN+83AxNcLohgNWHsFYjhXEg6HMHzugN4f42i142fwVVJ4Psvn60kgf\/914Ma4J+fn9d+\/\/uvdUno3389qLmAVJL6o8bP4M8SDidPWRLyQB7Xqpa\/u7vb2NDN+83ADJcPInhNGHsFYjhXXUB4f10XuNVqhYhcC7U88OfjvCCMEgAidLaFcr8grexVmUjBXpO7yCUoUTAB4L293ASPCdIPGrKVZRkavrGerlbRadoPC7dgm6Z9ezMuXPAPC8t0HobngXCm0+nK8o\/cZwjgrwvMMwmUg9R9Nr832lQjPzEf3RPAFkCWAQLgx+Csfnmv9z0DP65\/X3KYo2wmFUS\/TDh8vd4Tz8GyjHgvfSYncyGxvG\/8XIClydd2ux1aOWgSWCWgdTOCf\/\/1ILiAWCpR0rnt8QNkGSAB\/gzOWi\/AyVgFb27\/8L7kMM8yNBHNxKKykd4Tz8HY8V76TM5JgADYP+8lgFlWAcjqimBMEjgPJKDgi2QuJ3D1Pgz2DODsMPJyBewS0tyEOoi+2HlQW3QFC7Zg0fd1i6ujARyvD6BR+7vyor7GAK0MxusJpFFUW\/d3PB7Xeg2FlhNJt1qkvtuplppcLlEJFxIIAHITbK2LxcLm86ovEJLLeZ5bObhfFD50A1XpQ8Ffq2UZrBX82VXjgZU3A1ArI5OOkognJ7HuzbUCDOAeiP+W8TPxMdFxj591EtC6QrB\/\/\/UguIC0FfQfOX6OoD0ZhaPnppYKCv7sKvLA2psBMDgjsexVKHuOItX9uVZA3UtMXLomsCZiQQqedMJrATdp7JoYZt2eJSDNJ3AiVyN7TU7rDE67tEgAAByASURBVEBnIHgHJg+erSAarzp+VoD8Ko7sl34rdO\/05BXIPxeDaG0baOzjnkHDzrZdDKJqreGlGwftp9GCmjuOotHcJOkuW1IktYXnIQGhayhWKIMzCPo\/EsroMjob3hPAFkAG8gGvGoXfmmTkKJmBkDV1dv8oCSjg87laWwBw43uoHML31gpitZoC4BGd38b4X\/Z3Vwjgp++er50B\/HjSXiEEbgWh7S7+qPFDKoF8wqtm4bcmWXmWwBE\/vmukrSSggK8gzbUFmkPw5CC+t1YQN7WnQLKZi75YflHpxyMAbfUMj73KL+rUUQmoiQA8rd9zJHGugJPE6v\/3iA1eekTdWZbZsLO9jKoHteKq\/7kYB\/CEPIO\/WBISOYTZbBbyA6goRuIVa\/vCJopZARMAvqfRtbwEAuBF6HHfxWIRHEZwBXEb6CjqhFXP4HS6nOT3BIBWz17rZQAjHD8M2PgOtwpHq7hGZwkavep9AQrsgefolYmDgY0BDhKIAqDXzRNA+3vHjzbPP3\/Trtk5f\/ruedD2f\/6mbf+dHtq\/Bgf240k77OceQJxI\/lDjf\/78eU0\/V1CFDKNRPb7DrcMOHFyjswSN3vW+7NX3VhFj4tA2ECoBKQF43UyZAFi+0YVVdJ8SgFo0sU+lG+4syhIQ7uWBPSeF1f+P+3I\/IZWgdL86mgDe5SANun4aRaGxWx61LIu2w2\/INvDwYxF4RNvIJeR51aANUtLlJA\/A3Un7lSNnKQVBIgLwY91hEAU3fMujVug\/BPBHBfG78iJIWmhDAWsp7ol3xLoFm8bfjX8AgOx75ySjV4kLcEQEzCCKe\/H9mATW5QS4EKxJB9fFUbyIXXsHMfhx4zkmgN8zfiSB0c4BhIC1AbAB9NH6GSSB887OzmoE4P0b3Pb4QQDs++ckq1eJC3Lgtg08U9D7MQmsywmwPZOLvZpaTTTNWLR3EIM\/N55jAgDA6jq+3gIxSMJ6BMCaPQMwCKBpBqDRf5MDyCsMYwJgmacpN8FEA1sltmnaD+v0oloWydY34yJE6FmW2d7eXlgZrBxQa+g8r3T2ZYfQ2WwWzgNAQ\/d\/+7rq\/jmfz4NHPzx3WUvw6+XUyjwJuQnIQbpOMWoH0FYCx7CgDWYTk6Qbtk3j78Y\/vV6v5oDhHjwsP7Tb7dp+7MN+dQJ5nnqdCXBSU6NqbX2gEoiCNhMKLI+I3AF8al\/d2akWhf8940chGACcLaFYGAa\/0e4BdQM4huTv6elpkJE+1Pjx34T1f7V9Qu7RHAAAmqN+vk5rCnQmwE4dnVV4\/YTU9aPr\/PKshWcumsT2JCBuu6yJUiYAfGf935N\/PFsmdwoFwCMJ7N2Lo31OCvM9sKkDSIHeI4D9Rx+HxCj6+Q872yGyTpLr5PCbcbWMYhpFlncehpXC8jy3d+VFJelQN1BYNdF6GTUGAGgmA2xoNIfoXou4sPAM2k+8GRch0astKBj4Ef3v7e1V5LHMH8zi1j0BHB4erkTrnmbPCVOVbDwLpUopKp0oAaxbqUvfpykpysdY1tECLq6E\/b3j5wpcHgNH67yP\/3obCPBDjR\/RO0frnmaPxKxG9WwD1SSt6u6e7s9kwMDMkbu+T1NSmI+xrKXtI7gSmIGTQVb76jcRAFsxPfnHcxCxGwdtJdT\/z5ITJ3r5eiYCbUPNFlZNKHNeAFW3aOkMEkDEnEetSucnkGWNHm2fcR0idIB4WPQ9z8OsAou0h14\/S0nGSzprf\/\/\/uRjX1h1AJTKSydfrGF97\/jE7SKPrWc4sbt0TwNZWVQjGQAL3iYI3R6UMfqh6VUBq2tTWqK4U5BRAKup3VzDU47qxtZPfnauAf+\/4WX7hOgbISbivgrGOH9d8yPGzXRJRvdo3NSrnNhDcutlL8urmyTmcREZOAaTirUPsJX3ZCcQbW1v53T0CUAkIgItzvJYO6+QfBlqeEQCoAe5MAN69tP8PvyfO\/+Fwp7YOsGcp1ZnJ\/qOPwwpf81HV1rkcdoNTB0VXWOZxMBgG0IY+jwreYWfbZvG1RAOCYMmG1xNALgD3y7sduxhU+QIGfW5XjaKuy2JYNZ8bXRMG9\/fJu51QbMaLyud5Ht4HtQubxt+NfzjhyFZOgCDAi89j8NvZ2XEBBuDEUSw\/5\/T0dMWeyC4groDF9ax1cz5BQRFAC1DkClro40oCv2f8\/I7e+PE+mOko4HPtw4cevyZc2cqp7Rm0ORtA1ANYtY8yuSDy98gAZIN8AtcBsNbP+QQlBdyb5aJer6ogRn7Ak4DUZ68JVyWAJpcQE4BW9OI8OHWw0hi7eJQAPElI7Zy6RKXX\/4ffC8SBoi4UU2F1r1ncsstiaHm3Y3t7ezXtH3bRKLqOuJEQRuSPWQCie2yXkzxE\/+g0miRZcAVxHcFN1giG82c8HtdcQSCW0WhU6zI6nU6DO6jox\/cE0NRwTOUNPqbXsLTBmrOCk3r+dR9+7+\/vu3UHTUCoyVl+vlogAYa9Xm9lHLc1fshK\/H4M+PydZwWbGH9TwzWv02ZTszUu3mLN\/X2ef92H361Wy607aCIC\/u3ZQXk2AzJot9u1JSF5gRWO8Flq4UQtE4QmbdmCqQuweP5+zUNwLyGN4D0Jibt7ejMArzAMz8nzvNa8DeCNpO94PA6JWVg2sTxkGkVhVTC4ggCsIJVXcbQC7uwIQjQ+G167kLw+QE3VxbNhatPp1AV\/rBKGhWW4oyhaWWwafzf+AbAhGehFvdiPHjSI3hkgOeLlqF9lHwUtTyLCrII3lWUAbOqI0dYRHEHz\/XgGcNvjPzw8XAFrzgsAsHTcmxg\/gJ1dOhr1Yz968DBQY+OIn6N+lX1uIhFhVqERvfr\/2Uaqur\/2LlKC0BkAu2o0wsfGBKDSERd6MQDjuPYKwj34mJdL4AZwmgPgFcG0CliXnlQCwDsjmVv0YyvLMnj3NUHLTdeQB9jb27O889DyvIrq4bzJsiwkapFXwMwAlcGzYRqIJe88DI6geTFYIYCmmUBwEC3rF7BuQZIkgXRwLayqsJTO53Mbj+\/XBA7toAEWGolz8RO7TwAibANVTzqDPUe8DEYazQKYNJHMAMjPYKnD88V717PU9EeMXwvGePzeDICPf+jx8+IrDJTck8dz33g2UK\/oShO\/OivQaB7ArIlkJgDtO9Sk\/zddz1KTOnXYycOAzvt4hS62Z+oMQK2Z6gBCBK9kwgSA87UOQBeF5\/fSIjYuDNPEMoqwEC2Xg2ugR6tmyCZw7oxGo0Ace3t7QWvHVhRFWH1rFlc5BK\/BGwq2AP43ifo9EsD7J8l1S4q82wlJ5cViETYsF4nWEpvG341\/GPwARgAQRKkMfpxcBIhoxK\/Ax9E\/EwDAkq+BxKJuHF0bl8HUe3dOjuI9+DtH+Lc9fnU86fh5NoDz8P1Dj5\/Bn6WWFy9e1GybXmEVQFQjfgV+jv7VJaTEAIlJ3UhNswdelJ7fnZPDeA\/+DqLRKF8XYNd6ACUASClaP8AJX2\/GoDkBBnO2o\/Jvtn3qhqieCUgdSFyhDAKAZBPHcQDnxWJho9HIOmk\/OGpQeTsvBjadToNLCHmAvb29kAtAlI2F44ed7VpUj2pctG\/2wP8m+j9IBMloEAkifc4TwB6KXECeV3LXpvF34x8ACEe+p6erBUZelAk5QwGUwU+TnV7ky5EpF4IpaOl1\/HwFRva98xKK7LrBc257\/Jrc1fHjGhzb5PgBoBz5ewVWXpTNCV8GYU0Ia7sHBnyNzLkQTEFbr+PnKzF4vn9+pyYCUAmFo+l1MwD12Ot9vb5CXm6BI3aWnfTePLsAAbDbSKuHdRaD90aiNsuyGhCXZbmS8IXEA+snrJUggKIoQnUvkrKs\/6NXT5CJltKSridQlmW1SE1RrF3ghR1AcA+xY2g+n1dtpgdpaDcN8MfMZtP4u\/EPJx8BOCgkYtADyGhLAfbH4z4a+arsoVEyImBIKurOgTsGUgu7iLilM8seHJXzQul4Fwba2x6\/bjp+\/bfY5PgBoByl451UblFgRcSuUotG\/ojUvVoAJQtvSUjeuCcRCEPfS2sIlIj4ORyFA1DZ4slAzuDJMgp+K0DrtZxs5pkFJ6JZgmJCUkLRpDGienX68OIxLAPhWhDAaFTp6QBpROlYpnEv7tpe3A0J47Cc41IGgkMIgA8ZBu0X0EMIrRhCfcDy\/KIoApBXvfsrPb8oisZZgtf6+erqKvQ2Qo0DchZJkoQZQNGPrSiKewLgZm6IfD09WTVlSAy8ahXLEBw1a\/QPENLo2HPY4Bw+F9ZRAJmCKZ\/DrY89C+cfMX7NG+j4Gfg2PX5u5obI39PTVVOHxMKrdqk9k\/MK2s+H2zzguOcwYuupkgvnIHQGoMTB6wnzcxRYGUR5v0bPPxzuvFf\/90Dbs2NiURpNJmsEz5IOzz64EAxEhIVnNPmr7qWiKGpJXl696+3rUQDRPM9D4hckgOvQoI2XWkS7hyRJAvjHcX3tAc4\/QF6CdDMej62T9oN1U2coCvy4pizLQFqwmCLyH41GocEd3mPT+LvxDwMIt3NgDVm1b+xHBOp51hXwcQ02RM8MapAlPGumZ7UEmPF+jXQZQBX8+N63OX6N\/v9\/Hj8DaK\/XczV01f5Zl0fRlrcimFo8tViMn60FWmpNVaspgznv10ifCUTBH0ng3mcfrQCsgrcSAFspPWDX5DJ\/byIAzA64hUOT3IT6AK4E5vtiRqAyEo9r\/9HHwbrJgA6gxSwArRX29vZsb2+v5q9H\/34uvEJxGK\/6xb3\/ud9PHFdVwpwMxlrAWPA9jmPLOw9DUpflH3wfj8fBTQSHT5IkoQYA74XxYjayafzd+EcbuWkUi4gemjhHwgBA7TPjyRwqp0DKYG2bo2BtLQ33DS9vqKDM+vrZ2Vlt6UR+NgPtXR8\/ZBWAuJc0BfBzdI8cAHv2WQLyFprnmYT27NccgLaWhvuIZzlKSpqT4KUj+dlMNKzve5ZLngloQpjlHwZ2XvhdI3ZPTuIZAPIPXIPgFYThN96ZVzZDozqVtHRxGk4CIxKHdAKdH\/o8gziiadbXoasPBkMbDIa2t7cXJBfkEyDDcBfPOI5r4A\/Ax3OyLLO889CGne2VJSLH47HN53N7+3pU2VE7D8OsAmTE6\/9iTYCyLMMzN42\/G\/+cnZ2tgJ8mGzlyZQBEFMsOmHVJX71eXUAcBQP8GJw5WatgmKZpLdnJ0g0DsALtXR8\/GrlpywQlApZ0WNqBBMTSTlPS1\/PnKwFo\/YGuVYxzlQxAKFy3oDUAXrKZgdlz3vB+Pq79eThxzBZOrvjVFbk8AsBawkwAWhCmhAICYNICoTGhcM0DrtM2z3meW55Xa\/RiDV80aruc5EsHUL3YCks7Yj9+I1eAGgEFfz4Pzd948RichxYRnvsH+QUUpPVbW5ZHLSuKIhAPSG02m4U8wXg8tjS6bwWxxb52BiYGMK+qFxExQJSTu578oRo1QEp\/I6rmhCzO09wCvy+uVcDl+ysIwsJ5l8fPvn4tnOLEq\/r3MSNA4zZPe1cy0U0re3lWwQlpnKe5BXUmeYTD91cSgASknn+WcbyaAAC7Vv9y8thrAaEEAJ0eBMAaPkhD+wGpA4gTyfrefD+eFTCBTLKkligNOv6yuAsrcuG8eTG4XlZx2fGTW0QgeQs7KPr8c5EY+gBhg4WTwR0SDQAeNlJIUnAT5d1OWG4SrashFaHTqWcpXSwW9zbQra2tLa+NMwBCo18GEW58xoupeNEuA9A6gAKAwgfvJZcZBHUDAPL5Te+F59z18bOUogCp0T+DKCJu5AD0HM8ayhKRB9AgENQBeMllJgHdtNpYC9L4vfAcRM4cWXv+fQZy7hnESVf14DMBcJsJtYbiHb59di3frKtDUGsqZg5MREwAkIX4PvjOq3JFUSdIKJB1rvX0St5BxI7IvMyTmqsHJFAURdDzOWkMxw\/qDDppv6btA9iRKA7rAy9bU+A6XgAGiWgs\/whZCFtTfcFisbgnAF3ExVsgHaACAOI2w9DAGeAUdLwoGIVNGimzY0Utl17Uy8DGEfC6KBhaOTddu6vjh3zCGrsuEK\/VtgB8zgEwwCvoerMAtnIqQWh1sQK6J+8wAWjiWWcBLDVpVOwlgJUMGEQB\/qqzr3PwKHg3EQC7kfBM7hzKeQS+hsfkuX94VoH+\/5MsCXIQovokyexykgcyCL39o1bl2hmldlkMwyxhPhqExC0qf+fFoBb9c\/4AEhDsp79eVgvJ4x0ww0D\/fqwnkCSJddJ+JS8t6wgwA0G9gtYPsLSE3ME9AWxVEpCCCiJP\/qsRLdsQGYiQhNSokyNPXO\/JIohMT0+v1+nV+3AkrqDKEbC+s2eDvOvj16ZpnFjlvxrRswuHgVjbS2v+gPMDniyEyBzyj3cfnonotTwDWPfOSAJ7BKAW0N5nH600V2NgZQJQ\/Z8BX1f58ghAJRxO2nKegUmBCYClJYyF5R99R7RuRgO4QAJLUC2KIkT\/8PkX\/djejIvQlrnMEysHFRnAypnnuQ0Gw9CITdtFAPx5ScdQKbxccB620SS5Xj4SdQq8LjCS1ZCiptO6RRTFYto1tJjdu4BqBHB62txFkgEGIIKNgYgLo1SzVqDj6BTfcW\/W3rF5fneALr43rejF2jxHwHd9\/EwA7O\/3evqo\/RIbAzEXhnn1ADoD0DyB9hdSiUcJA6TD0b1KWpqb4BkAJ0+xaTVv77OPViJ5Bn4lAAZ7juDfRwC4j3cOEwInppUAQCL8fMwamABwjzxq2fb2tmXRdgB+\/AVIYx2AOI7Dwi+IvHnR+PkoDQllloJAAGrHxGIwcO\/Mi4EtFotAQtO0b4t+K5DAJOnWOoqCONgyulgsausJwC0EWQnPTZJq6cpN4+\/GPxr9AmgYFPW4AiFHqgqADEgajaoLBvu5J79Gv5pgVbkD0oqCLqJ5fO\/1eiHSvsvj1+ifZRxPcmGpBWDNkboSAAOyRuNeLyBIQOwm8nR+jwhUgmLSUSsrEtg8AwDQKylgP4Cz99lHIarWjaN9nklwzx5NKAOgOYmM67QOgJvAeTkAfr5XmObNAKKoWs6xWmSlAl7u8w8C2Iu7YYEYgD4i\/NGoWlcAbhzMGnjVL1hFuWKY2ziDUDAD+KXfCmQ0SarOom9fV0ndamZyncBGgRrPJEAA6EvESW4sF7lp\/N34R5OSACKNYptAEBo4R7CqN3ttonEegBDPRmQKKyRvAD9eGB2Axu\/lRd46Pk623uXxeyDL8sn7SAA5AI7gVW\/32kRzbx6eKbBHn5dx9NpCMLjze3kzDx0fpCZPAuJ9X+w8WJkB9D77yP751ZMaCSiwctTOFcOevAPC4WPc8pntp2pThdtI21dz0phnFVqodjGolmJkjbzMkxC1I3JHJTB0edbTx+NxaOWAZSGTJLOoU60NXPTjStNfFn8V\/diGne1aLUCSZMHdg26daE2NGQFsqJCjyrK0d+VF8Pqz9AP5Z7FYhOMoREPzuHsX0NZ1KwgAC8sEABoAiXrSAVZ8jVfd6unR6GHjJUD1ntzWgIFMwdoDat7Hz8O73\/XxayWtt7Hzp9e79uQDrL2WC6y5e3o8evh4CWC9p75LE1l5RMX7+HkqATUVf3kS0DoC4EidwVhX+eJjTABKGAr86kJCtA8bqMpDsIAqAYAUALb4Cxnmf6\/mVpZl5RBaRu5Rp2rvgOQuHDhvxoXNR9XC8fNiYK\/iKAD7q7haVxjLQoIQ0CcIuj02vu9sWOUX3oyrfkCcPNZI39sY\/PPOw2qhmmXiGGPeNP5u\/AOpgaPKddEvWx4RRfIKWgqquH9T9A25RVshKLDhWpVSOArWqJf38bNZA7\/r41fwf1\/0D7mHvfS8ghj\/5tYMXvTNoK6tIBTYPSsoA7oX9atlVPMYjx8\/rhVhqUbOIM3ADQJg8IfE4hWIsSTkVeMyQOvi9FqEpnZSVAQzifAiMXhH7nHEpMCR9myYhmTuYrEIhVQA3ahTJVqRA8C6vNcJ4Qq80V4aMwYQgG6QdVBtDNDHer34PS8GAcgHg6HFgzTMFgD202nl+1f3D5rSoZjt3gYqH9W7GfC0Bw7LGAyATf1rFAzZicKNzjx3ii6KjqhVI2AGPA8QVXfXZ9318avez4CvPYBYxmECaOrfo2TAswLt9qnunF6vvig8onbP\/6\/RPYO\/5h30Wf\/86slK0pQTpprQhSSk0T8Du67fq+v88jP2H31cKwTTtYmbon4lKCYAbirHbSW4jgAzAE7movoXgMtVwUVRWNRJwizgYlC5hliznyTd0FKC5R4kYOE4yqLtQAq\/9JezA2oNjfNBBihM4x5EbB1FdTJsol7LaPQ2AnEgb7Fp\/N34h6NKBTmNgNkaeSp69U02b01drwMm3DkMymmaBgDUyl0vWuYNoIeNn3nXx89RtYK8zgDYGqp6\/U02b01hrwMoLzIDkD8+Pq51LPU0\/qYiMW4Gp0QD8OVEr0o0nFD9YueBHWz\/KcwAGFBZ\/+eI3gNkjwC4XQRfp03heLaB57HTh9tK83sxAYAwkGTlls1lXuUBeIWv0WgUCIDdQABrRPp51Ar2TV5sHrMELBGJc0EcF4MouIFQLIYmcCADOHiwwAsAH32LUCWM2YBXATybzYLMdJ8D2KoIQFsgM+gx+HHVLEey0L0hkbBWzr31AWBNvWsYUBXQuPjKc9XwO6vksQ6o7\/r42+12DfA92Yf1f3b3gACg+0Mi4lwBZiRcI4Bj2ruHCUUBHfdochWts66uIyrOAXhtFDwCwAyA20hwpa2uKsYEoA4gbwbARKBVx2rnxHl4H1zL76yuIJ4BlMtmbrPZLBDAbJjaL\/1WAOKiKGw4LGp2ULSAhusHwA\/Xz2yYWjms1gWGrPR2VslEnhQ0SbrhnpUFteo+Wls0fjq1KKpaP2CtAgA+3h0WVKwj0LSIDNYE2DT+bvzDAAjQ8BKLDDCcROS2BZwgZRDCtXocAMVJUHa\/eNeyc4bdLRyh3xT8lADu4viZANSXrzIKJ1MZVBX8vRYM3nEANCeB2f3jXcvOIXb3aNHaTcCfCUDbLChIA3T3H31svc8+Wqm8BQGw3ZOjfG\/ReOxn2ynAnqN\/Tk5zkzgmGG8GoDkIHiOIAbo\/pBVExwzOat2MB2mQXCo7Zd33n3c7lWVzNgz3K\/MkSEVcdPYqrtYNLgdpkI2wlgBbRdEuAp1JsehLKPRa1gKghbW2gEATuKurq4o87tcDqD5qQ4Qm3hRZesDCUS3OV6+63oN1dPzmBCnAyZNo+B00Uv4t4MfgfVfHr7ZJr5WD5+HXaB0AjfPVq6\/34DwCfnOCmDuCqkTF7+BJPzcFfxAASyscpTNIY80AzAC8\/vsggHUWUM0tNFk4tSMpP0v3ow7Ak600Cc3k9vXTT6zox6GAC0Vg07RfS9xCs8+jVpXkpXUAELWPRiMbDosQWU\/Tvs1HlYYPsEXFMMigzBMrh91AAnnUCjLQsLMdIv9JltTknPl8HgiH8wB7cdeKoqgtDYnkMq9JDDfR\/XoAW9cuIAYOBRSOfD1gYV2cAckrWlL5gm2WuH\/Til2eht10zk11+bs+fm\/tXQVUjvw9YOW8AAOyV7S1rugM92eNnlcsa1rUxTvnpnkJBnKdCXASFhH1yZO6BKSuIbSK1uifl4H0isOUMDT692YOTADejEMJQInk66efLIF6UGnw3Y6VgzRo9Gm01PmTbtiPnjwA+jxqWb+1Ven+RWF5nl8niEdVEzde9QvOHnzHfVF8djGIQi0B8gJwCXFED2cS9lc9gioi4loCyFFMAO\/KC3tXXtjb1\/dJ4P8DsdPurmWsvTkAAAAASUVORK5CYII=","codes":[null,null,[0,-1],null,null,[0,2],[0,2],[0,2]]},"startpoint":{"x":96,"y":96,"angle":0},"tiles":{"tile_1":{"src":"data:image\/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAABgCAYAAABbjPFwAAAAAXNSR0IArs4c6QAAAAZiS0dEAP8A\/wD\/oL2nkwAAAAlwSFlzAAALEgAACxIB0t1+\/AAAAAd0SU1FB94HHg0MIQ4C50IAAAbRSURBVHja7Zm\/axtNGsc\/0g1mCUOYYootliAOcyxBvKhw8RYuXKS44uVI8RYq3zJFivwBKVSkOK5ykSJFihQuxJHCHOEwhwsXJpgXcahYjuUQYQnLsYQlDGF4WcLgvWIlWfJK\/nHHG+uO\/YKxbH1n5vn9PDsLDb4djp+qcthX5f+VUq1NsGqgq8\/hwLT+pxQ4frocDoH+z5S4Ewz7qryswOW\/v5kgv8a6b5Ksv+Yh\/7U3biLcLAxuo8gq7rr1N9m3ve4LrSsrvNzrXLuJ1hcHXndof1hPUq1XC7uKe2MFHr00rUBD2DVrLTE7INAQD1TZC6EXrm84q\/4XD6oyOjPCbT3Rvkq7cFApcdXmANIHPzTzn7Bbt+qwr8rL+8ziPM0rg13ltXU5IdYtigeqTPN6XR72VTmz\/GITQjypfkkPyT6BVuT5svCBrnv5Ns0uHqjysjxi3QI\/NBCrlfEeDyprSH\/qAWUQ0qu+nEl9CYGu+Pl+v9TPhrdqVmG3OuNGIXT8VJU7uwbpVWFx2XV5Pg2ZzmOkMpXw6hlIubRPml\/kSH9oWuMYbAa3FT59NTWWB9ao9SE0c\/NM+CJ4gUyf19zeH5rWsVblzu4bEE8Q\/gKhKIDVBy1WlPSVKn3fIB7fbJSRyoAPweN6yLVnVu+FlauEekahnyOkxIX7bPfMPGQWvTA6rYR0WQ6eh9AaPK9SIKvH90+97XJRoCJ4gR29KC\/vPcPjrl8CBE9MS3pQuOeYt09q40d7MT7nbpmWC2ctLtyvhdJYVN\/n42iauBJn7fra\/32vXCwOYvtF5a2imBtocf9FZeOBKl24jxf2EJ2And1lWdq9Xq88Ml0AVOenSvA8nwvkkmQuyA\/dbtnr9UqXOEb5Dk5EZNGQIoqn3BRn9ue51O92yl6vV1rr+H2YV8Wh25+H2sxQM+PN+IVzPN0rOH6qSumzZBzpXVSzH7rd8jc7Wg8+fkj58FWx9fE9fB5zb+tvbD34A+2tLc6N4bw44y9\/3+XjJ8v983NM8QX7+RdyHhLqf3HyT5\/t+64Kn88Tvlr463tFUkjun58jyBl+VPjqITsP7vH1wye8735XWTA\/Ipt4vP\/aJf3wBe9csMVX\/pFKvnvwC945\/PnnLzw8t9yzf8IWEMceD3+7O\/j4ydJ+F0Uth8Ylbq7lq8NH5CcD4tcvcWZ\/npTvoqg14+fOm1ebKB+DLciiIdJ7zJuJ5tCqJX7oeeTphNHokDeHZ+QnA0T8jCxTjGM4PjYMo6T1LopaFknuPI7G0zwbp0jxirfDi+IwjHPeRVFLAKRCgJHkp1VRckS89bsop9Emx2aQptlFaROCwDlejxJeo\/leWt7oCWak6D86JIuWS9eMf5gJDo8qvoi7\/Eg0z6lUiJX8\/FDjsDx\/u02PHGsUx0bX+4AWBYmbcJRZrIPRyYST0wibwR8PNad2uedpURB4E6y94CdWkOZrBr5L\/HSUsn9QWfTt2Xr+TJ43x5bM765vZHphUFGiakqnthLeYVd05GX+cVbxD041R9n1\/INJgXUFL0811l7Ph0rpl6eaNLLLCig3rgjFNjtaY5wldRnWWhI34Thb3nwVP9QX\/MtYxz9M4Gx8c\/7BpOBsvCzPxShRZOxOpwFfgqKqbT4dpJQEzi2fsiH8NoCkS2wksxAT00a1pz0yknkFmtfiDeLPPWCJMKmPEjmyU2DI0Equ7a6bwm8vaqOCDOmBSX3SYhvZKYhzv7Zok\/jtRbe5xGEL8ANF6HnYxMP3fQKvnmibwm8D7HUp46IgdQrjNHmSEBcFxuZYa5F02esyH6A2iS+gyvBQW4TwAEtuIPQkUvn82M1wiSWzPlDVr03iCwApQAoP0SnY1gGeCKpK5lKKrIPpJEy7PpvGbwMcjLNWakC5Dr7eJvAVSnnzhWZiORhn8zK3SfyLR8ooaWklSwAjkvl0al3Bq7Os9ii3KfylCS0xkLsca72lejCLzcvYBH67PgW66TWIIvTl0pi7esq8W\/6SAnFR4EQ14qogw7qrN98E\/tqrReU6pLmpD1kbxq8pYIpq1i6ER1wU2MX6tgJ3za8pMMotgVZkqcFay0l09eXTXfOXFLDWEk4vp6Ty2Ov4V1pnE\/hLCmRZ1pJSYApLniRYe3V8bgK\/FkKZHWOto\/AkozU3zZvErykwe3Sz1iGlvL463DG\/roCoNJVS3Ky83TG\/psCphb2Ozyi3Nzrgrvnt1dnv8H1\/5X3NpvFrfgm9qmGQZWRZdu0LiE3jz6+tfd+\/8cvru+S3r6rBt3mXtWn8Bg0aNGjQoEGDBg0aNGjQoEGDBg0aNGjQoEGDBg0aNGjQoEGDBhuIfwOglNS\/zyEM1QAAAABJRU5ErkJggg==","width":12,"height":96,"frames":4,"noshading":true,"animations":[[[0,0,0,0,0,0,0,0],4,100,1]]}},"blueprints":{"thing_1":{"type":3,"tile":"tile_1","width":12,"height":96,"thinker":null,"data":null,"fx":2}},"objects":[{"x":506,"y":352,"blueprint":"thing_1","angle":0},{"x":506,"y":480,"blueprint":"thing_1","angle":0}],"tags":[],"background":"data:image\/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAEsCAMAAACCIPsYAAADAFBMVEUAAAD8\/Pz09PTs7Ozo6Ojg4ODc3NzY2NjQ0NDMzMzExMTAwMC4uLiwsLCsrKykpKSgoKCYmJiMjIyIiIiAgIB4eHhwcHBoaGhgYGBUVFRMTExEREQ4ODgsLCwgICAMDAz87Oj05ODw4Njo2NDk0MjgzMDYxLjUwLDMuKzIsKTArKC8pJi0oIywmIislISkjHygiHSYgHCQeGiIcGSIaFyAZFR4XFBwUEhoTERgRDxcPDhQNDRILCw8KCg0ICAsGBj88OT05Njw3Mzs1MDozLDgwKTguJzcsJjYrJDUpIjMoITMmIDEkHjAiHC4hGywfGSseGCkcFSgbFCcZEyUXEiMVDyIUDiASDR4RCxwPChsOChkNCBULCBMKBg8IAw0GAzAVFS4UFCwTEyoREigPEScODyUNDyMLDiEKCx4IChsGBhkDAxUAAxIAAw4AAwsABjYNDTQLCzIKCjAICC4GBiwDAyoAACgAACUAACIAAB8AABwAABgAABQAAA8AAAsAADo3Hzg1HTcyGzYwGjQsGDMqFTEoEzAkES4iDioeDSYbCyIYCh4TCBkPBhMLAw0GACw8Iis4ISs1HykxHSguGyYqGSQmFyIiFB4fEhocDxcZDRMVCg8SCAsNAwYIAwAAACwoIiomISgkHyYiHSQhGyIfGSAdFx4bFBwaEhoYERgVDxUTDRQRChENCA0KBggGAygoJCYnIiQlHyIjHSAiGh0gGBseFRgcExUaERQYDhMVDRITCxEPCg4NCAsKBggGAzU3OjM2OTI0ODAzOC8yNy0xNiwwNiovNSgtNCcsMyUrMyMpMiIoMCEnMCAmLh4kLB0iLBsiKhogKRgeKBcdJhQbJRMZIhIXIQ8UHw4THQ0RGwsOGAgLFQYIEwMDEQAADikiKCgiJycgJiUeJSQcJCMaIyIZIiEXIR8VHxwTHBoSGhcRGBQOFBINEg4KDgsICzs4Ljo1KDoxIjktHTgqFzcoFTYlEjYhETUdCzEXCC0OAyoGACcKACMIAyENBiIUJAUUCaxAAAACXBIWXMAAAsSAAALEgHS3X78AAAACXZwQWcAAAIAAAABLAC6vq25AABTY0lEQVR42s1dCYLrOqrNJv6NrSH7X+av2AIOk2SnhtfufreqMlricEAI0GMv46rHf7W+\/xt\/8uPx9fXa2lqrx3uOv85rvE1+bf2lrs5Xg+v9WV8Pvf7s6uZq\/qIhlHOo\/KC+zLzse\/n63\/vatq\/\/X7ie58W\/nL\/L08dLNnwIrve37O\/v3FE28i\/d3n78t5vrsaM8SYpv8c1Ez\/J\/T0ttYxaOP3nGiszMFwJ6PPVuxuGFvwuGfv5fyZ9vp4OwabC5\/C0E3pLYbwFgO2UPAHDSfk7ePWRZ1pcVfykPJ\/xKv59SjGFQScVpQooFQMGJ+XpZCACtbe+J7yz24wWvX8NAtyTQIgZgDlgAQEPgPgBEzwcOhsrDM2sAEAgmSMgAkIypIo877RcANAMfeg2+HhGgCICndpiAAwBv0ffef5cEFACa4FEBk1ShNo+AlgIA5vg6AgbRx6JOALBr+Z+24Kr43y985PLXoxs6XkjVaQramIgSToUgQPkBigFgbg8eNtfvIkA7AsT+HgEIgEbSbzVBgMLAHRpgtY\/kHT12fjwIXwNgtwgoWvwHAJbiJyePPER8IuJE96UOAQYAOLndX3+IgEEFigtgpMRUwci9tpXyGQtM9D2mgH3zih3TgMCExXIRANnF05EDQIxAjgA2ASECfpsDXn12kcJrx+C4Xxy7m2tFudstb2BNEBMAEAnsOQB2AUh93JK3B0urhgKG1+RRoJcCygscfHoVAD+OiA4+RwAAVnhggPOHAoAfMtqBD2gg4oXnFmFg99dJQTEEUCoPLTr57WTmNQVUbQrJafLT8aaAc55B6YxbFSPAk\/af0oCzUidZ1YY3X+JVs5LJz4AgAIATPfO89wJUuODrxh9WmmTbzgGuMdDyP9WUHE+ySHsMgFovUMDvGIWeoqBNLlkGQ9gjRcA3bcET\/p1q\/xGIOkxBmUYH6gCAoXAZGv02Fbp+loSp4wDjL+\/n+aV1ggAVH+oksZ8GwTvuYFEwFT7fealxzMQL53vOgCUAD4Aibt5eVuJHBuDVTTjYq1dL1kaKRNnfVm6VAYBfD3aS\/6\/5hv3lVgUT2Wu2oxh6ZHN\/DgAWAUcceAsoYDDAJCykANCG6CZk55Q8sgD+AgDwfEYAgOUWzXxsCmbewU8AQBxUB4DjjnswJQAABMHQwp9kAH\/tMQBKTv\/DYRkAEP+7tjYBANs77RkEAGgRBCp7ACJY\/eFCAfRkX16\/QAIaY3oG+hGrRgDInIIp0AxQHAZ+ZkkIANjvAEDs8wCAZbbFxW5PqvvEjo0BwNT+ntsWzW7F1WRrMQH8GQLsImVIvw1URgCIzN5ggWALjohgJxbf5L970rcION2\/ieZbXX1cEboHQEvlb9QaHzcWVhvU+jcAuPgOoioDAAwTalmnADgtgaMBtyT8dJmo+D8VPm7RK2FpBjCAn6EghYCiEnEtTwLoGbtWiK3LLUyv9psAeNlb5K9s5Lqgg6MZIF4O+hXhbvR3AGAY9U8sQOrxVbvfyzM9AcC5LRICgWl+AQAQb0Pbbz908FGrCgFr+d9GwOWoYgiA8cWKAYIpiHfQQ1ttLfgp0m2\/CoB9s2HgCQAM+59STAEwOC9whZAFPKVEzuR4cnh2WurwPP\/CQWENRSX\/8chtCnByntoApRCau+rkCgEQscAEEZc8Ar\/6gzi\/dfi1mo6pf8gAjewbUV4aC4nUn2EQvDBUe3QTzP3ZJZgmgM8AYKOKEwpQ9GfIZ46AMfUuq24p\/rtrhcj\/X+q+FoRmAFE1nvBGrOc2yiF6wwKUdSLMnCBA1HyhQhKT4PChp4ADAPcg4MPKr5wCMgAQC0wRUEc+ld4loAj9BTSs3f8IAMGizzJ\/iwGAY22s+2BvEzOgheb0\/3x\/CMK6uhrhSX0W2qWbFHAApr9U3mH+0j6Tv7EDfku8stNVSqnXvQLLAnso+sh\/2O3+n+X+MNLzYDUlny9xuSJL0ZzEDMHQuyMALOXvKcsC4CYF8GiMTejpa1MASC5LhgCDhu8AYGfC3+LAr9h\/xQA+dSe4HqL1mfANBOY2gCmA\/f7TnFq83AIA7CKxMJgAbi3sAgRMX60B4Lex3OAnIIjXhmXqGZLAZ6wv4jeZ4RfEDwBQ2nVR\/g2tu0yBpgA1mwYAl7OR9JciAi5SwD3xu2iwlb+YANlCS7AwS5bc6V+RokXAzqvCTPUp8FvMxg989bDXGQBwXBMA+PV7pQiO2xMGWQ2efdFk4muZpSwSwpiFIWS58x8EgEpKlyVQMDsyA7yXIjuqEQVMr31fcMGE+tMdv7X+DwC0OfsTAIIIDpFAy2RlkoGRNuUm7S0LeAXD1a4t4J7XduCy\/pP8MXW9504gqxZvELfcGCwgcGeVWITyU+EzANrseoTbbj4zRtYGhgIkesM\/JwjAIiJeHoUAoKoUMRlmdaEWhjcIwAnbPKDLEhLnKLWIlFTlCa2UVanVZRBQlddkrx9T97OrEwD6pQsUz4zYJY5pZTUAkHsErCoE6Mo2xFdrECW8yuoTBBgHQqjEw99PxvxS4vfySQ3BWvjzPB+W\/toAHJJ8tCX7gxHwAQFOHm1aTqirMsND\/vuQbDQbVbIqOJMAscXwMve94HV8YVeZHxANHCGC\/notJ8PS4BQAl6+L\/L+qAqyXVgCncXtk8n9dHL0E\/zMnQAGAHd6SzI0yDh4A5A8wH1kMWCTYwbxG\/JceoxzDc73ajQMw0YbrDBAQQAKKuQkoU4\/PkSYpZIjQYc77FwCMwF\/0z6snvoCpm4LivpUX2N8AKAxiJ+tRpOqNwjUAsHBB9nYEvCCRIRIjAI\/Yd37PBDgjUNPYUAgBUZql7K\/E\/min5\/TrHjx3FgD4s2WjV94ZQ06+qKmyYAEARSyC+hELgChWML5R3dcLQw6pGg9Vl1qQF76V\/cCfZYDq3ZyZYQjUfln2myqLBQAt5UiqD5kaPZmTwdtRmvwPVk+7X9cBABq2OASH6xpdQGRX75s5giw9vwUA8FoDQALn1+VvnRrl5UQkINmEpQTbvDJbY80czlR0Y91MnAPASI6fV8rIOA3JCBiYN5CQTycwyFuAPiWGLQv7NKouNS8kWwCgMwAQFV7+yfhHUCCcWYyT1AgBsjYnAITJQ7K+z+t8E2oUvQ\/Iv8M+P0NA+QDoF03lD0WdOgmQiruc8msAxMBPSKEwwoPY1jqEhSt59PiCNUAIgFcw+o7aJEBsfpsQ\/QAb3ywMbJVKfoHpF+J3chGIdjthDxY+xD9CP8ATgAqEq29SqgUU0Fpu+\/Z0qBHqcVQLuQcVJmDpo4AQbhzq8es8OQMAcqxjAASUELoI6VxY7p\/of3gFeVWKAQT7L7YDbkJtNYfWRk6ajBHwGrkhpZTq6G+fTYEYBjvKhKNGNgf97QBAA032klD8po8QTqZTMGCAJQZmmcRzABh1h99cFatWy0gdHjzSFxVIjgBZYgkU4Qd7NNMAnU0NGGAORrwoaIoSRzFpb6Qw8R+9hyB4LQDQMwBIjpQFgMzNDQYIyc7rfCB\/2IdtLQtK4USlAAAu7LNgmFJ\/B7FVdC7kxxXfXQRAqKckqNhSXAFAgv54jpV2LAFQ1K9TDJwvczk+rbY213s9URMTQGZxuRJChrMq0FYRepkjtSt8XfzcnC4XPycTBwoaoyAVv3ziWvxBc6klBCwWrrE+AuDylYmTncD+Wk9Dhx19WGngzg97QzEAbKrNfQTgyLN97GD4+RS8Lo5cSkLkI4NvuQcBK\/9oJmJ\/r10X\/6zQ8qVXAbggCtXA6G7DHl+9WcZ9vXIIJAC41JxSWYAsXy\/XArO+uST\/XOpG\/DYurlU95gH0BmwgLHvvdcWfr5Mfaik8mQcRrrZBSbwpZQCsvpaJioTt\/cB4i9O7+QsAOAIQ3yc2fVEL0eyqnBdyFQDUXsQCYPa2a1rfFB\/nAEhSI0BXlNO7uBXIoXpNEdBDBMwpIPveDikic31wgY0X54H1CPVRKtwUAJHsp8K0VbsM9vQtcZRHqtcHB18qsH8kltpuo6ohTuEoPfbSPXqDgIbjDqtrA19oWstOrQzsq5z2GwpIiP+G+CPLX2q6pUHoCAGgZS5NOVu4xdfFVeWA5Ur6bwC8LuipTQGwzJZo2yRTL0LA6MhaE\/6\/AQBZH5GPUmdbBxwQStb83wNAmNdiX1OsJ1AjzhDn26kcCUrd+4r\/DwCE5t9OhKzddGe8ifznpXscYIFpK9hqawkAUgu6Lav7Qk+4YnEEwBHBbyu\/65iYK3SIksovy6m\/ZSY3vvsZAEbgPzMBygFQNhAHNiWAloufvkLCAooNUwcgyQ1AZ9SEYBvLv+oS9fnljf41r1uJFOV\/oQBCTGC9teyPyzlEByO97+L1PJYGoCdjlHGlDPBaXb338GOveIEJFqJZw\/m7hgAV7mJQqQQrVwFtbKNOeK+lLG506fvn0r8LAN76\/jYAprd2sQJLf3D5CACzoIupTr+g\/ZaXsi8UJNiOca5f2BUSWL0qmeQUwQn1IwBeGQAmbIh3O7+3SzVbgLBvAODS1ZZGYLjSrTuVTj6Q2myg9At05JneuOqL9AEAFsu8PNlX7YA8FvJ35UAy0LoCwKWLWUZPRHJOidKz+xDQagNtD3pX66hmnAkxz06GphZIH9Pj7l13zapXto3DOb6yxo\/yICDqMQGAJxPXHbEsTMA1A6ABsDYCVFL0IQCkYlm3ewJ7KiveGrgldcVAiQMreW0uddp0W7pIAFfyoKKXmO4ICQCCj2p+VtR25k8AQHsBGRLuiz2YRZ\/QA7dtqK7euIUk11eV6cKdVD+ruY9z1fYvLhf1faTil+8B7dcNIH8CAN4GsLokilTuqv\/FSnmNiEz8RZOf\/qKQ++23Ixh4DZuIPUjyuaT9OQCsWB6x\/BFpalLEBEwDATcAQAEhLbKIArj50i3hh0JYXfjm3SeolWS5JvcozmACgKZ+sxsscJdB2k3vl+L8ofwXADCkP8tyUoP7hvyhc4DTWetGFU6Fl82zOSJCzCwJAL5959J9C4PsCzU0KIPFyJ\/ETqHqppqlRr32UCT9ExqIe+I9nCiYkQ0FBFNrZhRSdW81b+LviOWH\/I8crKCRWYUSKyIIBe6b1FIAwJVa\/PMDh0TrspoxE8Ru7pYMQD+lf8rzPqY7BYC8nm4F3CI7sVW5Nt8CgIsIRwiApEjbey1l5MqtBjRc69haC3raGOcvbs7gIJBUL\/kPN7wf2Z6MnUgyEwkvMPABAKqfFwOCcIx3ATDhANXm+AMAnG+jf6xwajAClv4hbdeN1dGAQVeqFF7+9645668AQJm+ExPQIwAIV8lkWtz7Q2ZuA+Bsy8g6YMWn0mfZBoBHtlibeflbeOgK51P5bUfODSs2fXVb1d9jZGfkj7lUnVLXncDx0c+oX2EgvB4og1P4pIw4MTBdjvgQ3nz3tzt4CglkhMPfT6jIPO2JmI2W4jOy4XNqv+nJyk26toQMYOHidbzTsPBmS8VOFyatXBj\/Ql7XJf4XTV8AgEWOAp4AQNuJz22AGn8KAnU4x\/jxYXhIGhYVC4BCAHgKAM7\/u1Z9mgcOg4EYwP64FazFmEen2w0wcVfIeTXHq+vUxwAA+g5GCRdNCfMBDaGgJAIAfOAGIvvMEfBjlxB+BcOjCOAZNGo15gCWhzs3czw+lKfxa\/p2ZbrYt2k+cfNTus9Lukns4AQEm0FWB3G6iQ8K+18gCiZujFh+BgCrBzNjsBTtaj8P\/T1TqBkCYNc48CyAZuN4mD7sYIZ9Dyu8oxZ0Hwh\/3tYoJH8NgI4bs+gOoerDqtrm5zLNNY4gfGIDIhzMCSGVrvglwXOyJC9DOhYAvlt32MB7eAVFUAMHwCNGjr8HUOYA+Ej7VQ5XIn+e69AE2DMyDmOot\/3B7QZkNP0e6hRzEwHJrUfhecXf2WMz6ODDJOxdDXMPIRB2cOdjXugtT3u8LwBgBwCIk\/0j8k+TGxdyMD6ABYAtYg8Sl+xUkzN1eyX4io1YJEjTlm5ADoJ4LborF5gBut93hjrxuQhuiH\/Swl+9+Bk9Cb6BWrewybyFA1\/bEPQ4NfKP5aEB0FpT++FqgVskFo9LczPVEur47DyXCMewQKpZaEXvrdK0eiDov4HuuXdd0QjYWf6KE96K\/owBMGGA3cofC+uuCVseZNYf8+aafLyi3Z8EAKhtErLmu5Woy1jICAT0zIIOrsgnJQJhAlOcsOrPKhhktQou5egqAOzG2in7bU5yOgDwfIYAyMhBmqOF3kokYI+ClwYAdXPwrY+yBhjhMlDTLXt0GOyE3xEAqFo6P+4zBlhwgRbkomqLc7xUgZcKy4ENYAqolXeCSXrOIBAATgjs+55CgPaS6BvyrUkRMQ3\/FQKAFvWY3McAeIUAyEWhAOBo1a9bCkdeRP7VhAJ4ZPEG5A0qiFCgY2OJltOE6ooZQMRAwqAA0nBXouVCfwKAbQDgqRx+4zWOT9WbiVr8EkjXNps0O6D\/wfuqrB+LnRlFQQbQGgC+YtMkt+J\/ld1+K\/7TCLTvsEDWt9Eby0z++dWo0pk3fTY0ATR4vxe4oaenAVAQBBAyZHuC3r91n2Q5IGOPb526mEGfSzEIUNbJSJjKIGYAbQodB1DaFu6wNrfiPub4W2ZAd31dyFPze1+EUynyzgggCyBejEdAcWoubsAuLV3NpScvED9loduiek39YAo4vbf3fO3fhT7NZBoABLPIZ0KGFoBTc5S0ayD\/T1cCOSI0E05q+i6tqhqEAkj+qAIGAULlyhMgvg8oQ02aiZ4p4x8CYIzYHHeC3Q4VLGBi6EfeB00AEKlRzX0ALnmq84sp7UcBwCDIYTEGckH8AgAi6BoAoJjjuJypFwBwXSud3R74\/DA7GgDN+gDAgyjnF7gAEw+hg5MwkQI2iYpibt4HgN31RZ0ejejHEZBhAiWbSNwZ1ibxYC1\/xYCKxXcOHnLo9wRApDRK6Dg3rs6DpytvW0lLe+YFFQzwbPDCNeIaAC0CgIWAJGOuSOAvAeAWQJn4j1fpA4EaDdR5ZakTpHmAYv+8m+Dlj45enPUFpJUBHBL7QNP9oF843MX0dwAAdIBqxhHCvjWQzmBrnQKO+yP5v9K+Vlr6EjTniUK4k++g+v065xcQoPyAXar9aMoiuhcfS2SvankzSUFDE3QNXqGbyB90HQAmMVujOW5bAi9Tb6lSyvJnAIB5SiEAjcvliAiCPchAN3yWU4CJ+TQF0FLwXEO23vR0xAm+VceAlduayl+5dMkGIE\/CMgY8XkkASDbfifaZ\/8tK\/jTo+qcEcAkBPX65dsc6hpzzQn4AwMYI+LqaPSe3JfIXHXEt\/JNRvdC7l36uZgUAPy9N1kPNgXPvSPGJB64D4G8tAA4qQMGr9xm3Bu0UnDuUAuDEwIj97LbQK5E\/bEy6Fs4Zpk+pSxh4PKuHjA\/cBwAxHiTTh2EgJ28XFKi8vfXXCEgCaKk1VOKOIFDBarNN8CGhAQDr9ycWgDKW6EsnAHiZZzr+J06+2Dn5eRkAKH+\/8CtMBL7KKibJyoT25+I3UzZXf359C3ot6STdJltdAAC\/83O1kZk+WyU1VODjsfA79vVW8sd1wQUfIDEBauUr6T8FHAEQdGwMZmuaPwfA+j5CBtCWwHLkFQBgrC+EwBIAZktYZM4rmlf\/GADdMYAAQEWwqyQBGxMASsH28X8BAK\/JnMavNm6YJgLL3XHW4Bkbgt2EVmfiB2zMGMA9pYwB+Hr2lVdGHZuAyudWBVbfpoO73ngCgP8ZErjy4lD9NRV0nKTitJ+i\/7RD3uw6P9u5nlqADADsAMB28OcAUEtACXYmbh8+osWvHtd3\/R8gQCnL4rUr8aulYVQ6JJs\/kJomGg56bpvOzwjA3YVaE8CuUASVOybAeoG4lRUUu9uMBvGNMVGwT7H9Rxi4+EKnPDMIRBSwS0ZRRPF2pZf6HEr8y9i2tvrBBy3jgBoAIscwfcErOrSLsT1OeXyqn8FfQ+AT+V8BQFUAGFUi53y1GABKH+z+X6Yk\/RoG7BCuUV93ABCKPxGQLPujSEAEFAC5pLz+17K+AoDsSm2AyvYKbLynQ+ltPxH\/xRvzALg40x0AoJwA03rjGgCiTW8CAGD9P3EHfgoAPQTAmfZH2Z6ttSB7+eI39I9uLfEB5kPWANDbX9F+pvl5CQDVT8IIDv+vMQELeAUBDQDJF5UASYNzG27LP08FSF7eMQrgUTFHQAYA1YFnSB27mZXEBqQAoH1Wcnn\/a3EnCFidsdE0AFTyF0+VAP1HCOASBpLcuMWI3SpAderj2J\/S49wEZBctiCgF7n8ZADQPGQ8oAOgGUkX4X6S9QEDUzX8lrAlu\/FnHF4fMDGDdgOg4kImoSwoAyi\/hifivpT2bDhJ1jAA0lLInWLT7FwAg\/LS1D5jdn6EAeoFOEp3bgK4AQJUzWsa++LfVnAU489VGCaQjMk3Ffy3s6RQfYcEEAM0BoFC2aPVlvrIMTADgH54JLANBhJILyQD82gcvSNEIBMWLCh4lQgEvHPDdQgKVil\/+a1EvoRADwE6CWStNdpL6VQq4CNI5ACgZfPFRHArGm4yaFqvlrHqBd\/zcg1hoSkD7KTH9CQJMb\/kQAZRP6t8yBUD\/cQBITdh6L1AYAJiqJXv7+oLRV1oAijbslDhw6n\/FVIqfBMA3a46uTU4YwRe001Y5mDdHAf0GA6zuaurrc9broIG5PRGEPiLpWg1urbsXFJUyvhe1JHLbxlWU5Edk9MbUryFgqv9Ad2DsJgBILcrFNYATW\/ae63DqIQC6l78pXwsNIEeOqXTu3EcQ0Q8n4CctQH93dqi\/DwAlSlrRor8zl3\/vk9CSXR58clf2XfqZvvqkRgCoIGKtuLiSMZvG1QEAqyyTz\/gR+Z+VdOUvbIAWv6uZxRp5PnHk2mXXh4sbykuFUwBMs2ABACikKis9MAtdfEDtJUK+YAqA+jsAWJuAb9Wli\/5C+Kch8jH8yw5uu4uAywCYXIiSIIPMISkEgCvvx74FnNIArxH\/z7ZTwTYIozhADjf8AfFzBtdU+N\/8LpgkrpdCw8fVxD5YchUAxjzkQ1nuCEmSsOGJ4LMMAL7u\/NFY3Cpig6Y\/addXMD9EhcUqNV+FI5p+0m1fYKmvSqJvQECvfE5PB0LAgID+OwC4cI24HzQEGA9rHNl45zmuh16vB5WL5tSwaLGgzKL3jKSq9S+u6Xx+8FlMemWHrh+4BVSLCpdch8AKANff3XVJyCCGmZNIJp0BQBwQn1URnaYbgMCtILiY8Y+kfw7z58hGAFCkgbwCwAgFsK3Ljuu7D4A78Oms\/iqoPeujQACQrrpsBQIAcAGzRUC2QcR8+IeCV+P8aQRIDkjQ+4WOVunyr5KsZeeZ+Dnl+yaFUFWQ2hY0H+zlDwBIZM85bdRYS7NAQgZ\/L3\/5riGFH\/vYrwucHNf1p3DHX6gtTWQ7ER9WeuQvzQ+MyboFIADsmSDMANaTzVHg7UAAAG4X\/Zfil1L0ceQV7JR+43NPvWkAAHF1EACZnAI0rRR5cq2bX7mPUV8fAaCuAdA5tdNXNkB5mOoX98eZH4eBIoEP40Sx\/PY5G9AgjtAjhzip9rXKlogKGscKGADgLs13yKuaf5AFgC8kdwCYqv+QqASwnDNo7cffih8JgABAG1BfPnoztpAmRqrteJWiQqg8gX0ggNO+j7moFAxxZcWx\/H8EAH0NAOVv2HHfA4DLa6LEOcsBdvkQjP53AQBgh4jdPuoZ1UzxHeLBPOc\/XnHErIzYBrxSqE+L4Kr8719ijxdYEoVPv3\/obgoA2srSjkBrkRlQ6k90+Hfy137\/1\/1Jo1\/ibbhvync8uWE80IYcya3p3nvjrDaWdyOjp1QU5aOP6enL5SC9KHwVa+SdUEMKQGLvDABiQFcdmUXnQft\/Vf5x9rTIv2HCHsfsapGMd4HG1+O7dIpuR7jnII7AbCjj3s2AYYcVOaDb6GwoJeetevMg1URXEGC7Snj5OwbQAWA5qPLiNT5VVkC\/CIA5Ok6VxqMf6TiI\/ZSu6viqizx3ifVUGIPqwGHUSOluWvGlXmVfEeH5ZW02q2EHr\/yC\/BMAgAlQHYsG0XNM65LwqwLAf1sEdm5xqD0q6uRr+72alr\/6enf7YZUV6b8CT07WClGzIQ8A95JgFIHMFDs3IoXka0IA+I87AkENTlEihMW2vsWxolrhY\/\/r2o8uvhkggDdxys7MsEvn7wgA72YfK28bzmMV5c4RcN4gasxKVVBgqiE2B+aWBCDl+d1\/2gkAztxFB6M59c\/ZwADvv5M+CYF3K0HYnLGoMtjOtu7P8DpafrUhMJ\/085KplS+3wvWa2MeL1OM9H42HgKhn\/xwArL2PFq3gNOIyuQNj6Fn5O3EHUwaJ+3ACWAkuNgRG8v+O\/78RQGejFDoIUus\/Ca\/zFIsZFUq0WtF9dsSl3UCZ9VXRiUkNegVpBQoARp1tt8Q5AtAUrTbqf1z+Qa1Z59Itm7BcEhBQs1cBwD\/CwHALqRloKYH7Jq0Yeid+h6WTowAWhZJ0MsAYACH\/Itw890RYOq4cAOtL09AfCp5mZ6znu3kQg\/Sq1DlFgHYE\/r0R8O8f\/n1czwMCIb3yVlszflIXp8+aC\/wjH2MAAPQHXd+BBAKGF2YAuLgAhLjEfyL+t6j3t+7q\/GCO2UJ6ioCB\/5ID8CjPY4NzoJ7\/nicG\/p2\/MgIOq9Dstr8BgFZO9UdWsTEFwAuFZqj5YkzIoSkHAIxMP5FtFvxktt9d+Q893atkPNXzeAfd4EjnKpmCJt310wDg3z8EwJsEdqiYBtP38gCQWXQdAS0MrjAAyUYRgEbixCvUHzYzAWExFGYKckAU16J\/L\/5T\/w8BfSGAxtfKjh1bCjR5TzJXcKmAENCCP4Hw9gtGM0AlU8\/U6k\/oGRvo5WKcPnQYyeoCAnqMAF4GBqSC8ncgYYRfHsxPyv99HvtG5vpLLTt5f\/aIVkFArTMIYNyQSQCFTwB4UmRxlASySodX6zpbAmfynLbLCeGRXMyTvt8tQiAGUeoD9JkNkIjff8EAp6JvpKlvBLzv4lT+bUR+aN3v8pRQGAYDe0EEGPnzIYHqvNDaFla4tTxr7srMRQigD3ZfNatMSMKKwSqAv66Bz2m2i4wF+OPF31B\/iNm8+\/SXTQ54dTVqZrtjpMBlLKABMMICIn+49nIBAW2CgHW+bL9ytVsAQB\/AytUjyl\/yskYf\/ZfyZ\/VHOdTKKXubHOWH5jq6sN15KZL56SjAAYDXBSWvDAx5FE9bvQiAJQZUuu4VuMj9aAbQEaxU\/nYf4u+k\/3U1q\/4jcl8QAGc873i4SpOqFAX2qMhTznoFeH7g+bAAQNYFE+FEu2p8rN6qwm2dUm7akt0CQLYKaNE9J1\/wp+J\/tXrKX0wxu2WDxdmEMwLGbU+YQG0gCQdoBJz6b9eG58KgLp0BTwdXJ08Ve4SA0OGh7wKg9flc3V7L\/CwAyknx5zE9G23o7WLEmb\/PcL7k8eEYMxIYuwewHBT5nwxgVofDPFCb8AsgEIq9PH3mtcFH8bgulShPAeDmx51yyWj8ewAckR7TpBsJgOT\/JKnRieCzASoWgPiwQODp48ImTCQRossQOGbv2vyZiY6cAq5OvgLDywDAXG+o9hj38x8QwLECoJ18V5BsAfCPKKAuyh4sAnCX8J92N5Tq\/4OY8XPjbuE\/LH6a6ZQCuCG5YvFvAAAmhAHAk9hZ8v9F\/LdVVYlevPwtADQCpkCQKnAdFDKbxbw4\/CcAGD7CTkdGRNLmH9e5E6p69cOBUKMA0VL+MwaAcnFYR3M18n9x9TPj7wzZUJbfGZYrFd03QYDU8LaRLWhjAhoB3A1eQgI+YYA2jP9FjuJeQo9wWrrvhf6ien6SuCLclVgvy3\/GADxr+Md\/Ue6LAOhwshVpPez67WahflDAPg5wP8yHJHeEAIAFIeQNyj6h5Ixw4ojfLlguChZdPOln139p4AThgasUcAMA588mkcD\/TPkJABhcd9u+h8rKdg4ndXzRw7aV4T+cBmNiBuT8PEwdfUbXv3hVMHaNURSXCQCAgEDJwm1etOum55d9AG8x\/9uMPxglQgA2fdFwc\/TuMBHnSg2Ov+vJYlevCAkBe5I4+GRvgLxByCaDAxTvSh8SjWD0sfL129d1APhdwP8SAC99+1Vv9AoARFgjRPD15PYO20Onq2YmIoPAWBKmADiZ5h97hAN3FJkIggOvqyRq2Hb2xvsAIMnmANBNAm+hdy7C1+d7BzIA2WUD+e\/qMK+R0jcKegtt2\/haV090vFdIJLAHAACioSUBrBmp3AjLpdkYXB2uF\/i3mgl1atcEi7o5AzAAfkr+eKffeS\/agYLi1xUf1LNuyDQwjgrvOulFuQLMKhtwS8oK74WDTkyBpeG9EV998KYB4JVQAgBfKvhT8pes6I96eWkaIwRAljfn+3NWgPTwmpnDKkoBPKAig9GVAsAGqhCAPzKPH8u\/o\/wTAGC590+Xe+mb+fj9IiIlfl69Hbwt8kfUxRCIswagvsQfFWoRsEHMQE4T5L0K6iTzCxC4I\/8VAGzI7OdR+z0InGNwACiQBab7uGndp08wnQAxaUPrQVVpg\/YSKtjw1yfAZBcA\/GjvpFFAer\/LxFUAwN7GTxf8gDxuYwAqs204oJBBEOvL8QsFN1WD79skgwW0CUMaCFBmuFlEaKKQDprlqDn80Um8KnlJHBCcAwDsHiAC4IcvKWAdme+RmHN3EXmM3EB1wq0qDXCVeC8dRmuaTzQNcOqgjj3uclqMoMCcKb8jBXAI8v3u+gNTCux1Ue0xxS8EgHWApIbxp+WPQOhYtzJFtUNA1KQQ2\/py5F8DAHL4BwC64wB95h0grUyvnePHx8pxl54DmjjaRw5wqARDdZea7wW8AMD451flzwFuB9eoyslOQKKzlhr05txLFfEYHcE3q3ly7MJnK8YnJwwqMOtRPmuUCs9ZCz6Xf9TX3Sv\/5How90cvTEn4p+RPIHAGGe+Af4sgIEUXlsEGI0QFGfSp0USZdncWAXQ8WhnN4osnBu8hAgCeAwGcEPjh\/HbaFQHEBgBYtvcRAITiD1tN\/AYUtBxApCrVLUBAeqnWJ4lV7MlsVVgH17AZJkm\/yAZDldY0vJvMFkFWhAMBlYtK2kdbLMIAlQ+tFdK+qv9TAHTdr+o35f8yER7RRX1D4SR43ScPFri8B9LO6LLSvKrwYNUgAFNA7mapRRcYgDFQDCARivd31s+WBSYYimi9If8QANSQkntX\/SwGevq7br4VdB8MUdPEuR35ImLFqQ2yzZVkiHv5W79CGRh0Ca3x57rjSg5hED0gizDOHHnf3\/t17Wo3U0wLg7stmq445P8BAGQHM1DPdSnbTQBEAtUr88WJU06CcJI5AmDAwyrF+DoABa0g1LQ6jqm1xi5gMR4BJq+NzWWJGUjHovwIrJ4\/oQBwTlWW6XIVANIMh2Vl+0vMJbsCwGhhKePKv8jt1cVfTrdF74FDC4e0zLlVAC1+AEKLElHyswn1FxEAxokJRWSiscB44H0i\/jMDQD7vaumKt3wTAY\/WODbACOhs\/m3cNBLC4hG1jS2ddagTHj+GkAgs2CUTBACIh6sSigQBEB\/h8PGRP1ZNQx59fp6YfFuGKjaIDcZQeBUP4FrW7Ay0GQAAAQDacE20AgArWoW4GW3b0z\/rThBBEkvGARIHpC4YwTuds74EwEDAvBxQTjvyz1Dz5zZ6hprX6JJ5oICdU8IjvjmuwkI3HsEbAJkFGGuTCQDQI6VDW3Ql9yUADGNLPkRvL65DehEArkqhx79KdqNQy4txlpgPtAjXHIzeFiQIhBk9cVR8n64E5xK4eEuXdCSx9MpieP+ymoixihq33NIPJQiRgQTAo1JLnxkAugCAFj5q1ewV985ioLs3C+V34AAAQvIx977RtTe0c5AB4KTpNykfU3rS9dmEquGciodqQsBF+wwTCLhepaX1OQIwIVwAMCIBXv5k3tr6esjwq90CjgAQySPNWpGsdrLy7E84JvihZIMTARDbdEthJsrKjDe0vIwN\/v1IL6f+grX1FhuMYDMAS2gCBNQKYUJqU7kd7Q3yCdCygK5v\/jb0wV0XxI8mQAAAnd+09wZqTI+JrJ3wkfa7AEDJv+Pn\/oj8YSnpzzaglG+lKhQvrDtlfB0oONIAt9MRVPPJ\/UODcAC64j24hmkpGCU8AcCroGBQPgQKBkCvM6Qlxji6c4WDBw\/K9b5iMbOJ7uwY6Oc6yJsgInTB\/l58iQ1gGX4DAJjo0bvfBuO5KaUYIBTM7jm887MlgD0dlIMt9GkYH2QDkyCASpvUhsGO3QcvjXN8EmWtWktUiznZvNm7dybA2y44LgM5QGRN2m8rWNDN77DhQeSPgmcA\/NSF20oy50b+p5yoj9A+6G\/UlQsCnlxdxgeh0hRyOICIn7iE12KTHVrg7ZFKottSX0RAG77KDr0RVCaMA4CNrQcA0Heh13VY02gUHl7rAABmvuMBCi\/5og8BAPfIWNS5HgYAGMEbnWTeP\/YzfLeP6v+R6\/\/1F9X6yCJfckfPQGs9BFBFsWTSI6IDU0DW4xAYB6RabReCwkxtBgB7DgCG5xwAIpKXSBgNOas0Pc9LeKB\/Hu+dNpaRSK\/jAOAXGpuGIZmTNyHNm6hgg\/4vWPR3tCOtxenU6dgfu7vOSbDiN7em8hmP0Esb+4tXAXCOaUQYq5gA6pFp7xZ3OBEAnQcjABA97zy\/Hezri10WcUrZlF8SuofA91Jk+H7R5AQswFG5g+83TuUdYTks+LINQtUeA19lH7u753LBM6kQH08Y35BCAJmTawFPRAAcY8jSd0vC7GTQB8TCNWAhX4\/Xb\/zbi1w9R7kfAMAuI2a7RdNpeYm5CYigcddGk6tD+7M7VBYbDFCjCQ4UtzPMUknnRrIn2YZoRsRAHndzuOiyemgBAHoyaCnw0XuXJhxAf7T06gcAdM+vl\/B5R95ScQA06SaZD1lOtR2eyL+DLzHTb7UkkVtkb7QrqEaoHN0FpLXQuSPDADB1pdgpHJvPEmVyb7pzG9in5AhzkuzZhS\/S017KG\/dxxB3kLYcAEFZTvgmFuBEPKQLOz3gYYYCrZ\/ArXIaj6yq6A68\/DQ4AddrBkPV3QfOs3KTycLIfojX8otYwGseVY+XcjuHuEtQZ9rlJV7DRbGY3IUQJ71KKjwaARD05RiHyL5QTAH2s95ElMo2BJw29DeMLAJzYAabtYeLtkSqD5HmFr2kgmuxzO53lLyfwTKxkbP\/YR+CNZMECgJaeTq\/DDJYdUnSL7NCN5gIMgHMhwBB4PqXQUPwq2QYYpV9uYOwodbnh3pocRYv7ePV06OCGo3Iyw60dW8hjLmNoAtykPGTTD4yxxYJT8GWE57RvgE2ulCbScgCQieI7gL0A8DxA\/CHhp\/I\/5\/hkfs7TF0EYADACNuo0MVoADTWrDAClaCGyQXEghsf9i9gdoKTxcb9cXSyO8vgAv8QyBF9lz4PvK+Lgx4s3fGFPnnfpQDwQxzUPhk435lMMhIvaKJzzJ2CUEd1mWHPwbpJANlv5+flhAMBSCeO4ZyDA9AbkGtB\/1GyADMGIJu3a1IZfDiYdAYDAqVx3JBO1M+JMAjstNH0KMOQriD8YwnLg8pF4m1Y4+vfExbIjDO3TWK7AmF4dVJkB+WKbqZQIPH0R\/muJAMHhe1rFW5ZN9BEIcF2fqEHs+cexUXRKZUf2kMTMDAAwUw1Dkg0AAPak0lEmZ6TIzi5t9SZDbdYFpOfG\/cj10Osoj4BoblfhfQ8AiZDJ0ld9Gig6xJpZyJrwhaDWkqc7GiU+tFiu\/hpdZgEATx8X2MaJBKXS+bMchqHVQYwANFTeZUMASM9LOfwAKYBXcDEAxOYCwah7UdcDpd8jBoiv6QtoTM5HxRQ2cW8EAOzpIcmjL907zuT1mAMXeJQCJWN88DkDYNiAZwqA5xALWH8KD8wowNxrUzPEfrJKFoMcYl3jDAAISkGM+D3\/vyYAuC7\/SwBwXolengYLZs0tOrj4CnjnMgLaSHeWZXJwexAL1O1e0C04QwgYPqD0kVLuAIDnCXeWIYG4CAg4MUmO89YdwtW8uxAATHGwxBIAvG4BYCqE1qYQKAUogGTtt49MxEFWe5eBOO7mvKVzmZ6GxYADkmZg7BGMYm8STQVHIAeAnR81UzIxrssB9TmslQ+4p0RWmWgjf6X+i+4ej\/hhmqoPpB+3x29YzOspIFVriDIlsl5DYNEpHihA2sK5lj9oEN6bQxAB4PaTF+VP67imAeCqDMQnEHdBTL+6eSV\/rlnUt3MPAK2Wem0w0YTPGUBTwBJbt\/hogYF5ezjKr9ig3yRvGaqm0XA+AULhKgAYBfTNEGamskP4YA48oMIb+fs2F98GwMcIaDC0CAGFAfAhwj5FAQNgCYGkUTS7A8dRMfqI+j10uRbTBAAw2\/jnJ1O+eZjpDf3u5PNS+d8DwJlqUOvVwcCw2EoFTQl0g8+\/RgDWTlqQdr6\/1A4Yd3AHNT22lMstI6Br8mvBvSafaNhy54Ur2wACyjSc0r\/nA4wwZPlAQvTFLbS8AnD2av4SAC3MiUAIDACEbsA2koSelCRC8cONsgiLahEcp4V296WDAzC9G7ggq3PSyQctmG\/1va97AOhNyiJuzzP944TvWrr8LQUIAo+yXD2BWBs6KAAcAOr6BUcGnRvE8Mqxu6xrSNSstPwS5qcGFKt0XvNp9tVr0S8AUCksTc2lrk8zKlyk\/amV+isAcPK01laFAAQAtIXEJJHnxidN8hIRXDYeXxt7NzNxJpNz+VJHo8GYX6trDoB3wmxWS78AQFCRoRqxiWPzR8KHShrZwVP9IxwHAPcHADhJYAdeoOSyc5tpp5MjlrKrKjKM6JkqvUWP0\/6l9DMAdAZAOXsY3DDWzfokSFIIb3FsflPu+BtP1q5W2GZ6KywHw8awcFbUKB+QrJEnR++p7LuCjHgeQt2\/VNXrid9zxg3xnwAItgDOQqkzLkm9De9NeYvWAXqsvy9\/jUy+CT4lWPXvNPcYNnsyGYNPOktUAYAbwkAQB+pFmAK5xU\/O+GuzEfS2uwkAfK1U06mzmYotXbgGhLg7nRvr3wOAjxfaVJRNK6SOxu3U9c0Hh+GcWTqzFtsCQrBIUhB4HbS0+OFzXvTqMw6RXsTA4wj60ms7K2flKTpbmpR20RMcgepkGSgVyP8dACDcAxoq+sj78bR1DDgABKjTBOWEom3fdVfIsWuMYJDV3tLfgwZQXMFba+g0xquPufh7f\/QGMbkmq08A\/UYnYV3a58C5vhSE\/x1xJzlTuhPQWG3hLAbR+AwBDgDHZnHZd+4i6y\/6XEjhnxn\/qkICiyud0ySYfjj7jzM\/dYi37nrs1OwU\/KV8xp28tRlIsfAL0l98ruJ6+d3miGHusPIG8gjxJvF85BmLgF2ySWL9N4C8K\/80Ucg+3cqD7rNKbYIeL975dDlgAMC4YJVM+IDe+xOSly+p3OkoyVoO5xz35fbh4T91M\/gUAuc2oXIngEToXzQsJTjdXuTutwdrqeWK+CMEKFiJTn4BYMQzpWfC6SFJNoKyXWnhu4S3O+cr9L7KXT3fcJ8HZhCnRjnk12DNkL+PsH6c\/cQnHQsmwcCNVwW4V0i7hbtKhCR9KsfSs9gL4obWCgWvto7DwoPUc9TO9a3YPXJ7GAA7pUcWyUsR4Ve4YTX99FfjCDCEwaOMtRgErd8INiYQp6kYVlOKLOUX\/SkZLZEYcIkPKcK7FBap7WI6Rdx9zqE2dMClq9wyADC+h5e\/NCheIMBkCmEzCQDbo0BpBDS\/p2gWfK84TVJIqNVI9iSGpBe6OietXP51FGFo+Y+k+oHt0P+NyaSZrTlOD5KCcUkHoTPrYU1IMcJzSwgSfZFzZXGBVGsVH6t8d+5TlF1LBEBhjnZvZM\/xUYa2b6D0O9c\/lKpebk5djXWZ\/umUuPTTAICtEiGbs75\/O3Z5sKmSaiCQfKCsEGBTyJxEzD+k\/TfuAnHxCB0OROIf\/3ZN2XbpYRYfxne8AgHubWzMgM3EQyoRALhDDUxRB5CT3qZaGKFQsilWL15D1SljZYjulL80Yo\/0\/5UnF8kNCF+yjDfieS4XYi+ZdgFHOuk4GeQM+DUBQO9VKjhtcpyS\/Z6tHGIA2MZQdjEwBhO3tHp\/1QPOx1XyjwGgNlGMUQmpwIlWGOJDADTwratkQZz5+voohtdFK9D1agUogI8PP00+R\/s4vkM1xrRegMWd0swOaIilv+dXWV6ZMcAtEMHM+Y7zOx9wSvZY+hfm+aoAUP0X6ptIEKD9gNwLvA8AcLnPgp29TgHQJwhwHAVGgBd\/vAGkI3xlOIzbBj6TDdLrh8StRoc7kb\/HgHQmxxKwgIzZwWGBqU73XwCQoD\/2sKbGMmjIkKUUAnYDC09DLHpyDF1ejNfIXDqyUoEGOJzA8hEBRBCQ3KAAANQdliq8TwsEANDyrxHrZwLffCx5L7sFAHuUBgC1NR1u58BI095gZQAELge0PJI9x5B4CBGsChEdUB2DAMD2YF6tAnFxCcXVdJvkU8\/kb33AGRqIAgoj4DDzZ3UYA4AWTnWwBS+a9WX9qCH+qdpLX9kxpVgwoL8CZJHQgL7khe\/PepBxZwOPyTLqFxcq5b8D+BbPRZ2ddi5tBBsxUXl6BzT25zZvdHcUycsNgPtc7n4Yl7bUykxDq\/8nB\/x3EffpMYmD5AEQaY\/T+sDo+9RzfNp+8GCCMgWArAop7+ER3ByCCOIUvBhE30\/dnfIlXWsKEWIAALte5ICifgev1Ij6Tq6WBJPuEJACawYS8JtkYBzwH5skrKglnEAW0FL6gfDL5C2MDNcldrm7SGMTLniYdqOWRCq7gtAHNRuQXkxEawOmfyyLoAU4+wZkMNztw9vAuUKLY+U7MyvXEMAD46jgxqd\/HXZhU9HS4j1k3YSg5D5fyS+WfPJaJ3kTo1OzgxnkD+7fAbLHj6roP2L0yslfGi9tCIEIh9Ej5sEhg5ZfI\/BBoHTD7FiQHfoUEwQgBXDUl1MBKf63H+0Gt\/3KSm2h\/aWkn7GP3hEQtKUK0oC10Y6NoQYzw0N8gIyN66LmWhFAAoCRDbMBAPz5BctLoY+0PHst3hu7vjD4TP4xAHwJPyePIQKgVuAMAJ4hKC3mAlQ9Himx2NU7k4ANwoN9D7tJl66lI\/GTo\/MQOjVuq5MKEoHprQIAAAoo5Zpbqr9JhqPcjvATKr4MXmP3FyVNbm4CbCtPsgC7hIR13wBpLbvhEUDas+P9\/wuMX528Iw45X7HzG0w2YCh\/ngANcg2AEa0AAGiXodKOdERrGgCFY4bkl14CQaVTGtgyEdZ5xZdwBuxydwztapGvAIA9+NAH0IVhlA9GeODV4U5N5mlCtOkuqeCN\/CfWQOPjpL8G4RYZGsqfbaJ9wgBgzHEorirSrPpmwQbQwcnaQhVA2FL+O7XfpiUGB\/lzAKi\/0QA6cc\/EjwtCRAAmAqrKECKDESI+lP5JLeU29InJhO+pZIN0AXx95agTIGAoSeM9WD04D4CuANAZAMZWx3Qrqxq7GggXAcZGActM5F\/3DVOpTwFs5y4rhyWDt4H0fT7cS2fIiiaEYWKct0o7Ak74aAr+PSVEODoJbMQbY6ugzEQPUyg4YMaA+SvqJSIH2nk9R2YYQBsH1VCfGAA6ynFolSfWuAdyM9UBgK2eSoxXGAavrnoR0gg56aFS6ybJ3873nFpQafSSqfDijtcA3grsKjPEA0DvFCMYYIdoQe0YRR2wQC9yzMUOlUciD8V50OyJHT3oxQEAaMwAqqUclmwE2cc65jhU1B2FRmcle2fHrzXAspRdRshAOw7ykG7dTvoq478ZCHDjsf5aAYBlr4IBVTJDDAKedLCA8ACEixQCbqwSNShY18ed0PSQo64aroGlJ\/WXtGJVL4jU8NB6bZddLGgQeVW\/ehIQZxBz5AUBkI4ijl6hHZVtQ9obFuB5epXG1ZdENLhbxwFzrceDMbpNGGhNtoW1EeCMcO4cxBljG7WW3Xj5+BkC2Gtk94eqGslfpynlXHzj9lA4uwSNCxoCoKg4UEWr6sRuCIHrJ0D+OwBgsvDZ8QftqVJnRILEsADbMA3k8\/qUR4CrB4C0v31Bs3F1ygm+DCdpTLsKBCHzq5xgpIAnpI2dZ5BFUq655w\/7KhSrGfNFBEBq0qBxGM5IheVahYxuLI946LQv5wY03AeIACDpTJoAdhMUMl6Oj4mcERceNDTy3Z4MC6YAyEIVBHD+lXJ5X9xYUrxj1RbPugfY8vygAGZzPlDI54MzAJgXIIV82yINKJO4T4HUbF4V2yoB+mMQIjnBTWZDfWDo1z9Ij1n8LvJWF5c2Apu7zvNxnby57mzDxxQeRBM2I38wAo4EzI6QbjtpeT+5jA1QTUNIrizckTQEbYWhUHQbuUKG3EQvMSGQgkVGR5gBlLEWP6nWRGCaa6tZ5R2veFinLPq8JFisv2aPEbBTFq2pmgtAEqVCSF2dykZUO0XaqDUOeukl\/qv7hxfyJzcKt4Vpa1glijw3BMDwEXj4zwGQp3WK2Y2CUhR4Bf9lZhpnftjvwrqr1d5nAlfI8CgEgMa7qSxpBMCKDTReYwpgDNACMXgZyH+DOBrUcRLXoednvJtGq6FEqLcBIMbX0Fc00O2JPsAmboD0EcKC1JoAYNcLQuVw7+w7I\/kKO1KmhIUK\/63kWB7o8QfdBjQXTABQJlND8l5NIABg2zCSSh6AkvZZ\/mUB0BNB948BIAuu0IzRfTMx0AYBjFwMRQAAtPo4XNxeHkJnRmDfGQnynCHchrZfg4Idlz42DowAE4r1B734VSxgm1ziC6Sv4JoL8wbIVKPF7GADsPpTBKQHkriX6T2hKQJON3dTgMAVwWA78hcoMIg8XCXch3UZulcYpZ0dX4d2nd41ok218bJMBA4f4bf4HiqUEgJgYQFKwADPQLKs30NVcqjs6vehFuDHUDTj\/K1SIagWf89kewUAZn2p7BwkAyaMoOoIZchUQwLeDANgV45fCa0E7Yq4yDLcE5fvMNHIXhnJn2IG59geOk9bfauL2E4MwEL+26b0ZMoTkU2AY3EbBr1fmQ24xPRW8In8aVPIbMEHeij2awfyIhdSskh03QXvd3p\/Tc0z7zSaVQQhEyHEz1olVmGO3ujUsFjIBgCp+Gfe0e6EGbuAg0sTAOxuKUCKHgPg\/imUcPhYqP\/GNzPmm3OrnaE4D5egKCcPqVScVc70df46TDsviAV6aJsUJWmfL28d0fo4OBIdfksCUQUzAiB2ixwAwMmHB9nQb1uMC7c0LJweAmLyADCZoe6X2DqoyRG3t2CKrouKSXK0rLzAK9xpowP4bC+aWVmYYved610k9XxXN2LcR5okb\/SjNgwPlX3JcUAAQDWRACpRrn7tEgOAzL9YAcGFocvUJzAYoCJVXPgpKNBhbXcooFvfLyiqVVsmgSHUftlGxSKkwOJGlNS3cuEuLMzYIVSEX22dEXk6Vf5hAx5dr6jN7Ri1L0BS3valDLBTNa28htvPKOHOnAH4j5fTemxumE7hYWvAyL6Hlp\/0y8uf+HKCgEP+tBHEUVz6HFRLXYDHrf6dTMDrKxw8sEKADaM5AM6AygkA39cxAECJLgs9r\/8S4Bc\/kAFh9gr0m58TOPC+sawNZJx4wB0KOQSFyRw3ZhfEj4F4P1PoGMpgZCdQa5LmZdFx\/7wio\/FVXKKr5KDjSPg5XUfNtQnQg1f2z1n7+wjAkB4CQP6dRIcmAEB\/SnOBAoAI3fxNB3kC6ePAoxKoqtImIr4MHWJBaZIKhXs3In8omqEvsdWFzMh1eJGYfKjs\/6zs6sHjt61f2iX5T6JjG0h+N7KOLrViWAsfEaBMajLSZuqUneYb4BezTSrmOUmYDiGwCwG0xaX0nw2aPGvIJtVPAgBMCFTnWjQIA\/gyfjT9+balsI6Tf7S5MwEAvvdpP8d7BORKHBfIBUwcDH6uDJlEnQuU6z+IQg2rIAAMdtRviv+5u0p0ZxziU6ZDrAIDoGvHnyuvLgCgd42AUuYIECh8Jv2JA8hbQ1rxyRHgYlTEwEzT+goCaIvhX2+fDXGjMpqUaBGZfacBAHk0cg51DLaUhCBLJB9kCAA0kdYJWAFAkYFh548IwDl8Oj4Mb5IilBI3KrkPAI6bVm70kk19RhfWdohdlnW2ci9gF0clvdkordmcCe5CpmE+xggAdik0R4AEgflPQEAiZlfnOmGAHTne7yjaTz6jH99AAOyJjJBIDVQciXueJyEiORsNwYEiYChY7MW7Cyg1RI9HgNnMjYYZz8MjdRAtAEwxiKSFY3GsyDIR\/0mP4K1OKcD6jVNasfpzFwEAAgiBy0FXzjLw46LJkaf+NUQ4j34vo52FraXGcURMNsIDNQwVXRilHha\/4mFfGa0EC3OACn+fySiC26sAAHPh0ixUkPieGSlWf+4D4JyAkGBpzBHXS+sseZDD9u9bw3zijbb2Y1MpOSP01eMeRoM2MifYIOnSEA1fMABMMYX8IYfaFvxPCMBYgKooYCF+2FsxCBCvP\/MibdBjPAbM1FaFiNOGNJn8pSsDShruAS2+lIS8O4h9Cf7\/8JyZAZDt6SDApWQSehg7eueWf6Udoa+Pqeno8uaMaCiO1z6MweAmOz2MBikA6OQzREAkuWztYBvMwJzYvimmMg7ErwyTs9U3KSCQ\/\/DsXVYv54Bs7y6x4+t36Cp69pIzJw2prQKNgE3PlwCr7JxcPBKMUgRgVCvotIGm7KwLaNJ59ZwcCpHOAaATDrURAKFlJbE7\/oYTkHB\/iS4HABdyJSwAIKYugIUAjNrfhdSMPdnAv0UFDSUPXYcq4v\/joiHGjmnRaTViqNuu0oyPN5agiJdP7EiXwnqCGAAEHQHAKwIA+jcKADUCgJN1dgGnR4bRfVHFN7on\/aVKiPvystqv7kRm4A0AKRj\/d\/SK\/np040rBE53UXIoqBpjqiQPUUKsFAPvOG2WWUjL6Zr1FOLEJ7H1TLq0R6cO+X1pnhAwAxO9Sjh2hL+VeiikrIQTk4je3wTvjufAHAJoNFeYeoKozMeKnjXDy5LBU\/GgSUMpIC5X0B2wo8tzc7gd8uFEcbD3HhMPpxm+8QS+urmP5YvMbtl2xK1uVFAozoWpLlfrXUH4mM9DwcoAYUlj\/zi0WfeyAG1ykANCOYUb\/sfGHOzF3wACACmEyCxYAtCOqLrUQfF9kN5jh+LtHneTBIMwfZ8JRm3v9YPGtFRj9AW4AYFbL5CG80n79gch65lNUD0R3Jxfkb1pI6EZCU1vpb1gB4CmtIrgc4OgYwG3EjqPoSdCqVYhluUoA2OO5KmV\/DhPC\/DAiCxmZxQCA6wEToD\/g9SkAXBlk+Jb4AxP7ochcaecl+QcQIBxMLnV\/RH\/w4BnMGeYeHYFRQzhkiX4eDfL411nLWit1n\/anxZzB4oNNMH9w5zPdcndmDQDTRqZ3LpD8AAG4YI4AYKMmaAZ8pwxdue77FpR6Sf7SqP3ypWRNv4HyH3e7DbLfWPaqUJg6CSZarQFApHI07LbEM7aLzviS8oVOz1GHciIAaKZnl+EBpq+7groxEcF2k5G5l7CJGiqKcFqrlhRIiaZwuXrxJFfOC98AAFxnfQYAADtEcKHwto9iDgZAEA0b4+Vv8ya0iisHkQHZVSgAALRymG5GKq46d\/fj3EC1S6jPkY3kP2UAvSCPKCDMkEo+mR5j6ZMrF0hV44m+VUeuP0RAdKf7+2yCk5H\/0ZkxT+oozHWiGy7qTopXOLAAIHnuxY0PEMCMADdqm6XYZ3VWCAJAvdhSwJkXFG19LK8UKhEDOBCMiskKazsaCf8D02NAYXAHK5IbIJjJ\/8zxJgSQ4nNnKKoLPFmCt8CiKeF1D+BYVrQ8+8zTVXpkNK31PYlhGgCA\/I\/HNAAMAnrvbhl4Vf7xcAn8s7kdAKDiZwMAQoFOoYvkr1UM1lPXIKA10AFgP2M2srQnccMJE2dUZ8zF6PMgplEldCPNq2Gdb4HUAJKnX\/J1\/hcPeKBPkjUPLRGO1z\/cDqFxAhIV\/QwASA85AqDgIXTxbA6tIQDGGsRaIOByFQGzW6R+luc64CkfXfgQGSoChX4OLD94uEC8PwTA+VrbByNe8g8roCfi\/CSVZIpc8Wh6MjQAwpyHSyQwNxYz5aoVAJBBRac+mJJ3STfwyUXiYBpAQZl882na\/l55r38bHYDYyFMei6nNqLYKlzb3z7tRZfpclEef4EJWfqWXIhfYIYD5o8oJMYQsZQKijyxLDCxwYu8wlnK5sMajucV3TZtVqEWXQwEDIAWefmuhdRnDfpj0zRb\/NLs4o5kd8xHIpknyT88R0NDPx1uH2PeE5h6HuuikAKyXSFC1QkAAE1I8scKiv1nnCRDqgEOxmTn25ooFwJGM9TR7r2CmAACs\/jneztvQdLPj5jiHMlXdUhyoaezU+UoQjxtTAOeMlYbO9OK6x7I\/zu0GAZrpNJbxygUGWOl+Iy83m\/KSfJsWm49SYKidengRCAwEgEkq+pkpAFyasHwOQW9QAqd3ZxG6Hsiud4nh2lI3xhJKmssGa70V5qK69G2cHArQqCZA7nyTGqj3JwCo4s6t4jr2M1Teh0KM138PAEHAxTCiBQBkGchXq90sSsxuE+G3ZlN8RzHDmH1b+c4WgREj48eZXUqe3vyW\/36aAGghVymqZN4TKSjLuUrYpQpbT+Xf8McCAO5T3OdQ8r3V\/82EZi0FqIXmJQAYkoV7pGUALOpi8cvskunlA5VwtYasILb+2BEoaPlkXXla2lHLbdUdBUwO6AAAxZKP58vZfNi8PWsOwPNHy3YCRhSMK+AX39I7dCLcR9VKfQ7ZCBsDYOVv3ADA5ZITUjYVLRz3prU3dgCsgImEzz99KdH4niPCWNvoHwZTvI\/wM0kFtZ0\/qByBCaaAxzhxsVHv3UodJa2xuSIo+lGYHuLt1HvyZ8kmZKKBEck\/YABhEw\/UuwAAKkCPvDv\/TYvfb9sACFScC6f42BI+hKwijfvoqvxOSoFanfH2wo2p6r5TGslBAV8A2HbYTGi11Hh8F4QmABBeUBICX+U2APYMAZH0txkBBB07p57KJQA4dWWpxk1s\/IMg\/IMABqmpuS1niinvMg2Pg0b93pD4x21LxznAx\/tkB6mMLKOxvfzgM1oYACUd5jX5V2dY1cTazyrBb\/Zz2bZeBQC3agcA7KbW5EMEXHK146UUKniECv1GJXjOQTtSULgV+QhB44gpM4WaFY54pKSzsQf8lvX2oN3Exl9b1LKk+QXn\/WsGgKns8f3kZCGbVNo9s\/KHJYBk0+oG9sE2AQAgj0FeAYDy5MbbfLnCzEUgpx\/b8xwJQzggIrtT\/dXJVpSpRD6B2LtztGNvan+gwBl3E5a7a79B\/qRDQW7qPKWTbUDBhBO737C7EKBhgH2b1JZdJwE2Ym2GBljQu42rJQD4vAetLSMxeOOGmmLwtpE1DgAYvc2JAnjRhkUU59nBFJMZ3xUEJnH9w+GSFAl+7jwA3FvUxknGALuclyjLD3IQ8FIA2Lhr6x4RQNLKfQlrqCGOERAcZ6PsQO\/RscV0ojEiYEzCvpPg7XB5D1IAMJD\/lM6iZ7e6XRYP7w99VCYazjAJChNxryFKErlCAaICGivEUDWd9aIBAEIKssoBAcYE7DtmnMLc6VMqailLm6SAoMWKXcs1c4LoVf6d6mnEZ9yYNpU8RmlXioPdKc4l8v9HTepHeIQ\/Q03zA\/CpyxEzDmh6n+qS\/KsCgHtWADDLFMrZ2ouftoHUEiBifrswOL+OsHkTAD0FQAUz23ufW3\/tBVba3+R+ojHYNxmyEMD7ucKKXwgIHB5opll0WHsePwEMeAEAyO5BqQFEs1YAKBcBkPYc1eQvBx6r1ls3AoSW2BENai9NAcD2ZAoWhDh+LH3lCtyddp4tAKQ9\/YZ7lYX34iQYaQEgA1IbFCJ0ZcxmOzkGAInw8RUrAASFgDkAULszAJhXTdaFl+Vv0IAACHECISEnCDsBsswutOnIK0EaguqzNdwfnQl13jS3QhAAVCFnDYCOges4deLz9SHCo9SMd42cnfiLM4qiIvuEAZQN2FaBgfjejFh78uf1XFTtYQ27rCLfo0pMxQI2+HWnghTZADfyF8EyAOgJO6aq954xSQEeuyRosRqz3f8SPiMAMAQgUcJ9JeH0BTtMk2eWQtMXEsEdsTpzIUEWt1zQZMvC53S\/fUPf1g9RKtBZaXjnjRCJAKC0hGhQNp5lFz7Xt3ZkCXn3KrASvGACAgTs88vJ39ZqZi7qLQCY6gxc6eXl3IIK+aSCzedpkG5uWF+k074FQNMAiIc0v7c7FoAtzW0M0HI\/KJv4EQDswC6s9761QQyAK+FBM7kqvyfN6afXuo86z47YRgOCc5jPDUM8PmnLUPvIFH1QVlUu\/+w+7gJAhRA+cRsA1nsEAIjoYPchvQOA0j5frJvsmq7rQZGOH9gVIlCTS8KnFUG8cxDYBwYAN5\/nCdh0zZidtyrVASS243ocmz\/1CgCWDDARKkYP0xzQSyyw+3WAsvW7lF66rnXQVp966+6ePjQAri8IFnMkMBF5u186xg\/pT1oqMEZqrXhDIxHqzO2zNwMz68zOkRRKAKic43RP\/wlMpAlTArBI0Qm2lxjAewEofjSECAAn5InhUL2H1DkRHE\/PVizNOntVVTSus0Q8HvxjLdKgoEUwMo+Sv6DsCAVLB9yZ\/HMAcCB5AgDYD1GpYLcYADx+CwC93HfMkFj7OQCgCXJ6ZfduZt\/M44Uw4CpI6KVg0stVi+Qgt\/xM\/\/x604O1kz5ICRyXslkfBVH\/RP7t2kohpABXkl+sXd6LDvlcAsC+5yvHYn9cAIBBquysBRC4DwA69LS\/ot0jjYjkmdDKEABybpfX9uUyhTa8A91v\/NvNS20QFUKA7Nt4ArgOgFtX2JLOskDBH14JcFbvSD863arrE25SzJzyztBSTxMwEf94\/zUA6D1iyfim\/+UASAPEuKiR\/QLtne22yaz0JrsAgG1Lc0RSMGgDpKpXdLQgSQPIWYDPt6Vtwvz0s05ZAwoKeDCKQ4iq9aEbewTLfnOPTB8T6QukTLnHzXCxr\/IBZxcm3TqBEQXMxciHlf0UAISUolFdAAAcXnbljMuuX87HHmJpn5yYLKgCWb1v7bEkACGRNQDob4iPcAZQy8Q8sQA8qeABRPInZRYALMUoIfSss+1c\/MBGFq21mHE6AORcf\/Oks9XTJH11ICKqa3skQo3MVPv4ojj2\/asI+Y\/1l3XEnEhdB+KY+nc4iOxj9d8jACxDxldM\/c9cQCT6ZERW0Idi\/R8BQFjompy+sJa\/\/AKVSCEAiAai4E4EADpw5JaXaL+ct4p84DVFQKb\/vwQCj4oO68MH3FFwi6+fQMCN4G+QLcSdYkpSkeipfS1\/OYZmv+cCCMUzAkpUClknEIi9vz+SvgJAOwEAAh5VCeiWXIdAzRDQPloDovIPPyCqN8Ro\/g1Rkvm\/+UbUbmxBFdyZS3WWJv1e+P+V\/PnYuO6P1oPX3wSA\/aPC8uAzDLAjuEDADQDcVH1FAXBjGQBGInaAgAACfyj\/HgNAC\/qVAeCiDYhcgHwf8FLNWab\/YIo\/kOYHCBgAaHJnjAhApKAitgNmsv\/OAGhB9vPQKC3o5C3fXQhwyJhTAm4AQEzB9PoAAvtd5BgAqPI9B4A0LCjS\/0PtD51PBEB8LyD9bwEAyIAiBcILV9EQkO0+B8BavPcBoDcx4yrFvEcCZeX+se\/XewYAOlTbH6ps1f97FKAr3lV7IA4UzOoNuGQjtwVGpuW2eEN4qI8pgICyAEByDQD8qecXIuDV6dzAIPQYOIbflb9BQmsSO27NAGBJAjVcEEL9mPz\/tsQxdaSYsAJUos6EPLsEAH+JAHE4lfvxUHCYM0bLkthvC17XFsBe0iWHoGQAkHSRywAo0SPsVA45Ay5KKft1UcdbycMHeEUe1++J\/zX2k0G0GgBokHpqMpYpop+zQbu4ZRS1HjEcoKQ2Y\/bgsUL5YpQZrAqz+It+BAB\/uvxjxtE+wDHxfgHQ0+u3hM82YRUxoPq9dM53lhwkATphewehhEmA6clXe\/qHPBif\/dGkMPjPAHCCgGJ7sg6JAdC170+C\/wX9t2igdaJsKwfSj1wuEoOSYUIBnDVcHAEEktzVj5m+B2jcvdEw8cC\/IwDR7XEH7x9jN9DcDJgA6lzX6IW\/I3j+aZpiJBSQdiLUmdy7XReQaYeObor+Lwl6pfgKASEBmOOZ\/kD+5OoDi5\/\/KgCYN5DRX+cF\/oT85e9a6yqFZOIEKvHsCQAAAeI27Ldkv7xGWbd7VADQ4JC+35d\/bMXRBCjG+A2T72WPuYSmlcpE9pm22UoeCwD1D71eXIYPAcAdbHTbvmr6sdAzQYboN0V74UX4bVqksBuYwmYtyZ+BSeXwEHeBjpPII\/7X9RwkEVD8YAl3X+B+z0etTME7cW6KQNsC4NuqfQEA9MVOUo8+\/QwVBYDuFnTKbNABUU6l0Qj57k5SGhHQGNgCK3Bb0hX\/z5lI\/JO\/WPez1hYqu2mZDWoL9+sAePXRIdZLof8\/DufP6BKsNTQAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTAtMTItMjNUMDM6MDA6MDArMDE6MDCTKE3mAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDEwLTEyLTIzVDAzOjAwOjAwKzAxOjAw4nX1WgAAAABJRU5ErkJggg==","decals":[]});
function main() {
	screenResize();
	window.addEventListener('resize', screenResize);
	window.G = new Stub.Game();

	var oScreen = document.getElementById(CONFIG.raycaster.canvas);
	if (O876_Raycaster.PointerLock.init()) {
		oScreen.addEventListener('click', function(oEvent) {
			lockPointer(oEvent.target);
		});
	} else {
		document.getElementById('info').innerHTML = 'No PointerLock AP available on this browser';
	}
}

/**
 * Entre en mode pointerlock
 * @param oElement
 * @returns {Boolean}
 */
function lockPointer(oElement) {
	if (!G.oRaycaster.oCamera || !G.oRaycaster.oCamera.oThinker) {
		return false;
	}
	if (O876_Raycaster.PointerLock.locked()) {
		return false;
	}
	if (CONFIG.game.fullscreen) {
		O876_Raycaster.FullScreen.changeEvent = function() {
			if (O876_Raycaster.FullScreen.isFullScreen()) {
				O876_Raycaster.PointerLock.requestPointerLock(oElement);
				O876_Raycaster.PointerLock.setHook(G.oRaycaster.oCamera.oThinker.readMouseMovement, G.oRaycaster.oCamera.oThinker);
			}
		};
		O876_Raycaster.FullScreen.enter(oElement);
	} else {
		O876_Raycaster.PointerLock.requestPointerLock(oElement);
		O876_Raycaster.PointerLock.setHook(G.oRaycaster.oCamera.oThinker.readMouseMovement, G.oRaycaster.oCamera.oThinker);
	}
	return true;
}


function screenResize(oEvent) {
	var nPadding = 24;
	var h = innerHeight;
	var w = innerWidth;
	var r = (h - nPadding) / w;
	var oCanvas = document.getElementById('screen');
	var rBase = oCanvas.height / oCanvas.width; 
	if (r < rBase) { // utiliser height
		h -= nPadding;
		oCanvas.style.width = '';
		oCanvas.style.height = h.toString() + 'px';
	} else { // utiliser width
		oCanvas.style.width = w.toString() + 'px';
		oCanvas.style.height = '';
	}
}

window.addEventListener('load', main);

/* globals O2, H5UI */

O2.extendClass('H5UI.Box', H5UI.WinControl, {
	_sClass : 'Box',
	_sColor : '#FFFFFF',
	_sColorOutside : '#FF6666',
	_sColorInside : '#FFBBBB',
	_sColorBorder : '#000000',
	_sColorBorderOutside : '#000000',
	_sColorBorderInside : '#000000',
	_nBorderWidth : 8,

	_xGradStart : 0,
	_yGradStart : 0,
	_xGradEnd : 0,
	_yGradEnd : 0,
	_nGradOrientation : 0,
	

	setColor : function(sNormal, sHighlight) {
		if (sHighlight === undefined) {
			sHighlight = sNormal;
		}
		this._sColorInside = sHighlight;
		this._set('_sColor', this._sColorOutside = sNormal);
	},

	setBorder : function(n, sOut, sIn) {
		if (sOut === undefined) {
			sOut = '#000000';
		}
		if (sIn === undefined) {
			sIn = sOut;
		}
		if (n) {
			this._set('_sColorBorderOutside', sOut);
			this._set('_sColorBorderInside', sIn);
			this._set('_sColorBorder', sOut);
		}
		this._set('_nBorderWidth', n);
	},

	onMouseIn : function(x, y, b) {
		this._set('_sColorBorder', this._sColorBorderInside);
		this._set('_sColor', this._sColorInside);
	},

	onMouseOut : function(x, y, b) {
		this._set('_sColorBorder', this._sColorBorderOutside);
		this._set('_sColor', this._sColorOutside);
	},

	computeGradientOrientation : function() {
		switch (this._nGradOrientation) {
		case 1: // Vertical
			this._xGradStart = 0;
			this._yGradStart = 0;
			this._xGradEnd = 0;
			this._yGradEnd = this.getHeight() - 1;
			break;

		case 2: // Horiz
			this._xGradStart = 0;
			this._yGradStart = 0;
			this._xGradEnd = this.getWidth() - 1;
			this._yGradEnd = 0;
			break;
	
		case 3: // Diag 1
			this._xGradStart = 0;
			this._yGradStart = 0;
			this._xGradEnd = this.getWidth() - 1;
			this._yGradEnd = this.getHeight() - 1;
			break;
	
		case 4: // Diag 2
			this._xGradStart = this.getWidth() - 1;
			this._yGradStart = 0;
			this._xGradEnd = 0;
			this._yGradEnd = this.getHeight() - 1;
			break;
		}
	},

	getFillStyle : function() {
		var s = this.getSurface();
		var aGrad = this._sColor.split(' ');
		var xFillStyle;
		if (aGrad.length === 1) {
			xFillStyle = this._sColor;
		} else {
			// Le gradient contient il un mot clé permettant d'influencer le
			// type de gradient ?
			switch (aGrad[0]) {
				case 'hgrad':
					this._nGradOrientation = 2;
					break;
	
				case 'vgrad':
					this._nGradOrientation = 1;
					break;
	
				case 'd1grad':
					this._nGradOrientation = 3;
					break;
	
				case 'd2grad':
					this._nGradOrientation = 4;
					break;
	
				default:
					this._nGradOrientation = 0;
					break;
			}
			if (this._nGradOrientation) {
				aGrad.shift();
			}
			this.computeGradientOrientation();
			var oGrad = s.createLinearGradient(this._xGradStart, this._yGradStart,
					this._xGradEnd, this._yGradEnd);
			for ( var iGrad = 0; iGrad < aGrad.length; iGrad++) {
				oGrad.addColorStop(iGrad / (aGrad.length - 1), aGrad[iGrad]);
			}
			xFillStyle = oGrad;
		}
		return xFillStyle;
	},

	renderSelf : function() {
		this._oContext.fillStyle = this.getFillStyle();
		this._oContext.fillRect(0, 0, this.getWidth(), this.getHeight());
		if (this._nBorderWidth) {
			this._oContext.strokeStyle = this._sColorBorder;
			this._oContext.lineWidth = this._nBorderWidth;
			this._oContext.strokeRect(0, 0, this.getWidth(), this.getHeight());
		}
	}
});

/**
 * Ce composant est un bouton cliquable avec un caption de texte Le bouton
 * change de couleur lorsque la souris passe dessus Et il possède 2 état
 * (normal/surbrillance)
 */
O2.extendClass('H5UI.Button', H5UI.Box, {
	oText : null,
	_sColorNormal : '#999',
	_sColorOver : '#BBB',
	_sColorSelect : '#DDD',
	_sColorBorder : '#000',

	__construct : function() {
		__inherited();
		this.setSize(64, 24);
		this.setColor(this._sColorNormal, this._sColorOver);
		this.setBorder(1, this._sColorBorder);
		this.oText = this.linkControl(new H5UI.Text());
		this.oText.font.setFont('Arial');
		this.oText.font.setSize(12);
		this.oText.font.setColor('#000');
		this.oText.moveTo(4, 4);
		this.oText.setCaption('Button');
		this.oText.align('center');
	},

	setCaption : function(sCaption) {
		this.oText.setCaption(sCaption);
		this.realignControls();
	},

	getCaption : function() {
		return this.oText._sCaption;
	},

	highlight : function(b) {
		if (b) {
			this.setColor(this._sColorSelect, this._sColorOver);
		} else {
			this.setColor(this._sColorNormal, this._sColorOver);
		}
	}
});

O2.extendClass('H5UI.Image', H5UI.WinControl, {
	_oTexture: null,
	_bAutosize: true,
	onLoad: null,
	
	_loadEvent: function(oEvent) {
		var i = oEvent.target.__image;
		oEvent.target.__image = null;
		if (i.onLoad) {
			i.onLoad();
		} else {
			i.invalidate();
		}
	},
	
	setSource: function(sSrc) {
		if (!this._oTexture) {
			this._oTexture = new Image();
		}
		this._oTexture.src = sSrc;
		this._oTexture.__image = this;
		this._oTexture.addEventListener('load', this._loadEvent, true);
		this.invalidate();
	},
	
	setImage: function(oImage) {
		if (this._oTexture != oImage) {
			this._oTexture = oImage;
			this._oTexture.__image = this;
			this._oTexture.addEventListener('load', this._loadEvent, true);
			this.invalidate();
		}
	},
	
	
	renderSelf: function() {
		var s = this.getSurface();
		if (this._oTexture && this._oTexture.complete) {
			if (this._bAutosize) {
				this.setSize(this._oTexture.width, this._oTexture.height);
				s.drawImage(this._oTexture,	0, 0);						
			} else {
				s.clearRect(0, 0, this.getWidth(), this.getHeight());
				s.drawImage(
					this._oTexture,
					0, 
					0, 
					this._oTexture.width, 
					this._oTexture.height,
					0, 
					0, 
					this.getWidth(),
					this.getHeight()
				);
			}
		}
	}
});

/**
 * Ce composant est une surface qui peut afficher une partie d'une surface plus
 * grande que lui. On appellera "conteneur interne" le composant de grande
 * taille dont on affiche une partie. On utilise des methode de scroll pour
 * déplacer la fenetre d'affichage afin de voir d'autre parties du container
 * interne. Le conteneur interne se redimensionne en fonction de la taille et de
 * la position des objets qu'il contient.
 */
O2.extendClass('H5UI.ScrollBox', 'H5UI.WinControl', {
	_sClass : 'ScrollBox',
	_oContainer : null,
	_xScroll : 0,
	_yScroll : 0,

	/**
	 * Methode modifiée qui linke le controle transmis en paramètre directement
	 * dans le conteneur interne
	 * 
	 * @param o
	 *            control à linker
	 * @param bParent, -
	 *            true: on link le controle sur la scrollbox (ce control ne se
	 *            déplacera donc pas par scrolling puisse qu'il ne fera pas
	 *            partie du conteneur inter. - false: on link le controle dans
	 *            le conteneur interne, le controle sera sujet au scrolling le
	 *            conteneur interne s'agrrandi en cas de besoin
	 */
	linkControl : function(o, bParent) {
		if (bParent === undefined) {
			bParent = false;
		}
		if (bParent) {
			__inherited(o);
		} else {
			this.getContainer().linkControl(o);
		}
		return o;
	},

	/**
	 * Renvoie l'instance du controleur interne Construit le conteneur interne
	 * on the fly en cas de besoin
	 * 
	 * @return ScrollBoxContainer
	 */
	getContainer : function() {
		if (this._oContainer === null) {
			this._oContainer = this.linkControl(new H5UI.WinControl(), true);
			this._oContainer._sClass = 'ScrollBoxContainer';
		}
		return this._oContainer;
	},

	/**
	 * Déplace la position de scrolling
	 * 
	 * @param x,
	 *            y nouvelle position de scroll
	 */
	scrollTo : function(x, y) {
		if (x != this._xScroll || y != this._yScroll) {
			this._xScroll = x;
			this._yScroll = y;
			this.getContainer().moveTo(-x, -y);
			this.invalidate();
		}
	},

	/**
	 * Renvoie la position X de la fenetre d'affichage
	 * 
	 * @return int (pixels)
	 */
	getScrollX : function() {
		return this._xScroll;
	},

	/**
	 * Renvoie la position Y de la fenetre d'affichage
	 * 
	 * @return int (pixels)
	 */
	getScrollY : function() {
		return this._yScroll;
	},

	// la première errer de non transmission d'évènement souris était du a une
	// Height mal calculée
	// cette deuxième erreur est également du au fait d'une mauvaise redimension
	// de controle

	renderSelf : function() {
		// Le container doit être assez grand pour tout contenir
		var w = 0, h = 0, o;
		var c = this.getContainer();
		for ( var i = 0; i < c._aControls.length; i++) {
			o = c.getControl(i);
			w = Math.max(w, o._x + o.getWidth());
			h = Math.max(h, o._y + o.getHeight());
		}
		c.setSize(w, h);
	}
});


/**
 * Un composant simple qui affiche un texte Penser à redimensionner correctement
 * le controle, sinon le texte sera invisible
 */
O2.extendClass('H5UI.Text', H5UI.WinControl, {
	_sClass : 'Text',
	_sCaption : '',
	_bAutosize : true,
	_bWordWrap: false,
	_nTextWidth: 0,	
	_nLineHeight: 0,
	_yLastWritten: 0,
	

	// propriété publique
	font : null,

	__construct : function() {
		__inherited();
		O876.CanvasFactory.setImageSmoothing(this.getSurface(), true);
		this.font = new H5UI.Font(this);
	},

	/**
	 * Modification du caption
	 * 
	 * @param s
	 *            nouveau caption
	 */
	setCaption : function(s) {
		this._set('_sCaption', s);
		if (this._bAutosize && this._bInvalid) {
			this.font.update();
			var oMetrics = this.getSurface().measureText(this._sCaption);
			this.setSize(oMetrics.width, this.font._nFontSize + 1);
		}
	},

	/**
	 * Définition du flag autosize quand ce flag est actif, le control prend la
	 * dimension du texte qu'il contient
	 */
	setAutosize : function(b) {
		this._set('_bAutosize', b);
	},

	/**
	 * Définition du flag wordwrap, quand ce flag est actif, la taille est fixe
	 * et le texte passe à la ligne si celui-ci est plus long que la longeur.
	 */
	setWordWrap : function(b) {
		this._set('_bWordWrap', b);
	},

	renderSelf : function() {
		var oSurface = this.getSurface();
		var oMetrics;
		// Redimensionnement du texte
		oSurface.clearRect(0, 0, this.getWidth(), this.getHeight());
		if (this._bWordWrap){
			this.font.update();
			var aWords;
			var sLine = '', sWord, x = 0, y = 0;
			var sSpace;
			oSurface.textBaseline = 'top';
			var aParas = this._sCaption.split('\n');
			for (var iPara = 0; iPara < aParas.length; iPara++) {
				aWords = aParas[iPara].split(' ');
				while (aWords.length) {
					sWord = aWords.shift();
					sSpace = sLine ? ' ' : '';
					oMetrics = oSurface.measureText(sLine + sSpace + sWord);
					if (oMetrics.width >= this.getWidth()) {
						// flush
						x = 0;
						if (this.font._bOutline) {
							oSurface.strokeText(sLine, x, y);
						}		
						oSurface.fillText(sLine, x, y);
						y += this.font._nFontSize + this._nLineHeight;
						sLine = sWord;
					} else {
						sLine += sSpace + sWord;
						x += oMetrics.width;
					}
				}
				x = 0;
				if (this.font._bOutline) {
					oSurface.strokeText(sLine, x, y);
				}		
				oSurface.fillText(sLine, x, y);
				y += this.font._nFontSize + this._nLineHeight;
				sLine = '';
				this._yLastWritten = y;
			}
		} else {
			if (this._bAutosize) {
				this.font.update();
				oMetrics = oSurface.measureText(this._sCaption);
				this.setSize(oMetrics.width, this.font._nFontSize + 1);
			} else {
			}
			oSurface.textBaseline = 'middle';
			if (this.font._bOutline) {
				oSurface.strokeText(this._sCaption, 0, this.getHeight() >> 1);
			}		
			oSurface.fillText(this._sCaption, 0, this.getHeight() >> 1);
		}
	}
});


/**
 * Grille d'image (petites images)
 * 
 */
O2.extendClass('H5UI.TileGrid', H5UI.WinControl, {
	_oTexture : null,
	
	_nCellWidth: 8,
	_nCellHeight: 8,
	_nCellPadding: 0,
	
	_aCells: null,
	_aInvalidCells: null,
	
	_bTransparent: true,  // true: considère les Tile comme transparentes (nécessitant un clearRect)
	
	
	/** Modification de la taille de la grille
	 * @param w int largeur (nombre de cellule en X)
	 * @param h int hauteur (nombre de cellule en Y)
	 */
	setGridSize: function(w, h, nPadding) {
		this._nCellPadding = nPadding | 0;
		this._aCells = [];
		var x, y, aRow;
		for (y = 0; y < h; y++) {
			aRow = [];
			for (x = 0; x < w; x++) {
				aRow.push(-1);
			}
			this._aCells.push(aRow);
		}
		this._aInvalidCells = {};
		var wTotal = (this._nCellWidth + this._nCellPadding) * w;
		var hTotal = (this._nCellHeight + this._nCellPadding) * h;
		this.setSize(wTotal, hTotal);
	},
	
	/** Fabrique une clé à partir des coordonnées transmise
	 * utilisé pour déterminer la liste des case qui ont été modifiées
	 * @param x
	 * @param y coordonnée de la celluel dont on cherche la clé
	 * @return string
	 */
	getCellKey: function(x, y) {
		return x.toString() + ':' + y.toString(); 
	},
	
	
	/** Modifie le code d'une cellule
	 * @param x 
	 * @param y coordonnées de la cellule
	 * @param n nouveau code de la cellule
	 */
	setCell: function(x, y, n) {
		if (this._aCells[y][x] !== n) {
			this._aCells[y][x] = n;
			var sKey = this.getCellKey(x, y);
			if (!(sKey in this._aInvalidCells)) {
				this._aInvalidCells[sKey] = [x, y];
				this.invalidate();
			}
		}
	},
	
	renderCell: function(x, y, n) {
		this.getSurface().drawImage(
			this._oTexture, 
			n * this._nCellWidth, 
			0, 
			this._nCellWidth, 
			this._nCellHeight, 
			x * (this._nCellWidth + this._nCellPadding), 
			y * (this._nCellHeight + this._nCellPadding), 
			this._nCellWidth, 
			this._nCellHeight
		);
	},
	
	renderSelf: function() {
		var h = this._aCells.length; 
		if (h === 0) {
			return;
		}
		var w = this._aCells[0].length;
		if (w === 0) {
			return;
		}
		if (this._nCellWidth * this._nCellHeight === 0) {
			return;
		}
		if (this._oTexture === null) {
			return;
		}
		var oCell, n, x, y;
		var s = this.getSurface();
		var b = false;
		for (var sKeyCell in this._aInvalidCells) {
			b = true;
			oCell = this._aInvalidCells[sKeyCell];
			x = oCell[0];
			y = oCell[1];
			n = this._aCells[y][x];
			if (this._bTransparent) {
				s.clearRect(x * (this._nCellWidth + this._nCellPadding), y * (this._nCellHeight + this._nCellPadding), this._nCellWidth + this._nCellPadding, this._nCellHeight + this._nCellPadding);
			}
			this.renderCell(x, y, n);
		}
		if (b) {
			this._aInvalidCells = {};			
		}
	}
});

O2.extendClass('O876_Raycaster.Engine', O876_Raycaster.Transistate, {
	// Juste une copie du TIME_FACTOR du raycaster
	TIME_FACTOR : 50, // Doit être identique au TIME_FACTOR du raycaster

	// public
	oRaycaster : null,
	oKbdDevice : null,
	oMouseDevice : null,
	oThinkerManager : null,
	
	// protected
	_oFrameCounter: null,
	_nTimeStamp : 0,
	_nShadedTiles : 0,
	_nShadedTileCount : 0,
	
	__construct : function() {
		if (!O876.Browser.checkHTML5('O876 Raycaster Engine')) {
			throw new Error('browser is not full html 5');
		}
		__inherited('stateInitialize');
		this.resume();
	},

	initRequestAnimationFrame : function() {
		if ('requestAnimationFrame' in window) {
			return true;
		}
		var RAF = null;
		if ('requestAnimationFrame' in window) {
			RAF = window.requestAnimationFrame;
		} else if ('webkitRequestAnimationFrame' in window) {
			RAF = window.webkitRequestAnimationFrame;
		} else if ('mozRequestAnimationFrame' in window) {
			RAF = window.mozRequestAnimationFrame;
		}
		if (RAF) {
			window.requestAnimationFrame = RAF;
			return true;
		} else {
			return false;
		}
	},
	
	initDoomLoop: function() {
		__inherited();
		this._nTimeStamp = null;
	},

	/**
	 * Déclenche un évènement
	 * 
	 * @param sEvent
	 *            nom de l'évènement
	 * @param oParam
	 *            paramètre optionnels à transmettre à l'évènement
	 * @return retour éventuel de la fonction évènement
	 */
	_callGameEvent : function(sEvent) {
		if (sEvent in this && this[sEvent]) {
			var pFunc = this[sEvent];
			var aParams = Array.prototype.slice.call(arguments, 1);
			return pFunc.apply(this, aParams);
		}
		return null;
	},

	/**
	 * Arret du moteur et affichage d'une erreur
	 * 
	 * @param sError
	 *            Message d'erreur
	 */
	_halt : function(sError, oError) {
		if (('console' in window) && ('log' in window.console) && (sError)) {
			console.log(sError);
			if (oError) {
				console.log(oError.toString());
			}
		}
		this.pause();
		this.setDoomloop('stateEnd');
		if (this.oKbdDevice) {
			this.oKbdDevice.unplugEvents();
		}
		if (this.oMouseDevice) {
			this.oMouseDevice.unplugEvents();
		}
	},

	/**
	 * Renvoie une instance du périphérique clavier
	 * 
	 * @return KeyboardDevice
	 */
	getKeyboardDevice : function() {
		if (this.oKbdDevice === null) {
			this.oKbdDevice = new O876_Raycaster.KeyboardDevice();
			this.oKbdDevice.plugEvents();
		}
		return this.oKbdDevice;
	},

	getMouseDevice : function(oElement) {
		if (this.oMouseDevice === null) {
			if (oElement === undefined) {
				throw new Error('no target element specified for the mouse device');
			}
			this.oMouseDevice = new O876_Raycaster.MouseDevice();
			this.oMouseDevice.plugEvents(oElement);
		}
		return this.oMouseDevice;
	},
	
	/**
	 * Renvoie le temps actuel en millisecondes
	 * @return int
	 */
	getTime: function() {
		return this._nTimeStamp;
	},

	/**
	 * Define time
	 * May be usefull whn using pause, to update the last time stamp
	 * and avoid a large amount of compensating calc.
	 */
	setTime: function(n) {
		this._nTimeStamp = n;
	},

	// ////////// METHODES PUBLIQUES API ////////////////

	/**
	 * Charge un nouveau niveau et ralnce la machine. Déclenche l'évènement
	 * onExitLevel avant de changer de niveau. Utiliser cet évènement afin de
	 * sauvegarder les données utiles entre les niveaux.
	 * 
	 * @param sLevel
	 *            référence du niveau à charger
	 */
	enterLevel : function() {
		this._callGameEvent('onExitLevel');
		this.setDoomloop('stateStartRaycaster');
	},

	/**
	 * Active un effet d'ouverture de porte ou passage secret sur un block
	 * donné. L'effet d'ouverture inclue la modification temporaire de la
	 * propriété du block permettant ainsi le libre passage des mobiles le temps
	 * d'ouverture (ce comportement est codé dans le GXDoor). Le bloc doit
	 * comporte un code physique correspondant à une porte : Un simple mur (code
	 * 1) ne peut pas faire office de porte
	 * 
	 * @param x
	 *            coordonnées du bloc-porte
	 * @param y
	 *            coordonnées du bloc-porte
	 * @param bStayOpen
	 *            désactive autoclose et garde la porte ouverte
	 * 
	 */
	openDoor : function(x, y, bStayOpen) {
		var nPhys = this.oRaycaster.getMapPhys(x, y);
		var o = null;
		switch (nPhys) {
			case 2: // Raycaster::PHYS_FIRST_DOOR
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8: // Raycaster::PHYS_LAST_DOOR
				if (!Marker.getMarkXY(this.oRaycaster.oDoors, x, y)) {
					o = new O876_Raycaster.GXDoor(this.oRaycaster);
					o.x = x;
					o.y = y;
					if (bStayOpen) {
						o.setAutoClose(0);
					}
					this.oRaycaster.oEffects.addEffect(o);
				}
				break;
	
			case 9: // Raycaster::PHYS_SECRET_BLOCK
				if (!Marker.getMarkXY(this.oRaycaster.oDoors, x, y)) {
					o = new O876_Raycaster.GXSecret(this.oRaycaster);
					o.x = x;
					o.y = y;
					this.oRaycaster.oEffects.addEffect(o);
				}
				break;
		}
		return o;
	},

	/**
	 * Fermeture manuelle d'une porte à la position X Y Utilisé avec les portes
	 * sans autoclose. S'il n'y a pas de porte ouverte en X Y -> aucun effet
	 * 
	 * @param x
	 *            coordonnées du bloc-porte
	 * @param y
	 *            coordonnées du bloc-porte
	 * @param bForce
	 *            force la fermeture même en case de présence de mobile
	 */
	closeDoor : function(x, y, bForce) {
		var oDoor = Marker.getMarkXY(this.oRaycaster.oDoors, x, y);
		if (oDoor) {
			oDoor.setAutoClose(1);
			oDoor.close();
		}
		return oDoor;
	},


	/**
	 * Création d'un nouveau mobile à la position spécifiée
	 * 
	 * @param sBlueprint
	 *            blueprint de l'objet à créer
	 * @param x
	 *            coordonnées initiales
	 * @param y
	 * @param fAngle
	 *            angle initial
	 * @return objet créé
	 */
	spawnMobile : function(sBlueprint, x, y, fAngle) {
		return this.oRaycaster.oHorde.spawnMobile(sBlueprint, x, y, fAngle);
	},
	
	// /////////// EVENEMENTS /////////////

	// onInitialize: null,

	// onRequestLevelData: null,

	// onLoading: null,

	// onEnterLevel: null,

	// onMenuLoop: null,

	// onDoomLoop: null,

	// onFrameRendered: null,

	// ////////////// ETATS ///////////////

	/**
	 * Initialisation du programme Ceci n'intervient qu'une fois
	 */
	stateInitialize : function() {
		// Evènement initialization
		this._callGameEvent('onInitialize');

		this.TIME_FACTOR = this.nInterval = CONFIG.game.interval;

		switch (CONFIG.game.doomloop) {
			case 'interval':
				this.stateRunning = this.stateRunningInt;
				break;

			case 'raf':
				if (this.initRequestAnimationFrame()) {
					this.stateRunning = this.stateRunningRAF;
				} else {
					CONFIG.game.doomloop = 'interval';
					this.stateRunning = this.stateRunningInt;
				}
				break;
		}
		this.setDoomloop('stateMenuLoop');
		this.resume();
	},

	/**
	 * Attend le choix d'une partie. Le programme doit afficher un menu ou un
	 * écran d'accueil. Pour lancer la partie, l'évènement onMenuLoop doit
	 * retourner la valeur 'true';
	 */
	stateMenuLoop : function() {
		if (this._callGameEvent('onMenuLoop')) {
			this.setDoomloop('stateStartRaycaster');
		}
	},

	/**
	 * Initialisation du Raycaster Ceci survient à chaque chargement de niveau
	 */
	stateStartRaycaster : function() {
		if (this.oRaycaster) {
			this.oRaycaster.finalize();
		} else {
			this.oRaycaster = new O876_Raycaster.Raycaster();
			this.oRaycaster.TIME_FACTOR = this.TIME_FACTOR;
		}
		this.oRaycaster.setConfig(CONFIG.raycaster);
		this.oRaycaster.initialize();
		this.oThinkerManager = this.oRaycaster.oThinkerManager;
		this.oThinkerManager.oGameInstance = this;
		this._callGameEvent('onLoading', 'lvl', 0, 2);
		this.setDoomloop('stateBuildLevel');
	},

	/**
	 * Prépare le chargement du niveau. RAZ de tous les objets.
	 */
	stateBuildLevel : function() {
		// Evènement chargement de niveau
		var oData = this._callGameEvent('onRequestLevelData');
		if (typeof oData != 'object') {
			this._halt('no world data : without world data I can\'t build the world. (onRequestLevelData did not return object)');
			return;
		}
		this.oRaycaster.defineWorld(oData);
		try {
			this.oRaycaster.buildLevel();
		} catch (e) {
			console.log(e.stack);
			this._halt('invalid world data (' + e.message + ')');
			return;
		}

		// calculer le nombre de shading à faire
		this._nShadedTileCount = 0;
		var iStc = '';
		for (iStc in this.oRaycaster.oHorde.oTiles) {
			if (this.oRaycaster.oHorde.oTiles[iStc].bShading) {
				++this._nShadedTileCount;
			}
		}
		this.setDoomloop('stateLoadComplete');
	},

	/**
	 * Patiente jusqu'à ce que les ressource soient chargée
	 */
	stateLoadComplete : function() {
		this._callGameEvent('onLoading', 'gfx', this.oRaycaster.oImages.countLoaded(), this.oRaycaster.oImages.countLoading() + this._nShadedTileCount);
		if (this.oRaycaster.oImages.complete()) {
			this.oRaycaster.backgroundRedim();
			this._nShadedTiles = 0;
			this.setDoomloop('stateShading');
		}
	},

	/**
	 * Procède à l'ombrage des textures
	 */
	stateShading : function() {
		this._callGameEvent('onLoading', 'shd', this.oRaycaster.oImages.countLoaded() + this._nShadedTiles, this.oRaycaster.oImages.countLoading() + this._nShadedTileCount);
		++this._nShadedTiles;
		if (!this.oRaycaster.shadeProcess()) {
			return;
		}
		// this._callGameEvent('onLoading', 'shd', 1, 1);
		this._oFrameCounter = new O876_Raycaster.FrameCounter();
		this.setDoomloop('stateRunning', CONFIG.game.doomloop);
		this._callGameEvent('onLoading', 'end', 1, 1);
		this._callGameEvent('onEnterLevel');
	},

	/**
	 * Déroulement du jeu
	 */
	stateRunning : null,

	/**
	 * Déroulement du jeu
	 */
	stateRunningInt : function() {
		var nNowTimeStamp = performance.now();
		var nFrames = 0;
		while (this._nTimeStamp < nNowTimeStamp) {
			this.oRaycaster.frameProcess();
			this._callGameEvent('onDoomLoop');
			this._nTimeStamp += this.nInterval;
			nFrames++;
		}
		if (nFrames) {
			var fc = this._oFrameCounter;
			this.oRaycaster.frameRender();
			this._callGameEvent('onFrameRendered');
			if (fc.check(nNowTimeStamp)) {
				this._callGameEvent('onFrameCount', fc.nFPS, fc.getAvgFPS(), fc.nSeconds);
			}
		}
	},

	/**
	 * Déroulement du jeu
	 */
	stateRunningRAF : function(nTime) {
		var nFrames = 0;
		var rc = this.oRaycaster;
		if (this._nTimeStamp === null) {
			this._nTimeStamp = nTime;
		}
		while (this._nTimeStamp < nTime) {
			rc.frameProcess();
			this._callGameEvent('onDoomLoop');
			this._nTimeStamp += this.nInterval;
			nFrames++;
		}
		if (nFrames) {
			rc.frameRender();
			this._callGameEvent('onFrameRendered');
			var fc = this._oFrameCounter;
			if (fc.check(nTime | 0)) {
				this._callGameEvent('onFrameCount', fc.nFPS, fc.getAvgFPS(), fc.nSeconds);
			}
		}
		this.oRafInterval = window.requestAnimationFrame(this.pDoomloop);
	},

	/**
	 * Fin du programme
	 * 
	 */
	stateEnd : function() {
		this.pause();
	}
});

/** Effet spécial temporisé
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet
 * Cet effet gère l'ouverture et la fermeture des portes, ce n'est pas un effet visuel a proprement parlé
 * L'effet se sert de sa référence au raycaster pour déterminer la présence d'obstacle génant la fermeture de la porte
 * C'est la fonction de temporisation qui est exploitée ici, même si l'effet n'est pas visuel.
 */
O2.extendClass('O876_Raycaster.GXDoor', O876_Raycaster.GXEffect, {
	sClass : 'Door',
	nPhase : 0, // Code de phase : les porte ont 4 phases : 0: fermée(init), 1: ouverture, 2: ouverte et en attente de fermeture, 3: en cours de fermeture, 4: fermée->0
	oRaycaster : null, // Référence au raycaster        
	x : 0, // position de la porte
	y : 0, // ...
	fOffset : 0, // offset de la porte
	
	nMaxTime : 3000, // temps d'ouverture max en ms
	nTime : 3000, // temps restant avant fermeture
	nAutoClose : 0, // Flag autoclose 1: autoclose ; 0: stay open

	fSpeed : 0, // vitesse d'incrémentation/décrémentation de la porte
	nLimit : 0, // limite d'incrément de l'offset (reduit par 2 pour les porte double)
	nCode : 0, // Code physique de la porte

	__construct: function(r) {
		__inherited(r);
		this.setAutoClose(true);
	},
	
	isOver : function() {
		return this.nPhase > 3;
	},

	process : function() {
		var r = this.oRaycaster;
		switch (this.nPhase) {
			case 0: // init
				Marker.markXY(r.oDoors, this.x, this.y, this);
				this.nCode = r.getMapPhys(this.x, this.y);
				switch (this.nCode) {
					case r.PHYS_DOOR_SLIDING_DOUBLE:
						this.fSpeed = r.TIME_FACTOR * 60 / 1000;
						this.nLimit = 32;
						break;
			
					case r.PHYS_DOOR_SLIDING_LEFT:
					case r.PHYS_DOOR_SLIDING_RIGHT:
						this.fSpeed = r.TIME_FACTOR * 120 / 1000;
						this.nLimit = r.nPlaneSpacing;
						break;
			
					default:
						this.fSpeed = r.TIME_FACTOR * 120 / 1000;
						this.nLimit = 96;
						break;
				}
				this.nPhase++;	/** no break on the next line */

			case 1: // la porte s'ouvre jusqu'a : offset > limite
				this.fOffset += this.fSpeed;
				if (this.fOffset >= this.nLimit) {
					this.fOffset = this.nLimit - 1;
					r.setMapPhys(this.x, this.y, 0);
					this.nPhase++;
				}
				break;

			case 2: // la porte attend avant de se refermer   
				this.nTime -= this.nAutoclose;
				if (this.nTime <= 0) {
					// Recherche de sprites solides empechant de refermer la porte
					if (r.oMobileSectors.get(this.x, this.y).length) {
						this.nTime = this.nMaxTime >> 1;
					} else {
						r.setMapPhys(this.x, this.y, this.nCode);
						this.nPhase++;
					}
				}
				break;
		
			case 3: // la porte se referme
				this.fOffset -= this.fSpeed;
				if (this.fOffset < 0) {
					this.terminate();
				}
				break;
		}
		r.setMapOffs(this.x, this.y, this.fOffset | 0);
	},

	/** Fermeture de la porte
	 * @param bForce force la fermeture en cas de présence de mobile
	 */
	close : function(bForce) {
		this.nTime = 0;
		if (bForce && this.nPhase == 2) {
			this.nPhase++;
		}
	},
	
	/** Position le flag autoclose
	 * @param n nouvelle valeur du flag
	 * 0: pas d'autoclose : la porte reste ouverte
	 * 1: autoclose : la porte se referme après le délai normal imparti
	 */
	setAutoClose : function(n) {
		this.nAutoclose = n ? this.oRaycaster.TIME_FACTOR : 0;
	},
	
	terminate : function() {
		// en phase 0 rien n'a vraiment commencé : se positionner en phase 4 et partir
		if (this.nPhase === 0) {
			this.nPhase = 4;
			Marker.clearXY(this.oRaycaster.oDoors, this.x, this.y);
			return;
		}
		this.fOffset = 0;
		Marker.clearXY(this.oRaycaster.oDoors, this.x, this.y);
		this.nPhase = 4;
		this.oRaycaster.setMapOffs(this.x, this.y, 0);
		this.oRaycaster.setMapPhys(this.x, this.y, this.nCode);
	}
});

/* globals O2, ClassMagic, O876, O876_Raycaster, WORLD_DATA, CONFIG, Marker */
O2.extendClass('O876_Raycaster.GameAbstract', O876_Raycaster.Engine, {
	_sLevelIndex: '',
	_oScreenShot: null,
	_oTagData: null,
	_sTag: '',
	_xTagProcessing: 0,
	_yTagProcessing: 0,
	_oClassLoader: null,

	/** 
	 * Evènement apellé lors de l'initialisation du jeu
	 * Appelé une seule fois.
	 */
	onInitialize: function() {
		this._oClassLoader = new O876.ClassLoader();
		this.on('tag', this.onTagTriggered.bind(this));
		if ('init' in this) {
			this.init();
		}
	},
	
	/**
	 * Cette évènement doit renvoyer TRUE pour pouvoir passer à l'étape suivante
	 * @return bool
	 */
	onMenuLoop: function() {
		var data = { exit: true };
		this.trigger('menuloop', data);
		return data.exit;
		// Doit retourner TRUE pour indiquer la validation du menu et passer à l'étape suivante
		// ici il n'y a pas de menu donc "true" pour passer directement à l'étape suivante
	},
	
	
	/**
	 * Evènement appelé lors du chargement d'un niveau,
	 * cet évènement doit renvoyer des données au format du Raycaster.
	 * @return object
	 */
	onRequestLevelData: function() {
		if ('WORLD_DATA' in window) {
			var aWorldDataKeys = Object.keys(WORLD_DATA);
			this._sLevelIndex = aWorldDataKeys[aWorldDataKeys.indexOf(this._sLevelIndex) + 1];
			this.trigger('build', WORLD_DATA[this._sLevelIndex]);
			return WORLD_DATA[this._sLevelIndex];
		} else {
			var wd = {};
			this.trigger('build', wd);
			return wd;
		}
	},
	
	/**
	 * Evènement appelé quand une ressource et chargée
	 * sert à faire des barres de progressions
	 */
	onLoading: function(sPhase, nProgress, nMax) {
		this.trigger('load', { phase: sPhase, progress: nProgress, max: nMax });
	},
	
	/**
	 * Evènement appelé lorsqu'un niveau a été chargé
	 * Permet l'initialisation des objet nouvellement créés (comme la caméra)
	 */
	onEnterLevel: function() {
		this.getMouseDevice(this.oRaycaster.oCanvas);
		this.oRaycaster.bSky = true;
		this.oRaycaster.bFlatSky = true;
		this.oRaycaster.nPlaneSpacing = 64;
		var oCT;
		if (('controlthinker' in CONFIG.game) && (CONFIG.game.controlthinker)) {
			var ControlThinkerClass = this._oClassLoader.loadClass(CONFIG.game.controlthinker);
			oCT = new ControlThinkerClass();
		} else {
			if (CONFIG.game.fpscontrol) {
				oCT = new O876_Raycaster.FirstPersonThinker();
			} else {
				oCT = new O876_Raycaster.CameraKeyboardThinker();
			}
			oCT.on('use.down', (function() {
				this.oGame.activateWall(this.oMobile);    
			}).bind(oCT));
		}
		oCT.oGame = this;
		this.oRaycaster.oCamera.setThinker(oCT);
		// Tags data
		var iTag, oTag;
		var aTags = this.oRaycaster.aWorld.tags;
		this._oTagData = Marker.create();
		for (iTag = 0; iTag < aTags.length; ++iTag) {
			oTag = aTags[iTag];
			Marker.markXY(this._oTagData, oTag.x, oTag.y, oTag.tag);
		}
		// decals
		var oRC = this.oRaycaster;
		if ('decals' in oRC.aWorld) {
			oRC.aWorld.decals.forEach(function(d) {
				var x = d.x;
				var y = d.y;
				var nSide = d.side;
				var sImage = d.tile;
				oRC.cloneWall(x, y, nSide, function(rc, oCanvas, xw, yw, sw) {
					var oImage = rc.oHorde.oTiles[sImage].oImage;
					var wt = rc.oHorde.oTiles[sImage].nWidth;
					var ht = rc.oHorde.oTiles[sImage].nHeight;
					oCanvas.getContext('2d').drawImage(
						oImage,
						0,
						0,
						wt,
						ht,
						(rc.xTexture - wt) >> 1, 
						(rc.yTexture - ht) >> 1, 
						wt,
						ht
					);
				});
			});
		}
		this.oRaycaster.oCamera.fSpeed = 6;
		this.trigger('enter');
		this.setDoomloop('stateTagProcessing');
	},

	stateTagProcessing: function() {
		var nSize = this.oRaycaster.nMapSize;
		var x = this._xTagProcessing;
		var y = this._yTagProcessing;
		var nStart = Date.now();
		var nStepMax = 10;
		var nStep = 0;
		var tf = this.TIME_FACTOR;
		while (y < nSize) {
			while (x < nSize) {
				this.triggerTag(x, y, this.getBlockTag(x, y), true);
				++x;
				nStep = (nStep + 1) % nStepMax;
				if (nStep === 0 && (Date.now() - nStart) >= tf) {
					this._xTagProcessing = x;
					this._yTagProcessing = y;
					this.onLoading('tag', y * nSize + x, nSize * nSize);
					return;
				}
			}
			++y;
			x = 0;
		}
		this.setDoomloop('stateRunning', CONFIG.game.doomloop);
		this.trigger('level');
	},


	/**
	 * Evènement appelé par le processeur
	 * Ici on lance les animation de textures
	 */
	onDoomLoop: function() {
		this._processKeys();
		this.oRaycaster.textureAnimation();
		this.trigger('doomloop');
	},
	
	
	/** 
	 * Evènement appelé à chaque changement de tag
	 * Si on entre dans une zone non taggée, la valeur du tag sera une chaine vide
	 * @param int x
	 * @param int y position du tag
	 * @param string sTag valeur du tag 
	 */
	onTagTriggered: function(x, y, sTag) {
		if (sTag) {
			var rc = this.oRaycaster;
			var oMsg = new O876_Raycaster.GXMessage(rc);
			oMsg.setMessage(sTag);
			rc.oEffects.addEffect(oMsg);
		}
	},
	
	
	/**
	 * Evènement appelé à chaque rendu de frame
	 */
	onFrameRendered: function() {
		this._detectTag();
		this.trigger('frame');
	},
	
	onFrameCount: function(nFPS, nAVG, nTime) {
		this.trigger('framecount', {
			fps: nFPS, 
			avg: nAVG, 
			time: nTime
		});
	},




	////// PROTECTED FUNCTIONS ////// PROTECTED FUNCTIONS ////// PROTECTED FUNCTIONS //////
	////// PROTECTED FUNCTIONS ////// PROTECTED FUNCTIONS ////// PROTECTED FUNCTIONS //////
	////// PROTECTED FUNCTIONS ////// PROTECTED FUNCTIONS ////// PROTECTED FUNCTIONS //////

	/**
	 * Reads key from keyborad device
	 * and trigger events
	 */
	_processKeys: function() {
		var nKey = this.getKeyboardDevice().inputKey();
		if (nKey > 0) {
			this.trigger('key.down', {k: nKey});
		} else if (nKey < 0) {
			this.trigger('key.up', {k: -nKey});
		}
	},

	/**
	 * Effectue une vérification du block actuellement traversé
	 * Si on entre dans une zone taggée (ensemble des blocks contigüs portant le même tag), on déclenche l'évènement.
	 */
	_detectTag: function() {
		var rc = this.oRaycaster;
		var rcc = rc.oCamera;
		var x = rcc.xSector;
		var y = rcc.ySector;
		var sTag = this.getBlockTag(x, y);
		if (sTag && sTag != this._sTag) {
			this.triggerTag(x, y, sTag);
			this._sTag = sTag;
		}
	},
	

	////// RAYCASTER PUBLIC API ////// RAYCASTER PUBLIC API ////// RAYCASTER PUBLIC API //////
	////// RAYCASTER PUBLIC API ////// RAYCASTER PUBLIC API ////// RAYCASTER PUBLIC API //////
	////// RAYCASTER PUBLIC API ////// RAYCASTER PUBLIC API ////// RAYCASTER PUBLIC API //////
	
	/**
	 * Return the name of the level currently loaded
	 * @return string
	 */
	getLevel: function() {
		return this._sLevelIndex;
	},
	
	/**
	 * Loads a new Level
	 * @param sLevel new level reference
	 */
	setLevel: function(sLevel) {
		this._sLevelIndex = sLevel;
		this.enterLevel();
	},

	
	/**
	 * Affiche un message popup
	 * @param string sMessage contenu du message
	 */
	popupMessage: function(sMessage) {
		var rc = this.oRaycaster;
		var oMsg = new O876_Raycaster.GXMessage(rc);
		oMsg.setMessage(sMessage);
		rc.oEffects.addEffect(oMsg);
	},
	
	/**
	 * permet de définir l'apparence des popups
	 * l'objet spécifié peut contenir les propriété suivantes :
	 * - background : couleur de fond
	 * - border : couleur de bordure
	 * - text : couleur du texte
	 * - shadow : couleur de l'ombre du texte
	 * - width : taille x
	 * - height : taille y
	 * - speed : vitesse de frappe
	 * - font : propriété de police
	 * - position : position y du popup
	 */
	setPopupStyle: function(oProp) {
		var sProp = '';
		var gmxp = O876_Raycaster.GXMessage.prototype.oStyle;
		for (sProp in oProp) {
			gmxp[sProp] = oProp[sProp];
		}
	},


	/**
	 * Effectue un screenshot de l'écran actuellement rendu
	 * L'image (canvas) générée est stockée dans la propriété _oScreenShot
	 */
	screenShot: function() {
		var oCanvas = O876.CanvasFactory.getCanvas();
		var wr = this.oRaycaster.xScrSize;
		var hr = this.oRaycaster.yScrSize << 1;
		var w = 192;
		var h = hr * w / wr | 0;
		oCanvas.width = w;
		oCanvas.height = h;
		var oContext = oCanvas.getContext('2d');
		oContext.drawImage(this.oRaycaster.oCanvas, 0, 0, wr, hr, 0, 0, w, h);
		return this._oScreenShot = oCanvas;
	},

	/**
	 * TriggerTag
	 * Active volontaire le tag s'il existe à la position spécifiée
	 */
	triggerTag: function(x, y, sTag, bInit) {
		if (sTag) {
			var aTags = sTag.split(';');
			var sNewTag = aTags.filter(function(s) {
				var aTag = s.replace(/^ +/, '').replace(/ +$/, '').split(' ');
				var sCmd = aTag.shift();
				var oData = {x: x, y: y, data: aTag.join(' '), remove: false};
				var aEvent = [(bInit ? 'i' : '') + 'tag', sCmd];
				this.trigger(aEvent.join('.'), oData);
				return !oData.remove;
			}, this).join(';');
			this.setBlockTag(x, y, sNewTag);
		}
	},


	/**
	 * Répond à l'évènement : le player à activé un block mural (celui en face de lui) 
	 * Si le block mural activé est porteur d'un tag : déclencher l'evènement onTagTriggered
	 * Si le block est une porte : ouvrir la porte 
	 */
	activateWall: function(m) {
		var oBlock = m.getFrontCellXY();
		var x = oBlock.x;
		var y = oBlock.y;
		this.triggerTag(x, y, this.getBlockTag(x, y));
		var oEffect = this.openDoor(x, y);
		if (oEffect) {
			this.trigger('door', {x: x, y: y, door: oEffect});
		}
	},

	/**
	 * Renvoie le tag associé au block
	 * @param int x
	 * @param int y position du block qu'on interroge
	 */
	getBlockTag: function(x, y) {
		var s = this.oRaycaster.nMapSize;
		if (x >= 0 && y >= 0 && x < s && y < s) {
			return Marker.getMarkXY(this._oTagData, x, y);
		} else {
			return null;
		}
	},

	/**
	 * Ajoute un tag de block
	 * si le tag est null on le vire
	 * @param int x
	 * @param int y position du block
	 * @param string sTag tag
	 */
	setBlockTag: function(x, y, sTag) {
		var s = this.oRaycaster.nMapSize;
		if (x >= 0 && y >= 0 && x < s && y < s) {
			Marker.markXY(this._oTagData, x, y, sTag);
		} else {
			return null;
		}		
	}
});

ClassMagic.castEventHandler(O876_Raycaster.GameAbstract);

/**
 * Ce thinker permet de bouger un mobile en définissant un vecteur de vitesse.
 * Il ne dispose d'aucune intelligence artificielle Ce thinker a été conçu pour
 * être utilisé comme Thinker de base dans un environnement réseau. Le thinker
 * propose les fonction suivantes : - setSpeed(x, y) : définiiton de la vitesse
 * du mobile selon les axes X et Y - die() : le mobile passe à l'état DEAD (en
 * jouant l'animation correspondante - disable() : le mobile disparait -
 * restore() : le mobile réapparait dans la surface de jeux
 */
O2.extendClass('O876_Raycaster.CommandThinker', O876_Raycaster.Thinker, {

	fma : 0, // Moving Angle
	fms : 0, // Moving Speed

	nDeadTime : 0,

	ANIMATION_STAND : 0,
	ANIMATION_WALK : 1,
	ANIMATION_ACTION : 2,
	ANIMATION_DEATH : 3,

	setMovement : function(a, s) {
		if (this.fma != a || this.fms != s) {
			this.fma = a;
			this.fms = s;
			var oSprite = this.oMobile.oSprite;
			var nAnim = oSprite.nAnimationType;
			var bStopped = s === 0;
			switch (nAnim) {
				case this.ANIMATION_ACTION:
				case this.ANIMATION_STAND:
					if (!bStopped) {
						oSprite.playAnimationType(this.ANIMATION_WALK);
					}
				break;
				
				case this.ANIMATION_WALK:
					if (bStopped) {
						oSprite.playAnimationType(this.ANIMATION_STAND);
					}
				break;
			}
		}
	},

	die : function() {
		this.setMovement(this.fma, 0);
		this.oMobile.oSprite.playAnimationType(this.ANIMATION_DEATH);
		this.oMobile.bEthereal = true;
		this.nDeadTime = this.oMobile.oSprite.oAnimation.nDuration * this.oMobile.oSprite.oAnimation.nCount;
		this.think = this.thinkDying;
	},

	disable : function() {
		this.thinkDisable();
	},

	restore : function() {
		this.oMobile.bEthereal = false;
		this.think = this.thinkAlive;
	},

	think : function() {
		this.restore();
	},

	thinkAlive : function() {
		var m = this.oMobile;
		m.move(this.fma,this.fms);
		if (this.oGame.oRaycaster.clip(m.x, m.y, 1)) {
			m.rollbackXY();
		}
	},

	thinkDisable : function() {
		this.oMobile.bEthereal = true;
		this.nDeadTime = 0;
		this.think = this.thinkDying;
	},

	thinkDying : function() {
		this.nDeadTime -= this.oGame.TIME_FACTOR;
		if (this.nDeadTime <= 0) {
			this.oMobile.gotoLimbo();
			this.think = this.thinkDead;
		}
	},

	thinkDead : function() {
		this.oMobile.bActive = false;
	}
});

/** Interface de controle des mobile par clavier
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet 
 * Se sert d'un device keyboard pour bouger le mobile
 */
O2.extendClass('O876_Raycaster.KeyboardThinker', O876_Raycaster.Thinker, {
	aCommands : null,
	oBinds: null,
	aKeyBindings: null, // binds keycodes to symbolic events
	aKeyBoundList: null, // keeps a list of bound key
	
	
	bindKey: function(nKey, sEvent) {
		if (this.aKeyBindings === null) {
			this.aKeyBindings = [];
		}
		if (this.aKeyBoundList === null) {
			this.aKeyBoundList = [];
		}
		if (this.aCommands === null) {
			this.aCommands = [];
		}
		this.aKeyBindings[nKey] = [sEvent, 0];
		this.aCommands[sEvent] = false;
		if (this.aKeyBoundList.indexOf(nKey) < 0) {
			this.aKeyBoundList.push(nKey);
		}
	},

	/**
	 * Define keys that will be used to control the mobile on which is applied this Thinker
	 * @param a is an object matching KEY CODES and Event names
	 */
	defineKeys : function(a) {
		var sEvent, i, l;
		for (var sEvent in a) {
			if (Array.isArray(a[sEvent])) {
				l = a[sEvent].length;
				for (i = 0; i < l; ++i) {
					this.bindKey(a[sEvent][i], sEvent);
				}
			} else {
				this.bindKey(a[sEvent], sEvent);
			}
		}
	},
	
	getCommandStatus : function(sEvent) {
		return this.aCommands[sEvent];
	},

	updateKeys : function() {
		var sKey = '', nKey, sProc, pProc, aButton;
		var aKeys = this.aKeys;
		var aCmds = this.aCommands;
		var oKbd = this.oGame.getKeyboardDevice();
		var aKeyData;
		var sEvent;
		var kbl = this.aKeyBoundList;
		var kb = this.aKeyBindings;
		for (var iKey = 0, l = kbl.length; iKey < l; ++iKey) {
			nKey = kbl[iKey];
			aKeyData = kb[nKey];
			sEvent = aKeyData[0];
			sProc = '';
			switch (oKbd.aKeys[nKey]) {
				case 1: // down
					if (aKeyData[1] === 0) {
						sProc = sEvent + '.down';
						aCmds[sEvent] = true;
						aKeyData[1] = 1;
					}
					break;
		
				case 2: // Up
					if (aKeyData[1] == 1) {
						sProc = sEvent + '.up';
						aCmds[sEvent] = false;
						aKeyData[1] = 0;
					}
					break;
				default:
					sProc = '';
					break;
			}
			if (sProc) {
				this.trigger(sProc);
			}
		}
		for (sEvent in this.aCommands) {
			if (this.aCommands[sEvent]) {
				sProc = sEvent + '.command';
				if (sProc) {
					this.trigger(sProc);
				}
			}
		}
	}
});

ClassMagic.castEventHandler(O876_Raycaster.KeyboardThinker);

/** Interface de controle des mobile 
 * O876 Raycaster project
 * @date 2013-03-04
 * @author Raphaël Marandet 
 * Fait bouger le mobile de manière lineaire, à l'aide d'indication de vitesse
 * Utile lorsqu'on a une indication de vitesse, mais pas de point de destination précis
 */
O2.extendClass('O876_Raycaster.LinearThinker', O876_Raycaster.Thinker, {
	nTime : 0,
	nCurrentTime: 0,
	
	xStart: 0,
	yStart: 0,
	aStart: 0,

	xDelta : 0,
	yDelta : 0,
	
	__construct : function() {
		this.nTime = 0;
	},

	think : function() {
		this.think = this.thinkInit;
	},
	
	setMove: function(x, y, a, dx, dy, t) {
		if (x !== null && x !== undefined) {
			this.xStart = x;
		} else {
			this.xStart = this.oMobile.x;
		}
		if (y !== null && y !== undefined) {
			this.yStart = y;
		} else {
			this.yStart = this.oMobile.y;
		}
		if (a !== null && a !== undefined) {
			this.aStart = a;
		} else {
			this.aStart = this.oMobile.fTheta;
		}
		if (dx !== null && dx !== undefined) {
			this.xDelta = dx;
		}
		if (dy !== null && dy !== undefined) {
			this.yDelta = dy;
		}
		if (t !== null && t !== undefined) {
			this.nTime = t;
		}
	},

	// Déplacement à la position de départ
	thinkInit : function() {
		this.oMobile.setXY(this.xStart, this.yStart);
		this.oMobile.setAngle(this.aStart);
		this.nCurrentTime = 0;
		this.think = this.thinkDeltaMove;
	},

	thinkDeltaMove : function() {
		this.oMobile.slide(this.xDelta, this.yDelta);
		this.nCurrentTime++;
		if (this.nCurrentTime > this.nTime) {
			this.think = this.thinkStop;
		}
	},
	
	thinkStop: function() {
	},
	
	thinkIdle: function() {
	}
});

/** Classe de déplacement automatisé et stupidité artificielle des mobiles
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet 
 * 
 * Classe spécialisée dans le déplacement des missile
 * Un missile possède deux animation 0: die 1: go
 * Ce thinker gère le dispenser.
 * Réécrire les methode advance et thinkHit pour personnaliser les effets
 */
O2.extendClass('O876_Raycaster.MissileThinker', O876_Raycaster.Thinker, {
  oOwner: null,				// Mobile a qui appartient ce projectile
  nExplosionTime: 0,		// Compteur d'explosion
  nExplosionMaxTime: 4,		// Max du compteur d'explosion (recalculé en fonction de la durée de l'anim)
  bExiting: true,			// Temoin de sortie du canon pour eviter les fausse collision avec le tireur
  oLastHitMobile: null,		// Dernier mobile touché
  nStepSpeed: 4,			// Nombre de déplacement par frame
  
  ANIMATION_EXPLOSION: 0,
  ANIMATION_MOVING: 1,
  
  nLifeOut: 0,
  
  __construct: function() {
    this.think = this.thinkIdle;
  },

  /** Renvoie true si le missile collisionne un objet ou un mur
   */
  isCollisioned: function() {
    var bWallCollision = this.oMobile.bWallCollision;  // collision murale
    var bMobileCollision = this.oMobile.oMobileCollision !== null;                        // collision avec un mobile
    var nTargetType = bMobileCollision ? this.oMobile.oMobileCollision.getType() : 0;
    var bOwnerCollision = this.oMobile.oMobileCollision == this.oOwner;                   // collision avec le tireur
    var bSolidCollision = bMobileCollision &&                                             // collision avec un mobile solide (non missile, et non item)
      nTargetType != RC.OBJECT_TYPE_MISSILE &&
      nTargetType != RC.OBJECT_TYPE_ITEM;

    if (bWallCollision) {
      this.oMobile.oMobileCollision = null;
      return true;
    }

    if (bOwnerCollision && !this.bExiting) {
      return true;
    }

    if (this.bExiting) {
      this.bExiting = bOwnerCollision;
      return false;
    }

    if (bSolidCollision) {
      return true;
    }
    return false;
  },
  
  advance: function() {
    this.oMobile.moveForward();
  },
  
  explode: function() {
    this.oLastHitMobile = this.oMobile.oMobileCollision;
    this.oMobile.rollbackXY();
    this.oMobile.oSprite.playAnimationType(this.ANIMATION_EXPLOSION);
    this.nExplosionTime = 0;
    this.nExplosionMaxTime = this.oMobile.oSprite.oAnimation.nDuration * this.oMobile.oSprite.oAnimation.nCount;
    this.oMobile.bEthereal = true;
    this.think = this.thinkHit;
  },

  extinct: function() {
    this.oMobile.bEthereal = true;
    this.oMobile.gotoLimbo();
    this.oMobile.oSprite.playAnimationType(-1);
    this.think = this.thinkIdle;
  },

  fire: function(oMobile) {
    this.bExiting = true;
    this.oOwner = oMobile;
    this.oMobile.oSprite.playAnimationType(this.ANIMATION_MOVING);
    this.oMobile.bSlideWall = false;
    this.oMobile.bEthereal = false;
    this.think = this.thinkGo;
    this.advance();
  },

  thinkGo: function() {
	if (this.nLifeOut < this.oGame.nTime) {
      this.extinct();
      return;
	}
    for (var i = 0; i < this.nStepSpeed; i++) {
      this.advance();
      if (this.isCollisioned()) {
        this.explode();
        break;
      }
    }
  },

  thinkHit: function() {
    this.nExplosionTime += this.oGame.TIME_FACTOR;
    if (this.nExplosionTime >= this.nExplosionMaxTime) {		
      this.oMobile.gotoLimbo();
      this.think = this.thinkIdle;
    }
  },

  thinkIdle: function() {
    this.oMobile.bActive = false;
  }
});

/** Interface de controle des mobile par clavier
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet 
 * Se sert d'un device keyboard pour bouger le mobile
 */
O2.extendClass('O876_Raycaster.MouseKeyboardThinker', O876_Raycaster.Thinker, {
	aCommands : null,
	oBinds: null,
	aKeyBindings: null, // binds keycodes to symbolic events
	aKeyBoundList: null, // keeps a list of bound key
	
	
	bindKey: function(nKey, sEvent) {
		if (this.aKeyBindings === null) {
			this.aKeyBindings = [];
		}
		if (this.aKeyBoundList === null) {
			this.aKeyBoundList = [];
		}
		if (this.aCommands === null) {
			this.aCommands = [];
		}
		this.aKeyBindings[nKey] = [sEvent, 0];
		this.aCommands[sEvent] = false;
		if (this.aKeyBoundList.indexOf(nKey) < 0) {
			this.aKeyBoundList.push(nKey);
		}
	},

	/**
	 * Define keys that will be used to control the mobile on which is applied this Thinker
	 * @param a is an object matching KEY CODES and Event names
	 */
	defineKeys : function(a) {
		var sEvent, i, l;
		for (var sEvent in a) {
			if (Array.isArray(a[sEvent])) {
				l = a[sEvent].length;
				for (i = 0; i < l; ++i) {
					this.bindKey(a[sEvent][i], sEvent);
				}
			} else {
				this.bindKey(a[sEvent], sEvent);
			}
		}
	},
	
	getCommandStatus : function(sEvent) {
		return this.aCommands[sEvent];
	},

	updateKeys : function() {
		var sKey = '', nKey, sProc, pProc, aButton;
		var aKeys = this.aKeys;
		var aCmds = this.aCommands;
		var oKbd = this.oGame.getKeyboardDevice();
		var aKeyData;
		var sEvent;
		var kbl = this.aKeyBoundList;
		var kb = this.aKeyBindings;
		for (var iKey = 0, l = kbl.length; iKey < l; ++iKey) {
			nKey = kbl[iKey];
			aKeyData = kb[nKey];
			sEvent = aKeyData[0];
			sProc = '';
			switch (oKbd.aKeys[nKey]) {
				case 1: // down
					if (aKeyData[1] === 0) {
						sProc = sEvent + '.down';
						aCmds[sEvent] = true;
						aKeyData[1] = 1;
					}
					break;
		
				case 2: // Up
					if (aKeyData[1] == 1) {
						sProc = sEvent + '.up';
						aCmds[sEvent] = false;
						aKeyData[1] = 0;
					}
					break;
				default:
					sProc = '';
					break;
			}
			if (sProc) {
				this.trigger(sProc);
			}
		}
		var oMouse = this.oGame.getMouseDevice();
		while (aButton = oMouse.inputMouse()) {
			nKey = aButton[3];
			sEvent = 'button' + nKey;
			sProc = '';
			switch (aButton[0]) {
				case 1: // button down
					sProc = sEvent + '.down';
					this.aCommands[sEvent] = true;
					break;
					
				case 0: // button up
					sProc = sEvent + '.up';
					this.aCommands[sEvent] = false;
					break;

				case 3:
					sProc = 'wheel.up';
					break;
					
				case -3:
					sProc = 'wheel.down';
					break;
					
				default:
					sProc = '';
					break;
			}
			if (sProc) {
				this.trigger(sProc);
			}
		}
		for (sEvent in this.aCommands) {
			if (this.aCommands[sEvent]) {
				sProc = sEvent + '.command';
				if (sProc) {
					this.trigger(sProc);
				}
			}
		}
	}
});

ClassMagic.castEventHandler(O876_Raycaster.MouseKeyboardThinker);

/** Interface de controle des mobile 
 * O876 Raycaster project
 * @date 2013-03-04
 * @author Raphaël Marandet 
 * Fait bouger le mobile de manière non-lineaire
 * Avec des coordonnée de dépat, d'arriver, et un temps donné
 * L'option lineaire est tout de même proposée.
 */
O2.extendClass('O876_Raycaster.NonLinearThinker', O876_Raycaster.Thinker, {
	nTime : 0,
	nCurrentTime: 0,
	
	xStart: 0,
	yStart: 0,
	aStart: 0,
	
	xEnd: 0,
	yEnd: 0,
	
	fWeight: 1,
	
	sFunction: 'smoothstepX2',
	
	__construct : function() {
		this.nTime = 0;
	},
	
	processTime: function() {
		this.nCurrentTime++;
		if (this.nCurrentTime > this.nTime) {
			this.think = this.thinkStop;
		}
	},
	
	setMove: function(x, y, a, dx, dy, t) {
		if (x !== null && x !== undefined) {
			this.xStart = x;
		} else {
			this.xStart = this.oMobile.x;
		}
		if (y !== null && y !== undefined) {
			this.yStart = y;
		} else {
			this.yStart = this.oMobile.y;
		}
		if (a !== null && a !== undefined) {
			this.aStart = a;
		} else {
			this.aStart = this.oMobile.fTheta;
		}
		if (dx !== null && dx !== undefined) {
			this.xEnd = dx;
		}
		if (dy !== null && dy !== undefined) {
			this.yEnd = dy;
		}
		if (t !== null && t !== undefined) {
			this.nTime = t;
		}
	},

	think : function() {
		this.think = this.thinkInit;
	},

	// Déplacement à la position de départ
	thinkInit : function() {
		this.oMobile.setXY(this.xStart, this.yStart);
		this.oMobile.setAngle(this.aStart);
		this.nCurrentTime = 0;
		this.think = this.thinkMove;
	},
	
	thinkMove: function() {
		var x, y;
		
		var v = this[this.sFunction](this.nCurrentTime / this.nTime);
		
		x = this.xEnd * v + (this.xStart * (1 - v));
		y = this.yEnd * v + (this.yStart * (1 - v));
		
		this.oMobile.setXY(x, y);
		this.processTime();
	},
	
	linear: function(v) {
		return v;
	},
	
	smoothstep: function(v) {
		return v * v * (3 - 2 * v);
	},
	
	smoothstepX2: function(v) {
		v = v * v * (3 - 2 * v);
		return v * v * (3 - 2 * v);
	},
	
	smoothstepX3: function(v) {
		v = v * v * (3 - 2 * v);
		v = v * v * (3 - 2 * v);
		return v * v * (3 - 2 * v);
	},
	
	squareAccel: function(v) {
		return v * v;
	},
	
	squareDeccel: function(v) {
		return 1 - (1 - v) * (1 - v);
	},
	
	cubeAccel: function(v) {
		return v * v * v;
	},
	
	cubeDeccel: function(v) {
		return 1 - (1 - v) * (1 - v) * (1 - v);
	},
	
	sine: function(v) {
		return Math.sin(v * 3.14159265 / 2);
	},
	
	cosine: function(v) {
		return 0.5 - Math.cos(-v * 3.14159265) * 0.5;
	},
	
	weightAverage: function(v) {
		return ((v * (this.nTime - 1)) + this.fWeight) / this.nTime;
	},
	
	thinkStop: function() {
	},
	
	thinkIdle: function() {
	}
});

O2.extendClass('Stub.Game', O876_Raycaster.Engine, {
	sGeneratorUrl : '../../dynamics/laby/laby.php',
	///////////// EVENEMENTS /////////////

	/** 
	 * Evènement apellé lors de l'initialisation du jeu
	 * Appelé une seule fois.
	 */
	onInitialize: function() {
	},
	
	/**
	 * Cette évènement doit renvoyer TRUE pour pouvoir passer à l'étape suivante
	 * @return bool
	 */
	onMenuLoop: function() {
		return true; // Doit retourner TRUE pour indiquer la validation du menu et passer à l'étape suivante
		// ici il n'y a pas de menu donc "true" pour passer directement à l'étape suivante
	},
	
	
	/**
	 * Evènement appelé lors du chargement d'un niveau,
	 * cet évènement doit renvoyer des données au format du Raycaster.
	 * @return object
	 */
	onRequestLevelData: function() {
		return WORLD_DATA.demo;
	},
	
	
	// onLoading: null,
	
	/**
	 * Evènement appelé lorsqu'un niveau a été chargé
	 * Permet l'initialisation des objet nouvellement créés (comme la caméra)
	 */
	onEnterLevel: function() {
		this.oRaycaster.nPlaneSpacing = 64;
		var oCT = new O876_Raycaster.FirstPersonThinker();
		oCT.oMouse = this.getMouseDevice(this.oRaycaster.oCanvas);
		oCT.oKeyboard = this.getKeyboardDevice();
		oCT.oGame = this;
		this.oRaycaster.oCamera.setThinker(oCT);
		oCT.on('use.down', (function() {
			this.oGame.activateWall(this.oMobile);    
		}).bind(oCT));

		this.oRaycaster.oCamera.fSpeed = 6;
		this.oRaycaster.bSky = true;
		this.oRaycaster.bFlatSky = true;
	},

	/**
	 * Evènement appelé par le processeur
	 * Ici on lance les animation de textures
	 */
	onDoomLoop: function() {
		this.processKeys();
		this.oRaycaster.textureAnimation();
	},
	
	processKeys: function() {
		switch (this.getKeyboardDevice().inputKey()) {
			case KEYS.ALPHANUM.I:
				this.oRaycaster.fViewHeight += 0.1;
				break;
				
			case KEYS.ALPHANUM.O: 
				this.oRaycaster.fViewHeight -= 0.1;
				break;
		}
	},
	
	
	/**
	 * Evènement appelé à chaque rendu de frame
	 */
	onFrameRendered: function() {
	},
	
	/** 
	 * Appelé par le thinker de caméra
	 */
	activateWall: function(m) {
		var oBlock = m.getFrontCellXY(); 
		this.openDoor(oBlock.x, oBlock.y);
	}
});

O2.extendClass('O876_Raycaster.CameraKeyboardThinker', O876_Raycaster.KeyboardThinker,
{
	nRotationTime : 0,
	nRotationMask : 0,
	nRotationLeftTime : 0,
	nRotationRightTime : 0,
	
	fRotationSpeed: 0.1,

	ROTATION_MASK_LEFT : 0,
	ROTATION_MASK_RIGHT : 1,
	ROTATION_MASK_FORWARD : 2,
	ROTATION_MASK_BACKWARD : 3,

	__construct : function() {
		this.defineKeys( {
			forward : KEYS.UP,
			backward : KEYS.DOWN,
			left : KEYS.LEFT,
			right : KEYS.RIGHT,
			use : KEYS.SPACE,
			strafe : KEYS.ALPHANUM.C
		});
		this.on('forward.command', this.forwardCommand.bind(this));
		this.on('left.command', this.leftCommand.bind(this));
		this.on('right.command', this.rightCommand.bind(this));
		this.on('strafe.down', this.strafeDown.bind(this));
		this.on('strafe.up', this.strafeUp.bind(this));
		this.on('backward.command', this.backwardCommand.bind(this));
		this.on('forward.down', this.forwardDown.bind(this));
		this.on('backward.down', this.backwardDown.bind(this));
		this.on('left.down', this.leftDown.bind(this));
		this.on('right.down', this.rightDown.bind(this));
		this.on('forward.up', this.forwardUp.bind(this));
		this.on('backward.up', this.backwardUp.bind(this));
		this.on('left.up', this.leftUp.bind(this));
		this.on('right.up', this.rightUp.bind(this));
	},

	setRotationMask : function(nBit, bValue) {
		var nMask = 1 << nBit;
		var nNotMask = 255 ^ nMask;
		if (bValue) {
			this.nRotationMask |= nMask;
		} else {
			this.nRotationMask &= nNotMask;
			if (this.nRotationMask === 0) {
				this.nRotationTime = 0;
			}
		}
	},

	think: function() {
		this.updateKeys();
	},

	checkCollision: function() {
		if (this.oMobile.oMobileCollision !== null) {
			var oTarget = this.oMobile.oMobileCollision;
			if (oTarget.oSprite.oBlueprint.nType != RC.OBJECT_TYPE_MISSILE) {
				this.oMobile.rollbackXY();
			}
		}
	},

	forwardCommand: function() {
		this.processRotationSpeed();
		this.oMobile.moveForward();
		this.checkCollision();
		this.setRotationMask(this.ROTATION_MASK_FORWARD, true);
	},

	leftCommand: function() {
		this.processRotationSpeed();
		this.setRotationMask(this.ROTATION_MASK_LEFT, true);
		if (this.bStrafe) {
			this.oMobile.strafeLeft();
			this.checkCollision();
		} else {
			this.oMobile.rotateLeft();
		}
	},

	rightCommand: function() {
		this.processRotationSpeed();
		this.setRotationMask(this.ROTATION_MASK_RIGHT, true);
		if (this.bStrafe) {
			this.oMobile.strafeRight();
			this.checkCollision();
		} else {
			this.oMobile.rotateRight();
		}
	},

	strafeDown: function() {
		this.bStrafe = true;
	},

	strafeUp: function() {
		this.bStrafe = false;
	},

	backwardCommand: function() {
		this.setRotationMask(this.ROTATION_MASK_FORWARD, true);
		this.oMobile.moveBackward();
		this.checkCollision();
	},

	forwardDown: function() {
		this.setRotationMask(this.ROTATION_MASK_FORWARD, true);
	},
	
	backwardDown: function() {
		this.setRotationMask(this.ROTATION_MASK_FORWARD, true);
	},
	
	leftDown: function() {
		this.setRotationMask(this.ROTATION_MASK_LEFT, true);
	},
	
	rightDown: function() {
		this.setRotationMask(this.ROTATION_MASK_RIGHT, true);
	},

	forwardUp : function() {
		this.setRotationMask(this.ROTATION_MASK_FORWARD, false);
	},

	backwardUp : function() {
		this.setRotationMask(this.ROTATION_MASK_FORWARD, false);
	},

	leftUp : function() {
		this.setRotationMask(this.ROTATION_MASK_LEFT, false);
	},

	rightUp : function() {
		this.setRotationMask(this.ROTATION_MASK_RIGHT, false);
	},

	processRotationSpeed : function() {
		if (this.nRotationMask !== 0) {
			this.nRotationTime++;
			switch (this.nRotationTime) {
			case 1:
				this.oMobile.fRotSpeed = this.fRotationSpeed / 4;
				break;

			case 4:
				this.oMobile.fRotSpeed = this.fRotationSpeed / 2;
				break;

			case 8:
				this.oMobile.fRotSpeed = this.fRotationSpeed;
				break;
			}
		}
	}
});

O2.extendClass('O876_Raycaster.FirstPersonThinker', O876_Raycaster.MouseKeyboardThinker,
{
	nMouseSensitivity: 166,

	__construct : function() {
		this.defineKeys( {
			forward : [KEYS.ALPHANUM.Z, KEYS.ALPHANUM.W],
			backward : KEYS.ALPHANUM.S,
			left : [KEYS.ALPHANUM.Q, KEYS.ALPHANUM.A],
			right : KEYS.ALPHANUM.D,
			use : KEYS.SPACE
		});
		this.on('forward.command', (function() {
			this.oMobile.moveForward();
			this.checkCollision();
		}).bind(this));
		this.on('left.command', (function() {
			this.oMobile.strafeLeft();
			this.checkCollision();
		}).bind(this));
		this.on('right.command', (function() {
			this.oMobile.strafeRight();
			this.checkCollision();
		}).bind(this));
		this.on('backward.command', (function() {
			this.oMobile.moveBackward();
			this.checkCollision();
		}).bind(this));
	},

	readMouseMovement: function(x, y) {
		this.oMobile.rotate(x / this.nMouseSensitivity);
	},

	think: function() {
		this.updateKeys();
	},

	checkCollision: function() {
		if (this.oMobile.oMobileCollision !== null) {
			var oTarget = this.oMobile.oMobileCollision;
			if (oTarget.oSprite.oBlueprint.nType != RC.OBJECT_TYPE_MISSILE) {
				this.oMobile.rollbackXY();
			}
		}
	}
});

/** Interface de controle des mobile par clavier
 * O876 Raycaster project
 * @date 2012-01-01
 * @author Raphaël Marandet 
 * Se sert d'un device keyboard pour bouger le mobile.
 * Permet de tester rapidement la mobilité d'un mobile
 */
O2.extendClass('O876_Raycaster.KbdArrowThinker', O876_Raycaster.KeyboardThinker, {
	
	__construct: function() {
		this.defineKeys( {
			forward : KEYS.UP,
			backward : KEYS.DOWN,
			left : KEYS.LEFT,
			right : KEYS.RIGHT
		});
	},
	
	think: function() {
		this.oMobile.fSpeed = 4;
		this.oMobile.fRotSpeed = 0.1;
		this.updateKeys();
	},

	checkCollision: function() {
		if (this.oMobile.oMobileCollision !== null) {
			var oTarget = this.oMobile.oMobileCollision;
			if (oTarget.oSprite.oBlueprint.nType != RC.OBJECT_TYPE_MISSILE) {
			  this.oMobile.rollbackXY();
			}
		}
	},

	forwardDown: function() {
		this.oMobile.oSprite.playAnimationType(1);
	},

	forwardUp: function() {
		this.oMobile.oSprite.playAnimationType(0);
	},
	
	forwardCommand: function() {
		this.oMobile.moveForward();
		this.checkCollision();
	},

	leftCommand: function() {
		this.oMobile.rotateLeft();
	},

	rightCommand: function() {
		this.oMobile.rotateRight();
	},

	backwardCommand: function() {
		this.oMobile.moveBackward();
		this.checkCollision();
	},
	
});

