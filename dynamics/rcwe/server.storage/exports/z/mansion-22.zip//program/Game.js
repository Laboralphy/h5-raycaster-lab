/* globals O2, O876_Raycaster */
O2.extendClass('MANSION-22.Game', O876_Raycaster.GameAbstract, {
});
